"use client";

import {
	BarChart3,
	BadgeAlert,
	BookMarked,
	CalendarDays,
	ClipboardList,
	Clock3,
	Database,
	FileText,
	FolderOpen,
	Gavel,
	House,
	KeyRound,
	ListChecks,
	LogOut,
	Menu,
	ScrollText,
	Settings,
	ShieldCheck,
	Timer,
	Users,
	type LucideIcon,
} from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import {
	PANEL_MODE_CONFIG,
	getDefaultMenuItemId,
} from "@/app/_components/home-tabs/config";
import { renderTabContent } from "@/app/_components/home-tabs/content-registry";
import type {
	AuthRole,
	AuthUser,
	MenuSection,
	PanelMode,
} from "@/app/_components/home-tabs/types";
import {
	clearStoredAuthSession,
	getStoredAuthSession,
	getStoredAuthToken,
	setStoredAuthSession,
} from "@/features/auth/session";
import type { LoginUser } from "@/features/auth/types";
import { normalizeAuthRole } from "@/features/auth/types";
import { useInactivityTimeout } from "@/shared/hooks/useInactivityTimeout";

const GLOBAL_INACTIVITY_TIMEOUT_MS = 20 * 60_000;
const GLOBAL_INACTIVITY_WARNING_MS = 60_000;
const DASHBOARD_OPEN_INSPECTION_EVENT = "dashboard:open-inspection";
const DASHBOARD_OPEN_RECOMMENDATION_EVENT = "dashboard:open-recommendation";
const DASHBOARD_OPEN_SANCTION_REQUEST_EVENT = "dashboard:open-sanction-request";
const DASHBOARD_OPEN_BINDING_DECISION_EVENT = "dashboard:open-binding-decision";
const MANAGEMENT_DICTIONARIES_READ_PERMISSION =
	"management.dictionaries.read";
const MANAGEMENT_DICTIONARIES_WRITE_PERMISSION =
	"management.dictionaries.write";

type PasswordLoginResponse = {
	ok?: boolean;
	token?: string;
	expiresAt?: string;
	user?: LoginUser;
};

type MeTokenResponse = {
	ok?: boolean;
	user?: LoginUser;
};

type PasswordLoginErrorDetail = {
	code: string;
	message: string;
	attemptsRemaining: number | null;
	maxAttempts: number | null;
	lockoutMinutes: number | null;
	lockedUntil: string;
	retryAfterSeconds: number | null;
};

function toNonNegativeInteger(value: unknown) {
	if (typeof value === "number" && Number.isFinite(value)) {
		return value >= 0 ? Math.trunc(value) : null;
	}

	if (typeof value === "string") {
		const parsed = Number(value.trim());
		if (Number.isFinite(parsed) && parsed >= 0) {
			return Math.trunc(parsed);
		}
	}

	return null;
}

function formatRetryAfterLabel(retryAfterSeconds: number) {
	const totalSeconds = Math.max(0, Math.trunc(retryAfterSeconds));
	const minutes = Math.floor(totalSeconds / 60);
	const seconds = totalSeconds % 60;

	if (minutes > 0 && seconds > 0) {
		return `${minutes} min ${seconds} s`;
	}

	if (minutes > 0) {
		return `${minutes} min`;
	}

	return `${seconds} s`;
}

function formatLockedUntilLabel(lockedUntilRaw: string) {
	const parsed = new Date(lockedUntilRaw);
	if (Number.isNaN(parsed.getTime())) {
		return "";
	}

	return parsed.toLocaleString("pl-PL", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
	});
}

function formatLockedUntilHourMinuteLabel(lockedUntilRaw: string) {
	const parsed = new Date(lockedUntilRaw);
	if (Number.isNaN(parsed.getTime())) {
		return "";
	}

	return parsed.toLocaleTimeString("pl-PL", {
		hour: "2-digit",
		minute: "2-digit",
	});
}

function resolveLockedUntilForMessage(detail: PasswordLoginErrorDetail) {
	if (detail.lockedUntil) {
		return detail.lockedUntil;
	}

	const minutesToAdd =
		detail.lockoutMinutes !== null && detail.lockoutMinutes > 0
			? detail.lockoutMinutes
			: 15;
	const fallbackDate = new Date(Date.now() + minutesToAdd * 60 * 1000);
	return fallbackDate.toISOString();
}

function buildAccountLockedNotice(detail: PasswordLoginErrorDetail) {
	const effectiveLockoutMinutes =
		detail.lockoutMinutes !== null && detail.lockoutMinutes > 0
			? detail.lockoutMinutes
			: 15;
	const resolvedLockedUntil = resolveLockedUntilForMessage(detail);
	const lockedUntilHourMinute = formatLockedUntilHourMinuteLabel(resolvedLockedUntil);

	if (lockedUntilHourMinute) {
		return `Konto zostało zablokowane na ${effectiveLockoutMinutes} minut.\nBlokada zostanie zwolniona o godzinie: ${lockedUntilHourMinute}.`;
	}

	return `Konto zostało zablokowane na ${effectiveLockoutMinutes} minut.`;
}

function buildInvalidCredentialsMessage(detail: PasswordLoginErrorDetail) {
	const recoveryHint =
		"\nRozważ nadanie nowego hasła. Kliknij \"Nie pamiętam hasła\".";

	if (detail.attemptsRemaining !== null) {
		if (detail.attemptsRemaining === 0) {
			return buildAccountLockedNotice(detail);
		}

		const isLastAttemptBeforeLock = detail.attemptsRemaining === 1;
		const suffix = isLastAttemptBeforeLock ? recoveryHint : "";

		if (detail.maxAttempts !== null) {
			return `Nieprawidłowy login lub hasło. Pozostało prób: ${detail.attemptsRemaining}/${detail.maxAttempts}.${suffix}`;
		}

		return `Nieprawidłowy login lub hasło. Pozostało prób: ${detail.attemptsRemaining}.${suffix}`;
	}

	return detail.message || "Nieprawidłowy login lub hasło.";
}

function buildLoginLockedMessage(detail: PasswordLoginErrorDetail) {
	if (detail.retryAfterSeconds !== null) {
		return `Logowanie zostało tymczasowo zablokowane. Spróbuj ponownie za ${formatRetryAfterLabel(detail.retryAfterSeconds)}.`;
	}

	if (detail.lockedUntil) {
		const lockedUntilLabel = formatLockedUntilLabel(detail.lockedUntil);
		if (lockedUntilLabel) {
			return `Logowanie zostało tymczasowo zablokowane. Spróbuj ponownie po ${lockedUntilLabel}.`;
		}
	}

	if (detail.lockoutMinutes !== null) {
		return `Logowanie zostało tymczasowo zablokowane. Spróbuj ponownie za około ${detail.lockoutMinutes} min.`;
	}

	return detail.message || "Logowanie zostało tymczasowo zablokowane. Spróbuj ponownie później.";
}

async function readPasswordLoginErrorDetail(
	response: Response,
): Promise<PasswordLoginErrorDetail | null> {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return null;
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
		};
		const detailSource = payload.detail;
		const detailRecord =
			detailSource && typeof detailSource === "object" && !Array.isArray(detailSource)
				? (detailSource as Record<string, unknown>)
				: null;
		const fallbackMessage =
			typeof payload.message === "string" ? payload.message.trim() : "";

		return {
			code:
				typeof detailRecord?.code === "string"
					? detailRecord.code.trim()
					: "",
			message:
				typeof detailRecord?.message === "string"
					? detailRecord.message.trim()
					: fallbackMessage,
			attemptsRemaining: toNonNegativeInteger(detailRecord?.attemptsRemaining),
			maxAttempts: toNonNegativeInteger(detailRecord?.maxAttempts),
			lockoutMinutes: toNonNegativeInteger(detailRecord?.lockoutMinutes),
			lockedUntil:
				typeof detailRecord?.lockedUntil === "string"
					? detailRecord.lockedUntil.trim()
					: "",
			retryAfterSeconds: toNonNegativeInteger(detailRecord?.retryAfterSeconds),
		};
	} catch {
		return null;
	}
}

function mapLoginUserToAuthUser(user: LoginUser): AuthUser {
	const effectivePermissions = Array.isArray(user.effectivePermissions)
		? user.effectivePermissions
				.filter((permission): permission is string => typeof permission === "string")
				.map((permission) => permission.trim())
				.filter(Boolean)
		: [];
	const isObserver =
		typeof user.accountType === "string" &&
		user.accountType.trim().toLowerCase() === "observer";

	return {
		...user,
		effectivePermissions,
		role: isObserver ? "external_user" : normalizeAuthRole(user.rola),
	};
}

function hasPermission(permissions: Set<string>, permission: string) {
	return permissions.has(permission);
}

function getVisibleMenuSections(
	panelMode: PanelMode,
	role: AuthRole,
	canViewTimeReports: boolean,
	canViewOwnTimeReport: boolean,
	effectivePermissions: Set<string>,
): MenuSection[] {
	const baseSections = PANEL_MODE_CONFIG[panelMode].sections;
	if (panelMode === "registry") {
		const usePermissionBasedRegistryVisibility =
			effectivePermissions.size > 0;

		if (usePermissionBasedRegistryVisibility) {
			const visibleSections = baseSections
				.map((section) => ({
					...section,
					items: section.items.filter((item) => {
						if (item.id === "inspections") {
							return hasPermission(
								effectivePermissions,
								"registry.inspections.read",
							);
						}

						if (item.id === "recommendations") {
							return hasPermission(
								effectivePermissions,
								"registry.recommendations.read",
							);
						}

						if (item.id === "binding_decisions") {
							return hasPermission(
								effectivePermissions,
								"registry.obligating_decisions.read",
							);
						}

						if (item.id === "sanction_requests") {
							return hasPermission(
								effectivePermissions,
								"registry.risk_exposure.read",
							);
						}

						if (item.id === "reports") {
							return hasPermission(
								effectivePermissions,
								"reports.executed_inspections.read",
							);
						}

						if (item.id === "report_protocol_time") {
							return hasPermission(
								effectivePermissions,
								"reports.protocol_time.read",
							);
						}

						if (item.id === "report_statement_time") {
							return hasPermission(
								effectivePermissions,
								"reports.report_time.read",
							);
						}

						if (item.id === "start") {
							return true;
						}

						if (item.id === "report_own_time") {
							return false;
						}

						return true;
					}),
				}))
				.filter((section) => section.items.length > 0);

			if (
				role === "inspector" &&
				hasPermission(
					effectivePermissions,
					MANAGEMENT_DICTIONARIES_READ_PERMISSION,
				)
			) {
				visibleSections.push({
					id: "dictionaries",
					label: "Słowniki",
					icon: "tools",
					items: [{ id: "dictionaries", label: "Słowniki" }],
				});
			}

			return visibleSections;
		}

		const visibleSections = baseSections
			.map((section) => ({
				...section,
				items: section.items.filter((item) => {
					if (
						item.id === "report_protocol_time" ||
						item.id === "report_statement_time"
					) {
						return canViewTimeReports;
					}

					if (item.id === "report_own_time") {
						return role === "inspector" && canViewOwnTimeReport;
					}

					return true;
				}),
			}))
			.filter((section) => section.items.length > 0);

		return visibleSections;
	}

	if (panelMode !== "management") {
		return baseSections;
	}

	const usePermissionBasedManagementVisibility =
		effectivePermissions.size > 0;

	if (usePermissionBasedManagementVisibility) {
		return baseSections
			.map((section) => ({
				...section,
				items: section.items.filter((item) => {
					if (item.id === "email") {
						return role === "director";
					}

					if (item.id === "dictionaries") {
						return hasPermission(
							effectivePermissions,
							MANAGEMENT_DICTIONARIES_READ_PERMISSION,
						);
					}

					if (role === "inspector" || role === "external_user") {
						return false;
					}

					if (role === "team_lead") {
						return (
							item.id !== "teams" &&
							item.id !== "schedules" &&
							item.id !== "external_users"
						);
					}

					return true;
				}),
			}))
			.filter((section) => section.items.length > 0);
	}

	if (role !== "team_lead") {
		return baseSections
			.map((section) => ({
				...section,
				items: section.items.filter((item) => {
					if (item.id === "email") {
						return role === "director";
					}

					return true;
				}),
			}))
			.filter((section) => section.items.length > 0);
	}

	return baseSections
		.map((section) => ({
			...section,
			items: section.items.filter(
				(item) =>
					item.id !== "email" &&
					item.id !== "teams" &&
					item.id !== "schedules" &&
					item.id !== "external_users",
			),
		}))
		.filter((section) => section.items.length > 0);
}

function getSectionIcon(section: MenuSection) {
	if (section.id === "start") {
		return House;
	}

	if (section.id === "registers") {
		return Database;
	}

	if (section.id === "tools") {
		return BarChart3;
	}

	if (section.id === "dictionaries") {
		return BookMarked;
	}

	if (section.id === "management") {
		return Settings;
	}

	return FolderOpen;
}

function getMenuItemIcon(itemId: string): LucideIcon {
	if (itemId === "start") {
		return House;
	}

	if (itemId === "inspections") {
		return ClipboardList;
	}

	if (itemId === "recommendations") {
		return ListChecks;
	}

	if (itemId === "binding_decisions") {
		return Gavel;
	}

	if (itemId === "sanction_requests") {
		return BadgeAlert;
	}

	if (itemId === "reports") {
		return FileText;
	}

	if (itemId === "report_protocol_time") {
		return Timer;
	}

	if (itemId === "report_statement_time") {
		return Clock3;
	}

	if (itemId === "report_own_time") {
		return Clock3;
	}

	if (itemId === "dictionaries") {
		return BookMarked;
	}

	if (itemId === "teams" || itemId === "users") {
		return Users;
	}

	if (itemId === "schedules") {
		return CalendarDays;
	}

	if (itemId === "logs") {
		return ScrollText;
	}

	return FolderOpen;
}

export function HomeTabs() {
	const router = useRouter();
	const pathname = usePathname();
	const companyShortName = "UPZ";
	const [initialSession] = useState(() => getStoredAuthSession());

	const [isCheckingSession, setIsCheckingSession] = useState(
		() => initialSession !== null,
	);
	const [isSidebarOpen, setIsSidebarOpen] = useState(false);
	const [isDesktopSidebarExpanded, setIsDesktopSidebarExpanded] = useState(true);
	const [panelMode, setPanelMode] = useState<PanelMode>("registry");
	const [selectedItemId, setSelectedItemId] = useState<string>(
		getDefaultMenuItemId("registry"),
	);
	const [authUser, setAuthUser] = useState<AuthUser | null>(() =>
		initialSession ? mapLoginUserToAuthUser(initialSession.user) : null,
	);
	const [loginInput, setLoginInput] = useState("");
	const [passwordInput, setPasswordInput] = useState("");
	const [isLoginSubmitting, setIsLoginSubmitting] = useState(false);
	const [loginError, setLoginError] = useState<string | null>(null);

	useEffect(() => {
		const session = initialSession;
		if (!session) {
			setIsCheckingSession(false);
			return;
		}

		const bootstrapSession = async () => {
			try {
				const response = await fetch("/api/auth/me-token", {
					method: "GET",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${session.token}`,
					},
					cache: "no-store",
				});

				if (!response.ok) {
					clearStoredAuthSession();
					setAuthUser(null);
					return;
				}

				const payload = (await response.json()) as MeTokenResponse;
				if (!payload.user) {
					clearStoredAuthSession();
					setAuthUser(null);
					return;
				}

				setStoredAuthSession({
					token: session.token,
					expiresAt: session.expiresAt,
					user: payload.user,
				});
				setAuthUser(mapLoginUserToAuthUser(payload.user));
			} catch {
				clearStoredAuthSession();
				setAuthUser(null);
			} finally {
				setIsCheckingSession(false);
			}
		};

		void bootstrapSession();
	}, [initialSession]);

	useEffect(() => {
		if (isCheckingSession) {
			return;
		}

		if (!authUser && pathname !== "/login") {
			router.replace("/login");
			return;
		}

		if (authUser && pathname === "/login") {
			router.replace("/");
		}
	}, [authUser, isCheckingSession, pathname, router]);

	const authRole = authUser?.role ?? "inspector";
	const isObserver = authUser?.accountType === "observer";
	const canViewTimeReports = authUser?.canViewTimeReports ?? false;
	const canViewOwnTimeReport = authUser?.canViewOwnTimeReport ?? false;
	const effectivePermissions = useMemo(
		() => new Set(authUser?.effectivePermissions ?? []),
		[authUser?.effectivePermissions],
	);
	const isDirector = authRole === "director";
	const isTeamLead = authRole === "team_lead";
	const canReadDictionaries = hasPermission(
		effectivePermissions,
		MANAGEMENT_DICTIONARIES_READ_PERMISSION,
	);
	const canWriteDictionariesByPermission = hasPermission(
		effectivePermissions,
		MANAGEMENT_DICTIONARIES_WRITE_PERMISSION,
	);
	const canEditDictionaries =
		canWriteDictionariesByPermission &&
		authRole !== "inspector" &&
		authRole !== "external_user";
	const canAccessManagement = isDirector || isTeamLead;
	const isRegistryOnlyUser = !canAccessManagement;

	const menuSections = useMemo(
		() =>
			getVisibleMenuSections(
				panelMode,
				authRole,
				canViewTimeReports,
				canViewOwnTimeReport,
				effectivePermissions,
			),
		[
			authRole,
			canViewOwnTimeReport,
			canViewTimeReports,
			effectivePermissions,
			panelMode,
		],
	);

	const firstVisibleItemId = menuSections[0]?.items[0]?.id ?? "";

	useEffect(() => {
		if (!authUser) {
			return;
		}

		if (isRegistryOnlyUser && panelMode !== "registry") {
			setPanelMode("registry");
			return;
		}

		const itemExists = menuSections.some((section) =>
			section.items.some((item) => item.id === selectedItemId),
		);
		if (!itemExists && firstVisibleItemId) {
			setSelectedItemId(firstVisibleItemId);
		}
	}, [
		authUser,
		firstVisibleItemId,
		isRegistryOnlyUser,
		menuSections,
		panelMode,
		selectedItemId,
	]);

	const switchPanelMode = (mode: PanelMode) => {
		if (isRegistryOnlyUser && mode === "management") {
			return;
		}

		setPanelMode(mode);
		const visibleSections = getVisibleMenuSections(
			mode,
			authRole,
			canViewTimeReports,
			canViewOwnTimeReport,
			effectivePermissions,
		);
		const nextDefaultItemId =
			visibleSections[0]?.items[0]?.id ?? getDefaultMenuItemId(mode);
		setSelectedItemId(nextDefaultItemId);
	};

	const handleMenuItemSelect = (itemId: string) => {
		setSelectedItemId(itemId);
		setIsSidebarOpen(false);
	};

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		const handleOpenInspectionFromDashboard = () => {
			setPanelMode("registry");
			setSelectedItemId("inspections");
			setIsSidebarOpen(false);
		};

		window.addEventListener(
			DASHBOARD_OPEN_INSPECTION_EVENT,
			handleOpenInspectionFromDashboard,
		);

		const handleOpenRecommendationFromDashboard = () => {
			setPanelMode("registry");
			setSelectedItemId("recommendations");
			setIsSidebarOpen(false);
		};

		window.addEventListener(
			DASHBOARD_OPEN_RECOMMENDATION_EVENT,
			handleOpenRecommendationFromDashboard,
		);

		const handleOpenSanctionRequestFromDashboard = () => {
			setPanelMode("registry");
			setSelectedItemId("sanction_requests");
			setIsSidebarOpen(false);
		};

		window.addEventListener(
			DASHBOARD_OPEN_SANCTION_REQUEST_EVENT,
			handleOpenSanctionRequestFromDashboard,
		);

		const handleOpenBindingDecisionFromDashboard = () => {
			setPanelMode("registry");
			setSelectedItemId("binding_decisions");
			setIsSidebarOpen(false);
		};

		window.addEventListener(
			DASHBOARD_OPEN_BINDING_DECISION_EVENT,
			handleOpenBindingDecisionFromDashboard,
		);

		return () => {
			window.removeEventListener(
				DASHBOARD_OPEN_INSPECTION_EVENT,
				handleOpenInspectionFromDashboard,
			);
			window.removeEventListener(
				DASHBOARD_OPEN_RECOMMENDATION_EVENT,
				handleOpenRecommendationFromDashboard,
			);
			window.removeEventListener(
				DASHBOARD_OPEN_SANCTION_REQUEST_EVENT,
				handleOpenSanctionRequestFromDashboard,
			);
			window.removeEventListener(
				DASHBOARD_OPEN_BINDING_DECISION_EVENT,
				handleOpenBindingDecisionFromDashboard,
			);
		};
	}, []);

	const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		const trimmedLogin = loginInput.trim();
		if (!trimmedLogin || !passwordInput) {
			setLoginError("Login i hasło są wymagane.");
			return;
		}

		setIsLoginSubmitting(true);
		setLoginError(null);

		try {
			const response = await fetch("/api/auth/password-login", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					login: trimmedLogin,
					password: passwordInput,
				}),
			});
			const errorDetail = !response.ok
				? await readPasswordLoginErrorDetail(response)
				: null;

			if (response.status === 400) {
				setLoginError(errorDetail?.message || "Login i hasło są wymagane.");
				return;
			}

			if (response.status === 401) {
				if (errorDetail?.code === "AUTH_INVALID_CREDENTIALS") {
					setLoginError(buildInvalidCredentialsMessage(errorDetail));
					return;
				}

				setLoginError(errorDetail?.message || "Nieprawidłowy login lub hasło.");
				return;
			}

			if (response.status === 403) {
				setLoginError(errorDetail?.message || "Użytkownik jest nieaktywny.");
				return;
			}

			if (response.status === 429) {
				if (errorDetail?.code === "AUTH_LOGIN_LOCKED") {
					setLoginError(buildLoginLockedMessage(errorDetail));
					return;
				}

				setLoginError(
					errorDetail?.message ||
						"Zbyt wiele nieudanych prób logowania. Spróbuj ponownie później.",
				);
				return;
			}

			if (!response.ok) {
				setLoginError("Nie udało się zalogować. Spróbuj ponownie za chwilę.");
				return;
			}

			const payload = (await response.json()) as PasswordLoginResponse;
			if (!payload.token || !payload.expiresAt || !payload.user) {
				setLoginError("Nieprawidłowa odpowiedź serwera logowania.");
				return;
			}

			// Always reset local UI preferences when establishing a new login session.
			clearStoredUiPreferences();

			setStoredAuthSession({
				token: payload.token,
				expiresAt: payload.expiresAt,
				user: payload.user,
			});
			setLoginError(null);
			router.replace("/");
		} catch {
			setLoginError("Brak połączenia z backendem logowania.");
		} finally {
			setIsLoginSubmitting(false);
		}
	};

	const clearStoredUiPreferences = () => {
		if (typeof window === "undefined") {
			return;
		}

		const uiPrefix = "triangle.ui.";
		const clearByPrefix = (storage: Storage) => {
			const keysToRemove: string[] = [];
			for (let index = 0; index < storage.length; index += 1) {
				const key = storage.key(index);
				if (!key || !key.startsWith(uiPrefix)) {
					continue;
				}

				keysToRemove.push(key);
			}

			for (const key of keysToRemove) {
				storage.removeItem(key);
			}
		};

		clearByPrefix(window.localStorage);
		clearByPrefix(window.sessionStorage);
	};

	const handleLogout = async () => {
		const token = getStoredAuthToken();
		if (token) {
			try {
				await fetch("/api/auth/logout-token", {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${token}`,
					},
				});
			} catch {
				// Local logout still needs to happen even if backend is unreachable.
			}
		}

		clearStoredAuthSession();
		clearStoredUiPreferences();
		setAuthUser(null);
		setLoginError(null);
		setLoginInput("");
		setPasswordInput("");
		router.replace("/login");
	};

	const inactivityTimeout = useInactivityTimeout({
		enabled: Boolean(authUser) && !isCheckingSession,
		inactivityMs: GLOBAL_INACTIVITY_TIMEOUT_MS,
		warningMs: GLOBAL_INACTIVITY_WARNING_MS,
		onTimeout: () => {
			void handleLogout();
		},
	});

	if (isCheckingSession && !authUser) {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<p className="text-slate-200/80">Sprawdzanie sesji...</p>
			</div>
		);
	}

	if (!authUser && pathname !== "/login") {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<p className="text-slate-200/80">Przekierowywanie do logowania...</p>
			</div>
		);
	}

	if (!authUser) {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />

				<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
					<div className="mb-6">
						<div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-[#4c78b1] bg-[#284878] text-sky-100">
							<ShieldCheck size={20} />
						</div>

						<p className="font-semibold text-[11px] text-slate-300/85 uppercase tracking-[0.16em]">
							System
						</p>
						<h1 className="mt-1 font-bold text-4xl text-sky-300 leading-none">
							Rejestr spraw
						</h1>
						<p className="mt-2 text-slate-200/80 text-sm">
							Uniwersytet Jazdy Rowerem
						</p>
						<p className="mt-1 text-slate-200/80 text-sm">
							Zaloguj się, aby kontynuować pracę w aplikacji.
						</p>
					</div>

					<form className="space-y-3" onSubmit={handleLogin}>
						<label className="block text-slate-200 text-sm">
							<span className="mb-1.5 block font-medium">Login</span>
							<input
								type="text"
								value={loginInput}
								onChange={(event) => setLoginInput(event.target.value)}
								placeholder="np. user123"
								className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
							/>
						</label>

						<label className="block text-slate-200 text-sm">
							<span className="mb-1.5 block font-medium">Hasło</span>
							<input
								type="password"
								value={passwordInput}
								onChange={(event) => setPasswordInput(event.target.value)}
								placeholder="Wpisz hasło"
								className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
							/>
						</label>

						{loginError ? (
							<p className="whitespace-pre-line font-medium text-rose-300 text-sm">{loginError}</p>
						) : null}

						<button
							type="submit"
							disabled={isLoginSubmitting}
							className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-[#6ea3f0] bg-linear-to-r from-[#2f4f83] to-[#365e9a] font-semibold text-base text-white transition-colors hover:from-[#3a619e] hover:to-[#4673b4] disabled:cursor-not-allowed disabled:opacity-70"
						>
							{isLoginSubmitting ? "Logowanie..." : "Zaloguj"}
						</button>

						<button
							type="button"
							onClick={() => router.push("/forgot-password")}
							className="inline-flex h-9 w-full items-center justify-center rounded-lg border border-[#5b7fae] bg-[#203a62] px-3 font-semibold text-sm text-slate-100 transition-colors hover:bg-[#2a4a79]"
						>
							Nie pamiętam hasła
						</button>
					</form>

					<p className="mt-5 border-[#33517d] border-t pt-3 text-center text-slate-300/85 text-xs">
						Rejestr spraw | Wersja robocza
					</p>
				</div>
			</div>
		);
	}

	const sidebarContent = (
		<>
			<div className="mb-4 hidden lg:block">
				<div className="relative min-w-0 rounded-2xl border border-[#3f5f8f] bg-[#22385c]/85 py-3.5 pr-3.5 pl-16 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
					<button
						type="button"
						onClick={() => setIsDesktopSidebarExpanded(false)}
						aria-label="Ukryj menu"
						className="absolute top-1/2 left-3 inline-flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-xl border border-slate-700 bg-[#1b2c4a] text-slate-100 transition-colors hover:bg-[#24395f]"
					>
						<Menu size={16} />
					</button>

					<p className="text-[11px] text-slate-300/80 uppercase tracking-[0.14em]">
						Rejestr spraw
					</p>
					<h1 className="mt-1 font-bold text-[1.75rem] text-sky-300 leading-none">
						{companyShortName}
					</h1>
				</div>
			</div>

			{!isRegistryOnlyUser ? (
				<div className="mb-5 grid grid-cols-2 gap-2 rounded-xl border border-[#37537d] bg-[#1c3153]/80 p-1.5">
					<button
						type="button"
						onClick={() => switchPanelMode("registry")}
						className={`rounded-lg px-3 py-2 font-semibold text-sm transition-colors ${
							panelMode === "registry"
								? "bg-[#345689] text-white"
								: "text-slate-200 hover:bg-[#274470]"
						}`}
					>
						Rejestr
					</button>

					<button
						type="button"
						onClick={() => switchPanelMode("management")}
						className={`rounded-lg px-3 py-2 font-semibold text-sm transition-colors ${
							panelMode === "management"
								? "bg-[#345689] text-white"
								: "text-slate-200 hover:bg-[#274470]"
						}`}
					>
						Zarządzanie
					</button>
				</div>
			) : null}

			<nav className="sidebar-menu-scroll min-h-0 flex-1 space-y-4 overflow-y-auto">
				{menuSections.map((section) => {
					const SectionIcon = getSectionIcon(section);
					const isStartSection = section.id === "start";
					const isStartActive = selectedItemId === "start";

					return (
						<section key={section.id} className="px-1 pb-2">
							{isStartSection ? (
								<button
									type="button"
									onClick={() => handleMenuItemSelect("start")}
									className={`mb-2 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left font-semibold text-[1rem] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
										isStartActive
											? "bg-[#345689]/90 text-white"
											: "text-slate-100 hover:bg-[#22375b]/65"
									}`}
								>
									<SectionIcon size={16} className="text-slate-300" />
									{section.label}
								</button>
							) : (
								<div className="mb-2 flex w-full items-center rounded-md px-1 py-1 text-left font-semibold text-[1rem] text-slate-100">
									<span className="flex items-center gap-2">
										<SectionIcon size={16} className="text-slate-300" />
										{section.label}
									</span>
								</div>
							)}

							{isStartSection ? null : (
								<div className="space-y-0.5">
								{section.items.map((item) => {
									const isActive = item.id === selectedItemId;

									return (
										<button
											key={item.id}
											type="button"
											onClick={() => handleMenuItemSelect(item.id)}
											className={`group relative flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-[1rem] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
												isActive
													? "bg-[#345689]/90 text-white"
													: "text-slate-100/90 hover:bg-[#22375b]/65"
											}`}
										>
											{isActive ? (
												<span className="absolute inset-y-1 left-0 w-0.5 rounded-r bg-sky-300" />
											) : null}
											<span
												className={`h-1.5 w-1.5 rounded-full ${isActive ? "bg-sky-300" : "bg-slate-500"}`}
											/>
											{item.label}
										</button>
									);
								})}
								</div>
							)}

							<div className="mt-3 border-[#36517b]/60 border-b" />
						</section>
					);
				})}
			</nav>

			<div className="mt-4 rounded-xl border border-[#466792] bg-[#1f3558]/90 p-3">
				<p className="text-[11px] text-slate-300/80 uppercase tracking-[0.12em]">
					Konto
				</p>
				<p className="mt-1 truncate font-semibold text-slate-100 text-sm">
					{authUser.login}
				</p>

				<div className="mt-3 flex items-center gap-2">
					<button
						type="button"
						onClick={() => router.push("/change-password")}
						className="inline-flex h-8 items-center justify-center rounded-md border border-[#5b7fae] bg-[#2a4774] px-2.5 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#35598e]"
					>
						Zmień hasło
					</button>

					<button
						type="button"
						onClick={() => void handleLogout()}
						className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[#5b7fae] bg-[#2a4774] px-2.5 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#35598e]"
					>
						<LogOut size={14} />
						Wyloguj
					</button>
				</div>
			</div>
		</>
	);

	const compactSidebarContent = (
		<>
			<button
				type="button"
				onClick={() => setIsDesktopSidebarExpanded(true)}
				aria-label="Pokaz menu"
				className="mb-4 w-full rounded-2xl border border-[#3f5f8f] bg-[#22385c]/85 p-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)] transition-colors hover:bg-[#2a4369]/35"
			>
				<span className="flex items-center justify-center gap-1.5">
					<span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-transparent text-slate-100">
						<Menu size={14} />
					</span>

					<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-transparent font-bold text-sky-300 text-xs">
						{companyShortName}
					</span>
				</span>
			</button>

			<nav className="sidebar-menu-scroll min-h-0 flex-1 space-y-3 overflow-y-auto">
				{(panelMode === "registry"
					? menuSections.filter(
							(section) =>
								section.id === "start" ||
								section.id === "registers" ||
								section.id === "tools" ||
								section.id === "dictionaries",
						)
					: menuSections
				).map((section, sectionIndex, sections) => {
					const SectionIcon = getSectionIcon(section);
					const targetItemId = section.items[0]?.id;
					const isSectionActive = section.items.some(
						(item) => item.id === selectedItemId,
					);
					const isRegistersSection =
						panelMode === "registry" && section.id === "registers";
					const isReportsSection =
						panelMode === "registry" && section.id === "tools";
					const isManagementSection =
						panelMode === "management" && section.id === "management";
					const isShortcutSection =
						isRegistersSection || isReportsSection || isManagementSection;
					const registerShortcuts = [
						{ id: "inspections", shortLabel: "I" },
						{ id: "recommendations", shortLabel: "Z" },
						{ id: "binding_decisions", shortLabel: "DZ" },
						{ id: "sanction_requests", shortLabel: "WS" },
					].filter((shortcut) =>
						section.items.some((item) => item.id === shortcut.id),
					);
					const reportShortcuts = [
						{ id: "reports", shortLabel: "WI" },
						{ id: "report_protocol_time", shortLabel: "CP" },
						{ id: "report_statement_time", shortLabel: "CS" },
					].filter((shortcut) =>
						section.items.some((item) => item.id === shortcut.id),
					);
					const managementShortcuts = [
						{ id: "dictionaries", shortLabel: "S" },
						{ id: "teams", shortLabel: "Z" },
						{ id: "users", shortLabel: "U" },
						{ id: "schedules", shortLabel: "H" },
						{ id: "logs", shortLabel: "L" },
					].filter((shortcut) =>
						section.items.some((item) => item.id === shortcut.id),
					);
					const sectionShortcuts = isRegistersSection
						? registerShortcuts
						: isReportsSection
							? reportShortcuts
							: isManagementSection
								? managementShortcuts
								: [];

					if (!targetItemId) {
						return null;
					}

					return (
						<div
							key={section.id}
							className="flex w-full flex-col items-center gap-2"
						>
							<button
								type="button"
								title={section.label}
								onClick={() => setSelectedItemId(targetItemId)}
								className={`relative inline-flex h-10 w-10 items-center justify-center rounded-xl border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
									isSectionActive
										? "border-[#84b0f2] bg-[#345689] text-sky-300 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
										: "border-transparent text-slate-200/90 hover:border-[#43628f] hover:bg-[#22375b]"
								}`}
								aria-label={section.label}
							>
								<SectionIcon size={18} />
							</button>

							{isShortcutSection ? (
								<div className="flex flex-col items-center gap-1.5">
									{sectionShortcuts.map((shortcut) => {
										const isShortcutActive = selectedItemId === shortcut.id;
										const shortcutLabel =
											section.items.find((item) => item.id === shortcut.id)?.label ??
											shortcut.shortLabel;

										return (
											<button
												key={shortcut.id}
												type="button"
												title={shortcutLabel}
												onClick={() => setSelectedItemId(shortcut.id)}
												className={`inline-flex h-7 min-w-7 items-center justify-center rounded-full border px-1.5 font-bold text-[10px] leading-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
													isShortcutActive
														? "border-[#84b0f2] bg-[#345689] text-white"
														: "border-[#3f5f8f] bg-[#22385c]/70 text-slate-200 hover:bg-[#2b4872]"
												}`}
												aria-label={shortcutLabel}
											>
												{shortcut.shortLabel}
											</button>
										);
									})}
								</div>
							) : null}

							{sectionIndex < sections.length - 1 ? (
								<div className="mt-1 w-full border-[#36517b]/60 border-b" />
							) : null}
						</div>
					);
				})}
			</nav>

			<div className="mt-4 flex flex-col items-center gap-2 rounded-xl border border-[#466792] bg-[#1f3558]/90 p-2">
				<button
					type="button"
					onClick={() => router.push("/change-password")}
					title="Zmien haslo"
					className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#5b7fae] bg-[#2a4774] text-slate-100 transition-colors hover:bg-[#35598e]"
					aria-label="Zmien haslo"
				>
					<KeyRound size={16} />
				</button>

				<button
					type="button"
					onClick={() => void handleLogout()}
					title="Wyloguj"
					className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#5b7fae] bg-[#2a4774] text-slate-100 transition-colors hover:bg-[#35598e]"
					aria-label="Wyloguj"
				>
					<LogOut size={16} />
				</button>
			</div>
		</>
	);

	return (
		<div className="relative flex h-dvh min-h-screen w-full overflow-hidden bg-[#09152b] text-slate-100">
			{inactivityTimeout.isWarning ? (
				<div className="fixed top-4 right-4 z-50 max-w-sm rounded-xl border border-amber-300/60 bg-amber-100 px-4 py-3 text-amber-900 shadow-xl">
					<p className="font-semibold text-sm">Automatyczne wylogowanie</p>
					<p className="mt-1 text-sm">
						Brak aktywności. Wylogowanie za <span className="tabular-nums">{inactivityTimeout.secondsRemaining}</span> s.
					</p>
					<button
						type="button"
						onClick={inactivityTimeout.resetTimer}
						className="mt-3 inline-flex h-8 items-center justify-center rounded-md border border-amber-500/70 bg-amber-200 px-3 font-semibold text-[13px] hover:bg-amber-300"
					>
						Kontynuuj pracę
					</button>
				</div>
			) : null}

			{isSidebarOpen ? (
				<button
					type="button"
					aria-label="Zamknij menu"
					className="fixed inset-0 z-20 bg-slate-950/50 lg:hidden"
					onClick={() => setIsSidebarOpen(false)}
				/>
			) : null}

			<aside
				className={`fixed inset-y-0 left-0 z-30 flex h-dvh w-[22rem] flex-col border-[#2f4368] border-r bg-linear-to-b from-[#1d3053] via-[#192b49] to-[#14233e] p-5 shadow-[12px_0_28px_rgba(2,8,23,0.38)] transition-transform duration-300 lg:hidden ${
					isSidebarOpen ? "translate-x-0" : "-translate-x-full"
				}`}
			>
				{sidebarContent}
			</aside>

			<div
				className={`hidden shrink-0 overflow-hidden transition-[width] duration-300 lg:block ${
					isDesktopSidebarExpanded ? "lg:w-[14.5rem] xl:w-[15rem]" : "lg:w-[4.5rem]"
				}`}
			>
				{isDesktopSidebarExpanded ? (
					<aside className="flex h-full w-[14.5rem] flex-col border-[#2f4368] border-r bg-linear-to-b from-[#1d3053] via-[#192b49] to-[#14233e] px-3 py-4 shadow-[12px_0_28px_rgba(2,8,23,0.38)] xl:w-[15rem] xl:px-4 xl:py-5">
						{sidebarContent}
					</aside>
				) : (
					<aside className="flex h-full w-[4.5rem] flex-col border-[#2f4368] border-r bg-linear-to-b from-[#1d3053] via-[#192b49] to-[#14233e] p-2.5 shadow-[12px_0_28px_rgba(2,8,23,0.38)]">
						{compactSidebarContent}
					</aside>
				)}
			</div>

			<main className="min-h-0 min-w-0 flex flex-1 flex-col overflow-hidden p-0 sm:p-0 lg:pt-0 lg:pl-1 lg:pr-0 lg:pb-0 xl:pt-0 xl:pl-1 xl:pr-0 xl:pb-0">
				<div className="mb-4 flex items-center gap-1 lg:hidden">
					<button
						type="button"
						onClick={() => setIsSidebarOpen(true)}
						className="inline-flex items-center gap-2 rounded-md border border-slate-700 bg-[#1b2c4a] px-3 py-2 text-sm"
					>
						<Menu size={16} />
						Nawigacja
					</button>
				</div>

				<div className="min-h-0 h-full flex-1 overflow-hidden lg:pr-0 lg:pb-0 xl:pr-0 xl:pb-0">
					{renderTabContent({
						panelMode,
						selectedItemId,
						operatorLogin: authUser.login,
						isObserver,
						authRole: authUser.role,
						canEditDictionaries,
					})}
				</div>
			</main>
		</div>
	);
}
