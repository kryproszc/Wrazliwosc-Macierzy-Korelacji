import { History, Pencil, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";

import type { AdminUser } from "@/features/admin-users/types";
import { getRoleLabelById } from "@/features/admin-users/utils";
import { TableAdvancedFilterModal } from "@/shared/components/table/TableAdvancedFilterModal";
import { TableSurface } from "@/shared/components/table/TableSurface";
import { getFloatingPanelAnchor } from "@/shared/utils/floating-panel";
import {
	hasActiveTableFilters,
	matchesAdvancedFilterCellValue,
	splitAdvancedFilterCellValue,
} from "@/shared/utils/table-filters";

type AdminUsersTableProps = {
	users: AdminUser[];
	usersError: string | null;
	isUsersLoading: boolean;
	canEditUser: (user: AdminUser) => boolean;
	canDeleteUser: boolean;
	isDeletingUserId: number | null;
	onEditUser: (user: AdminUser) => void;
	onDeleteUser: (user: AdminUser) => void;
	onViewHistory: (user: AdminUser) => void;
	className?: string;
};

type UserColumnFilterKey =
	| "login"
	| "fullName"
	| "accountType"
	| "role"
	| "team"
	| "department"
	| "email"
	| "status"
	| "visibility";

type UserFilterAnchor = {
	top: number;
	left: number;
};

export function AdminUsersTable({
	users,
	usersError,
	isUsersLoading,
	canEditUser,
	canDeleteUser,
	isDeletingUserId,
	onEditUser,
	onDeleteUser,
	onViewHistory,
	className,
}: AdminUsersTableProps) {
	const [columnFilters, setColumnFilters] = useState<
		Partial<Record<UserColumnFilterKey, string>>
	>({});
	const [advancedFilters, setAdvancedFilters] = useState<
		Partial<Record<UserColumnFilterKey, string[]>>
	>({});
	const [isAdvancedFilterModalOpen, setIsAdvancedFilterModalOpen] =
		useState(false);
	const [advancedFilterAnchor, setAdvancedFilterAnchor] =
		useState<UserFilterAnchor>({ top: 120, left: 120 });
	const [advancedFilterColumnKey, setAdvancedFilterColumnKey] =
		useState<UserColumnFilterKey>("login");
	const [advancedFilterSearch, setAdvancedFilterSearch] = useState("");

	const filterableColumnKeys: UserColumnFilterKey[] = [
		"login",
		"fullName",
		"accountType",
		"role",
		"team",
		"department",
		"email",
		"status",
		"visibility",
	];

	const getAccountTypeLabel = (accountType: AdminUser["accountType"]) => {
		switch ((accountType ?? "").toLowerCase()) {
			case "diu":
				return "Pracownicy DIU";
			case "observer":
			case "observers":
				return "Użytkownicy obserwatorzy";
			case "technical":
				return "Użytkownicy techniczni";
			default:
				return "-";
		}
	};

	const getListVisibilityLabel = (listVisibility: AdminUser["listVisibility"]) => {
		switch ((listVisibility ?? "").toLowerCase()) {
			case "visible":
			case "widoczny":
				return "Widoczny";
			case "hidden":
			case "ukryty":
				return "Ukryty";
			default:
				return "-";
		}
	};

	const headerCellClass =
		"whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800";

	const getCellValueByFilterKey = (
		user: AdminUser,
		key: UserColumnFilterKey,
	): string => {
		if (key === "login") {
			return user.login || "brak";
		}

		if (key === "fullName") {
			return `${user.imie} ${user.nazwisko}`.trim();
		}

		if (key === "accountType") {
			return getAccountTypeLabel(user.accountType);
		}

		if (key === "role") {
			return getRoleLabelById(user.rolaId, user.rola);
		}

		if (key === "team") {
			return user.zespolSkroconaNazwa ?? "-";
		}

		if (key === "department") {
			return user.departmentCode ?? user.departmentLabel ?? "-";
		}

		if (key === "email") {
			return user.email ?? "-";
		}

		if (key === "status") {
			return user.aktywny ? "Aktywny" : "Nieaktywny";
		}

		if (key === "visibility") {
			return getListVisibilityLabel(user.listVisibility);
		}

		return "";
	};

	const filteredUsers = useMemo(
		() =>
			users.filter((user) =>
				Object.entries(columnFilters).every(([key, value]) => {
					const normalizedFilterValue = (value ?? "").trim().toLowerCase();
					if (!normalizedFilterValue) {
						return true;
					}

					const cellValue = getCellValueByFilterKey(
						user,
						key as UserColumnFilterKey,
					)
						.toLowerCase()
						.trim();

					return cellValue.includes(normalizedFilterValue);
				}) &&
				filterableColumnKeys.every((columnKey) => {
					const selectedValues = advancedFilters[columnKey] ?? [];
					if (selectedValues.length === 0) {
						return true;
					}

					return matchesAdvancedFilterCellValue(
						getCellValueByFilterKey(user, columnKey),
						selectedValues,
					);
				}),
			),
		[advancedFilters, columnFilters, users],
	);

	const advancedFilterValuesByColumn = useMemo(() => {
		const map: Partial<Record<UserColumnFilterKey, string[]>> = {};

		for (const columnKey of filterableColumnKeys) {
			const uniqueValues = Array.from(
				new Set(
					users.flatMap((user) =>
						splitAdvancedFilterCellValue(getCellValueByFilterKey(user, columnKey)),
					),
				),
			).sort((left, right) =>
				left.localeCompare(right, "pl", {
					sensitivity: "base",
					numeric: true,
				}),
			);

			map[columnKey] = uniqueValues;
		}

		return map;
	}, [users]);

	const selectedAdvancedFilterValues =
		advancedFilters[advancedFilterColumnKey] ?? [];
	const visibleAdvancedFilterValues = useMemo(() => {
		const sourceValues = advancedFilterValuesByColumn[advancedFilterColumnKey] ?? [];
		const normalizedSearch = advancedFilterSearch.trim().toLowerCase();

		if (!normalizedSearch) {
			return sourceValues;
		}

		return sourceValues.filter((value) =>
			value.toLowerCase().includes(normalizedSearch),
		);
	}, [advancedFilterColumnKey, advancedFilterSearch, advancedFilterValuesByColumn]);

	const canClearFilters = useMemo(
		() => hasActiveTableFilters(columnFilters, advancedFilters),
		[advancedFilters, columnFilters],
	);

	const handleFilterChange = (key: UserColumnFilterKey, value: string) => {
		setColumnFilters((previous) => ({
			...previous,
			[key]: value,
		}));
	};

	const openAdvancedFilterForColumn = (
		columnKey: UserColumnFilterKey,
		triggerElement: HTMLElement,
	) => {
		setAdvancedFilterAnchor(getFloatingPanelAnchor(triggerElement));
		setAdvancedFilterColumnKey(columnKey);
		setAdvancedFilterSearch("");
		setIsAdvancedFilterModalOpen(true);
	};

	const toggleAdvancedFilterValue = (value: string) => {
		setAdvancedFilters((previous) => {
			const currentValues = previous[advancedFilterColumnKey] ?? [];
			const nextValues = currentValues.includes(value)
				? currentValues.filter((item) => item !== value)
				: [...currentValues, value];

			return {
				...previous,
				[advancedFilterColumnKey]: nextValues,
			};
		});
	};

	const selectAllVisibleAdvancedFilterValues = () => {
		setAdvancedFilters((previous) => {
			const current = new Set(previous[advancedFilterColumnKey] ?? []);
			visibleAdvancedFilterValues.forEach((value) => current.add(value));

			return {
				...previous,
				[advancedFilterColumnKey]: Array.from(current),
			};
		});
	};

	const clearAdvancedFilterForSelectedColumn = () => {
		setAdvancedFilters((previous) => ({
			...previous,
			[advancedFilterColumnKey]: [],
		}));
	};

	const clearAllTableFilters = () => {
		setColumnFilters({});
		setAdvancedFilters({});
		setAdvancedFilterSearch("");
	};

	const applyAdvancedSearchValue = (value: string) => {
		const normalized = value.trim();
		if (!normalized) {
			return;
		}

		setAdvancedFilters((previous) => {
			const currentValues = previous[advancedFilterColumnKey] ?? [];
			if (currentValues.includes(normalized)) {
				return previous;
			}

			return {
				...previous,
				[advancedFilterColumnKey]: [...currentValues, normalized],
			};
		});
	};

	const columnLabelByKey: Record<UserColumnFilterKey, string> = {
		login: "Login",
		fullName: "Imię i nazwisko",
		accountType: "Typ konta",
		role: "Rola",
		team: "Zespół",
		department: "Departament",
		email: "E-mail",
		status: "Status",
		visibility: "Widoczność",
	};

	return (
		<>
			<div className="mb-1 flex justify-end px-1">
				<button
					type="button"
					onClick={clearAllTableFilters}
					disabled={!canClearFilters}
					className={`inline-flex h-7 items-center rounded px-1.5 transition-colors disabled:cursor-not-allowed ${
						canClearFilters
							? "font-semibold text-blue-300 text-sm hover:text-blue-200"
							: "font-medium text-slate-500 text-xs"
					}`}
				>
					Wyczyść filtry
				</button>
			</div>

			<TableSurface
			isLoading={isUsersLoading}
			loadingMessage="Ładowanie użytkowników..."
			errorMessage={usersError}
			containerClassName={className ?? "h-full"}
			scrollAreaClassName="h-full min-h-0 pr-2"
			>
			<table className="w-max min-w-full border-collapse text-slate-900 text-sm">
				<thead className="sticky top-0 z-10">
					<tr className="bg-slate-100 text-slate-800">
						<th className={headerCellClass}>
							Login
						</th>
						<th className={headerCellClass}>
							Imię i nazwisko
						</th>
						<th className={headerCellClass}>
							Typ konta
						</th>
						<th className={headerCellClass}>
							Rola
						</th>
						<th className={headerCellClass}>
							Zespół
						</th>
						<th className={headerCellClass}>
							Departament
						</th>
						<th className={headerCellClass}>
							E-mail
						</th>
						<th className={headerCellClass}>
							Status
						</th>
						<th className={headerCellClass}>
							Widoczność
						</th>
						<th className={`${headerCellClass} min-w-[11rem]`}>
							
						</th>
					</tr>
					<tr className="bg-white text-slate-700">
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.login ?? ""}
									onChange={(event) => handleFilterChange("login", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[7rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("login", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.login ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.fullName ?? ""}
									onChange={(event) => handleFilterChange("fullName", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[8rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("fullName", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.fullName ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.accountType ?? ""}
									onChange={(event) => handleFilterChange("accountType", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[8rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("accountType", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.accountType ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.role ?? ""}
									onChange={(event) => handleFilterChange("role", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[7rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("role", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.role ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.team ?? ""}
									onChange={(event) => handleFilterChange("team", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[5rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("team", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.team ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.department ?? ""}
									onChange={(event) => handleFilterChange("department", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[6rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("department", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.department ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.email ?? ""}
									onChange={(event) => handleFilterChange("email", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[8rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("email", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.email ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.status ?? ""}
									onChange={(event) => handleFilterChange("status", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[6rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("status", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.status ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="border-slate-200 border-b bg-white px-2 py-2">
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters.visibility ?? ""}
									onChange={(event) => handleFilterChange("visibility", event.target.value)}
									placeholder="Filtruj..."
									className="w-full min-w-[6rem] rounded-md border border-slate-300 bg-white px-2 py-1 text-slate-800 text-xs outline-none transition-colors focus:border-blue-400"
								/>
								<button
									type="button"
									onClick={(event) => openAdvancedFilterForColumn("visibility", event.currentTarget)}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters.visibility ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									▾
								</button>
							</div>
						</th>
						<th className="min-w-[11rem] border-slate-200 border-b bg-white px-2 py-2" />
					</tr>
				</thead>

				<tbody>
					{filteredUsers.map((user) => (
						<tr
							key={user.id}
							className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
						>
							<td className="whitespace-nowrap px-3 py-2.5 font-medium">
								{user.login || "brak"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.imie} {user.nazwisko}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getAccountTypeLabel(user.accountType)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getRoleLabelById(user.rolaId, user.rola)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.zespolSkroconaNazwa ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.departmentCode ?? user.departmentLabel ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.email ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								<span
									className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${
										user.aktywny
											? "bg-emerald-100 text-emerald-800"
											: "bg-slate-200 text-slate-700"
									}`}
								>
									{user.aktywny ? "Aktywny" : "Nieaktywny"}
								</span>
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getListVisibilityLabel(user.listVisibility)}
							</td>
							<td className="min-w-[11rem] whitespace-nowrap px-3 py-2.5">
								<button
									type="button"
									onClick={() => onViewHistory(user)}
									className="mr-2 inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
								>
									<History size={12} />
									Historia
								</button>
								<button
									type="button"
									onClick={() => onEditUser(user)}
									disabled={!canEditUser(user)}
									className="mr-2 inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
								>
									<Pencil size={12} />
									Edytuj
								</button>
								{canDeleteUser ? (
									<button
										type="button"
										onClick={() => onDeleteUser(user)}
										disabled={isDeletingUserId === user.id}
										className="inline-flex w-[5.75rem] items-center justify-center gap-1 rounded-md border border-rose-300 px-2 py-1 font-semibold text-rose-700 text-xs transition-colors hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-50"
										aria-busy={isDeletingUserId === user.id}
									>
										<Trash2 size={12} />
										Usuń
									</button>
								) : null}
							</td>
						</tr>
					))}

					{!isUsersLoading && filteredUsers.length === 0 ? (
						<tr>
							<td colSpan={10} className="px-3 py-8 text-center text-slate-500">
								Brak użytkowników do wyświetlenia.
							</td>
						</tr>
					) : null}
				</tbody>
			</table>
			</TableSurface>

			<TableAdvancedFilterModal
				isOpen={isAdvancedFilterModalOpen}
				anchor={advancedFilterAnchor}
				columnLabel={columnLabelByKey[advancedFilterColumnKey] ?? "Kolumna"}
				searchValue={advancedFilterSearch}
				visibleValues={visibleAdvancedFilterValues}
				selectedValues={selectedAdvancedFilterValues}
				onClose={() => setIsAdvancedFilterModalOpen(false)}
				onSearchChange={setAdvancedFilterSearch}
				onSelectAllVisible={selectAllVisibleAdvancedFilterValues}
				onClearSelectedColumn={clearAdvancedFilterForSelectedColumn}
				onToggleValue={toggleAdvancedFilterValue}
				onApplySearchValue={applyAdvancedSearchValue}
				onClearAllFilters={clearAllTableFilters}
			/>
		</>
	);
}
