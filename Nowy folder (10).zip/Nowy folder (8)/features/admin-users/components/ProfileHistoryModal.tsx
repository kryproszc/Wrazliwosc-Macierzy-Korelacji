import { Clock3, X } from "lucide-react";
import { useMemo } from "react";

import type {
	AdminUser,
	AdminUserProfileHistoryEvent,
} from "@/features/admin-users/types";

type ProfileHistoryModalProps = {
	isOpen: boolean;
	user: AdminUser | null;
	isLoading: boolean;
	error: string | null;
	events: AdminUserProfileHistoryEvent[];
	onClose: () => void;
};

function formatDateTime(value: string | null) {
	if (!value) {
		return "-";
	}

	const parsed = new Date(value);
	if (Number.isNaN(parsed.getTime())) {
		return value;
	}

	return parsed.toLocaleString("pl-PL", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
	});
}

function formatChangeValue(value: unknown) {
	if (value === null || value === undefined) {
		return "-";
	}

	if (typeof value === "string") {
		const normalizedValue = value.trim();
		if (!normalizedValue) {
			return "-";
		}

		const normalizedLower = normalizedValue.toLowerCase();
		if (normalizedLower === "visible" || normalizedLower === "widoczny") {
			return "Widoczny";
		}

		if (
			normalizedLower === "hidden" ||
			normalizedLower === "ukryty" ||
			normalizedLower === "niewidoczny"
		) {
			return "Niewidoczny";
		}

		return normalizedValue.replace(/\s*\(\d+\)\s*$/g, "").trim();
	}

	if (typeof value === "boolean") {
		return value ? "Tak" : "Nie";
	}

	if (typeof value === "number") {
		return String(value);
	}

	try {
		return JSON.stringify(value);
	} catch {
		return String(value);
	}
}

export function ProfileHistoryModal({
	isOpen,
	user,
	isLoading,
	error,
	events,
	onClose,
}: ProfileHistoryModalProps) {
	const rows = useMemo(() => {
		const sortedEvents = [...events].sort((left, right) => {
			const leftTs = Number.isNaN(new Date(left.changedAt).getTime())
				? 0
				: new Date(left.changedAt).getTime();
			const rightTs = Number.isNaN(new Date(right.changedAt).getTime())
				? 0
				: new Date(right.changedAt).getTime();
			return rightTs - leftTs;
		});

		return sortedEvents.flatMap((event) =>
			event.changes.map((change, index) => ({
				id: `${event.eventId}-${change.field}-${index}`,
				changedBy: event.changedBy?.login ?? "-",
				changedAt: event.changedAt,
				label: change.label,
				before: change.before,
				after: change.after,
			})),
		);
	}, [events]);

	if (!isOpen || !user) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
			<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Historia profilu użytkownika"
				className="relative z-10 w-full max-w-5xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">Historia profilu</h3>
						<p className="mt-1 text-slate-600 text-sm">
							{user.imie} {user.nazwisko} ({user.login})
						</p>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				{error ? (
					<p className="mb-3 rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-rose-700 text-sm">
						{error}
					</p>
				) : null}

				{isLoading ? (
					<p className="mb-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-slate-600 text-sm">
						Ładowanie historii profilu...
					</p>
				) : null}

				<div className="subtle-horizontal-scroll subtle-vertical-scroll max-h-[65vh] overflow-x-auto overflow-y-auto rounded-xl border border-slate-200">
					<table className="min-w-full border-collapse text-slate-900 text-sm">
						<thead>
							<tr className="bg-slate-100 text-slate-800">
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Zmienił</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Kiedy</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Pozycja</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Przed zmianą</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Po zmianie</th>
							</tr>
						</thead>
						<tbody>
							{rows.map((row) => (
								<tr
									key={row.id}
									className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
								>
									<td className="whitespace-nowrap px-3 py-2.5">{row.changedBy}</td>
									<td className="whitespace-nowrap px-3 py-2.5">{formatDateTime(row.changedAt)}</td>
									<td className="whitespace-nowrap px-3 py-2.5 text-slate-700">{row.label}</td>
									<td className="px-3 py-2.5 text-slate-700">{formatChangeValue(row.before)}</td>
									<td className="px-3 py-2.5">{formatChangeValue(row.after)}</td>
								</tr>
							))}
							{!isLoading && rows.length === 0 ? (
								<tr>
										<td colSpan={5} className="px-3 py-8 text-center text-slate-500">
										<div className="inline-flex items-center gap-2">
											<Clock3 size={14} />
											Brak wpisów historii profilu.
										</div>
									</td>
								</tr>
							) : null}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
}
