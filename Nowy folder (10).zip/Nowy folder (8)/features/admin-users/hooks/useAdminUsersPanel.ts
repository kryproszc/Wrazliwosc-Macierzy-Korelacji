import { useCallback, useMemo, useRef, useState } from "react";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
	createAdminUser,
	fetchAdminTeams,
	fetchAdminUsers,
	sendAdminUserInvite,
	updateAdminUser,
} from "@/features/admin-users/api";
import { DEFAULT_ADD_USER_FORM } from "@/features/admin-users/constants";
import type {
	AddUserForm,
	AdminTeam,
	AdminUser,
} from "@/features/admin-users/types";

type UseAdminUsersPanelParams = {
	operatorLogin: string;
	authRole: AuthRole;
};

const cachedOperatorTeamIdByLogin = new Map<string, number | null>();

export function useAdminUsersPanel({
	operatorLogin,
	authRole,
}: UseAdminUsersPanelParams) {
	const normalizedOperatorLogin = operatorLogin.trim().toLowerCase();
	const [users, setUsers] = useState<AdminUser[]>([]);
	const [teams, setTeams] = useState<AdminTeam[]>([]);
	const [operatorTeamId, setOperatorTeamId] = useState<number | null>(() =>
		cachedOperatorTeamIdByLogin.has(normalizedOperatorLogin)
			? (cachedOperatorTeamIdByLogin.get(normalizedOperatorLogin) ?? null)
			: null,
	);
	const [isUsersLoading, setIsUsersLoading] = useState(true);
	const [isTeamsLoading, setIsTeamsLoading] = useState(false);
	const [usersError, setUsersError] = useState<string | null>(null);

	const [isAddModalOpen, setIsAddModalOpen] = useState(false);
	const [isAddingUser, setIsAddingUser] = useState(false);
	const [addUserError, setAddUserError] = useState<string | null>(null);
	const [addUserForm, setAddUserForm] = useState<AddUserForm>(
		DEFAULT_ADD_USER_FORM,
	);
	const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
	const [isEditModalOpen, setIsEditModalOpen] = useState(false);
	const [isUpdatingUser, setIsUpdatingUser] = useState(false);
	const [editUserError, setEditUserError] = useState<string | null>(null);
	const [inviteError, setInviteError] = useState<string | null>(null);
	const [inviteResult, setInviteResult] = useState<{
		userId: number;
		login: string;
		expiresAt: string;
		delivery: "log" | "smtp";
		inviteLink?: string;
	} | null>(null);
	const [isSendingInviteForUserId, setIsSendingInviteForUserId] = useState<
		number | null
	>(null);
	const [editUserForm, setEditUserForm] = useState<AddUserForm>(
		DEFAULT_ADD_USER_FORM,
	);
	const hasLoadedUsersRef = useRef(false);

	const isDirector = authRole === "director";
	const isTeamLead = authRole === "team_lead";

	const isUserCreatedByOperator = useCallback(
		(user: AdminUser) => {
			if (user.createdByOperator === true) {
				return true;
			}

			const createdByLogin = user.createdByLogin?.trim().toLowerCase() ?? "";
			return Boolean(createdByLogin) && createdByLogin === normalizedOperatorLogin;
		},
		[normalizedOperatorLogin],
	);

	const isTeamRequired =
		addUserForm.accountType === "diu" &&
		(addUserForm.rolaId === 1 || addUserForm.rolaId === 2);
	const visibleUsers = useMemo(() => {
		if (isDirector) {
			return users;
		}

		if (isTeamLead) {
			// Backend already returns exact scope for team lead
			// (team members + own created users outside team).
			return users;
		}

		return [];
	}, [isDirector, isTeamLead, users]);

	const availableTeams = useMemo(() => {
		if (isDirector) {
			return teams;
		}

		if (isTeamLead) {
			if (!operatorTeamId) {
				return [];
			}

			return teams.filter((team) => team.id === operatorTeamId);
		}

		return [];
	}, [isDirector, isTeamLead, operatorTeamId, teams]);

	const isRoleLocked = isTeamLead;
	const isTeamLocked = isTeamLead;

	const lockedTeamLabel = useMemo(() => {
		if (!operatorTeamId) {
			return null;
		}

		const team = teams.find((item) => item.id === operatorTeamId);
		if (!team) {
			return null;
		}

		return `${team.skroconaNazwa} - ${team.pelnaNazwa}`;
	}, [operatorTeamId, teams]);

	const loadUsers = useCallback(async () => {
		setUsersError(null);
		setIsUsersLoading(users.length === 0);

		try {
			const result = await fetchAdminUsers({ operatorLogin });
			if (!result.ok) {
				setUsersError(result.error);
				setUsers([]);
				setOperatorTeamId(null);
				cachedOperatorTeamIdByLogin.delete(normalizedOperatorLogin);
				return [] as AdminUser[];
			}

			setUsers(result.users);
			const operatorUser = result.users.find(
				(user) => user.login.trim().toLowerCase() === normalizedOperatorLogin,
			);
			const resolvedOperatorTeamId = operatorUser?.zespolId ?? null;
			setOperatorTeamId(resolvedOperatorTeamId);
			cachedOperatorTeamIdByLogin.set(
				normalizedOperatorLogin,
				resolvedOperatorTeamId,
			);
			return result.users;
		} catch {
			setUsersError("Nie udało się pobrać listy użytkowników.");
			setUsers([]);
			setOperatorTeamId(null);
			cachedOperatorTeamIdByLogin.delete(normalizedOperatorLogin);
			return [] as AdminUser[];
		} finally {
			setIsUsersLoading(false);
		}
	}, [normalizedOperatorLogin, operatorLogin, users.length]);

	const loadTeams = useCallback(async () => {
		setIsTeamsLoading(true);

		try {
			const result = await fetchAdminTeams();
			setTeams(result.teams);
		} catch {
			setTeams([]);
		} finally {
			setIsTeamsLoading(false);
		}
	}, []);

	const ensureUsersLoaded = useCallback(() => {
		if (hasLoadedUsersRef.current) {
			return;
		}

		hasLoadedUsersRef.current = true;
		void loadUsers();
	}, [loadUsers]);

	const openAddModal = useCallback(async () => {
		setAddUserForm(
			isTeamLead
				? {
						...DEFAULT_ADD_USER_FORM,
						rolaId: 1,
						zespolId: operatorTeamId,
					}
				: DEFAULT_ADD_USER_FORM,
		);
		setAddUserError(null);
		setIsAddModalOpen(true);

		if (teams.length === 0) {
			await loadTeams();
		}
	}, [isTeamLead, loadTeams, operatorTeamId, teams.length]);

	const closeAddModal = useCallback(() => {
		setIsAddModalOpen(false);
		setAddUserError(null);
	}, []);

	const canEditUser = useCallback(
		(user: AdminUser) => {
			if (isDirector) {
				return true;
			}

			if (isTeamLead) {
				const isInOperatorTeam =
					Boolean(operatorTeamId) && user.zespolId === operatorTeamId;
				return isInOperatorTeam || isUserCreatedByOperator(user);
			}

			return false;
		},
		[isDirector, isTeamLead, isUserCreatedByOperator, operatorTeamId],
	);

	const openEditModal = useCallback(
		(user: AdminUser) => {
			if (!canEditUser(user)) {
				return;
			}

			const normalizedAccountType =
				user.accountType === "observer" || user.accountType === "technical"
					? user.accountType
					: "diu";
			const requiresTeamForEdit =
				normalizedAccountType === "diu" && (user.rolaId === 1 || user.rolaId === 2);
			const resolvedTeamId =
				isTeamLead && requiresTeamForEdit
					? (operatorTeamId ?? user.zespolId)
					: user.zespolId;

			setEditingUser(user);
			setEditUserForm({
				login: user.login,
				imie: user.imie,
				nazwisko: user.nazwisko,
				email: user.email ?? "",
				rolaId: user.rolaId,
				zespolId: resolvedTeamId,
				aktywny: user.aktywny,
				accountType: normalizedAccountType,
				departmentCode:
					user.departmentCode ??
					((user.accountType ?? "diu") === "diu" ? "DIU" : null),
				listVisibility:
					user.listVisibility === "hidden" ? "hidden" : "visible",
			});
			setEditUserError(null);
			setIsEditModalOpen(true);

			if (teams.length === 0) {
				void loadTeams();
			}
		},
		[canEditUser, isTeamLead, loadTeams, operatorTeamId, teams.length],
	);

	const closeEditModal = useCallback(() => {
		setIsEditModalOpen(false);
		setIsUpdatingUser(false);
		setEditUserError(null);
		setEditingUser(null);
		setEditUserForm(DEFAULT_ADD_USER_FORM);
	}, []);

	const submitAddUser = useCallback(async () => {
		const isTechnicalAccount = addUserForm.accountType === "technical";
		const isDiuAccount = addUserForm.accountType === "diu";
		const isTeamLeadDiuCreation = isTeamLead && isDiuAccount;
		const isDiuTeamRequired =
			isDiuAccount && (addUserForm.rolaId === 1 || addUserForm.rolaId === 2);
		const effectiveIsActive = isTechnicalAccount ? false : addUserForm.aktywny;
		const trimmedLogin = addUserForm.login.trim();
		const trimmedImie = addUserForm.imie.trim();
		const trimmedNazwisko = addUserForm.nazwisko.trim();

		if (
			(effectiveIsActive && !trimmedLogin) ||
			!trimmedImie ||
			!trimmedNazwisko ||
			!addUserForm.rolaId
		) {
			setAddUserError(
				effectiveIsActive
					? "Uzupełnij wymagane pola: login, imię, nazwisko i rola."
					: "Uzupełnij wymagane pola: imię, nazwisko i rola.",
			);
			return { ok: false as const, inviteSent: false as const };
		}

		if (isDiuTeamRequired && !addUserForm.zespolId) {
			setAddUserError(
				"Dla roli Użytkownik i Kierownik zespołu wybierz zespół.",
			);
			return { ok: false as const, inviteSent: false as const };
		}

		if (isTeamLeadDiuCreation) {
			if (!operatorTeamId) {
				setAddUserError(
					"Brak przypisanego zespołu dla zalogowanego kierownika.",
				);
				return { ok: false as const, inviteSent: false as const };
			}

			if (addUserForm.rolaId !== 1) {
				setAddUserError(
					"Kierownik zespołu może dodawać tylko użytkowników do swojego zespołu.",
				);
				return { ok: false as const, inviteSent: false as const };
			}

			if (addUserForm.zespolId !== operatorTeamId) {
				setAddUserError(
					"Kierownik zespołu może dodawać użytkowników tylko do swojego zespołu.",
				);
				return { ok: false as const, inviteSent: false as const };
			}
		}

		setIsAddingUser(true);
		setAddUserError(null);

		try {
			const enforcedForm = {
				...addUserForm,
				login: trimmedLogin,
				email: effectiveIsActive ? addUserForm.email : "",
				aktywny: effectiveIsActive,
				departmentCode: isDiuAccount ? "DIU" : addUserForm.departmentCode,
				rolaId: isTeamLeadDiuCreation ? 1 : addUserForm.rolaId,
				zespolId: isDiuAccount
					? (isTeamLeadDiuCreation ? operatorTeamId : addUserForm.zespolId)
					: null,
			};

			const result = await createAdminUser({
				operatorLogin,
				form: enforcedForm,
			});
			if (!result.ok) {
				setAddUserError(result.error || "Nie udało się dodać użytkownika.");
				return { ok: false as const, inviteSent: false as const };
			}
			const latestUsers = await loadUsers();

			if (!effectiveIsActive || isTechnicalAccount || !trimmedLogin) {
				closeAddModal();
				setInviteError(null);
				return { ok: true as const, inviteSent: false as const };
			}

			const createdUserLogin = enforcedForm.login.trim().toLowerCase();
			const createdUser = latestUsers.find(
				(user) => user.login.trim().toLowerCase() === createdUserLogin,
			);

			if (!createdUser) {
				closeAddModal();
				setInviteError(
					"Użytkownik został dodany, ale nie udało się automatycznie wysłać zaproszenia.",
				);
				return { ok: true as const, inviteSent: false as const };
			}

			const frontendInviteUrl =
				typeof window !== "undefined"
					? `${window.location.origin}/set-password`
					: "http://localhost:3002/set-password";

			const inviteResult = await sendAdminUserInvite({
				operatorLogin,
				userId: createdUser.id,
				frontendInviteUrl,
			});

			if (!inviteResult.ok) {
				closeAddModal();
				setInviteError(
					`Użytkownik został dodany, ale zaproszenie nie zostało wysłane: ${inviteResult.error}`,
				);
				return { ok: true as const, inviteSent: false as const };
			}

			closeAddModal();
			setInviteError(null);
			setInviteResult({
				userId: createdUser.id,
				login: createdUser.login,
				expiresAt: inviteResult.data.expiresAt,
				delivery: inviteResult.data.delivery === "smtp" ? "smtp" : "log",
				inviteLink: inviteResult.data.inviteLink,
			});
			return { ok: true as const, inviteSent: true as const };
		} catch {
			setAddUserError("Brak połączenia z backendem.");
			return { ok: false as const, inviteSent: false as const };
		} finally {
			setIsAddingUser(false);
		}
	}, [
		addUserForm,
		closeAddModal,
		isTeamLead,
		loadUsers,
		operatorLogin,
		operatorTeamId,
	]);

	const submitEditUser = useCallback(
		async (
			options?: { skipClose?: boolean },
		): Promise<{ ok: boolean; requiresRelogin: boolean }> => {
		if (!editingUser) {
			return { ok: false, requiresRelogin: false };
		}

		if (!canEditUser(editingUser)) {
			setEditUserError("Brak uprawnień do edycji tego użytkownika.");
			return { ok: false, requiresRelogin: false };
		}

		const trimmedLogin = editUserForm.login.trim();
		const trimmedImie = editUserForm.imie.trim();
		const trimmedNazwisko = editUserForm.nazwisko.trim();
		const effectiveRoleId = isTeamLead ? 1 : editUserForm.rolaId;
		const isLoginRequired = editUserForm.aktywny;

		if (
			(isLoginRequired && !trimmedLogin) ||
			!trimmedImie ||
			!trimmedNazwisko ||
			!effectiveRoleId ||
			!editUserForm.accountType
		) {
			setEditUserError(
				isLoginRequired
					? "Uzupełnij wymagane pola: login, imię, nazwisko, rola i typ konta."
					: editUserForm.accountType === "technical"
					? "Uzupełnij wymagane pola: imię, nazwisko, rola i typ konta."
					: "Uzupełnij wymagane pola: imię, nazwisko i rola.",
			);
			return { ok: false, requiresRelogin: false };
		}

		if (editUserForm.accountType === "technical" && editUserForm.aktywny) {
			setEditUserError(
				"Konto techniczne nie może być aktywne. Ustaw konto jako nieaktywne.",
			);
			return { ok: false, requiresRelogin: false };
		}

		if (editUserForm.accountType === "observer" && !editUserForm.aktywny) {
			setEditUserError(
				"Observer nie może być nieaktywny. Zmień typ konta albo ustaw konto jako aktywne.",
			);
			return { ok: false, requiresRelogin: false };
		}

		if (
			editUserForm.accountType === "diu" &&
			editUserForm.departmentCode !== "DIU"
		) {
			setEditUserError("Dla typu konta DIU departament musi mieć kod DIU.");
			return { ok: false, requiresRelogin: false };
		}

		if (editUserForm.accountType !== "diu" && !editUserForm.departmentCode) {
			setEditUserError("Wybierz departament dla typu obserwator lub techniczny.");
			return { ok: false, requiresRelogin: false };
		}

		const isEditTeamRequired =
			editUserForm.accountType === "diu" &&
			(effectiveRoleId === 1 || effectiveRoleId === 2);
		const effectiveTeamIdForValidation =
			isTeamLead && isEditTeamRequired
				? (editUserForm.zespolId ?? operatorTeamId)
				: editUserForm.zespolId;
		if (isEditTeamRequired && !effectiveTeamIdForValidation) {
			setEditUserError(
				"Dla roli Użytkownik i Kierownik zespołu wybierz zespół.",
			);
			return { ok: false, requiresRelogin: false };
		}

		if (editUserForm.accountType !== "diu" && editUserForm.zespolId) {
			setEditUserError(
				"Dla typu obserwator i techniczny zespół musi być pusty.",
			);
			return { ok: false, requiresRelogin: false };
		}

		setIsUpdatingUser(true);
		setEditUserError(null);
		setInviteError(null);

		try {
			const effectiveIsActive =
				editUserForm.accountType === "technical" ? false : editUserForm.aktywny;
			const effectiveEmail = effectiveIsActive ? editUserForm.email : "";

			const enforcedForm = {
				...editUserForm,
				rolaId: effectiveRoleId,
				email: effectiveEmail,
				aktywny: effectiveIsActive,
				zespolId:
					editUserForm.accountType === "diu"
						? effectiveTeamIdForValidation
						: null,
				departmentCode:
					editUserForm.accountType === "diu"
						? "DIU"
						: editUserForm.departmentCode,
			};

			const result = await updateAdminUser({
				operatorLogin,
				userId: editingUser.id,
				form: enforcedForm,
			});

			if (!result.ok) {
				setEditUserError(result.error);
				return {
					ok: false,
					requiresRelogin: result.status === 401,
				};
			}

			const shouldSendActivationInvite =
				!editingUser.aktywny &&
				effectiveIsActive &&
				(editUserForm.accountType === "diu" ||
					editUserForm.accountType === "observer") &&
				trimmedLogin.length > 0 &&
				effectiveEmail.trim().length > 0;

			if (shouldSendActivationInvite) {
				const frontendInviteUrl =
					typeof window !== "undefined"
						? `${window.location.origin}/set-password`
						: "http://localhost:3002/set-password";

				const inviteResult = await sendAdminUserInvite({
					operatorLogin,
					userId: editingUser.id,
					frontendInviteUrl,
				});

				if (!inviteResult.ok) {
					setInviteError(
						`Użytkownik został aktywowany, ale zaproszenie do ustawienia hasła nie zostało wysłane: ${inviteResult.error}`,
					);
				} else {
					setInviteResult({
						userId: editingUser.id,
						login: trimmedLogin,
						expiresAt: inviteResult.data.expiresAt,
						delivery: inviteResult.data.delivery === "smtp" ? "smtp" : "log",
						inviteLink: inviteResult.data.inviteLink,
					});
				}
			}

			if (!options?.skipClose) {
				closeEditModal();
				await loadUsers();
			}
			return { ok: true, requiresRelogin: false };
		} catch {
			setEditUserError("Brak połączenia z backendem.");
			return { ok: false, requiresRelogin: false };
		} finally {
			setIsUpdatingUser(false);
		}
		},
		[
			canEditUser,
			closeEditModal,
			editUserForm,
			editingUser,
			isTeamLead,
			loadUsers,
			operatorLogin,
			operatorTeamId,
		],
	);

	const sendInvite = useCallback(
		async (user: AdminUser) => {
			if (user.accountType === "technical") {
				setInviteError(
					"Dla konta technicznego nie można wysłać zaproszenia do ustawienia hasła.",
				);
				return false;
			}

			setInviteError(null);
			setInviteResult(null);
			setIsSendingInviteForUserId(user.id);

			try {
				const frontendInviteUrl =
					typeof window !== "undefined"
						? `${window.location.origin}/set-password`
						: "http://localhost:3002/set-password";

				const result = await sendAdminUserInvite({
					operatorLogin,
					userId: user.id,
					frontendInviteUrl,
				});

				if (!result.ok) {
					setInviteError(result.error);
					return false;
				}

				setInviteResult({
					userId: user.id,
					login: user.login,
					expiresAt: result.data.expiresAt,
					delivery:
						result.data.delivery === "smtp" ? "smtp" : "log",
					inviteLink: result.data.inviteLink,
				});
				return true;
			} catch {
				setInviteError("Brak połączenia z backendem.");
				return false;
			} finally {
				setIsSendingInviteForUserId(null);
			}
		},
		[operatorLogin],
	);

	const canSendInvite = useCallback(
		(user: AdminUser) => {
			if (!user.aktywny) {
				return false;
			}

			if (user.accountType === "technical") {
				return false;
			}

			if (isDirector) {
				return true;
			}

			if (isTeamLead) {
				const isInspectorInOperatorTeam =
					Boolean(operatorTeamId) &&
					user.zespolId === operatorTeamId &&
					user.rolaId === 1;

				return isInspectorInOperatorTeam || isUserCreatedByOperator(user);
			}

			return false;
		},
		[isDirector, isTeamLead, isUserCreatedByOperator, operatorTeamId],
	);

	return {
		users: visibleUsers,
		usersError,
		isUsersLoading,
		loadUsers,
		ensureUsersLoaded,
		isAddModalOpen,
		openAddModal,
		closeAddModal,
		isAddingUser,
		addUserError,
		addUserForm,
		setAddUserForm,
		editingUser,
		isEditModalOpen,
		isUpdatingUser,
		editUserError,
		editUserForm,
		setEditUserForm,
		isTeamRequired,
		isRoleLocked,
		isTeamLocked,
		availableTeams,
		lockedTeamLabel,
		isTeamsLoading,
		canEditUser,
		canSendInvite,
		openEditModal,
		closeEditModal,
		submitAddUser,
		submitEditUser,
		sendInvite,
		inviteError,
		inviteResult,
		isSendingInviteForUserId,
	};
}
