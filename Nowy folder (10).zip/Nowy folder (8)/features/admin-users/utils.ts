import { ROLE_OPTIONS } from "@/features/admin-users/constants";

export function getRoleLabelById(roleId: number, fallbackRoleName?: string) {
	const roleOption = ROLE_OPTIONS.find((role) => role.id === roleId);
	if (roleOption) {
		return roleOption.label;
	}

	if (fallbackRoleName) {
		return fallbackRoleName;
	}

	return "Nieznana";
}
