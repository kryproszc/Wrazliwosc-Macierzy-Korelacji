import { useCallback, useMemo, useState } from "react";

import {
	clearInspectionStatusStyle,
	clearRecommendationStatusStyle,
	createDictionaryEntry,
	createTeamEntry,
	fetchDictionaryEntries,
	fetchDictionaryTypes,
	fetchTeamLeaders,
	fetchTeamsAsDictionaryEntries,
	upsertInspectionStatusStyle,
	upsertRecommendationStatusStyle,
} from "@/features/dictionaries/api";
import { DEFAULT_ADD_DICTIONARY_ENTRY_FORM } from "@/features/dictionaries/constants";
import type {
	AddDictionaryEntryForm,
	DictionaryEntry,
	DictionaryType,
	TeamLeaderOption,
} from "@/features/dictionaries/types";

type UseDictionariesSheetParams = {
	operatorLogin: string;
};

let cachedDictionaryTypes: DictionaryType[] | null = null;
const cachedDictionaryEntriesByType = new Map<string, DictionaryEntry[]>();

const UPPERCASE_NO_SPACES_PATTERN = /^[A-Z0-9_-]+$/;
const DICTIONARIES_CHANGED_EVENT = "dictionaries:changed";

const REQUIRED_COMMITMENT_DECISION_TYPES: DictionaryType[] = [
	{
		kodTypu: "rozstrzygniecie_decyzji_i",
		nazwaTypu: "Rozstrzygnięcie decyzji I",
		kategoria: 4,
	},
	{
		kodTypu: "rozstrzygniecie_decyzji_ii",
		nazwaTypu: "Rozstrzygnięcie decyzji II",
		kategoria: 4,
	},
];

export function useDictionariesSheet({
	operatorLogin,
}: UseDictionariesSheetParams) {
	const [types, setTypes] = useState<DictionaryType[]>(() =>
		cachedDictionaryTypes ?? [],
	);
	const [entries, setEntries] = useState<DictionaryEntry[]>([]);
	const [selectedKodTypu, setSelectedKodTypu] = useState(
		() => cachedDictionaryTypes?.[0]?.kodTypu ?? "",
	);

	const [isTypesLoading, setIsTypesLoading] = useState(
		() => cachedDictionaryTypes === null,
	);
	const [isEntriesLoading, setIsEntriesLoading] = useState(false);
	const [typesError, setTypesError] = useState<string | null>(null);
	const [entriesError, setEntriesError] = useState<string | null>(null);

	const [isAddModalOpen, setIsAddModalOpen] = useState(false);
	const [isAddingEntry, setIsAddingEntry] = useState(false);
	const [addEntryError, setAddEntryError] = useState<string | null>(null);
	const [addEntryForm, setAddEntryForm] = useState<AddDictionaryEntryForm>(
		DEFAULT_ADD_DICTIONARY_ENTRY_FORM,
	);
	const [teamLeaders, setTeamLeaders] = useState<TeamLeaderOption[]>([]);
	const [isTeamLeadersLoading, setIsTeamLeadersLoading] = useState(false);

	const isTeamsType = selectedKodTypu.trim().toLowerCase() === "zespoly";

	const selectedType = useMemo(
		() => types.find((type) => type.kodTypu === selectedKodTypu) ?? null,
		[selectedKodTypu, types],
	);

	const mergeRequiredDecisionTypes = useCallback((sourceTypes: DictionaryType[]) => {
		const nextTypes = [...sourceTypes];
		const existingCodes = new Set(
			sourceTypes.map((type) => type.kodTypu.trim().toLowerCase()),
		);

		for (const requiredType of REQUIRED_COMMITMENT_DECISION_TYPES) {
			const normalizedCode = requiredType.kodTypu.trim().toLowerCase();
			if (!existingCodes.has(normalizedCode)) {
				nextTypes.push(requiredType);
			}
		}

		return nextTypes;
	}, []);

	const loadTypes = useCallback(async () => {
		setTypesError(null);
		setIsTypesLoading(types.length === 0);

		if (cachedDictionaryTypes && cachedDictionaryTypes.length > 0) {
			setTypes(cachedDictionaryTypes);
			setSelectedKodTypu(
				(previous) => previous || cachedDictionaryTypes?.[0]?.kodTypu || "",
			);
			setIsTypesLoading(false);
			return;
		}

		try {
			const result = await fetchDictionaryTypes();
			if (!result.ok) {
				setTypes([]);
				cachedDictionaryTypes = null;
				setTypesError(result.error);
				return;
			}

			const mergedTypes = mergeRequiredDecisionTypes(result.data);
			setTypes(mergedTypes);
			cachedDictionaryTypes = mergedTypes;
			if (mergedTypes.length > 0) {
				const firstType = mergedTypes[0];
				if (firstType) {
					setSelectedKodTypu((previous) => previous || firstType.kodTypu);
				}
			}
		} catch {
			setTypes([]);
			cachedDictionaryTypes = null;
			setTypesError("Nie udało się pobrać typów słowników.");
		} finally {
			setIsTypesLoading(false);
		}
	}, [mergeRequiredDecisionTypes, types.length]);

	const loadEntries = useCallback(
		async (kodTypu: string, options?: { forceRefresh?: boolean }) => {
			if (!kodTypu) {
				setEntries([]);
				return;
			}

			const cacheKey = kodTypu.trim().toLowerCase();
			const cachedEntries = cachedDictionaryEntriesByType.get(cacheKey);
			if (cachedEntries && !options?.forceRefresh) {
				setEntries(cachedEntries);
				setEntriesError(null);
				setIsEntriesLoading(false);
				return;
			}

			setEntriesError(null);
			setIsEntriesLoading(true);

			try {
				const normalizedKodTypu = kodTypu.trim().toLowerCase();
				const result =
					normalizedKodTypu === "zespoly"
						? await fetchTeamsAsDictionaryEntries({ operatorLogin })
						: await fetchDictionaryEntries(kodTypu);

				if (!result.ok) {
					setEntries([]);
					setEntriesError(result.error);
					return;
				}

				setEntries(result.data);
				cachedDictionaryEntriesByType.set(normalizedKodTypu, result.data);
			} catch {
				setEntries([]);
				setEntriesError("Nie udało się pobrać pozycji słownika.");
			} finally {
				setIsEntriesLoading(false);
			}
		},
		[operatorLogin],
	);

	const loadTeamLeaders = useCallback(async () => {
		setIsTeamLeadersLoading(true);

		try {
			const result = await fetchTeamLeaders({ operatorLogin });
			if (!result.ok) {
				setTeamLeaders([]);
				return;
			}

			setTeamLeaders(result.data);
		} catch {
			setTeamLeaders([]);
		} finally {
			setIsTeamLeadersLoading(false);
		}
	}, [operatorLogin]);

	const openAddModal = useCallback(() => {
		setAddEntryError(null);
		setAddEntryForm(DEFAULT_ADD_DICTIONARY_ENTRY_FORM);

		if (isTeamsType) {
			void loadTeamLeaders();
		}

		setIsAddModalOpen(true);
	}, [isTeamsType, loadTeamLeaders]);

	const closeAddModal = useCallback(() => {
		setAddEntryError(null);
		setIsAddModalOpen(false);
	}, []);

	const validateForm = useCallback(() => {
		const kodTypu = selectedKodTypu.trim();
		const kodPozycji = addEntryForm.kodPozycji.trim().toUpperCase();
		const skrotPozycji = addEntryForm.skrotPozycji.trim().toUpperCase();
		const nazwaPozycji = addEntryForm.nazwaPozycji.trim();

		if (!kodTypu || !nazwaPozycji) {
			return "Uzupełnij wymagane pola.";
		}

		if (isTeamsType && !skrotPozycji) {
			return "Skrót nazwy zespołu jest wymagany.";
		}

		if (isTeamsType && !UPPERCASE_NO_SPACES_PATTERN.test(skrotPozycji)) {
			return "Skrót nazwy zespołu musi być uppercase i bez spacji.";
		}

		if (
			isTeamsType &&
			kodPozycji &&
			!UPPERCASE_NO_SPACES_PATTERN.test(kodPozycji)
		) {
			return "Kod techniczny zespołu ma nieprawidłowy format.";
		}

		return null;
	}, [addEntryForm, isTeamsType, selectedKodTypu]);

	const submitAddEntry = useCallback(async () => {
		const validationError = validateForm();
		if (validationError) {
			setAddEntryError(validationError);
			return false;
		}

		setAddEntryError(null);
		setIsAddingEntry(true);

		try {
			const teamForm = isTeamsType
				? {
						...addEntryForm,
						kodPozycji: addEntryForm.skrotPozycji.trim().toUpperCase(),
					}
				: addEntryForm;
			const isInspectionStatusesType =
				selectedKodTypu.trim().toLowerCase() === "statusy_inspekcji";
			const isRecommendationStatusesType =
				selectedKodTypu.trim().toLowerCase() === "statusy_zalecen";

			const result = isTeamsType
				? await createTeamEntry({
						operatorLogin,
						form: teamForm,
					})
				: await createDictionaryEntry({
						operatorLogin,
						kodTypu: selectedKodTypu,
						form: teamForm,
					});

			if (!result.ok) {
				setAddEntryError(result.error);
				return false;
			}

			if (!isTeamsType && (isInspectionStatusesType || isRecommendationStatusesType)) {
				let createdEntryId =
					"entryId" in result &&
					typeof result.entryId === "number" &&
					Number.isFinite(result.entryId)
						? result.entryId
						: null;

				if (!createdEntryId) {
					const entriesResult = await fetchDictionaryEntries(selectedKodTypu);
					if (entriesResult.ok) {
						const normalizedCode = teamForm.kodPozycji.trim().toUpperCase();
						const normalizedName = teamForm.nazwaPozycji.trim().toLowerCase();
						const matchedEntries = entriesResult.data
							.filter((entry) => {
								const entryCode = entry.kodPozycji.trim().toUpperCase();
								const entryName = entry.nazwaPozycji.trim().toLowerCase();

								return (
									(normalizedCode ? entryCode === normalizedCode : false) ||
									entryName === normalizedName
								);
							})
							.sort((left, right) => (right.id ?? 0) - (left.id ?? 0));

						const newestMatch = matchedEntries[0];
						if (
							typeof newestMatch?.id === "number" &&
							Number.isFinite(newestMatch.id)
						) {
							createdEntryId = newestMatch.id;
						}
					}
				}

				if (!createdEntryId) {
					setAddEntryError(
						"Pozycja została dodana, ale nie udało się ustalić ID do zapisu koloru. Odśwież listę i ustaw kolor przez edycję.",
					);
					return false;
				}

				const shouldSaveStyle =
					teamForm.kolor &&
					typeof teamForm.odcien === "number" &&
					typeof teamForm.intensywnosc === "number";
				const styleResult =
					isInspectionStatusesType
						? shouldSaveStyle
							? await upsertInspectionStatusStyle({
									operatorLogin,
									slownikPozycjaId: createdEntryId,
									kolor: teamForm.kolor,
									odcien: teamForm.odcien,
									intensywnosc: teamForm.intensywnosc,
							  })
							: await clearInspectionStatusStyle({
									operatorLogin,
									slownikPozycjaId: createdEntryId,
							  })
						: shouldSaveStyle
							? await upsertRecommendationStatusStyle({
									operatorLogin,
									slownikPozycjaId: createdEntryId,
									kolor: teamForm.kolor,
									odcien: teamForm.odcien,
									intensywnosc: teamForm.intensywnosc,
							  })
							: await clearRecommendationStatusStyle({
									operatorLogin,
									slownikPozycjaId: createdEntryId,
							  });

				if (!styleResult.ok) {
					setAddEntryError(
						`Pozycja została dodana, ale nie udało się zapisać koloru: ${styleResult.error}`,
					);
					return false;
				}
			}

			closeAddModal();
			await loadEntries(selectedKodTypu, { forceRefresh: true });
			if (typeof window !== "undefined") {
				window.dispatchEvent(
					new CustomEvent(DICTIONARIES_CHANGED_EVENT, {
						detail: { kodTypu: selectedKodTypu },
					}),
				);
			}
			return true;
		} catch {
			setAddEntryError("Brak połączenia z backendem.");
			return false;
		} finally {
			setIsAddingEntry(false);
		}
	}, [
		addEntryForm,
		closeAddModal,
		isTeamsType,
		loadEntries,
		operatorLogin,
		selectedKodTypu,
		validateForm,
	]);

	return {
		types,
		entries,
		selectedKodTypu,
		selectedType,
		setSelectedKodTypu,
		isTypesLoading,
		isEntriesLoading,
		typesError,
		entriesError,
		loadTypes,
		loadEntries,
		loadTeamLeaders,
		isAddModalOpen,
		openAddModal,
		closeAddModal,
		isAddingEntry,
		addEntryError,
		addEntryForm,
		setAddEntryForm,
		teamLeaders,
		isTeamLeadersLoading,
		isTeamsType,
		submitAddEntry,
	};
}
