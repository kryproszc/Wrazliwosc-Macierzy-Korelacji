import type {
	EmailInspection,
	EmailRecipientsPreview,
	EmailRecipientPreviewItem,
	EmailUser,
	PreviewEmailRecipientsPayload,
	SendEmailPayload,
} from "@/features/email/types";

type ApiErrorResult = {
	ok: false;
	error: string;
	status: number;
};

function buildHeaders(operatorLogin: string) {
	return {
		"Content-Type": "application/json",
		"X-Operator-Login": operatorLogin,
	};
}

async function readApiError(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown; message?: unknown };
		if (typeof payload.detail === "string") {
			return payload.detail;
		}

		if (typeof payload.message === "string") {
			return payload.message;
		}

		if (Array.isArray(payload.detail)) {
			return payload.detail
				.map((item) => {
					if (!item || typeof item !== "object") {
						return "";
					}

					const detail = (item as Record<string, unknown>).msg;
					return typeof detail === "string" ? detail : "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

function toErrorMessage(status: number, fallback: string, detail: string) {
	if (detail) {
		return detail;
	}

	if (status === 403) {
		return "Brak uprawnień do tej operacji.";
	}

	if (status === 404) {
		return "Nie znaleziono wskazanego zasobu.";
	}

	if (status === 422) {
		return "Nieprawidłowe dane wejściowe (422).";
	}

	if (status === 500) {
		return "Błąd serwera. Spróbuj ponownie.";
	}

	return `${fallback} (${status}).`;
}

async function toErrorResult(
	response: Response,
	fallback: string,
): Promise<ApiErrorResult> {
	const detail = await readApiError(response);
	return {
		ok: false,
		error: toErrorMessage(response.status, fallback, detail),
		status: response.status,
	};
}

function parseEmailUser(item: unknown): EmailUser | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id = typeof source.id === "number" ? source.id : null;
	const login = typeof source.login === "string" ? source.login.trim() : "";
	const email =
		typeof source.email === "string"
			? source.email.trim()
			: typeof source.mail === "string"
				? source.mail.trim()
				: "";
	const displayName =
		typeof source.displayName === "string"
			? source.displayName.trim()
			: typeof source.fullName === "string"
				? source.fullName.trim()
				: `${typeof source.imie === "string" ? source.imie.trim() : ""} ${typeof source.nazwisko === "string" ? source.nazwisko.trim() : ""}`.trim();

	if (!id || !email) {
		return null;
	}

	return {
		id,
		login,
		email,
		displayName: displayName || login || email,
	};
}

function parseInspection(item: unknown): EmailInspection | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id =
		typeof source.id === "string"
			? source.id.trim()
			: typeof source.id === "number"
				? String(source.id)
				: "";
	const code =
		typeof source.code === "string"
			? source.code.trim()
			: typeof source.inspectionCode === "string"
				? source.inspectionCode.trim()
				: "";
	const label =
		typeof source.label === "string"
			? source.label.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: code || id;

	if (!id) {
		return null;
	}

	return {
		id,
		label: code ? `${code}${label && label !== code ? ` - ${label}` : ""}` : label,
	};
}

function parsePreviewItem(item: unknown): EmailRecipientPreviewItem | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const email = typeof source.email === "string" ? source.email.trim() : "";
	if (!email) {
		return null;
	}

	const userId = typeof source.userId === "number" ? source.userId : null;
	const displayName =
		typeof source.displayName === "string"
			? source.displayName.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: email;
	const sourceLabel =
		typeof source.source === "string"
			? source.source.trim()
			: typeof source.origin === "string"
				? source.origin.trim()
				: "";

	return {
		userId,
		displayName: displayName || email,
		email,
		source: sourceLabel,
	};
}

export async function fetchEmailUsers(operatorLogin: string, query?: string) {
	const params = new URLSearchParams();
	if (query?.trim()) {
		params.set("q", query.trim());
	}

	const response = await fetch(
		`/api/admin/email/users${params.toString() ? `?${params.toString()}` : ""}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać użytkowników");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseEmailUser(item))
				.filter((item): item is EmailUser => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchEmailInspections(operatorLogin: string, query?: string) {
	const params = new URLSearchParams();
	if (query?.trim()) {
		params.set("q", query.trim());
	}

	const response = await fetch(
		`/api/admin/email/inspections${params.toString() ? `?${params.toString()}` : ""}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać listy inspekcji");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseInspection(item))
				.filter((item): item is EmailInspection => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchEmailInspectionMembers(
	operatorLogin: string,
	inspectionId: string,
) {
	const response = await fetch(
		`/api/admin/email/inspections/${encodeURIComponent(inspectionId)}/members`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać członków inspekcji");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseEmailUser(item))
				.filter((item): item is EmailUser => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function previewEmailRecipients(
	operatorLogin: string,
	payload: PreviewEmailRecipientsPayload,
) {
	const response = await fetch("/api/admin/email/recipients/preview", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać podglądu odbiorców");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const rawItems = Array.isArray(source.items) ? source.items : [];
	const items = rawItems
		.map((item) => parsePreviewItem(item))
		.filter((item): item is EmailRecipientPreviewItem => item !== null);
	const total =
		typeof source.total === "number" && Number.isFinite(source.total)
			? Math.max(0, Math.trunc(source.total))
			: items.length;

	const preview: EmailRecipientsPreview = {
		total,
		items,
	};

	return { ok: true as const, preview };
}

export async function sendEmailMessage(
	operatorLogin: string,
	payload: SendEmailPayload,
) {
	const response = await fetch("/api/admin/email/send", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się wysłać wiadomości");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const jobId =
		typeof source.jobId === "string"
			? source.jobId
			: typeof source.id === "string"
				? source.id
				: "";

	return { ok: true as const, jobId };
}
