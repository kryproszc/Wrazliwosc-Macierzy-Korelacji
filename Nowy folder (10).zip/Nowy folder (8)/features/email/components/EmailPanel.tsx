"use client";

import { Mail, Send } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
	Alert,
	Box,
	Button,
	Card,
	CardContent,
	Checkbox,
	Chip,
	CircularProgress,
	Divider,
	FormControlLabel,
	Radio,
	RadioGroup,
	Stack,
	TextField,
	Typography,
} from "@mui/material";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
	fetchEmailInspectionMembers,
	fetchEmailInspections,
	fetchEmailUsers,
	previewEmailRecipients,
	sendEmailMessage,
} from "@/features/email/api";
import type {
	EmailInspection,
	EmailRecipientMode,
	EmailRecipientsPreview,
	EmailUser,
} from "@/features/email/types";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";

type EmailPanelProps = {
	operatorLogin: string;
	authRole: AuthRole;
};

const RECIPIENT_MODE_OPTIONS: Array<{
	id: EmailRecipientMode;
	label: string;
	description: string;
}> = [
	{
		id: "selected_users",
		label: "Wybrani użytkownicy",
		description: "Ręczny wybór konkretnych osób z listy użytkowników.",
	},
	{
		id: "inspection_members",
		label: "Użytkownicy z inspekcji",
		description: "Automatyczny dobór odbiorców z wybranej inspekcji.",
	},
	{
		id: "all_users",
		label: "Wszyscy z bazy",
		description: "Wysłanie do wszystkich aktywnych adresów w systemie.",
	},
];

function buildUserLabel(user: EmailUser) {
	const details = [user.login, user.email].filter(Boolean).join(" | ");
	return details ? `${user.displayName} (${details})` : user.displayName;
}

export function EmailPanel({ operatorLogin, authRole }: EmailPanelProps) {
	const [isLoading, setIsLoading] = useState(true);
	const [isSending, setIsSending] = useState(false);
	const [isPreviewLoading, setIsPreviewLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [successMessage, setSuccessMessage] = useState<string | null>(null);

	const [recipientMode, setRecipientMode] =
		useState<EmailRecipientMode>("selected_users");
	const [users, setUsers] = useState<EmailUser[]>([]);
	const [inspections, setInspections] = useState<EmailInspection[]>([]);
	const [inspectionMembers, setInspectionMembers] = useState<EmailUser[]>([]);
	const [selectedUserIds, setSelectedUserIds] = useState<number[]>([]);
	const [selectedInspectionId, setSelectedInspectionId] = useState("");
	const [subject, setSubject] = useState("");
	const [body, setBody] = useState("");
	const [preview, setPreview] = useState<EmailRecipientsPreview | null>(null);
	const [formError, setFormError] = useState<string | null>(null);
	const [usersSearch, setUsersSearch] = useState("");

	const userById = useMemo(
		() => new Map(users.map((user) => [user.id, user])),
		[users],
	);

	const selectedUsersLabel = useMemo(() => {
		if (selectedUserIds.length === 0) {
			return "Brak wybranych użytkowników";
		}

		if (selectedUserIds.length === 1) {
			const firstSelectedId = selectedUserIds[0];
			if (firstSelectedId === undefined) {
				return "1 użytkownik";
			}

			const user = userById.get(firstSelectedId);
			return user ? buildUserLabel(user) : "1 użytkownik";
		}

		return `${selectedUserIds.length} wybranych użytkowników`;
	}, [selectedUserIds, userById]);

	const filteredUsers = useMemo(() => {
		const query = usersSearch.trim().toLowerCase();
		if (!query) {
			return users;
		}

		return users.filter((user) => {
			const searchable = `${user.displayName} ${user.login} ${user.email}`.toLowerCase();
			return searchable.includes(query);
		});
	}, [users, usersSearch]);

	const validateForm = useCallback(() => {
		if (!subject.trim()) {
			return "Temat wiadomości jest wymagany.";
		}

		if (!body.trim()) {
			return "Treść wiadomości jest wymagana.";
		}

		if (recipientMode === "selected_users" && selectedUserIds.length === 0) {
			return "Wybierz co najmniej jednego użytkownika.";
		}

		if (recipientMode === "inspection_members" && !selectedInspectionId.trim()) {
			return "Wybierz inspekcję dla odbiorców.";
		}

		return null;
	}, [body, recipientMode, selectedInspectionId, selectedUserIds.length, subject]);

	const buildRecipientsPayload = useCallback(() => {
		if (recipientMode === "selected_users") {
			return {
				recipientMode,
				selectedUserIds,
			};
		}

		if (recipientMode === "inspection_members") {
			return {
				recipientMode,
				inspectionId: selectedInspectionId,
			};
		}

		return {
			recipientMode,
		};
	}, [recipientMode, selectedInspectionId, selectedUserIds]);

	useEffect(() => {
		const loadInitial = async () => {
			setIsLoading(true);
			setError(null);

			const [usersResponse, inspectionsResponse] = await Promise.all([
				fetchEmailUsers(operatorLogin),
				fetchEmailInspections(operatorLogin),
			]);

			if (!usersResponse.ok) {
				setError(usersResponse.error);
				setUsers([]);
			} else {
				setUsers(usersResponse.items);
			}

			if (!inspectionsResponse.ok) {
				setError((previous) => previous ?? inspectionsResponse.error);
				setInspections([]);
			} else {
				setInspections(inspectionsResponse.items);
			}

			setIsLoading(false);
		};

		void loadInitial();
	}, [operatorLogin]);

	useEffect(() => {
		if (recipientMode !== "inspection_members" || !selectedInspectionId.trim()) {
			setInspectionMembers([]);
			return;
		}

		let isCancelled = false;
		const loadMembers = async () => {
			const response = await fetchEmailInspectionMembers(
				operatorLogin,
				selectedInspectionId,
			);

			if (isCancelled) {
				return;
			}

			if (!response.ok) {
				setInspectionMembers([]);
				setError((previous) => previous ?? response.error);
				return;
			}

			setInspectionMembers(response.items);
		};

		void loadMembers();

		return () => {
			isCancelled = true;
		};
	}, [operatorLogin, recipientMode, selectedInspectionId]);

	const handleToggleUser = (userId: number) => {
		setSelectedUserIds((previous) => {
			if (previous.includes(userId)) {
				return previous.filter((id) => id !== userId);
			}

			return [...previous, userId];
		});
	};

	const handlePreviewRecipients = async () => {
		setFormError(null);
		setError(null);
		setSuccessMessage(null);
		const validationError = validateForm();
		if (validationError) {
			setFormError(validationError);
			return;
		}

		setIsPreviewLoading(true);
		const response = await previewEmailRecipients(
			operatorLogin,
			buildRecipientsPayload(),
		);
		setIsPreviewLoading(false);

		if (!response.ok) {
			setError(response.error);
			setPreview(null);
			return;
		}

		setPreview(response.preview);
	};

	const handleSendEmail = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		setFormError(null);
		setError(null);
		setSuccessMessage(null);

		const validationError = validateForm();
		if (validationError) {
			setFormError(validationError);
			return;
		}

		setIsSending(true);
		const response = await sendEmailMessage(operatorLogin, {
			...buildRecipientsPayload(),
			subject: subject.trim(),
			body: body.trim(),
		});
		setIsSending(false);

		if (!response.ok) {
			setError(response.error);
			return;
		}

		setSuccessMessage(
			response.jobId
				? `Wiadomość została przekazana do wysyłki (ID: ${response.jobId}).`
				: "Wiadomość została przekazana do wysyłki.",
		);
	};

	if (authRole !== "director") {
		return (
			<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
				<p className="rounded-lg border border-amber-300/45 bg-amber-950/30 px-3 py-2 text-amber-200 text-sm">
					Tylko dyrektor może wysyłać wiadomości e-mail.
				</p>
			</section>
		);
	}

	if (isLoading) {
		return (
			<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-6">
				<p className="text-slate-300 text-sm">Ładowanie panelu e-mail...</p>
			</section>
		);
	}

	return (
		<section className="relative flex h-full min-h-0 flex-col rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
			<Stack spacing={2.5} className="min-h-0 flex-1">
				<Box className="flex items-center gap-2 border-slate-700/70 border-b pb-3">
					<Mail size={16} className="text-slate-200" />
					<Typography variant="h6" sx={{ color: "#e2e8f0", fontWeight: 700 }}>
						E-mail
					</Typography>
				</Box>

				{error ? <Alert severity="error">{error}</Alert> : null}

				{successMessage ? <Alert severity="success">{successMessage}</Alert> : null}

				<form className="min-h-0 flex-1" onSubmit={handleSendEmail}>
					<Stack spacing={2.5} className="min-h-0 h-full">
						<Box
							sx={{
								display: "grid",
								gap: 16,
								gridTemplateColumns: {
									xs: "minmax(0, 1fr)",
									xl: "minmax(0, 1.05fr) minmax(0, 1.2fr)",
								},
							}}
						>
							<Card variant="outlined" sx={{ borderRadius: 3 }}>
								<CardContent>
									<Stack spacing={2}>
										<Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
											Odbiorcy
										</Typography>

										<RadioGroup
											name="recipient-mode"
											value={recipientMode}
											onChange={(event) => {
												setRecipientMode(event.target.value as EmailRecipientMode);
												setPreview(null);
											}}
										>
											<Stack spacing={1}>
												{RECIPIENT_MODE_OPTIONS.map((option) => (
													<Box
														key={option.id}
														sx={{
															border: "1px solid",
															borderColor:
																recipientMode === option.id ? "primary.main" : "divider",
															borderRadius: 2,
															px: 1.25,
															py: 1,
															bgcolor:
																recipientMode === option.id ? "action.selected" : "background.paper",
														}}
													>
														<FormControlLabel
															value={option.id}
															control={<Radio size="small" />}
															label={
																<Box>
																	<Typography variant="body2" sx={{ fontWeight: 600 }}>
																		{option.label}
																	</Typography>
																	<Typography variant="caption" color="text.secondary">
																		{option.description}
																	</Typography>
																</Box>
															}
															sx={{ m: 0, alignItems: "flex-start" }}
														/>
													</Box>
												))}
											</Stack>
										</RadioGroup>

										{recipientMode === "selected_users" ? (
											<Stack spacing={1.25} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
												<TextField
													size="small"
													label="Szukaj użytkownika"
													value={usersSearch}
													onChange={(event) => setUsersSearch(event.target.value)}
													placeholder="Nazwisko, login lub e-mail"
												/>
												<Box
													sx={{
														maxHeight: 240,
														overflowY: "auto",
														border: "1px solid",
														borderColor: "divider",
														borderRadius: 2,
														p: 1,
														bgcolor: "#f8fafc",
													}}
												>
													{filteredUsers.length === 0 ? (
														<Typography variant="caption" color="text.secondary">
															Brak użytkowników.
														</Typography>
													) : (
														<Stack spacing={0.25}>
															{filteredUsers.map((user) => {
																const checked = selectedUserIds.includes(user.id);
																return (
																	<FormControlLabel
																		key={user.id}
																		control={
																			<Checkbox
																				size="small"
																				checked={checked}
																				onChange={() => handleToggleUser(user.id)}
																			/>
																		}
																		label={
																			<Typography variant="caption" sx={{ lineHeight: 1.35 }}>
																				{buildUserLabel(user)}
																			</Typography>
																		}
																		sx={{ m: 0, width: "100%" }}
																	/>
																);
															})}
														</Stack>
													)}
												</Box>
												<Chip
													size="small"
													variant="outlined"
													label={selectedUsersLabel}
													sx={{ alignSelf: "flex-start" }}
												/>
											</Stack>
										) : null}

										{recipientMode === "inspection_members" ? (
											<Stack spacing={1.25} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
												<SingleSelectPortalField
													label="Inspekcja"
													value={selectedInspectionId}
													options={inspections.map((inspection) => ({
														value: inspection.id,
														label: inspection.label,
													}))}
													placeholder="Wybierz inspekcję"
													onChange={(next) => {
														setSelectedInspectionId(next);
														setPreview(null);
													}}
													enableSearch
													searchPlaceholder="Szukaj inspekcji..."
												/>
												<Alert severity="info" sx={{ py: 0 }}>
													Liczba członków wybranej inspekcji: {inspectionMembers.length}
												</Alert>
											</Stack>
										) : null}

										{recipientMode === "all_users" ? (
											<Alert severity="warning">
												Tryb masowy: wiadomość zostanie wysłana do wszystkich odbiorców z bazy.
											</Alert>
										) : null}
									</Stack>
								</CardContent>
							</Card>

							<Card variant="outlined" sx={{ borderRadius: 3 }}>
								<CardContent>
									<Stack spacing={2}>
										<Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
											Treść wiadomości
										</Typography>

										<TextField
											required
											size="small"
											label="Temat wiadomości"
											value={subject}
											onChange={(event) => setSubject(event.target.value)}
										/>

										<TextField
											required
											label="Treść wiadomości"
											value={body}
											onChange={(event) => setBody(event.target.value)}
											multiline
											minRows={12}
										/>

										<Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5, bgcolor: "#f8fafc" }}>
											<Box className="mb-2 flex items-center justify-between gap-2">
												<Typography variant="body2" sx={{ fontWeight: 600 }}>
													Podgląd odbiorców
												</Typography>
												<Button
													type="button"
													onClick={() => void handlePreviewRecipients()}
													disabled={isPreviewLoading || isSending}
													variant="outlined"
													size="small"
												>
													{isPreviewLoading ? "Ładowanie..." : "Odśwież podgląd"}
												</Button>
											</Box>
											{preview ? (
												<Stack spacing={1}>
													<Chip
														size="small"
														color="primary"
														variant="outlined"
														label={`Łącznie odbiorców: ${preview.total}`}
														sx={{ alignSelf: "flex-start" }}
													/>
													<Box
														sx={{
															maxHeight: 180,
															overflowY: "auto",
															bgcolor: "background.paper",
															border: "1px solid",
															borderColor: "divider",
															borderRadius: 2,
															p: 1,
														}}
													>
														{preview.items.length === 0 ? (
															<Typography variant="caption" color="text.secondary">
																Brak danych podglądu.
															</Typography>
														) : (
															<Stack spacing={0.5}>
																{preview.items.slice(0, 50).map((item, index) => (
																	<Typography key={`${item.email}-${index}`} variant="caption">
																		{item.displayName} - {item.email}
																		{item.source ? ` (${item.source})` : ""}
																	</Typography>
																))}
															</Stack>
														)}
													</Box>
												</Stack>
											) : (
												<Typography variant="caption" color="text.secondary">
													Uruchom podgląd, aby sprawdzić listę odbiorców.
												</Typography>
											)}
										</Box>
									</Stack>
								</CardContent>
							</Card>
						</Box>

						{formError ? <Alert severity="error">{formError}</Alert> : null}

						<Divider sx={{ borderColor: "rgba(148, 163, 184, 0.45)" }} />

						<Box className="flex justify-end">
							<Button
								type="submit"
								disabled={isSending || isPreviewLoading}
								variant="contained"
								startIcon={
									isSending ? <CircularProgress size={14} color="inherit" /> : <Send size={14} />
								}
								sx={{
									textTransform: "none",
									fontWeight: 700,
									px: 2,
									bgcolor: "#2d4d7f",
									"&:hover": { bgcolor: "#375f99" },
								}}
							>
								{isSending ? "Wysyłanie..." : "Wyślij wiadomość"}
							</Button>
						</Box>
					</Stack>
				</form>
			</Stack>
		</section>
	);
}
