export type EmailRecipientMode = "selected_users" | "inspection_members" | "all_users";

export type EmailUser = {
	id: number;
	login: string;
	displayName: string;
	email: string;
};

export type EmailInspection = {
	id: string;
	label: string;
};

export type EmailRecipientPreviewItem = {
	userId: number | null;
	displayName: string;
	email: string;
	source: string;
};

export type EmailRecipientsPreview = {
	total: number;
	items: EmailRecipientPreviewItem[];
};

export type PreviewEmailRecipientsPayload = {
	recipientMode: EmailRecipientMode;
	selectedUserIds?: number[];
	inspectionId?: string;
};

export type SendEmailPayload = PreviewEmailRecipientsPayload & {
	subject: string;
	body: string;
};
