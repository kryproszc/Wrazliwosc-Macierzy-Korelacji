type InspectionTimelineMode = "control" | "visit";

type InspectionDatesValidationKind =
	| "status-forbids-dates"
	| "status-extra-dates"
	| "status-extra-no-suggestion"
	| "timeline-continuity"
	| "status-required"
	| "status-mismatch";

type InspectionDatesValidationModalData = {
	kind: InspectionDatesValidationKind;
	mode: InspectionTimelineMode;
	selectedStatusCode: string;
	suggestedStatusCode: string | null;
	enteredFieldNumbers: number[];
	expectedFieldNumbers: number[];
	missingFieldNumbers: number[];
	message: string;
};

type InspectionStatusGuidanceItem = {
	statusCode: string;
	missingFieldNumbers: number[];
	extraFieldNumbers: number[];
};

type InspectionDatesValidationModalProps = {
	inspectionDatesValidationModalData: InspectionDatesValidationModalData;
	onClose: () => void;
	onConfirmSave: () => void;
	getInspectionStatusLabelByCode: (code: string) => string;
	getInspectionDateFieldLabelForValidation: (fieldNumber: number) => string;
	getForbiddenDatesStatusGuidanceItems: (modalData: InspectionDatesValidationModalData) => Array<{
		statusCode: string;
		requiredFieldNumbers: number[];
		missingFieldNumbers: number[];
	}>;
	getControlClosedStatusMissingFieldNumbersForForbiddenDates: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getControlIS14StatusGuidanceItem: (
		modalData: InspectionDatesValidationModalData,
	) => { statusCode: string; missingFieldNumbers: number[] } | null;
	getControlClosedStatusMissingFieldNumbersForIS14ExtraDates: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	shouldShowControlIS4ToIS8Guidance: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getControlIS4ToIS6MissingFieldNumbers: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	shouldShowControlIS6ToIS8Guidance: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getControlIS6ToIS8MissingFieldNumbers: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getControlIS4ToIS8MissingFieldNumbers: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getVisitIS11StatusGuidanceItem: (
		modalData: InspectionDatesValidationModalData,
	) => InspectionStatusGuidanceItem | null;
	getVisitIS5StatusGuidanceItem: (
		modalData: InspectionDatesValidationModalData,
	) => InspectionStatusGuidanceItem | null;
	hasVisitIS11ClosedFieldsCompleted: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getVisitClosedStatusMissingFieldNumbersForIS11: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	hasVisitIS5ClosedFieldsCompleted: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getVisitClosedStatusMissingFieldNumbersForIS5: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getControlClosedStatusMissingFieldNumbersForIS4ExtraDates: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	hasControlIS4ClosedFieldsCompleted: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getControlClosedStatusMissingFieldNumbersForIS6ExtraDates: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	hasControlIS6ClosedFieldsCompleted: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	getControlIS8LowerStatusGuidanceCode: (
		modalData: InspectionDatesValidationModalData,
	) => string | null;
	getVisitIS8LowerStatusGuidanceCode: (
		modalData: InspectionDatesValidationModalData,
	) => string | null;
	getControlIS4StatusGuidanceItem: (
		modalData: InspectionDatesValidationModalData,
	) => InspectionStatusGuidanceItem | null;
	getControlIS6StatusGuidanceItem: (
		modalData: InspectionDatesValidationModalData,
	) => InspectionStatusGuidanceItem | null;
	getControlIS6LowerStatusGuidanceCode: (
		modalData: InspectionDatesValidationModalData,
	) => string | null;
	getVisitClosedStatusMissingFieldNumbersForIS8Required: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getControlClosedStatusMissingFieldNumbersForIS8Required: (
		modalData: InspectionDatesValidationModalData,
	) => number[];
	getOptionalFieldNumberForStatusIS8: (
		modalData: InspectionDatesValidationModalData,
	) => number | null;
	shouldShowClosedStatusGuidance: (
		modalData: InspectionDatesValidationModalData,
	) => boolean;
	inspectionDateFieldLabelByNumber: Record<number, string>;
	optionalAcceptanceNoteValidationLabel: string;
};

export function InspectionDatesValidationModal({
	inspectionDatesValidationModalData,
	onClose,
	onConfirmSave,
	getInspectionStatusLabelByCode,
	getInspectionDateFieldLabelForValidation,
	getForbiddenDatesStatusGuidanceItems,
	getControlClosedStatusMissingFieldNumbersForForbiddenDates,
	getControlIS14StatusGuidanceItem,
	getControlClosedStatusMissingFieldNumbersForIS14ExtraDates,
	shouldShowControlIS4ToIS8Guidance,
	getControlIS4ToIS6MissingFieldNumbers,
	shouldShowControlIS6ToIS8Guidance,
	getControlIS6ToIS8MissingFieldNumbers,
	getControlIS4ToIS8MissingFieldNumbers,
	getVisitIS11StatusGuidanceItem,
	getVisitIS5StatusGuidanceItem,
	hasVisitIS11ClosedFieldsCompleted,
	getVisitClosedStatusMissingFieldNumbersForIS11,
	hasVisitIS5ClosedFieldsCompleted,
	getVisitClosedStatusMissingFieldNumbersForIS5,
	getControlClosedStatusMissingFieldNumbersForIS4ExtraDates,
	hasControlIS4ClosedFieldsCompleted,
	getControlClosedStatusMissingFieldNumbersForIS6ExtraDates,
	hasControlIS6ClosedFieldsCompleted,
	getControlIS8LowerStatusGuidanceCode,
	getVisitIS8LowerStatusGuidanceCode,
	getControlIS4StatusGuidanceItem,
	getControlIS6StatusGuidanceItem,
	getControlIS6LowerStatusGuidanceCode,
	getVisitClosedStatusMissingFieldNumbersForIS8Required,
	getControlClosedStatusMissingFieldNumbersForIS8Required,
	getOptionalFieldNumberForStatusIS8,
	shouldShowClosedStatusGuidance,
	inspectionDateFieldLabelByNumber,
	optionalAcceptanceNoteValidationLabel,
}: InspectionDatesValidationModalProps) {
	return (
		<div className="fixed inset-0 z-60 flex items-center justify-center p-4">
			<button
				type="button"
				aria-label="Zamknij okno walidacji dat inspekcji"
				className="absolute inset-0 bg-slate-950/65"
				onClick={onClose}
			/>

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Walidacja dat i statusu inspekcji"
				className="relative z-10 w-full max-w-3xl rounded-2xl border border-slate-300 bg-white p-5 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)]"
			>
				<h3 className="font-semibold text-base text-slate-900">
					Nie można zapisać inspekcji
				</h3>
				{inspectionDatesValidationModalData.kind === "status-forbids-dates" ||
				inspectionDatesValidationModalData.kind === "status-extra-dates" ||
				inspectionDatesValidationModalData.kind ===
					"status-extra-no-suggestion" ? null : (
					<p className="mt-2 text-slate-800 text-sm">
						{inspectionDatesValidationModalData.message}
					</p>
				)}

				<div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3">
					{inspectionDatesValidationModalData.kind === "status-forbids-dates" ? (
						<>
							<p className="font-semibold text-blue-900 text-sm">
								Dla statusu:{" "}
								<span className="font-bold">
									{getInspectionStatusLabelByCode(
										inspectionDatesValidationModalData.selectedStatusCode,
									)}
								</span>{" "}
								nie powinny być uzupełnione poniższe pola dat:
							</p>
							{inspectionDatesValidationModalData.enteredFieldNumbers.length > 0 ? (
								<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
									{inspectionDatesValidationModalData.enteredFieldNumbers.map(
										(fieldNumber) => (
											<li key={`entered-field-${fieldNumber}`}>
												{getInspectionDateFieldLabelForValidation(fieldNumber)}
											</li>
										),
									)}
								</ul>
							) : (
								<p className="mt-2 text-blue-900 text-sm">
									Brak wprowadzonych dat dla tego statusu.
								</p>
							)}
							{(() => {
								const forbiddenDatesGuidanceItems =
									getForbiddenDatesStatusGuidanceItems(
										inspectionDatesValidationModalData,
									);

								if (forbiddenDatesGuidanceItems.length === 0) {
									return null;
								}

								return (
									<div className="mt-2 pt-1">
										{forbiddenDatesGuidanceItems.map((guidanceItem) =>
											guidanceItem.missingFieldNumbers.length > 0 ? (
												<div
													className="mt-2"
													key={`forbidden-guidance-${guidanceItem.statusCode}`}
												>
													<p className="text-blue-900 text-sm">
														Aby ustawić status{" "}
														<span className="font-semibold">
															{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
														</span>{" "}
														uzupełnij:
													</p>
													<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
														{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
															<li
																key={`forbidden-guidance-field-${guidanceItem.statusCode}-${fieldNumber}`}
															>
																{getInspectionDateFieldLabelForValidation(fieldNumber)}
															</li>
														))}
													</ul>
												</div>
											) : (
												<p
													className="mt-2 text-blue-900 text-sm"
													key={`forbidden-guidance-complete-${guidanceItem.statusCode}`}
												>
													Status zgodny z danymi:{" "}
													<span className="font-semibold">
														{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
													</span>
													.
												</p>
											),
										)}
									</div>
								);
							})()}
							{(() => {
								const missingClosedFields =
									getControlClosedStatusMissingFieldNumbersForForbiddenDates(
										inspectionDatesValidationModalData,
									);

								if (missingClosedFields.length === 0) {
									return null;
								}

								return (
									<div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900 text-sm">
										<p>
											Jeśli zamykasz inspekcję, to w zależności od tego, czy dodano zalecenie oraz wniosek sankcyjny, ustaw status:
										</p>
										<ul className="mt-2 list-disc space-y-1 pl-5">
											<li>
												<strong>Zamknięte - wydano zalecenia</strong>
											</li>
											<li>
												<strong>Zamknięte - brak zaleceń i wniosku sankcyjnego</strong>
											</li>
											<li>
												<strong>Zamknięte - sporządzono wniosek sankcyjny</strong>
											</li>
											<li>
												<strong>Zamknięte - wydano zalecenia i sporządzono wniosek sankcyjny</strong>
											</li>
										</ul>
									</div>
								);
							})()}
						</>
					) : inspectionDatesValidationModalData.kind === "status-extra-dates" ? (
						<>
							{inspectionDatesValidationModalData.mode === "control" &&
							inspectionDatesValidationModalData.selectedStatusCode === "I_SI_14" ? (
								<>
									{inspectionDatesValidationModalData.missingFieldNumbers.includes(1) ? (
										<>
											<p className="font-semibold text-blue-900 text-sm">
												Dla statusu:{" "}
												<span className="font-bold">
													{getInspectionStatusLabelByCode(
														inspectionDatesValidationModalData.selectedStatusCode,
													)}
												</span>{" "}
												należy uzupełnić:
											</p>
											<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
												{(
													inspectionDatesValidationModalData.expectedFieldNumbers.length >
													0
														? inspectionDatesValidationModalData.expectedFieldNumbers
														: [1]
												).map((fieldNumber) => (
													<li key={`is14-required-field-${fieldNumber}`}>
														{getInspectionDateFieldLabelForValidation(fieldNumber)}
													</li>
												))}
											</ul>
										</>
									) : (
										<>
											<p className="font-semibold text-blue-900 text-sm">
												Dla statusu:{" "}
												<span className="font-bold">
													{getInspectionStatusLabelByCode(
														inspectionDatesValidationModalData.selectedStatusCode,
													)}
												</span>{" "}
												nie powinny być uzupełnione poniższe pola dat:
											</p>
											{inspectionDatesValidationModalData.enteredFieldNumbers.length >
											0 ? (
												<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
													{inspectionDatesValidationModalData.enteredFieldNumbers.map(
														(fieldNumber) => (
															<li key={`is14-extra-field-${fieldNumber}`}>
																{getInspectionDateFieldLabelForValidation(fieldNumber)}
															</li>
														),
													)}
												</ul>
											) : (
												<p className="mt-2 text-blue-900 text-sm">-</p>
											)}
										</>
									)}
								</>
							) : (
								<>
									<p className="font-semibold text-blue-900 text-sm">
										Dla statusu:{" "}
										<span className="font-bold">
											{getInspectionStatusLabelByCode(
												inspectionDatesValidationModalData.selectedStatusCode,
											)}
										</span>
									</p>
									<div className="mt-2 grid grid-cols-2 gap-3 text-blue-900 text-sm">
										<div>
											<p className="font-semibold">Wymagana jest data:</p>
											{inspectionDatesValidationModalData.expectedFieldNumbers.length >
											0 ? (
												<ul className="mt-1 list-disc space-y-1 pl-5">
													{inspectionDatesValidationModalData.expectedFieldNumbers.map(
														(fieldNumber) => (
															<li key={`expected-field-${fieldNumber}`}>
																{getInspectionDateFieldLabelForValidation(fieldNumber)}
															</li>
														),
													)}
												</ul>
											) : (
												<p className="mt-1">-</p>
											)}
										</div>
										<div>
											<p className="font-semibold">Wprowadzono dodatkowo:</p>
											{inspectionDatesValidationModalData.enteredFieldNumbers.length >
											0 ? (
												<ul className="mt-1 list-disc space-y-1 pl-5">
													{inspectionDatesValidationModalData.enteredFieldNumbers.map(
														(fieldNumber) => (
															<li key={`extra-field-${fieldNumber}`}>
																{getInspectionDateFieldLabelForValidation(fieldNumber)}
															</li>
														),
													)}
												</ul>
											) : (
												<p className="mt-1">-</p>
											)}
										</div>
									</div>
								</>
							)}
							{(() => {
								const guidanceItem = getControlIS14StatusGuidanceItem(
									inspectionDatesValidationModalData,
								);

								if (!guidanceItem) {
									return null;
								}

								return guidanceItem.missingFieldNumbers.length > 0 ? (
									<div className="mt-3 border-blue-200 border-t pt-3">
										{inspectionDatesValidationModalData.missingFieldNumbers.includes(1) &&
										inspectionDatesValidationModalData.enteredFieldNumbers.length > 0 ? (
											<>
												<p className="mt-2 font-semibold text-blue-900 text-sm">
													Dodatkowo nie powinny być uzupełnione poniższe pola dat:
												</p>
												<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
													{inspectionDatesValidationModalData.enteredFieldNumbers.map(
														(fieldNumber) => (
															<li key={`is14-extra-field-${fieldNumber}`}>
																{getInspectionDateFieldLabelForValidation(fieldNumber)}
															</li>
														),
													)}
												</ul>
											</>
										) : null}
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {inspectionDatesValidationModalData.enteredFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {guidanceItem.missingFieldNumbers.length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
												<li key={`is14-guidance-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
											</span>
											.
										</p>
									</div>
								) : (
									<p className="mt-3 border-blue-200 border-t pt-3 text-blue-900 text-sm">
										Status zgodny z danymi:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
										</span>
										.
									</p>
								);
							})()}
							{(() => {
								const missingClosedFields =
									getControlClosedStatusMissingFieldNumbersForIS14ExtraDates(
										inspectionDatesValidationModalData,
									);

								if (missingClosedFields.length === 0) {
									return null;
								}

								return (
									<div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900 text-sm">
										<p>
											Jeśli zamykasz inspekcję, to w zależności od tego, czy dodano zalecenie oraz wniosek sankcyjny, ustaw status:
										</p>
										<ul className="mt-2 list-disc space-y-1 pl-5">
											<li>
												<strong>Zamknięte - wydano zalecenia</strong>
											</li>
											<li>
												<strong>Zamknięte - brak zaleceń i wniosku sankcyjnego</strong>
											</li>
											<li>
												<strong>Zamknięte - sporządzono wniosek sankcyjny</strong>
											</li>
											<li>
												<strong>Zamknięte - wydano zalecenia i sporządzono wniosek sankcyjny</strong>
											</li>
										</ul>
									</div>
								);
							})()}
						</>
					) : inspectionDatesValidationModalData.kind ===
					  "status-extra-no-suggestion" ? (
						<>
							<p className="font-semibold text-blue-900 text-sm">
								Dla statusu:{" "}
								<span className="font-bold">
									{getInspectionStatusLabelByCode(
										inspectionDatesValidationModalData.selectedStatusCode,
									)}
								</span>{" "}
								nie powinny być uzupełnione poniższe pola dat:
							</p>
							{inspectionDatesValidationModalData.enteredFieldNumbers.length > 0 ? (
								<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
									{inspectionDatesValidationModalData.enteredFieldNumbers.map(
										(fieldNumber) => (
											<li key={`extra-no-suggestion-${fieldNumber}`}>
												{getInspectionDateFieldLabelForValidation(fieldNumber)}
											</li>
										),
									)}
								</ul>
							) : (
								<p className="mt-2 text-blue-900 text-sm">-</p>
							)}
							<p className="mt-2 text-blue-900 text-sm">
								Usuń dodatkowe daty albo wybierz status zgodny z etapem sprawy.
							</p>
							{!shouldShowControlIS4ToIS8Guidance(inspectionDatesValidationModalData) &&
							getControlIS4ToIS6MissingFieldNumbers(inspectionDatesValidationModalData)
								.length > 0 ? (
								<>
									<p className="mt-2 text-blue-900 text-sm">
										Ewentualnie, jeśli chcesz pozostawić {inspectionDatesValidationModalData.enteredFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {getControlIS4ToIS6MissingFieldNumbers(inspectionDatesValidationModalData).length === 1 ? "pole" : "pola"}:
									</p>
									<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
										{getControlIS4ToIS6MissingFieldNumbers(
											inspectionDatesValidationModalData,
										).map((fieldNumber) => (
											<li key={`missing-is6-${fieldNumber}`}>
												{getInspectionDateFieldLabelForValidation(fieldNumber)}
											</li>
										))}
									</ul>
									<p className="mt-2 text-blue-900 text-sm">
										Dla wybranych pól można ustawić status:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode("I_SI_6")}
										</span>
										.
									</p>
								</>
							) : null}
							{shouldShowControlIS6ToIS8Guidance(inspectionDatesValidationModalData) ? (
								getControlIS6ToIS8MissingFieldNumbers(
									inspectionDatesValidationModalData,
								).length > 0 ? (
									<>
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {inspectionDatesValidationModalData.enteredFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {getControlIS6ToIS8MissingFieldNumbers(inspectionDatesValidationModalData).length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{getControlIS6ToIS8MissingFieldNumbers(
												inspectionDatesValidationModalData,
											).map((fieldNumber) => (
												<li key={`missing-is8-from-is6-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											<li>
												{(inspectionDateFieldLabelByNumber[8] ?? "Pole daty").replace(" (lista)", "")} (opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)
											</li>
										</ul>
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode("I_SI_8")}
											</span>
											.
										</p>
									</>
								) : (
									<p className="mt-2 text-blue-900 text-sm">
										Status zgodny z danymi:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode("I_SI_8")}
										</span>
										.
									</p>
								)
							) : null}
							{shouldShowControlIS4ToIS8Guidance(inspectionDatesValidationModalData) ? (
								getControlIS4ToIS8MissingFieldNumbers(
									inspectionDatesValidationModalData,
								).length > 0 ? (
									<>
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {inspectionDatesValidationModalData.enteredFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {getControlIS4ToIS8MissingFieldNumbers(inspectionDatesValidationModalData).length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{getControlIS4ToIS8MissingFieldNumbers(
												inspectionDatesValidationModalData,
											).map((fieldNumber) => (
												<li key={`missing-is8-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											<li>
												{(inspectionDateFieldLabelByNumber[8] ?? "Pole daty").replace(" (lista)", "")} (opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)
											</li>
										</ul>
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode("I_SI_8")}
											</span>
											.
										</p>
									</>
								) : (
									<p className="mt-2 text-blue-900 text-sm">
										Status zgodny z danymi:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode("I_SI_8")}
										</span>
										.
									</p>
								)
							) : null}
							{(() => {
								const guidanceItem = getVisitIS11StatusGuidanceItem(
									inspectionDatesValidationModalData,
								);
								if (!guidanceItem) {
									return null;
								}
								if (guidanceItem.missingFieldNumbers.length === 0) {
									return (
										<>
											{guidanceItem.statusCode === "I_SI_8" ? (
												<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
													<li>{optionalAcceptanceNoteValidationLabel}</li>
												</ul>
											) : null}
											<p className="mt-2 text-blue-900 text-sm">
												Status zgodny z danymi:{" "}
												<span className="font-semibold">
													{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
												</span>
												.
											</p>
										</>
									);
								}
								return (
									<>
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {guidanceItem.extraFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {guidanceItem.missingFieldNumbers.length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
												<li key={`is11-guidance-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										{guidanceItem.statusCode === "I_SI_8" ? (
											<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
												<li>{optionalAcceptanceNoteValidationLabel}</li>
											</ul>
										) : null}
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
											</span>
											.
										</p>
									</>
								);
							})()}
							{(() => {
								const guidanceItem = getVisitIS5StatusGuidanceItem(
									inspectionDatesValidationModalData,
								);
								if (!guidanceItem) {
									return null;
								}
								if (guidanceItem.missingFieldNumbers.length === 0) {
									return (
										<>
											{guidanceItem.statusCode === "I_SI_8" ? (
												<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
													<li>{optionalAcceptanceNoteValidationLabel}</li>
												</ul>
											) : null}
											<p className="mt-2 text-blue-900 text-sm">
												Status zgodny z danymi:{" "}
												<span className="font-semibold">
													{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
												</span>
												.
											</p>
										</>
									);
								}
								return (
									<>
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {guidanceItem.extraFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {guidanceItem.missingFieldNumbers.length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
												<li key={`is5-guidance-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										{guidanceItem.statusCode === "I_SI_8" ? (
											<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
												<li>{optionalAcceptanceNoteValidationLabel}</li>
											</ul>
										) : null}
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
											</span>
											.
										</p>
									</>
								);
							})()}
						</>
					) : (
						<>
							<p className="font-semibold text-blue-900 text-sm">
								{inspectionDatesValidationModalData.kind === "status-required" &&
								(inspectionDatesValidationModalData.selectedStatusCode === "I_SI_4" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_6" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_5" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_8" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_11")
									? "Dla statusu: "
									: "Aby ustawić status: "}
								<span className="font-bold">
									{getInspectionStatusLabelByCode(
										inspectionDatesValidationModalData.selectedStatusCode,
									)}
								</span>{" "}
								{inspectionDatesValidationModalData.kind === "status-required" &&
								(inspectionDatesValidationModalData.selectedStatusCode === "I_SI_4" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_6" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_5" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_8" ||
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_11")
									? inspectionDatesValidationModalData.missingFieldNumbers.length === 1
										? "brakuje wymaganego pola:"
										: "brakuje wymaganych pól:"
									: "uzupełnij poniższe pola:"}
							</p>
							{inspectionDatesValidationModalData.missingFieldNumbers.length > 0 ? (
								<ul className="mt-2 list-disc space-y-1 pl-5 marker:text-blue-900 text-blue-900 text-sm">
									{inspectionDatesValidationModalData.missingFieldNumbers.map(
										(fieldNumber) => (
											<li key={`missing-field-${fieldNumber}`}>
												{getInspectionDateFieldLabelForValidation(fieldNumber)}
											</li>
										),
									)}
									{inspectionDatesValidationModalData.kind === "status-required" &&
									inspectionDatesValidationModalData.selectedStatusCode === "I_SI_8" ? (
										<li>
											{inspectionDateFieldLabelByNumber[
												getOptionalFieldNumberForStatusIS8(
													inspectionDatesValidationModalData,
												) as number
											] ?? "Pole daty"}{" "}
											<span className="italic">(opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)</span>
										</li>
									) : null}
								</ul>
							) : (
								<p className="mt-2 text-blue-900 text-sm">
									Brak brakujących pól dat. Zweryfikuj zgodność wybranego statusu z etapem sprawy.
								</p>
							)}
							{inspectionDatesValidationModalData.kind === "status-mismatch" &&
							inspectionDatesValidationModalData.suggestedStatusCode ? (
								<p className="mt-2 text-blue-900 text-sm">
									Status zgodny z danymi:{" "}
									<span className="font-semibold">
										{getInspectionStatusLabelByCode(
											inspectionDatesValidationModalData.suggestedStatusCode,
										)}
									</span>
									.
								</p>
							) : null}
							{(() => {
								const guidanceStatusCode =
									getControlIS8LowerStatusGuidanceCode(inspectionDatesValidationModalData);
								if (!guidanceStatusCode) {
									return null;
								}
								return (
									<p className="mt-2 text-blue-900 text-sm">
										Dla wybranych pól można ustawić status:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode(guidanceStatusCode)}
										</span>
										.
									</p>
								);
							})()}
							{(() => {
								const guidanceStatusCode =
									getVisitIS8LowerStatusGuidanceCode(inspectionDatesValidationModalData);
								if (!guidanceStatusCode) {
									return null;
								}
								return (
									<p className="mt-2 text-blue-900 text-sm">
										Dla wybranych pól można ustawić status:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode(guidanceStatusCode)}
										</span>
										.
									</p>
								);
							})()}
							{(() => {
								const guidanceItem = getControlIS4StatusGuidanceItem(
									inspectionDatesValidationModalData,
								);
								if (!guidanceItem || guidanceItem.missingFieldNumbers.length === 0) {
									return null;
								}
								return (
									<div className="mt-3 border-blue-200 border-t pt-3">
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {guidanceItem.extraFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {guidanceItem.missingFieldNumbers.length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
												<li key={`is4-guidance-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										{guidanceItem.statusCode === "I_SI_8" ? (
											<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
												<li>
													{(inspectionDateFieldLabelByNumber[8] ?? "Pole daty").replace(" (lista)", "")} (opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)
												</li>
											</ul>
										) : null}
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
											</span>
											.
										</p>
									</div>
								);
							})()}
							{(() => {
								const guidanceItem = getControlIS6StatusGuidanceItem(
									inspectionDatesValidationModalData,
								);
								if (!guidanceItem || guidanceItem.missingFieldNumbers.length === 0) {
									return null;
								}
								return (
									<div className="mt-3 border-blue-200 border-t pt-3">
										<p className="mt-2 text-blue-900 text-sm">
											Ewentualnie, jeśli chcesz pozostawić {guidanceItem.extraFieldNumbers.length === 1 ? "to pole" : "te pola"}, uzupełnij {guidanceItem.missingFieldNumbers.length === 1 ? "pole" : "pola"}:
										</p>
										<ul className="mt-1 list-disc space-y-1 pl-5 text-blue-900 text-sm">
											{guidanceItem.missingFieldNumbers.map((fieldNumber) => (
												<li key={`is6-guidance-${fieldNumber}`}>
													{getInspectionDateFieldLabelForValidation(fieldNumber)}
												</li>
											))}
										</ul>
										{guidanceItem.statusCode === "I_SI_8" ? (
											<ul className="mt-2 list-disc space-y-1 pl-5 text-blue-900 text-sm">
												<li>
													{(inspectionDateFieldLabelByNumber[8] ?? "Pole daty").replace(" (lista)", "")} (opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)
												</li>
											</ul>
										) : null}
										<p className="mt-2 text-blue-900 text-sm">
											Dla wybranych pól można ustawić status:{" "}
											<span className="font-semibold">
												{getInspectionStatusLabelByCode(guidanceItem.statusCode)}
											</span>
											.
										</p>
									</div>
								);
							})()}
							{(() => {
								const guidanceStatusCode = getControlIS6LowerStatusGuidanceCode(
									inspectionDatesValidationModalData,
								);
								if (!guidanceStatusCode) {
									return null;
								}
								return (
									<p className="mt-2 text-blue-900 text-sm">
										Dla wybranych pól można ustawić status:{" "}
										<span className="font-semibold">
											{getInspectionStatusLabelByCode(guidanceStatusCode)}
										</span>
										.
									</p>
								);
							})()}
							{getOptionalFieldNumberForStatusIS8(inspectionDatesValidationModalData) &&
							inspectionDatesValidationModalData.kind !== "status-required" ? (
								<ul className="mt-2 list-disc space-y-1 pl-5 marker:text-blue-900 text-blue-900 text-sm">
									<li>
										{inspectionDateFieldLabelByNumber[
											getOptionalFieldNumberForStatusIS8(
												inspectionDatesValidationModalData,
											) as number
										] ?? "Pole daty"}{" "}
										<span className="italic">(opcjonalne dla statusu opracowywanie rekomendacji dalszych dzialan/zalecen.)</span>
									</li>
								</ul>
							) : null}
						</>
					)}
				</div>

				{shouldShowClosedStatusGuidance(inspectionDatesValidationModalData) ? (
					<div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900 text-sm">
						<p>
							Jeśli zamykasz inspekcję, to w zależności od tego, czy dodano zalecenie oraz wniosek sankcyjny, ustaw status:
						</p>
						<ul className="mt-2 list-disc space-y-1 pl-5">
							<li>
								<strong>Zamknięte - wydano zalecenia</strong>
							</li>
							<li>
								<strong>Zamknięte - brak zaleceń i wniosku sankcyjnego</strong>
							</li>
							<li>
								<strong>Zamknięte - sporządzono wniosek sankcyjny</strong>
							</li>
							<li>
								<strong>Zamknięte - wydano zalecenia i sporządzono wniosek sankcyjny</strong>
							</li>
						</ul>
					</div>
				) : null}

				<div className="mt-5 flex items-center justify-end gap-2">
					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-10 items-center rounded-lg border border-slate-300 bg-white px-4 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Anuluj
					</button>
					<button
						type="button"
						onClick={onConfirmSave}
						className="inline-flex h-10 items-center rounded-lg border border-[#93b9ee] bg-[#d9e9ff] px-4 font-semibold text-[#21508f] text-sm transition-colors hover:bg-[#c9e0ff]"
					>
						Mimo to zapisz
					</button>
				</div>
			</div>
		</div>
	);
}
