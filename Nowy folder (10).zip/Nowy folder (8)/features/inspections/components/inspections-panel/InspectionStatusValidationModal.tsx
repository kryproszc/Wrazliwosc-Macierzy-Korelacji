type InspectionStatusValidationViolation = {
	violationCodeId: number | null;
	message: string;
};

type InspectionStatusValidationModalProps = {
	isOpen: boolean;
	selectedStatusForValidation: string | null;
	statusValidationViolations: InspectionStatusValidationViolation[];
	onClose: () => void;
};

export function InspectionStatusValidationModal({
	isOpen,
	selectedStatusForValidation,
	statusValidationViolations,
	onClose,
}: InspectionStatusValidationModalProps) {
	if (!isOpen) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-60 flex items-center justify-center p-4">
			<button
				type="button"
				aria-label="Zamknij okno walidacji statusu"
				className="absolute inset-0 bg-slate-950/65"
				onClick={onClose}
			/>

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Walidacja statusu inspekcji"
				className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-300 bg-white p-5 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)]"
			>
				<h3 className="font-semibold text-base text-slate-900">
					Nie można zapisać inspekcji z tym statusem
				</h3>
				{selectedStatusForValidation ? (
					<p className="mt-2 text-slate-800 text-sm">
						Status: <span className="font-semibold">{selectedStatusForValidation}</span>
					</p>
				) : null}

				<div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 p-3">
					<p className="font-semibold text-rose-700 text-sm">Naruszenia:</p>
					<ul className="mt-2 list-disc space-y-1 pl-5 text-rose-800 text-sm">
						{statusValidationViolations.map((violation, index) => (
							<li
								key={`${String(violation.violationCodeId)}-${violation.message}-${index}`}
							>
								{violation.message}
							</li>
						))}
					</ul>
				</div>

				<div className="mt-5 flex items-center justify-end gap-2">
					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-10 items-center rounded-lg border border-slate-300 bg-white px-4 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Wróć do formularza
					</button>
				</div>
			</div>
		</div>
	);
}
