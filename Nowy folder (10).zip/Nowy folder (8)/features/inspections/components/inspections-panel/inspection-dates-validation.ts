﻿const CLOSED_STATUS_CODE_POSITIONS = new Set([
"I_SI_9",
"I_SI_10",
"I_SI_12",
"I_SI_13",
]);
const STATUS_CODES_WITHOUT_DATES = new Set(["I_SI_1", "I_SI_2", "I_SI_3"]);
export function resolveInspectionTimelineModeFromTypeValue(
	inspectionTypeValue: string,
): InspectionTimelineMode | null {
	const normalizedType = inspectionTypeValue.trim().toLowerCase();
	const isControlType =
		normalizedType.includes("kontrol") ||
		normalizedType.startsWith("kont") ||
		normalizedType === "k";
	const isSupervisoryVisitType =
		normalizedType.includes("wizyta") ||
		normalizedType.startsWith("wiz") ||
		normalizedType === "w";

	if (isControlType && !isSupervisoryVisitType) {
		return "control";
	}

	if (isSupervisoryVisitType && !isControlType) {
		return "visit";
	}

	return null;
}

export type InspectionTimelineMode = "control" | "visit";

export type InspectionDatesValidationKind =
	| "status-forbids-dates"
	| "status-extra-dates"
	| "status-extra-no-suggestion"
	| "timeline-continuity"
	| "status-required"
	| "status-mismatch";

export type InspectionDatesValidationModalData = {
	kind: InspectionDatesValidationKind;
	mode: InspectionTimelineMode;
	selectedStatusCode: string;
	suggestedStatusCode: string | null;
	enteredFieldNumbers: number[];
	expectedFieldNumbers: number[];
	missingFieldNumbers: number[];
	message: string;
};

export const INSPECTION_DATE_FIELD_ID = {
	PROTOCOL_OR_REPORT: "protocolOrReport",
	PROTOCOL_DELIVERY: "protocolDelivery",
	OBJECTIONS_LETTER: "objectionsLetter",
	OBJECTIONS_SENT: "objectionsSent",
	OBJECTIONS_RECEIVED: "objectionsReceived",
	CONTROL_RESPONSE_SENT: "controlResponseSent",
	CONTROL_RESPONSE_LETTER: "controlResponseLetter",
	ACCEPTANCE_NOTE: "acceptanceNote",
	VISIT_REPORT_ACCEPTANCE: "visitReportAcceptance",
	VISIT_LETTER_DELIVERY: "visitLetterDelivery",
} as const;

export type InspectionDateFieldId =
	(typeof INSPECTION_DATE_FIELD_ID)[keyof typeof INSPECTION_DATE_FIELD_ID];

const CONTROL_DATE_FIELD_NUMBER_BY_ID: Partial<
	Record<InspectionDateFieldId, number>
> = {
	[INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT]: 1,
	[INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY]: 2,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER]: 3,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT]: 4,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED]: 5,
	[INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT]: 6,
	[INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER]: 7,
	[INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE]: 8,
};

const VISIT_DATE_FIELD_NUMBER_BY_ID: Partial<
	Record<InspectionDateFieldId, number>
> = {
	[INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT]: 9,
	[INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE]: 10,
	[INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY]: 11,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER]: 12,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT]: 13,
	[INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED]: 14,
	[INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE]: 15,
};

export const CONTROL_TIMELINE_GROUPS: InspectionDateFieldId[][] = [
	[INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT],
	[INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY],
	[
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
	],
	[
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
	],
	[INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE],
];

export const VISIT_TIMELINE_GROUPS: InspectionDateFieldId[][] = [
	[
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
	],
	[INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY],
	[
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
	],
	[INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE],
];

export function mapInspectionDateFieldIdsToNumbers(
	mode: InspectionTimelineMode,
	fieldIds: InspectionDateFieldId[],
): number[] {
	const fieldNumberById =
		mode === "control"
			? CONTROL_DATE_FIELD_NUMBER_BY_ID
			: VISIT_DATE_FIELD_NUMBER_BY_ID;

	return Array.from(
		new Set(
			fieldIds
				.map((fieldId) => fieldNumberById[fieldId])
				.filter((fieldNumber): fieldNumber is number =>
					typeof fieldNumber === "number",
				),
		),
	).sort((left, right) => left - right);
}

export const CONTROL_STATUS_REQUIRED_FIELDS_BY_CODE: Record<
	string,
	InspectionDateFieldId[]
> = {
	I_SI_1: [],
	I_SI_2: [],
	I_SI_3: [],
	I_SI_14: [INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT],
	I_SI_4: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
	],
	I_SI_6: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
	],
	I_SI_8: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
	],
	I_SI_9: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_10: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_12: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_13: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
		INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
};

export const VISIT_STATUS_REQUIRED_FIELDS_BY_CODE: Record<
	string,
	InspectionDateFieldId[]
> = {
	I_SI_1: [],
	I_SI_2: [],
	I_SI_3: [],
	I_SI_11: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
	],
	I_SI_5: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
	],
	I_SI_8: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
	],
	I_SI_9: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_10: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_12: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
	I_SI_13: [
		INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
		INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
		INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		INSPECTION_DATE_FIELD_ID.ACCEPTANCE_NOTE,
	],
};

export const CONTROL_PROGRESS_STATUS_BY_REQUIRED_FIELDS: Array<{
	statusCode: string;
	requiredFieldIds: InspectionDateFieldId[];
}> = [
	{
		statusCode: "I_SI_8",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
			INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_SENT,
			INSPECTION_DATE_FIELD_ID.CONTROL_RESPONSE_LETTER,
		],
	},
	{
		statusCode: "I_SI_6",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		],
	},
	{
		statusCode: "I_SI_4",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.PROTOCOL_DELIVERY,
		],
	},
];

export const VISIT_PROGRESS_STATUS_BY_REQUIRED_FIELDS: Array<{
	statusCode: string;
	requiredFieldIds: InspectionDateFieldId[];
}> = [
	{
		statusCode: "I_SI_8",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
			INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_LETTER,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_SENT,
			INSPECTION_DATE_FIELD_ID.OBJECTIONS_RECEIVED,
		],
	},
	{
		statusCode: "I_SI_5",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
			INSPECTION_DATE_FIELD_ID.VISIT_LETTER_DELIVERY,
		],
	},
	{
		statusCode: "I_SI_11",
		requiredFieldIds: [
			INSPECTION_DATE_FIELD_ID.PROTOCOL_OR_REPORT,
			INSPECTION_DATE_FIELD_ID.VISIT_REPORT_ACCEPTANCE,
		],
	},
];

export const INSPECTION_DATE_FIELD_LABEL_BY_NUMBER: Record<number, string> = {
	1: "Data protokołu kontroli",
	2: "Data doręczenia protokołu kontroli",
	3: "Data pisma podmiotu z zastrzeżeniami do protokołu kontroli",
	4: "Data wysłania pisma podmiotu z zastrzeżeniami do protokołu kontroli",
	5: "Data wpływu pisma podmiotu z zastrzeżeniami do protokołu kontroli",
	6: "Data wysłania pisma z odpowiedzią na zastrzeżenia do protokołu kontroli",
	7: "Data pisma z odpowiedzią na zastrzeżenia do protokołu kontroli",
	8: "Data akceptacji noty z rekomendacjami dalszych działań (lista)",
	9: "Data sprawozdania z wizyty nadzorczej",
	10: "Data akceptacji sprawozdania z wizyty nadzorczej",
	11: "Data doręczenia pisma do podmiotu z ustaleniami wizyty nadzorczej",
	12: "Data uwag do pisma po wizycie nadzorczej",
	13: "Data wysłania uwag do pisma po wizycie nadzorczej",
	14: "Data wpływu uwag do pisma po wizycie nadzorczej",
	15: "Data akceptacji noty z rekomendacjami dalszych działań (lista)",
};

export const OPTIONAL_ACCEPTANCE_NOTE_VALIDATION_LABEL =
	"Data akceptacji noty (opcjonalnie dla opracowywanie rekomendacji dalszych dzialan/zalecen)";

export function getInspectionDateFieldLabelForValidation(fieldNumber: number) {
	if (fieldNumber === 8 || fieldNumber === 15) {
		return OPTIONAL_ACCEPTANCE_NOTE_VALIDATION_LABEL;
	}

	return INSPECTION_DATE_FIELD_LABEL_BY_NUMBER[fieldNumber] ?? "Pole daty";
}

export const CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE: Record<
	InspectionTimelineMode,
	number[]
> = {
	control: [1, 2, 3, 4, 5, 6, 7, 8],
	visit: [9, 10, 11, 12, 13, 14, 15],
};
const CONTROL_IS6_OBJECTIONS_FIELD_NUMBERS = [3, 4, 5] as const;
const CONTROL_IS8_PROGRESS_FIELD_NUMBERS = [3, 4, 5, 6, 7] as const;
const CONTROL_CLOSED_EXTRA_FIELD_NUMBERS = [3, 4, 5, 6, 7, 8] as const;
const FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE: Record<
	InspectionTimelineMode,
	Array<{
		statusCode: string;
		requiredFieldNumbers: number[];
		matchingFieldNumbers?: number[];
	}>
> = {
	control: [
		{ statusCode: "I_SI_14", requiredFieldNumbers: [1] },
		{ statusCode: "I_SI_4", requiredFieldNumbers: [1, 2] },
		{ statusCode: "I_SI_6", requiredFieldNumbers: [1, 2, 3, 4, 5] },
		{
			statusCode: "I_SI_8",
			requiredFieldNumbers: [1, 2, 3, 4, 5, 6, 7],
			matchingFieldNumbers: [1, 2, 3, 4, 5, 6, 7, 8],
		},
	],
	visit: [
		{ statusCode: "I_SI_11", requiredFieldNumbers: [9, 10] },
		{ statusCode: "I_SI_5", requiredFieldNumbers: [9, 10, 11] },
		{
			statusCode: "I_SI_8",
			requiredFieldNumbers: [9, 10, 11, 12, 13, 14],
			matchingFieldNumbers: [9, 10, 11, 12, 13, 14, 15],
		},
	],
};

export function getForbiddenDatesStatusGuidanceItems(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-forbids-dates" ||
		!STATUS_CODES_WITHOUT_DATES.has(modalData.selectedStatusCode)
	) {
		return [] as Array<{
			statusCode: string;
			requiredFieldNumbers: number[];
			missingFieldNumbers: number[];
		}>;
	}

	const guidanceItems =
		FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE[modalData.mode] ?? [];

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbers.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return [];
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return [
		{
			statusCode: bestMatch.statusCode,
			requiredFieldNumbers: bestMatch.requiredFieldNumbers,
			missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
				(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
			),
		},
	];
}

export function getEnteredFieldNumbersForGuidance(
	modalData: InspectionDatesValidationModalData,
) {
	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);

	if (
		modalData.kind === "status-extra-dates" &&
		modalData.mode === "control" &&
		modalData.selectedStatusCode === "I_SI_14" &&
		!modalData.missingFieldNumbers.includes(1)
	) {
		return Array.from(new Set([...enteredFieldNumbers, 1])).sort(
			(left, right) => left - right,
		);
	}

	return enteredFieldNumbers;
}

export function getControlIS14StatusGuidanceItem(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-dates" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_14"
	) {
		return null;
	}

	const enteredFieldNumbers = getEnteredFieldNumbersForGuidance(modalData);
	const enteredFieldNumbersForMatching = modalData.missingFieldNumbers.includes(1)
		? enteredFieldNumbers.filter((fieldNumber) => fieldNumber !== 1)
		: enteredFieldNumbers;
	const guidanceItems = FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE.control.filter(
		(guidanceItem) => guidanceItem.statusCode !== "I_SI_14",
	);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbersForMatching.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return null;
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return {
		statusCode: bestMatch.statusCode,
		missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
			(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
		),
	};
}

export function getControlIS4StatusGuidanceItem(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_4" ||
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion")
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);
	const extraFieldNumbers = enteredFieldNumbers.filter(
		(fieldNumber) => ![1, 2].includes(fieldNumber),
	);

	if (extraFieldNumbers.length === 0) {
		return null;
	}

	const guidanceItems = FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE.control.filter(
		(guidanceItem) =>
			guidanceItem.statusCode === "I_SI_6" || guidanceItem.statusCode === "I_SI_8",
	);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbers.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return null;
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return {
		statusCode: bestMatch.statusCode,
		extraFieldNumbers,
		missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
			(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
		),
	};
}

export function getVisitIS11StatusGuidanceItem(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_11" ||
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion")
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);
	const enteredFieldNumbersForGuidance =
		modalData.kind === "status-extra-no-suggestion"
			? Array.from(
				new Set([
					...modalData.expectedFieldNumbers,
					...modalData.enteredFieldNumbers,
				]),
			).sort((left, right) => left - right)
			: enteredFieldNumbers;
	const extraFieldNumbers = enteredFieldNumbers.filter(
		(fieldNumber) => ![9, 10].includes(fieldNumber),
	);

	if (extraFieldNumbers.length === 0) {
		return null;
	}

	const guidanceItems = FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE.visit.filter(
		(guidanceItem) =>
			guidanceItem.statusCode === "I_SI_5" || guidanceItem.statusCode === "I_SI_8",
	);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbersForGuidance.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return null;
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return {
		statusCode: bestMatch.statusCode,
		extraFieldNumbers,
		missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
			(fieldNumber) => !enteredFieldNumbersForGuidance.includes(fieldNumber),
		),
	};
}

export function getVisitIS5StatusGuidanceItem(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_5" ||
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion")
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);
	const enteredFieldNumbersForGuidance =
		modalData.kind === "status-extra-no-suggestion"
			? Array.from(
				new Set([
					...modalData.expectedFieldNumbers,
					...modalData.enteredFieldNumbers,
				]),
			).sort((left, right) => left - right)
			: enteredFieldNumbers;
	const extraFieldNumbers = enteredFieldNumbers.filter(
		(fieldNumber) => ![9, 10, 11].includes(fieldNumber),
	);

	if (extraFieldNumbers.length === 0) {
		return null;
	}

	const guidanceItems = FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE.visit.filter(
		(guidanceItem) => guidanceItem.statusCode === "I_SI_8",
	);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbersForGuidance.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return null;
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return {
		statusCode: bestMatch.statusCode,
		extraFieldNumbers,
		missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
			(fieldNumber) => !enteredFieldNumbersForGuidance.includes(fieldNumber),
		),
	};
}

export function getControlIS6StatusGuidanceItem(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_6" ||
		modalData.kind !== "status-required"
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);
	const extraFieldNumbers = enteredFieldNumbers.filter(
		(fieldNumber) => ![1, 2, 3, 4, 5].includes(fieldNumber),
	);

	if (extraFieldNumbers.length === 0) {
		return null;
	}

	const guidanceItems = FORBIDDEN_DATES_STATUS_GUIDANCE_BY_MODE.control.filter(
		(guidanceItem) => guidanceItem.statusCode === "I_SI_8",
	);

	const matchingItems = guidanceItems.filter((guidanceItem) =>
		enteredFieldNumbers.every((fieldNumber) =>
			(
				guidanceItem.matchingFieldNumbers ?? guidanceItem.requiredFieldNumbers
			).includes(fieldNumber),
		),
	);

	if (matchingItems.length === 0) {
		return null;
	}

	const bestMatch = matchingItems.reduce((best, current) =>
		current.requiredFieldNumbers.length < best.requiredFieldNumbers.length
			? current
			: best,
	);

	return {
		statusCode: bestMatch.statusCode,
		extraFieldNumbers,
		missingFieldNumbers: bestMatch.requiredFieldNumbers.filter(
			(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
		),
	};
}

export function getControlIS6LowerStatusGuidanceCode(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_6" ||
		modalData.kind !== "status-required"
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);

	if (
		enteredFieldNumbers.length === 1 &&
		enteredFieldNumbers[0] === 1
	) {
		return "I_SI_14";
	}

	if (
		enteredFieldNumbers.length === 2 &&
		enteredFieldNumbers[0] === 1 &&
		enteredFieldNumbers[1] === 2
	) {
		return "I_SI_4";
	}

	return null;
}

export function getControlIS8LowerStatusGuidanceCode(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "control" ||
		(modalData.selectedStatusCode !== "I_SI_8" &&
			!CLOSED_STATUS_CODE_POSITIONS.has(modalData.selectedStatusCode)) ||
		modalData.kind !== "status-required"
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);

	if (enteredFieldNumbers.length === 1 && enteredFieldNumbers[0] === 1) {
		return "I_SI_14";
	}

	if (
		enteredFieldNumbers.length === 2 &&
		enteredFieldNumbers[0] === 1 &&
		enteredFieldNumbers[1] === 2
	) {
		return "I_SI_4";
	}

	if (
		enteredFieldNumbers.length === 5 &&
		enteredFieldNumbers.every((fieldNumber, index) =>
			fieldNumber === [1, 2, 3, 4, 5][index],
		)
	) {
		return "I_SI_6";
	}

	if (
		enteredFieldNumbers.length === 7 &&
		enteredFieldNumbers.every((fieldNumber, index) =>
			fieldNumber === [1, 2, 3, 4, 5, 6, 7][index],
		)
	) {
		return "I_SI_8";
	}

	return null;
}

export function getVisitIS8LowerStatusGuidanceCode(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.mode !== "visit" ||
		(modalData.selectedStatusCode !== "I_SI_8" &&
			!CLOSED_STATUS_CODE_POSITIONS.has(modalData.selectedStatusCode)) ||
		modalData.kind !== "status-required"
	) {
		return null;
	}

	const enteredFieldNumbers = Array.from(
		new Set(modalData.enteredFieldNumbers),
	).sort((left, right) => left - right);

	if (
		enteredFieldNumbers.length === 2 &&
		enteredFieldNumbers[0] === 9 &&
		enteredFieldNumbers[1] === 10
	) {
		return "I_SI_11";
	}

	if (
		enteredFieldNumbers.length === 3 &&
		enteredFieldNumbers[0] === 9 &&
		enteredFieldNumbers[1] === 10 &&
		enteredFieldNumbers[2] === 11
	) {
		return "I_SI_5";
	}

	if (
		enteredFieldNumbers.length === 6 &&
		enteredFieldNumbers.every((fieldNumber, index) =>
			fieldNumber === [9, 10, 11, 12, 13, 14][index],
		)
	) {
		return "I_SI_8";
	}

	return null;
}

export function shouldShowClosedStatusGuidance(
	modalData: InspectionDatesValidationModalData,
) {
	const requiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE[modalData.mode] ?? [];

	if (requiredFieldNumbers.length === 0) {
		return false;
	}

	const enteredFieldNumbers = getEnteredFieldNumbersForGuidance(modalData);

	return requiredFieldNumbers.every((fieldNumber) =>
		enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlIS4ToIS6MissingFieldNumbers(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-no-suggestion" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_4"
	) {
		return [] as number[];
	}

	const hasAnyObjectionField = CONTROL_IS6_OBJECTIONS_FIELD_NUMBERS.some(
		(fieldNumber) => modalData.enteredFieldNumbers.includes(fieldNumber),
	);
	if (!hasAnyObjectionField) {
		return [] as number[];
	}

	return CONTROL_IS6_OBJECTIONS_FIELD_NUMBERS.filter(
		(fieldNumber) => !modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function shouldShowControlIS4ToIS8Guidance(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-no-suggestion" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_4"
	) {
		return false;
	}

	return [6, 7, 8].some((fieldNumber) =>
		modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlIS4ToIS8MissingFieldNumbers(
	modalData: InspectionDatesValidationModalData,
) {
	if (!shouldShowControlIS4ToIS8Guidance(modalData)) {
		return [] as number[];
	}

	return CONTROL_IS8_PROGRESS_FIELD_NUMBERS.filter(
		(fieldNumber) => !modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function hasControlIS4ClosedFieldsCompleted(
	modalData: InspectionDatesValidationModalData,
) {
	if (!shouldShowControlIS4ToIS8Guidance(modalData)) {
		return false;
	}

	return CONTROL_CLOSED_EXTRA_FIELD_NUMBERS.every((fieldNumber) =>
		modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function shouldShowControlIS6ToIS8Guidance(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-no-suggestion" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_6"
	) {
		return false;
	}

	return [6, 7, 8].some((fieldNumber) =>
		modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlIS6ToIS8MissingFieldNumbers(
	modalData: InspectionDatesValidationModalData,
) {
	if (!shouldShowControlIS6ToIS8Guidance(modalData)) {
		return [] as number[];
	}

	return [6, 7].filter(
		(fieldNumber) => !modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function hasControlIS6ClosedFieldsCompleted(
	modalData: InspectionDatesValidationModalData,
) {
	if (!shouldShowControlIS6ToIS8Guidance(modalData)) {
		return false;
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.control;

	return closedRequiredFieldNumbers.every((fieldNumber) =>
		enteredFieldNumbers.includes(fieldNumber),
	);
}

export function hasVisitIS11ClosedFieldsCompleted(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-no-suggestion" ||
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_11"
	) {
		return false;
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.visit;

	return closedRequiredFieldNumbers.every((fieldNumber) =>
		enteredFieldNumbers.includes(fieldNumber),
	);
}

export function hasVisitIS5ClosedFieldsCompleted(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-no-suggestion" ||
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_5"
	) {
		return false;
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.visit;

	return closedRequiredFieldNumbers.every((fieldNumber) =>
		enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getOptionalFieldNumberForStatusIS8(
	modalData: InspectionDatesValidationModalData,
) {
	if (modalData.selectedStatusCode !== "I_SI_8") {
		return null;
	}

	return modalData.mode === "control" ? 8 : 15;
}

export function getControlClosedStatusMissingFieldNumbersForForbiddenDates(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-forbids-dates" ||
		modalData.mode !== "control" ||
		!STATUS_CODES_WITHOUT_DATES.has(modalData.selectedStatusCode) ||
		!modalData.enteredFieldNumbers.includes(8)
	) {
		return [] as number[];
	}

	return CONTROL_CLOSED_EXTRA_FIELD_NUMBERS.filter(
		(fieldNumber) => !modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlClosedStatusMissingFieldNumbersForIS14ExtraDates(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-extra-dates" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_14"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = getEnteredFieldNumbersForGuidance(modalData);
	if (!enteredFieldNumbers.includes(8)) {
		return [] as number[];
	}

	return CONTROL_CLOSED_EXTRA_FIELD_NUMBERS.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlClosedStatusMissingFieldNumbersForIS4ExtraDates(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion") ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_4" ||
		!modalData.enteredFieldNumbers.includes(8)
	) {
		return [] as number[];
	}

	return CONTROL_CLOSED_EXTRA_FIELD_NUMBERS.filter(
		(fieldNumber) => !modalData.enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlClosedStatusMissingFieldNumbersForIS6ExtraDates(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion") ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_6"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	if (!enteredFieldNumbers.includes(8)) {
		return [] as number[];
	}

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.control;

	return closedRequiredFieldNumbers.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getControlClosedStatusMissingFieldNumbersForIS8Required(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-required" ||
		modalData.mode !== "control" ||
		modalData.selectedStatusCode !== "I_SI_8"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	if (!enteredFieldNumbers.includes(8)) {
		return [] as number[];
	}

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.control;

	return closedRequiredFieldNumbers.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getVisitClosedStatusMissingFieldNumbersForIS8Required(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		modalData.kind !== "status-required" ||
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_8"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	if (!enteredFieldNumbers.includes(15)) {
		return [] as number[];
	}

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.visit;

	return closedRequiredFieldNumbers.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getVisitClosedStatusMissingFieldNumbersForIS11(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion") ||
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_11"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	if (!enteredFieldNumbers.includes(15)) {
		return [] as number[];
	}

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.visit;

	return closedRequiredFieldNumbers.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

export function getVisitClosedStatusMissingFieldNumbersForIS5(
	modalData: InspectionDatesValidationModalData,
) {
	if (
		(modalData.kind !== "status-required" &&
			modalData.kind !== "status-extra-no-suggestion") ||
		modalData.mode !== "visit" ||
		modalData.selectedStatusCode !== "I_SI_5"
	) {
		return [] as number[];
	}

	const enteredFieldNumbers = Array.from(
		new Set([
			...modalData.expectedFieldNumbers,
			...modalData.enteredFieldNumbers,
		]),
	).sort((left, right) => left - right);

	if (!enteredFieldNumbers.includes(15)) {
		return [] as number[];
	}

	const closedRequiredFieldNumbers =
		CLOSED_STATUS_REQUIRED_FIELD_NUMBERS_BY_MODE.visit;

	return closedRequiredFieldNumbers.filter(
		(fieldNumber) => !enteredFieldNumbers.includes(fieldNumber),
	);
}

