import type { InspectionWritePayload } from "@/features/inspections/components/inspections-panel/inspection-write-payload";

type BaseSaveRequestParams = {
	apiUrl: string;
	operatorLogin: string;
	payload: InspectionWritePayload;
	leaderUserId: number;
};

type UpdateInspectionRequestParams = BaseSaveRequestParams & {
	inspectionId: string;
	expectedUpdatedAt: string | null;
	lockToken: string | null;
};

export function createInspectionRequest({
	apiUrl,
	operatorLogin,
	payload,
	leaderUserId,
}: BaseSaveRequestParams) {
	return fetch(apiUrl, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			...payload,
			osobaKierujacaUserId: leaderUserId,
		}),
	});
}

export function updateInspectionRequest({
	apiUrl,
	inspectionId,
	operatorLogin,
	payload,
	leaderUserId,
	expectedUpdatedAt,
	lockToken,
}: UpdateInspectionRequestParams) {
	return fetch(`${apiUrl}/${inspectionId}`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			...payload,
			osobaKierujacaUserId: leaderUserId,
			expectedUpdatedAt,
			lockToken,
		}),
	});
}
