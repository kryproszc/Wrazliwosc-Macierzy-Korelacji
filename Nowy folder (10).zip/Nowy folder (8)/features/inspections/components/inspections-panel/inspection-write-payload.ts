import type { AddInspectionForm } from "@/features/inspections/components/inspections-panel.utils";
import { toDateInputValue } from "@/shared/utils/date";

type DictionaryIdentity = {
	id: number | null;
	code: string | null;
};

type DictionaryIdentityMaps = {
	idByValue: Record<string, number>;
	codeByValue: Record<string, string>;
};

type BuildInspectionWritePayloadParams = {
	formState: AddInspectionForm;
	scopeValues: string[];
	teamMemberIds: number[];
	inspectionTeamIds: number[];
	acceptanceDates: string[];
	isNoAcceptanceDates: boolean;
	inspectionScopeIdByValue: Record<string, number>;
	inspectionTypeMaps: DictionaryIdentityMaps;
	marketMaps: DictionaryIdentityMaps;
	entityTypeMaps: DictionaryIdentityMaps;
	statusMaps: DictionaryIdentityMaps;
};

function toNullable(value: string) {
	const normalized = value.trim();
	return normalized ? normalized : null;
}

function normalizeDateList(list: string[]) {
	const normalized = list.map((value) => toDateInputValue(value)).filter(Boolean);
	return Array.from(new Set(normalized)).sort((left, right) =>
		left.localeCompare(right),
	);
}

function normalizeInspectionScopeValues(values: string[]) {
	const normalized = values
		.map((value) => value.trim())
		.filter(Boolean)
		.filter((value) => {
			const lowered = value.toLowerCase();
			return lowered !== "brak" && lowered !== "-";
		});

	return Array.from(new Set(normalized)).sort((left, right) =>
		left.localeCompare(right, "pl", { sensitivity: "base" }),
	);
}

export function resolveDictionaryIdentity(
	value: string,
	idByValue: Record<string, number>,
	codeByValue: Record<string, string>,
): DictionaryIdentity {
	const normalizedValue = value.trim();
	if (!normalizedValue) {
		return { id: null, code: null };
	}

	const id = idByValue[normalizedValue] ?? null;
	const code = codeByValue[normalizedValue] ?? null;

	return { id, code };
}

export function buildInspectionWritePayload({
	formState,
	scopeValues,
	teamMemberIds,
	inspectionTeamIds,
	acceptanceDates,
	isNoAcceptanceDates,
	inspectionScopeIdByValue,
	inspectionTypeMaps,
	marketMaps,
	entityTypeMaps,
	statusMaps,
}: BuildInspectionWritePayloadParams) {
	const inspectionTypeIdentity = resolveDictionaryIdentity(
		formState.typInspekcji,
		inspectionTypeMaps.idByValue,
		inspectionTypeMaps.codeByValue,
	);
	const marketIdentity = resolveDictionaryIdentity(
		formState.rynek,
		marketMaps.idByValue,
		marketMaps.codeByValue,
	);
	const entityTypeIdentity = resolveDictionaryIdentity(
		formState.rodzajPodmiotu,
		entityTypeMaps.idByValue,
		entityTypeMaps.codeByValue,
	);
	const statusIdentity = resolveDictionaryIdentity(
		formState.status,
		statusMaps.idByValue,
		statusMaps.codeByValue,
	);

	const normalizedZakresInspekcjiList = normalizeInspectionScopeValues(scopeValues);
	const normalizedZakresInspekcjiIds = Array.from(
		new Set(
			normalizedZakresInspekcjiList
				.map((scopeValue) => inspectionScopeIdByValue[scopeValue] ?? Number.NaN)
				.filter(
					(scopeId): scopeId is number =>
						Number.isFinite(scopeId) && scopeId > 0,
				),
		),
	).sort((left, right) => left - right);
	const normalizedDataAkceptacjiNotyList = isNoAcceptanceDates
		? []
		: normalizeDateList(acceptanceDates);
	const brakDatAkceptacjiNoty =
		isNoAcceptanceDates && normalizedDataAkceptacjiNotyList.length === 0;
	const dataDoreczeniaPisma = toNullable(formState.dataDoreczeniaPisma);
	const dataPismaZastrzezenia = toNullable(formState.dataPismaZastrzezenia);
	const dataWyslaniaPismaZZastrzezeniami = toNullable(
		formState.dataWyslaniaPismaZZastrzezeniami,
	);
	const dataWplywuPisma = toNullable(formState.dataWplywuPisma);
	const dataPismaZOdpowiedzia = toNullable(formState.dataPismaZOdpowiedzia);
	const dataWyslaniaPismaZOdpowiedzia = toNullable(
		formState.dataWyslaniaPismaZOdpowiedzia,
	);
	const brakDataDoreczeniaPisma =
		formState.brakDataDoreczeniaPisma && !dataDoreczeniaPisma;
	const brakDataPismaZastrzezenia =
		formState.brakDataPismaZastrzezenia && !dataPismaZastrzezenia;
	const brakDataWyslaniaPismaZZastrzezeniami =
		formState.brakDataWyslaniaPismaZZastrzezeniami &&
		!dataWyslaniaPismaZZastrzezeniami;
	const brakDataWplywuPisma =
		formState.brakDataWplywuPisma && !dataWplywuPisma;
	const brakDataPismaZOdpowiedzia =
		formState.brakDataPismaZOdpowiedzia && !dataPismaZOdpowiedzia;
	const brakDataWyslaniaPismaZOdpowiedzia =
		formState.brakDataWyslaniaPismaZOdpowiedzia &&
		!dataWyslaniaPismaZOdpowiedzia;

	return {
		nazwaPodmiotu: formState.nazwaPodmiotu.trim(),
		typInspekcji: toNullable(formState.typInspekcji),
		typInspekcjiId: inspectionTypeIdentity.id,
		typInspekcjiKodPozycji: inspectionTypeIdentity.code,
		zakresInspekcjiIds: normalizedZakresInspekcjiIds,
		szczegolyDotyczaceZakresu: toNullable(formState.szczegolyDotyczaceZakresu),
		aspektKonsumencki: toNullable(formState.aspektKonsumencki),
		poczatekInspekcji: formState.poczatekInspekcji,
		koniecInspekcji: formState.koniecInspekcji,
		rynek: toNullable(formState.rynek),
		rynekId: marketIdentity.id,
		rynekKodPozycji: marketIdentity.code,
		rodzajPodmiotu: toNullable(formState.rodzajPodmiotu),
		rodzajPodmiotuId: entityTypeIdentity.id,
		rodzajPodmiotuKodPozycji: entityTypeIdentity.code,
		dataProtokolu: toNullable(formState.dataProtokolu),
		dataDoreczeniaProtokolu: toNullable(formState.dataDoreczeniaProtokolu),
		dataAkceptacjiSprawozdania: toNullable(formState.dataAkceptacjiSprawozdania),
		dataDoreczeniaPisma: brakDataDoreczeniaPisma ? null : dataDoreczeniaPisma,
		brakDataDoreczeniaPisma,
		dataPismaZastrzezenia: brakDataPismaZastrzezenia
			? null
			: dataPismaZastrzezenia,
		brakDataPismaZastrzezenia,
		dataWyslaniaPismaZZastrzezeniami: brakDataWyslaniaPismaZZastrzezeniami
			? null
			: dataWyslaniaPismaZZastrzezeniami,
		brakDataWyslaniaPismaZZastrzezeniami,
		dataWplywuPisma: brakDataWplywuPisma ? null : dataWplywuPisma,
		brakDataWplywuPisma,
		dataPismaZOdpowiedzia: brakDataPismaZOdpowiedzia
			? null
			: dataPismaZOdpowiedzia,
		brakDataPismaZOdpowiedzia,
		dataWyslaniaPismaZOdpowiedzia: brakDataWyslaniaPismaZOdpowiedzia
			? null
			: dataWyslaniaPismaZOdpowiedzia,
		brakDataWyslaniaPismaZOdpowiedzia,
		dataAkceptacjiNotyList: normalizedDataAkceptacjiNotyList,
		brakDatAkceptacjiNoty,
		status: toNullable(formState.status),
		statusId: statusIdentity.id,
		statusKodPozycji: statusIdentity.code,
		komentarz: toNullable(formState.komentarz),
		teamMemberUserIds: [...teamMemberIds].sort((left, right) => left - right),
		inspectionTeamIds: [...inspectionTeamIds].sort((left, right) => left - right),
	};
}

export type InspectionWritePayload = ReturnType<typeof buildInspectionWritePayload>;

export function toComparableInspectionPayload(
	payload: InspectionWritePayload,
	leaderUserId: number | null,
) {
	return JSON.stringify({
		...payload,
		dataAkceptacjiNotyList: [...payload.dataAkceptacjiNotyList].sort(
			(left, right) => left.localeCompare(right),
		),
		osobaKierujacaUserId: leaderUserId,
	});
}
