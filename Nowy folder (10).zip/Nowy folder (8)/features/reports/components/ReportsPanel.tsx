"use client";

import { ChevronDown, Download, Maximize2, Minimize2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { fetchDictionaryEntries } from "@/features/dictionaries/api";
import {
	fetchInspectionsDetailedReport,
	fetchInspectionsReportMatrix,
} from "@/features/reports/api";
import type { ReportInspectionMatrixRow } from "@/features/reports/types";
import {
	createStyledExportWorkbook,
	saveWorkbookAsXlsx,
} from "@/shared/utils/excel-export";
import { formatIsoDateForDisplay } from "@/shared/utils/date";
import { TableFullscreenContainer } from "@/shared/components/table/TableFullscreenContainer";
import { TableAdvancedFilterModal } from "@/shared/components/table/TableAdvancedFilterModal";
import { getFloatingPanelAnchor } from "@/shared/utils/floating-panel";

type ReportsPanelProps = {
	operatorLogin: string;
};

type ReportsMapViewMode = "table" | "chart";
type ControlsCountSortDirection = "none" | "asc" | "desc";
type EntitySortDirection = "none" | "asc" | "desc";
type TableHeaderAdvancedFilterTarget =
	| { kind: "entity" }
	| { kind: "year"; year: string }
	| null;

const INSPECTIONS_CHANGED_EVENT = "inspections:changed";
const DASHBOARD_OPEN_INSPECTION_EVENT = "dashboard:open-inspection";
const DASHBOARD_OPEN_INSPECTION_CODE_KEY = "triangle.dashboard.openInspectionCode";
// Widok tabeli celuje w maksymalnie 8 kolumn rocznych naraz; nadmiar idzie w poziomy scroll.
const REPORTS_MAP_MAX_VISIBLE_YEAR_COLUMNS = 8;
const REPORTS_MAP_MIN_YEAR_COLUMN_WIDTH_PX = 140;
const REPORTS_MAP_MAX_YEAR_COLUMN_WIDTH_PX = 240;
const REPORTS_MAP_FIRST_COLUMN_RESERVED_WIDTH_PX = 260;
const REPORTS_MAP_COUNT_COLUMN_WIDTH_PX = 72;

function openInspectionFromDashboard(inspectionToken: string) {
	const normalizedToken = inspectionToken.trim();
	if (!normalizedToken || typeof window === "undefined") {
		return;
	}

	window.sessionStorage.setItem(
		DASHBOARD_OPEN_INSPECTION_CODE_KEY,
		normalizedToken,
	);
	window.dispatchEvent(
		new CustomEvent(DASHBOARD_OPEN_INSPECTION_EVENT, {
			detail: { inspectionCode: normalizedToken },
		}),
	);
}

function TableLoadingOverlay() {
	return (
		<div className="absolute inset-0 z-20 flex items-center justify-center bg-white/70 backdrop-blur-[1px]">
			<div className="flex items-center gap-3 rounded-full border border-slate-200 bg-white/90 px-4 py-2 shadow-[0_8px_20px_rgba(2,8,23,0.15)]">
				<span className="h-4 w-4 animate-spin rounded-full border-2 border-[#7aa5dc] border-t-[#255087]" />
				<span className="font-medium text-slate-700 text-sm">Ładowanie danych...</span>
			</div>
		</div>
	);
}

export function ReportsPanel({ operatorLogin }: ReportsPanelProps) {
	const [rows, setRows] = useState<ReportInspectionMatrixRow[]>([]);
	const [years, setYears] = useState<string[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [isExporting, setIsExporting] = useState(false);
	const [isFullscreen, setIsFullscreen] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [mapViewMode, setMapViewMode] = useState<ReportsMapViewMode>("table");
	const [isHeatmapEnabled, setIsHeatmapEnabled] = useState(false);
	const [selectedPlants, setSelectedPlants] = useState<string[]>([]);
	const [selectedEntityTypes, setSelectedEntityTypes] = useState<string[]>([]);
	const [selectedYears, setSelectedYears] = useState<string[]>([]);
	const [selectedInspectionScopes, setSelectedInspectionScopes] = useState<string[]>([]);
	const [controlsCountSortDirection, setControlsCountSortDirection] =
		useState<ControlsCountSortDirection>("none");
	const [tableViewportWidthPx, setTableViewportWidthPx] = useState(0);
	const [inspectionScopeFullNameByKey, setInspectionScopeFullNameByKey] = useState<
		Record<string, string>
	>({});
	const [plantSearch, setPlantSearch] = useState("");
	const [entityTypeSearch, setEntityTypeSearch] = useState("");
	const [yearSearch, setYearSearch] = useState("");
	const [tableEntityFilter, setTableEntityFilter] = useState("");
	const [tableControlsFilter, setTableControlsFilter] = useState("");
	const [tableYearFilters, setTableYearFilters] = useState<Record<string, string>>({});
	const [selectedTableEntities, setSelectedTableEntities] = useState<string[]>([]);
	const [selectedTableYearScopes, setSelectedTableYearScopes] = useState<
		Record<string, string[]>
	>({});
	const [isTableHeaderAdvancedFilterModalOpen, setIsTableHeaderAdvancedFilterModalOpen] =
		useState(false);
	const [tableHeaderAdvancedFilterTarget, setTableHeaderAdvancedFilterTarget] =
		useState<TableHeaderAdvancedFilterTarget>(null);
	const [tableHeaderAdvancedFilterSearch, setTableHeaderAdvancedFilterSearch] =
		useState("");
	const [tableHeaderAdvancedFilterAnchor, setTableHeaderAdvancedFilterAnchor] = useState({
		top: 120,
		left: 120,
	});
	const [tableEntitySortDirection, setTableEntitySortDirection] =
		useState<EntitySortDirection>("none");
	const [activeControlTooltipKey, setActiveControlTooltipKey] = useState<string | null>(
		null,
	);
	const [inspectionDetailsByCode, setInspectionDetailsByCode] = useState<
		Record<
			string,
			{
				inspectionCode: string;
				poczatekInspekcji: string;
				koniecInspekcji: string;
				statusInspekcji: string;
			}
		>
	>({});
	const [inspectionDetailsByEntityYearType, setInspectionDetailsByEntityYearType] =
		useState<
			Record<
				string,
				Array<{
					inspectionCode: string;
					poczatekInspekcji: string;
					koniecInspekcji: string;
					statusInspekcji: string;
					scopes: string[];
				}>
			>
		>({});
	const filtersRef = useRef<HTMLDivElement | null>(null);
	const tableWrapperRef = useRef<HTMLDivElement | null>(null);
	const firstColumnNaturalWidthCh = useMemo(() => {
		const headerLength = "Nazwa podmiotu".length;
		const longestNameLength = rows.reduce(
			(maxLength, row) => Math.max(maxLength, row.nazwaPodmiotu.length),
			headerLength,
		);

		return Math.min(32, Math.max(18, longestNameLength + 2));
	}, [rows]);

	const toControlLabelFromCellEntry = useCallback(
		(entry: ReportInspectionMatrixRow["cells"][string][number]) => {
			const normalizedScopes = entry.scopes
				.map((scope) => scope.trim())
				.filter(Boolean);

			if (normalizedScopes.length === 0) {
				return `${entry.type}_[]`;
			}

			return `${entry.type}_[${normalizedScopes.join(", ")}]`;
		},
		[],
	);

	const parseControls = (value: string) =>
		value
			.split(",")
			.map((item) => item.trim())
			.filter((item) => item.length > 0 && item !== "-");

	const normalizeScope = useCallback((value: string) => value.trim().toLowerCase(), []);

	const getInspectionCodeLookupKeys = useCallback((inspectionCode: string) => {
		const raw = inspectionCode.trim();
		if (!raw || raw === "-") {
			return [] as string[];
		}

		const lower = raw.toLowerCase();
		const compact = lower.replace(/\s+/g, "");
		const separatorsNormalized = compact.replace(/[\\_|]+/g, "/");
		const withoutSeparators = compact.replace(/[^a-z0-9]/g, "");
		return Array.from(
			new Set(
				[lower, compact, separatorsNormalized, withoutSeparators].filter(Boolean),
			),
		);
	}, []);

	const getControlsForCell = useCallback(
		(row: ReportInspectionMatrixRow, year: string) => {
			const cellEntries = row.cells[year] ?? [];
			if (cellEntries.length > 0) {
				return cellEntries.map(toControlLabelFromCellEntry);
			}

			return parseControls(row.wartosci[year] ?? "-");
		},
		[toControlLabelFromCellEntry],
	);

	const selectedPlantsSet = useMemo(() => new Set(selectedPlants), [selectedPlants]);
	const selectedEntityTypesSet = useMemo(
		() => new Set(selectedEntityTypes),
		[selectedEntityTypes],
	);
	const selectedYearsSet = useMemo(() => new Set(selectedYears), [selectedYears]);
	const selectedInspectionScopesSet = useMemo(
		() => new Set(selectedInspectionScopes.map((scope) => normalizeScope(scope))),
		[selectedInspectionScopes, normalizeScope],
	);

	const allPlants = useMemo(
		() =>
			Array.from(new Set(rows.map((row) => row.nazwaPodmiotu))).sort((left, right) =>
				left.localeCompare(right),
			),
		[rows],
	);

	const allEntityTypes = useMemo(
		() =>
			Array.from(
				new Set(
					rows
						.map((row) => row.rodzajPodmiotu.trim())
						.filter((value) => value.length > 0 && value !== "-"),
				),
			).sort((left, right) => left.localeCompare(right, "pl", { sensitivity: "base" })),
		[rows],
	);

	const allYears = useMemo(() => [...years], [years]);

	const allInspectionScopes = useMemo(() => {
		const scopeSet = new Set<string>();

		for (const row of rows) {
			for (const year of years) {
				const cellEntries = row.cells[year] ?? [];
				for (const entry of cellEntries) {
					const fullScopes = entry.scopesFull.length > 0 ? entry.scopesFull : entry.scopes;
					for (const rawScope of fullScopes) {
						const trimmedScope = rawScope.trim();
						if (!trimmedScope) {
							continue;
						}

						const resolvedScope =
							inspectionScopeFullNameByKey[trimmedScope.toLowerCase()] ?? trimmedScope;
						const normalizedScope = resolvedScope.trim();
						if (normalizedScope) {
							scopeSet.add(normalizedScope);
						}
					}
				}
			}
		}

		return Array.from(scopeSet).sort((left, right) =>
			left.localeCompare(right, "pl", { sensitivity: "base" }),
		);
	}, [inspectionScopeFullNameByKey, rows, years]);

	const visibleYears = useMemo(() => {
		if (selectedYearsSet.size === 0) {
			return allYears;
		}

		return allYears.filter((year) => selectedYearsSet.has(year));
	}, [allYears, selectedYearsSet]);

	const tableYearScopeOptionsByYear = useMemo(() => {
		const next: Record<string, string[]> = {};
		for (const year of visibleYears) {
			const scopeSet = new Set<string>();
			for (const row of rows) {
				const cellEntries = row.cells[year] ?? [];
				for (const entry of cellEntries) {
					for (const scope of entry.scopes) {
						const trimmed = scope.trim();
						if (trimmed) {
							scopeSet.add(trimmed);
						}
					}
				}
			}

			next[year] = Array.from(scopeSet).sort((left, right) =>
				left.localeCompare(right, "pl", { sensitivity: "base" }),
			);
		}

		return next;
	}, [rows, visibleYears]);

	const resolvedYearColumnWidthPx = useMemo(() => {
		const availableWidthForYears =
			tableViewportWidthPx > 0
				? tableViewportWidthPx - REPORTS_MAP_FIRST_COLUMN_RESERVED_WIDTH_PX - REPORTS_MAP_COUNT_COLUMN_WIDTH_PX
				: 0;
		const targetWidth = Math.floor(
			availableWidthForYears / REPORTS_MAP_MAX_VISIBLE_YEAR_COLUMNS,
		);

		return Math.max(
			REPORTS_MAP_MIN_YEAR_COLUMN_WIDTH_PX,
			Math.min(
				REPORTS_MAP_MAX_YEAR_COLUMN_WIDTH_PX,
				Number.isFinite(targetWidth) && targetWidth > 0
					? targetWidth
					: REPORTS_MAP_MIN_YEAR_COLUMN_WIDTH_PX,
			),
		);
	}, [tableViewportWidthPx]);

	const yearColumnWidthByYearPx = useMemo(() => {
		const next: Record<string, number> = {};

		for (const year of visibleYears) {
			next[year] = resolvedYearColumnWidthPx;
		}

		return next;
	}, [resolvedYearColumnWidthPx, visibleYears]);

	const firstColumnWidthCh = useMemo(() => {
		const visibleYearCount = visibleYears.length;
		const maxByYearCount =
			visibleYearCount <= 4
				? 30
				: visibleYearCount <= 6
					? 26
					: visibleYearCount <= 8
						? 23
						: visibleYearCount <= 10
							? 20
							: 18;

		return Math.max(16, Math.min(firstColumnNaturalWidthCh, maxByYearCount));
	}, [firstColumnNaturalWidthCh, visibleYears.length]);

	const visiblePlantOptions = useMemo(() => {
		const query = plantSearch.trim().toLowerCase();
		if (!query) {
			return allPlants;
		}

		return allPlants.filter((plant) => plant.toLowerCase().includes(query));
	}, [allPlants, plantSearch]);

	const visibleEntityTypeOptions = useMemo(() => {
		const query = entityTypeSearch.trim().toLowerCase();
		if (!query) {
			return allEntityTypes;
		}

		return allEntityTypes.filter((entityType) =>
			entityType.toLowerCase().includes(query),
		);
	}, [allEntityTypes, entityTypeSearch]);

	const visibleYearOptions = useMemo(() => {
		const query = yearSearch.trim();
		if (!query) {
			return allYears;
		}

		return allYears.filter((year) => year.includes(query));
	}, [allYears, yearSearch]);

	const tableHeaderAdvancedFilterValues = useMemo(() => {
		if (!tableHeaderAdvancedFilterTarget) {
			return [] as string[];
		}

		if (tableHeaderAdvancedFilterTarget.kind === "entity") {
			return allPlants;
		}

		return tableYearScopeOptionsByYear[tableHeaderAdvancedFilterTarget.year] ?? [];
	}, [allPlants, tableHeaderAdvancedFilterTarget, tableYearScopeOptionsByYear]);

	const visibleTableHeaderAdvancedFilterValues = useMemo(() => {
		const query = tableHeaderAdvancedFilterSearch.trim().toLowerCase();
		if (!query) {
			return tableHeaderAdvancedFilterValues;
		}

		return tableHeaderAdvancedFilterValues.filter((value) =>
			value.toLowerCase().includes(query),
		);
	}, [tableHeaderAdvancedFilterSearch, tableHeaderAdvancedFilterValues]);

	const selectedTableHeaderAdvancedFilterValues = useMemo(() => {
		if (!tableHeaderAdvancedFilterTarget) {
			return [] as string[];
		}

		if (tableHeaderAdvancedFilterTarget.kind === "entity") {
			return selectedTableEntities;
		}

		return selectedTableYearScopes[tableHeaderAdvancedFilterTarget.year] ?? [];
	}, [selectedTableEntities, selectedTableYearScopes, tableHeaderAdvancedFilterTarget]);

	const tableHeaderAdvancedFilterColumnLabel = useMemo(() => {
		if (!tableHeaderAdvancedFilterTarget) {
			return "Kolumna";
		}

		if (tableHeaderAdvancedFilterTarget.kind === "entity") {
			return "Nazwa podmiotu";
		}

		return tableHeaderAdvancedFilterTarget.year;
	}, [tableHeaderAdvancedFilterTarget]);

	const getSelectionLabel = useCallback(
		(label: string, selectedCount: number, total: number) => {
			if (total === 0) return `${label}: brak`;
			if (selectedCount === 0) return `${label}: wszystkie`;
			return `${label}: ${selectedCount}`;
		},
		[],
	);

	const yearSelectionLabel = useMemo(() => {
		if (allYears.length === 0) {
			return "Rok: brak";
		}
		if (selectedYears.length === 0) {
			return "Rok: wszystkie";
		}
		if (selectedYears.length === allYears.length) {
			return "Rok: wszystkie";
		}

		const orderedSelectedYears = allYears.filter((year) =>
			selectedYearsSet.has(year),
		);
		if (selectedYears.length === 1) {
			return `Rok: ${selectedYears[0]}`;
		}
		if (orderedSelectedYears.length <= 3) {
			return `Rok: ${orderedSelectedYears.join(", ")}`;
		}

		const previewYears = orderedSelectedYears.slice(0, 3).join(", ");
		const remainingYearsCount = orderedSelectedYears.length - 3;
		return `Rok: ${previewYears} +${remainingYearsCount}`;

	}, [allYears, selectedYears, selectedYearsSet]);

	const toggleControlsSortDirection = useCallback(() => {
		setControlsCountSortDirection((previous) => {
			if (previous === "none") {
				return "desc";
			}
			if (previous === "desc") {
				return "asc";
			}

			return "none";
		});
	}, []);

	const toggleTableEntitySortDirection = useCallback(() => {
		setTableEntitySortDirection((previous) => {
			if (previous === "none") {
				return "asc";
			}
			if (previous === "asc") {
				return "desc";
			}

			return "none";
		});
	}, []);

	const filteredRows = useMemo(() => {
		return rows.filter((row) => {
			if (selectedPlantsSet.size > 0 && !selectedPlantsSet.has(row.nazwaPodmiotu)) {
				return false;
			}

			if (
				selectedEntityTypesSet.size > 0 &&
				!selectedEntityTypesSet.has(row.rodzajPodmiotu)
			) {
				return false;
			}

			return true;
		});
	}, [
		rows,
		selectedPlantsSet,
		selectedEntityTypesSet,
	]);

	const matchesInspectionScopeFilter = useCallback(
		(entry: ReportInspectionMatrixRow["cells"][string][number]) => {
			if (selectedInspectionScopesSet.size === 0) {
				return true;
			}

			const preferredScopes = entry.scopesFull.length > 0 ? entry.scopesFull : entry.scopes;
			for (const scope of preferredScopes) {
				const trimmedScope = scope.trim();
				if (!trimmedScope) {
					continue;
				}

				const resolvedScope =
					inspectionScopeFullNameByKey[trimmedScope.toLowerCase()] ?? trimmedScope;
				if (selectedInspectionScopesSet.has(normalizeScope(resolvedScope))) {
					return true;
				}
			}

			return false;
		},
		[inspectionScopeFullNameByKey, normalizeScope, selectedInspectionScopesSet],
	);

	const filteredRowsByScope = useMemo(() => {
		if (selectedInspectionScopesSet.size === 0) {
			return filteredRows;
		}

		return filteredRows.filter((row) => {
			for (const year of visibleYears) {
				const cellEntries = row.cells[year] ?? [];
				if (cellEntries.some((entry) => matchesInspectionScopeFilter(entry))) {
					return true;
				}
			}

			return false;
		});
	}, [
		filteredRows,
		matchesInspectionScopeFilter,
		selectedInspectionScopesSet,
		visibleYears,
	]);

	const togglePlant = useCallback((plant: string) => {
		setSelectedPlants((previous) =>
			previous.includes(plant)
				? previous.filter((item) => item !== plant)
				: [...previous, plant],
		);
	}, []);

	const toggleEntityType = useCallback((entityType: string) => {
		setSelectedEntityTypes((previous) =>
			previous.includes(entityType)
				? previous.filter((item) => item !== entityType)
				: [...previous, entityType],
		);
	}, []);

	const toggleYear = useCallback((year: string) => {
		setSelectedYears((previous) =>
			previous.includes(year)
				? previous.filter((item) => item !== year)
				: [...previous, year],
		);
	}, []);

	const toggleTableEntityOption = useCallback((entity: string) => {
		setSelectedTableEntities((previous) =>
			previous.includes(entity)
				? previous.filter((item) => item !== entity)
				: [...previous, entity],
		);
	}, []);

	const toggleTableYearScopeOption = useCallback((year: string, scope: string) => {
		setSelectedTableYearScopes((previous) => {
			const current = previous[year] ?? [];
			const next = current.includes(scope)
				? current.filter((item) => item !== scope)
				: [...current, scope];
			return {
				...previous,
				[year]: next,
			};
		});
	}, []);

	const closeOpenFilters = useCallback(() => {
		if (!filtersRef.current) return;

		for (const detailsElement of filtersRef.current.querySelectorAll("details[open]")) {
			(detailsElement as HTMLDetailsElement).open = false;
		}
	}, []);

	const clearFilters = useCallback(() => {
		setSelectedPlants([]);
		setSelectedEntityTypes([]);
		setSelectedYears([]);
		setSelectedInspectionScopes([]);
		setControlsCountSortDirection("none");
		setTableEntityFilter("");
		setTableControlsFilter("");
		setTableYearFilters({});
		setSelectedTableEntities([]);
		setSelectedTableYearScopes({});
		setTableEntitySortDirection("none");
		setIsHeatmapEnabled(false);
		setTableHeaderAdvancedFilterSearch("");
		setIsTableHeaderAdvancedFilterModalOpen(false);
		setTableHeaderAdvancedFilterTarget(null);
		closeOpenFilters();
	}, [closeOpenFilters]);

	const handleFilterToggle = useCallback((currentDetails: HTMLDetailsElement) => {
		if (!currentDetails.open || !filtersRef.current) return;

		for (const detailsElement of filtersRef.current.querySelectorAll("details[open]")) {
			if (detailsElement !== currentDetails) {
				(detailsElement as HTMLDetailsElement).open = false;
			}
		}
	}, []);

	const openTableHeaderAdvancedFilter = useCallback(
		(target: TableHeaderAdvancedFilterTarget, triggerElement: HTMLElement) => {
			if (!target) {
				return;
			}

			setTableHeaderAdvancedFilterAnchor(getFloatingPanelAnchor(triggerElement));
			setTableHeaderAdvancedFilterTarget(target);
			setTableHeaderAdvancedFilterSearch("");
			setIsTableHeaderAdvancedFilterModalOpen(true);
		},
		[],
	);

	const toggleTableHeaderAdvancedFilterValue = useCallback(
		(value: string) => {
			if (!tableHeaderAdvancedFilterTarget) {
				return;
			}

			if (tableHeaderAdvancedFilterTarget.kind === "entity") {
				setSelectedTableEntities((previous) =>
					previous.includes(value)
						? previous.filter((item) => item !== value)
						: [...previous, value],
				);
				return;
			}

			const selectedYear = tableHeaderAdvancedFilterTarget.year;
			setSelectedTableYearScopes((previous) => {
				const current = previous[selectedYear] ?? [];
				const next = current.includes(value)
					? current.filter((item) => item !== value)
					: [...current, value];
				return {
					...previous,
					[selectedYear]: next,
				};
			});
		},
		[tableHeaderAdvancedFilterTarget],
	);

	const selectAllVisibleTableHeaderAdvancedFilterValues = useCallback(() => {
		if (!tableHeaderAdvancedFilterTarget) {
			return;
		}

		if (tableHeaderAdvancedFilterTarget.kind === "entity") {
			setSelectedTableEntities((previous) => {
				const current = new Set(previous);
				for (const value of visibleTableHeaderAdvancedFilterValues) {
					current.add(value);
				}
				return Array.from(current);
			});
			return;
		}

		const selectedYear = tableHeaderAdvancedFilterTarget.year;
		setSelectedTableYearScopes((previous) => {
			const current = new Set(previous[selectedYear] ?? []);
			for (const value of visibleTableHeaderAdvancedFilterValues) {
				current.add(value);
			}

			return {
				...previous,
				[selectedYear]: Array.from(current),
			};
		});
	}, [tableHeaderAdvancedFilterTarget, visibleTableHeaderAdvancedFilterValues]);

	const clearSelectedTableHeaderAdvancedFilterValues = useCallback(() => {
		if (!tableHeaderAdvancedFilterTarget) {
			return;
		}

		if (tableHeaderAdvancedFilterTarget.kind === "entity") {
			setSelectedTableEntities([]);
			return;
		}

		const selectedYear = tableHeaderAdvancedFilterTarget.year;
		setSelectedTableYearScopes((previous) => ({
			...previous,
			[selectedYear]: [],
		}));
	}, [tableHeaderAdvancedFilterTarget]);

	useEffect(() => {
		const wrapper = tableWrapperRef.current;
		if (!wrapper) {
			return;
		}

		const updateViewportWidth = () => {
			setTableViewportWidthPx(wrapper.clientWidth);
		};

		updateViewportWidth();
		const observer = new ResizeObserver(() => {
			updateViewportWidth();
		});
		observer.observe(wrapper);

		return () => {
			observer.disconnect();
		};
	}, []);

	useEffect(() => {
		if (mapViewMode === "chart") {
			closeOpenFilters();
			setIsTableHeaderAdvancedFilterModalOpen(false);
			setTableHeaderAdvancedFilterTarget(null);
			setActiveControlTooltipKey(null);
		}
	}, [closeOpenFilters, mapViewMode]);

	useEffect(() => {
		if (!isFullscreen || typeof document === "undefined") {
			return;
		}

		const previousOverflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";

		const handleKeyDown = (event: KeyboardEvent) => {
			if (event.key === "Escape") {
				setIsFullscreen(false);
			}
		};

		window.addEventListener("keydown", handleKeyDown);

		return () => {
			document.body.style.overflow = previousOverflow;
			window.removeEventListener("keydown", handleKeyDown);
		};
	}, [isFullscreen]);

	useEffect(() => {
		setSelectedPlants((previous) => {
			const filtered = previous.filter((plant) => allPlants.includes(plant));
			return filtered.length === previous.length ? previous : filtered;
		});
	}, [allPlants]);

	useEffect(() => {
		setSelectedEntityTypes((previous) => {
			const filtered = previous.filter((entityType) =>
				allEntityTypes.includes(entityType),
			);
			return filtered.length === previous.length ? previous : filtered;
		});
	}, [allEntityTypes]);

	useEffect(() => {
		setSelectedYears((previous) => {
			const filtered = previous.filter((year) => allYears.includes(year));
			return filtered.length === previous.length ? previous : filtered;
		});
	}, [allYears]);

	useEffect(() => {
		setSelectedInspectionScopes((previous) => {
			const availableScopesSet = new Set(allInspectionScopes);
			const filtered = previous.filter((scope) => availableScopesSet.has(scope));
			return filtered.length === previous.length ? previous : filtered;
		});
	}, [allInspectionScopes]);

	useEffect(() => {
		setTableYearFilters((previous) => {
			const allowedYears = new Set(allYears);
			const nextEntries = Object.entries(previous).filter(([year]) =>
				allowedYears.has(year),
			);
			if (nextEntries.length === Object.keys(previous).length) {
				return previous;
			}

			return Object.fromEntries(nextEntries);
		});
	}, [allYears]);

	useEffect(() => {
		setSelectedTableEntities((previous) => {
			const allowedEntities = new Set(allPlants);
			const filtered = previous.filter((entity) => allowedEntities.has(entity));
			return filtered.length === previous.length ? previous : filtered;
		});
	}, [allPlants]);

	useEffect(() => {
		setSelectedTableYearScopes((previous) => {
			const next: Record<string, string[]> = {};
			let changed = false;

			for (const year of Object.keys(previous)) {
				const allowedScopes = new Set(tableYearScopeOptionsByYear[year] ?? []);
				const filtered = (previous[year] ?? []).filter((scope) => allowedScopes.has(scope));
				next[year] = filtered;
				if (filtered.length !== (previous[year] ?? []).length) {
					changed = true;
				}
			}

			return changed ? next : previous;
		});
	}, [tableYearScopeOptionsByYear]);

	const getDisplayCellValue = useCallback(
		(row: ReportInspectionMatrixRow, year: string) => {
			const controls = getControlsForCell(row, year);
			if (controls.length === 0) {
				return "-";
			}

			const parseForExport = (controlLabel: string) => {
				const normalized = controlLabel.trim();
				const match = normalized.match(/^([A-Za-z]+)_\[(.*)\]$/);
				if (!match) {
					return {
						type: normalized.toUpperCase().startsWith("WN") ? "WN" : "K",
						scopesLabel: normalized || "-",
					};
				}

				const rawType = (match[1] ?? "K").trim().toUpperCase();
				const type = rawType === "WN" ? "WN" : "K";
				const rawScopes = (match[2] ?? "").trim();
				const scopes = rawScopes
					.split(",")
					.map((scope) => scope.trim())
					.filter(Boolean);

				return {
					type,
					scopesLabel: scopes.length > 0 ? scopes.join(", ") : "Brak zakresu",
				};
			};

			const getRankForExport = (controlLabel: string) =>
				parseForExport(controlLabel).type === "K" ? 0 : 1;

			const sortedControls = [...controls].sort((left, right) => {
				const rankDiff = getRankForExport(left) - getRankForExport(right);
				if (rankDiff !== 0) {
					return rankDiff;
				}

				return left.localeCompare(right, "pl", { sensitivity: "base" });
			});

			const displayLines = sortedControls.map((controlLabel) => {
				const parsed = parseForExport(controlLabel);
				return `${parsed.type}: ${parsed.scopesLabel}`;
			});

			return displayLines.join("\n");
		},
		[getControlsForCell],
	);

	const getTotalControlsForRow = useCallback(
		(row: ReportInspectionMatrixRow) => {
			return visibleYears.reduce((total, year) => {
				const cellEntries = row.cells[year] ?? [];
				if (cellEntries.length > 0) {
					return (
						total + cellEntries.filter((entry) => matchesInspectionScopeFilter(entry)).length
					);
				}

				if (selectedInspectionScopesSet.size > 0) {
					return total;
				}

				return total + getControlsForCell(row, year).length;
			}, 0);
		},
		[
			getControlsForCell,
			matchesInspectionScopeFilter,
			selectedInspectionScopesSet,
			visibleYears,
		],
	);

	const displayedRows = useMemo(() => {
		const nextRows = [...filteredRowsByScope];
		if (controlsCountSortDirection === "none") {
			return nextRows;
		}

		nextRows.sort((left, right) => {
			const leftCount = getTotalControlsForRow(left);
			const rightCount = getTotalControlsForRow(right);
			if (leftCount !== rightCount) {
				return controlsCountSortDirection === "asc"
					? leftCount - rightCount
					: rightCount - leftCount;
			}

			return left.nazwaPodmiotu.localeCompare(right.nazwaPodmiotu, "pl", {
				sensitivity: "base",
			});
		});

		return nextRows;
	}, [controlsCountSortDirection, filteredRowsByScope, getTotalControlsForRow]);

	const getCellSearchTextForYearFilter = useCallback(
		(row: ReportInspectionMatrixRow, year: string) => {
			const cellEntries = row.cells[year] ?? [];
			if (cellEntries.length > 0) {
				const filteredEntries =
					selectedInspectionScopesSet.size > 0
						? cellEntries.filter((entry) => matchesInspectionScopeFilter(entry))
						: cellEntries;
				if (filteredEntries.length === 0) {
					return "";
				}

				return filteredEntries
					.map((entry) => {
						const scopesLabel =
							entry.scopes.length > 0
								? entry.scopes.join(", ")
								: entry.zakresInspekcji || entry.zakresInspekcjiPelny || "Brak zakresu";
						return `${entry.type}: ${scopesLabel}`;
					})
					.join(" | ")
					.toLowerCase();
			}

			if (selectedInspectionScopesSet.size > 0) {
				return "";
			}

			return getControlsForCell(row, year).join(" | ").toLowerCase();
		},
		[
			getControlsForCell,
			matchesInspectionScopeFilter,
			selectedInspectionScopesSet,
		],
	);

	const tableFilteredRows = useMemo(() => {
		const entityQuery = tableEntityFilter.trim().toLowerCase();
		const controlsRaw = tableControlsFilter.trim();
		const controlsValue = Number(controlsRaw);
		const hasControlsNumber =
			controlsRaw.length > 0 &&
			Number.isFinite(controlsValue) &&
			Number.isInteger(controlsValue) &&
			controlsValue >= 0;
		const selectedTableEntitiesSet = new Set(selectedTableEntities);
		const normalizedYearScopeSelections: Record<string, Set<string>> = {};
		for (const year of visibleYears) {
			normalizedYearScopeSelections[year] = new Set(
				(selectedTableYearScopes[year] ?? []).map((scope) => normalizeScope(scope)),
			);
		}

		const filteredRows = displayedRows.filter((row) => {
			if (entityQuery && !row.nazwaPodmiotu.toLowerCase().includes(entityQuery)) {
				return false;
			}
			if (
				selectedTableEntitiesSet.size > 0 &&
				!selectedTableEntitiesSet.has(row.nazwaPodmiotu)
			) {
				return false;
			}

			const controlsCount = getTotalControlsForRow(row);
			if (hasControlsNumber && controlsCount !== controlsValue) {
				return false;
			}

			for (const year of visibleYears) {
				const selectedYearScopesSet = normalizedYearScopeSelections[year] ?? new Set();
				if (selectedYearScopesSet.size > 0) {
					const cellEntries = row.cells[year] ?? [];
					const hasMatchingScope = cellEntries.some((entry) =>
						entry.scopes.some((scope) => selectedYearScopesSet.has(normalizeScope(scope))),
					);
					if (!hasMatchingScope) {
						return false;
					}
				}

				const query = (tableYearFilters[year] ?? "").trim().toLowerCase();
				if (!query) {
					continue;
				}

				const searchableCellValue = getCellSearchTextForYearFilter(row, year);
				if (!searchableCellValue.includes(query)) {
					return false;
				}
			}

			return true;
		});

		if (tableEntitySortDirection === "none") {
			return filteredRows;
		}

		return [...filteredRows].sort((left, right) => {
			const compare = left.nazwaPodmiotu.localeCompare(right.nazwaPodmiotu, "pl", {
				sensitivity: "base",
			});
			return tableEntitySortDirection === "asc" ? compare : -compare;
		});
	}, [
		displayedRows,
		getCellSearchTextForYearFilter,
		getTotalControlsForRow,
		normalizeScope,
		selectedTableEntities,
		selectedTableYearScopes,
		tableControlsFilter,
		tableEntityFilter,
		tableEntitySortDirection,
		tableYearFilters,
		visibleYears,
	]);

	const handleTableYearFilterChange = useCallback((year: string, value: string) => {
		setTableYearFilters((previous) => ({
			...previous,
			[year]: value,
		}));
	}, []);

	const chartRows = useMemo(
		() =>
			displayedRows
				.map((row) => ({
					entityName: row.nazwaPodmiotu,
					controlsCount: getTotalControlsForRow(row),
				}))
				.sort((left, right) => {
					if (right.controlsCount !== left.controlsCount) {
						return right.controlsCount - left.controlsCount;
					}

					return left.entityName.localeCompare(right.entityName, "pl", {
						sensitivity: "base",
					});
				}),
		[displayedRows, getTotalControlsForRow],
	);

	const maxChartControlsCount = useMemo(
		() => chartRows.reduce((max, row) => Math.max(max, row.controlsCount), 0),
		[chartRows],
	);

	const formatRangeLabel = useCallback((values: number[]) => {
		if (values.length === 0) {
			return null;
		}

		const min = Math.min(...values);
		const max = Math.max(...values);
		return min === max ? String(min) : `${min}-${max}`;
	}, []);

	const rowControlCounts = useMemo(
		() => tableFilteredRows.map((row) => getTotalControlsForRow(row)),
		[tableFilteredRows, getTotalControlsForRow],
	);

	const nonZeroRowControlCounts = useMemo(
		() => rowControlCounts.filter((value) => value > 0),
		[rowControlCounts],
	);

	const rowIntensityScale = useMemo(() => {
		if (nonZeroRowControlCounts.length === 0) {
			return null;
		}

		const sorted = [...nonZeroRowControlCounts].sort((left, right) => left - right);
		const lastIndex = sorted.length - 1;
		const minValue = sorted[0] as number;
		const maxValue = sorted[lastIndex] as number;
		const q1 = sorted[Math.floor(lastIndex / 4)] ?? minValue;
		const q2 = sorted[Math.floor(lastIndex / 2)] ?? minValue;
		const q3 = sorted[Math.floor((3 * lastIndex) / 4)] ?? maxValue;

		return {
			q1,
			q2,
			q3,
		};
	}, [nonZeroRowControlCounts]);

	const rowIntensityLegend = useMemo(() => {
		const hasZero = rowControlCounts.some((value) => value === 0);

		if (!rowIntensityScale) {
			return {
				hasZero,
				bin1Label: null as string | null,
				bin2Label: null as string | null,
				bin3Label: null as string | null,
				bin4Label: null as string | null,
			};
		}

		const bin1Values = nonZeroRowControlCounts.filter(
			(value) => value <= rowIntensityScale.q1,
		);
		const bin2Values = nonZeroRowControlCounts.filter(
			(value) => value > rowIntensityScale.q1 && value <= rowIntensityScale.q2,
		);
		const bin3Values = nonZeroRowControlCounts.filter(
			(value) => value > rowIntensityScale.q2 && value <= rowIntensityScale.q3,
		);
		const bin4Values = nonZeroRowControlCounts.filter(
			(value) => value > rowIntensityScale.q3,
		);

		return {
			hasZero,
			bin1Label: formatRangeLabel(bin1Values),
			bin2Label: formatRangeLabel(bin2Values),
			bin3Label: formatRangeLabel(bin3Values),
			bin4Label: formatRangeLabel(bin4Values),
		};
	}, [formatRangeLabel, nonZeroRowControlCounts, rowControlCounts, rowIntensityScale]);

	const getRowIntensityClass = useCallback(
		(controlsCount: number) => {
			if (!isHeatmapEnabled || controlsCount <= 0 || !rowIntensityScale) {
				return "";
			}

			if (controlsCount <= rowIntensityScale.q1) {
				return "bg-[#e9f2ff]";
			}
			if (controlsCount <= rowIntensityScale.q2) {
				return "bg-[#d4e7ff]";
			}
			if (controlsCount <= rowIntensityScale.q3) {
				return "bg-[#bbd8ff]";
			}

			return "bg-[#8dbaf5]";
		},
		[isHeatmapEnabled, rowIntensityScale],
	);

	const parseControlLabel = useCallback((controlLabel: string) => {
		const normalized = controlLabel.trim();
		const match = normalized.match(/^([A-Za-z]+)_\[(.*)\]$/);
		if (!match) {
			return {
				type: normalized.toUpperCase().startsWith("WN") ? "WN" : "K",
				scopesLabel: normalized || "-",
			};
		}

		const rawType = (match[1] ?? "K").trim().toUpperCase();
		const type = rawType === "WN" ? "WN" : "K";
		const rawScopes = (match[2] ?? "").trim();
		const scopes = rawScopes
			.split(",")
			.map((scope) => scope.trim())
			.filter(Boolean);

		return {
			type,
			scopesLabel: scopes.length > 0 ? scopes.join(", ") : "Brak zakresu",
		};
	}, []);

	const toScopesList = useCallback((scopesLabel: string) => {
		const scopes = scopesLabel
			.split(",")
			.map((scope) => scope.trim())
			.filter(Boolean);

		return scopes.length > 0 ? scopes : ["Brak zakresu"];
	}, []);

	const resolveFullScopeLabel = useCallback(
		(scopeLabel: string) => {
			const normalizedScopeLabel = scopeLabel.trim();
			if (!normalizedScopeLabel) {
				return "Brak zakresu";
			}

			return (
				inspectionScopeFullNameByKey[normalizedScopeLabel.toLowerCase()] ??
				normalizedScopeLabel
			);
		},
		[inspectionScopeFullNameByKey],
	);

	const normalizeTooltipScopes = useCallback(
		(scopes: string[]) => {
			const normalized = scopes
				.map((scope) => resolveFullScopeLabel(scope).trim())
				.filter(Boolean);
			const unique = Array.from(new Set(normalized));

			return unique.length > 0 ? unique : ["Brak zakresu"];
		},
		[resolveFullScopeLabel],
	);

	const getMatrixEntryScopes = useCallback(
		(entry: ReportInspectionMatrixRow["cells"][string][number]) => {
			if (entry.scopesFull.length > 0) {
				return entry.scopesFull;
			}

			if (entry.scopes.length > 0) {
				return entry.scopes;
			}

			return [] as string[];
		},
		[],
	);

	const getMatrixEntryScopesLabel = useCallback(
		(entry: ReportInspectionMatrixRow["cells"][string][number]) => {
			if (entry.scopes.length > 0) {
				return entry.scopes.join(", ");
			}

			if (entry.zakresInspekcji.trim()) {
				return entry.zakresInspekcji.trim();
			}

			if (entry.scopesFull.length > 0) {
				return entry.scopesFull.join(", ");
			}

			if (entry.zakresInspekcjiPelny.trim()) {
				return entry.zakresInspekcjiPelny.trim();
			}

			return "Brak zakresu";
		},
		[getMatrixEntryScopes],
	);

	const getFallbackDetailForLegacyCell = useCallback(
		(row: ReportInspectionMatrixRow, year: string, controlLabel: string) => {
			const parsed = parseControlLabel(controlLabel);
			const key = `${row.nazwaPodmiotu.trim().toLowerCase()}|${year}|${parsed.type}`;
			const candidates = inspectionDetailsByEntityYearType[key] ?? [];
			if (candidates.length === 0) {
				return null;
			}

			return candidates[0] ?? null;
		},
		[
			inspectionDetailsByEntityYearType,
			parseControlLabel,
		],
	);

	const getControlTypeRank = useCallback((controlLabel: string) => {
		const parsed = parseControlLabel(controlLabel);
		return parsed.type === "K" ? 0 : 1;
	}, [parseControlLabel]);

	const loadReport = useCallback(async () => {
		setIsLoading(true);
		setError(null);

		const [matrixResult, detailsResult] = await Promise.all([
			fetchInspectionsReportMatrix(operatorLogin),
			fetchInspectionsDetailedReport(operatorLogin),
		]);

		if (!matrixResult.ok) {
			setRows([]);
			setYears([]);
			setInspectionDetailsByCode({});
			setInspectionDetailsByEntityYearType({});
			setError(matrixResult.error);
			setIsLoading(false);
			return;
		}

		setRows(matrixResult.data.rows);
		setYears(matrixResult.data.lata);

		if (detailsResult.ok) {
			const nextDetailsByCode: Record<
				string,
				{
					inspectionCode: string;
					poczatekInspekcji: string;
					koniecInspekcji: string;
					statusInspekcji: string;
				}
			> = {};
			const nextDetailsByEntityYearType: Record<
				string,
				Array<{
					inspectionCode: string;
					poczatekInspekcji: string;
					koniecInspekcji: string;
					statusInspekcji: string;
					scopes: string[];
				}>
			> = {};

			for (const detailRow of detailsResult.data.rows) {
				const inspectionCode = String(detailRow.kodInspekcji ?? "").trim();
				const inspectionId =
					typeof detailRow.inspectionId === "number" && Number.isFinite(detailRow.inspectionId)
						? detailRow.inspectionId
						: null;
				if ((!inspectionCode || inspectionCode === "-") && inspectionId === null) {
					continue;
				}

				const poczatekInspekcji =
					String(detailRow.poczatekInspekcji ?? "-").trim() || "-";
				const koniecInspekcji =
					String(detailRow.koniecInspekcji ?? "-").trim() || "-";
				const statusInspekcji =
					String(detailRow.statusInspekcji ?? "-").trim() || "-";

				const nextDetail = {
					inspectionCode,
					poczatekInspekcji,
					koniecInspekcji,
					statusInspekcji,
				};

				for (const lookupKey of getInspectionCodeLookupKeys(inspectionCode)) {
					nextDetailsByCode[lookupKey] = nextDetail;
				}
				if (inspectionId !== null) {
					nextDetailsByCode[`id:${inspectionId}`] = nextDetail;
				}

				const entityName = String(detailRow.nazwaPodmiotu ?? "").trim().toLowerCase();
				const year = String(detailRow.rokPoczatku ?? "").trim();
				const controlType = detailRow.inspekcja === "W" ? "WN" : "K";
				if (entityName && year) {
					const key = `${entityName}|${year}|${controlType}`;
					const scopesRaw = detailRow.zakresInspekcjiItems;
					const scopes = scopesRaw
						.map(resolveFullScopeLabel)
						.map(normalizeScope)
						.filter(Boolean);

					nextDetailsByEntityYearType[key] ??= [];
					nextDetailsByEntityYearType[key].push({
						inspectionCode,
						poczatekInspekcji,
						koniecInspekcji,
						statusInspekcji,
						scopes,
					});
				}
			}

			setInspectionDetailsByCode(nextDetailsByCode);
			setInspectionDetailsByEntityYearType(nextDetailsByEntityYearType);
		} else {
			setInspectionDetailsByCode({});
			setInspectionDetailsByEntityYearType({});
		}

		setIsLoading(false);
	}, [
		getInspectionCodeLookupKeys,
		normalizeScope,
		operatorLogin,
		resolveFullScopeLabel,
	]);

	const handleExportToExcel = useCallback(async () => {
		if (isExporting || tableFilteredRows.length === 0) {
			return;
		}

		setIsExporting(true);
		setError(null);

		try {
			const workbook = await createStyledExportWorkbook("Mapa inspekcji");
			const worksheet = workbook.addWorksheet("Mapa inspekcji");

			const headers = ["Nazwa podmiotu", "Liczba kontroli", ...visibleYears];
			worksheet.addRow(headers);

			for (const row of tableFilteredRows) {
				const values = visibleYears.map((year) => {
					return getDisplayCellValue(row, year);
				});
				const dataRow = worksheet.addRow([
					row.nazwaPodmiotu,
					getTotalControlsForRow(row),
					...values,
				]);
				dataRow.getCell(2).alignment = {
					vertical: "top",
					horizontal: "right",
				};
				for (let yearColumnIndex = 3; yearColumnIndex <= headers.length; yearColumnIndex += 1) {
					dataRow.getCell(yearColumnIndex).alignment = {
						vertical: "top",
						horizontal: "left",
						wrapText: true,
					};
				}
			}

			const headerRow = worksheet.getRow(1);
			headerRow.font = { bold: true };
			headerRow.alignment = { vertical: "middle", horizontal: "left" };

			worksheet.columns = headers.map((header, index) => {
				if (index === 0) {
					return { header, width: Math.max(22, firstColumnWidthCh) };
				}
				if (index === 1) {
					return { header, width: 18 };
				}
				return {
					header,
					width: Math.max(
						12,
						Math.round((yearColumnWidthByYearPx[header] ?? 160) / 8),
					),
				};
			});

			const legendWorksheet = workbook.addWorksheet("Legenda zakresow inspekcji");
			legendWorksheet.addRow(["Nazwa pełna", "Nazwa skrócona"]);

			const inspectionScopesResult = await fetchDictionaryEntries(
				"zakresy_inspekcji",
				operatorLogin,
			);

			if (inspectionScopesResult.ok) {
				const sortedScopes = [...inspectionScopesResult.data].sort((left, right) => {
					const leftOrder = left.kolejnosc ?? Number.MAX_SAFE_INTEGER;
					const rightOrder = right.kolejnosc ?? Number.MAX_SAFE_INTEGER;
					if (leftOrder !== rightOrder) {
						return leftOrder - rightOrder;
					}

					return left.nazwaPozycji.localeCompare(right.nazwaPozycji, "pl", {
						sensitivity: "base",
					});
				});

				for (const scopeEntry of sortedScopes) {
					legendWorksheet.addRow([
						scopeEntry.nazwaPozycji,
						scopeEntry.skrotPozycji?.trim() || "-",
					]);
				}
			} else {
				legendWorksheet.addRow([
					"Nie udało się pobrać słownika zakresów inspekcji.",
					"-",
				]);
			}

			const legendHeaderRow = legendWorksheet.getRow(1);
			legendHeaderRow.font = { bold: true };
			legendHeaderRow.alignment = { vertical: "middle", horizontal: "left" };
			legendWorksheet.columns = [
				{ header: "Nazwa pełna", width: 54 },
				{ header: "Nazwa skrócona", width: 28 },
			];

			const fileName = "wykonane-inspekcje.xlsx";
			await saveWorkbookAsXlsx(workbook, fileName);
		} catch (exportError) {
			if (exportError instanceof DOMException && exportError.name === "AbortError") {
				return;
			}

			setError("Nie udało się wyeksportować danych do Excela.");
		} finally {
			setIsExporting(false);
		}
	}, [
		firstColumnWidthCh,
		getDisplayCellValue,
		getTotalControlsForRow,
		isExporting,
		operatorLogin,
		tableFilteredRows,
		yearColumnWidthByYearPx,
		visibleYears,
	]);

	useEffect(() => {
		loadReport();
	}, [loadReport]);

	useEffect(() => {
		const handleInspectionsChanged = () => {
			void loadReport();
		};

		window.addEventListener(INSPECTIONS_CHANGED_EVENT, handleInspectionsChanged);
		return () => {
			window.removeEventListener(INSPECTIONS_CHANGED_EVENT, handleInspectionsChanged);
		};
	}, [loadReport]);

	useEffect(() => {
		let isActive = true;

		const loadInspectionScopeDictionary = async () => {
			const result = await fetchDictionaryEntries("zakresy_inspekcji", operatorLogin);
			if (!result.ok || !isActive) {
				return;
			}

			const nextMap: Record<string, string> = {};
			for (const entry of result.data) {
				const fullName = String(entry.nazwaPozycji ?? "").trim();
				if (!fullName) {
					continue;
				}

				nextMap[fullName.toLowerCase()] = fullName;

				const shortName = String(entry.skrotPozycji ?? "").trim();
				if (shortName) {
					nextMap[shortName.toLowerCase()] = fullName;
				}

				const userName = String(entry.nazwaUzytkowa ?? "").trim();
				if (userName) {
					nextMap[userName.toLowerCase()] = fullName;
				}
			}

			setInspectionScopeFullNameByKey(nextMap);
		};

		void loadInspectionScopeDictionary();

		return () => {
			isActive = false;
		};
	}, [operatorLogin]);

	useEffect(() => {
		const handlePointerDown = (event: MouseEvent) => {
			if (!filtersRef.current) return;

			const target = event.target;
			if (!(target instanceof Node)) return;

			if (!filtersRef.current.contains(target)) {
				closeOpenFilters();
			}

			if (tableWrapperRef.current?.contains(target)) {
				if (
					target instanceof HTMLElement &&
					target.closest("[data-tooltip-interactive='true']")
				) {
					return;
				}

				setActiveControlTooltipKey(null);
				return;
			}

			setActiveControlTooltipKey(null);
		};

		const handleEscape = (event: KeyboardEvent) => {
			if (event.key === "Escape") {
				closeOpenFilters();
				setIsTableHeaderAdvancedFilterModalOpen(false);
				setTableHeaderAdvancedFilterTarget(null);
			}
		};

		document.addEventListener("mousedown", handlePointerDown);
		document.addEventListener("keydown", handleEscape);

		return () => {
			document.removeEventListener("mousedown", handlePointerDown);
			document.removeEventListener("keydown", handleEscape);
		};
	}, [closeOpenFilters]);

	return (
		<TableFullscreenContainer
			isFullscreen={isFullscreen}
			onClose={() => setIsFullscreen(false)}
			className="relative flex h-full min-h-0 w-full flex-col gap-3 rounded-2xl border border-slate-700/70 bg-[#101f39] px-2 pt-4 pb-2 sm:px-2 sm:pt-5 sm:pb-2 shadow-[0_18px_44px_rgba(2,8,23,0.34)]"
		>
			{!isFullscreen ? (
				<div ref={filtersRef} className="space-y-2">
				<div className="flex flex-wrap items-center gap-3">
					<h2 className="whitespace-nowrap font-semibold text-slate-100 text-xl leading-none">
						Mapa inspekcji
					</h2>

					<div className="flex min-w-0 flex-wrap items-center gap-2">
						<div className="flex min-w-0 max-w-full flex-wrap items-center gap-2 rounded-xl border border-[#3a588b]/90 bg-[#172c4a]/95 px-2.5 py-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]">
							<span className="shrink-0 rounded-md border border-slate-500/60 bg-slate-900/35 px-2 py-1 font-semibold text-[10px] text-slate-300 uppercase tracking-wide">
								Filtry
							</span>
							<div className="h-5 w-px shrink-0 bg-slate-500/50" />
							<div className="flex min-w-0 flex-wrap items-center gap-2 overflow-visible">
						<details
							className="group relative"
							onToggle={(event) => handleFilterToggle(event.currentTarget)}
						>
							<summary className="inline-flex h-8 w-52 cursor-pointer list-none items-center justify-between rounded-md border border-slate-500/80 bg-[#1f3658] px-3 py-1 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#294673]">
								<span className="truncate">
									{getSelectionLabel(
										"Rodzaj podmiotu",
										selectedEntityTypes.length,
										allEntityTypes.length,
									)}
								</span>
								<ChevronDown
									size={14}
									className="shrink-0 text-slate-300 transition-transform duration-150 group-open:rotate-180"
								/>
							</summary>
							<div className="absolute left-0 z-30 mt-2 w-80 rounded-lg border border-slate-300 bg-slate-100 p-2 shadow-[0_14px_28px_rgba(2,8,23,0.24)]">
								<input
									type="text"
									value={entityTypeSearch}
									onChange={(event) => setEntityTypeSearch(event.target.value)}
									placeholder="Szukaj rodzaju podmiotu"
									className="w-full rounded-md border border-slate-300 bg-white px-2.5 py-2 text-slate-700 text-sm outline-none placeholder:text-slate-400 focus:border-slate-400"
								/>
								<div className="subtle-vertical-scroll mt-2 max-h-36 space-y-1 overflow-auto pr-1">
									{visibleEntityTypeOptions.map((entityType) => {
										const isSelected = selectedEntityTypes.includes(entityType);
										return (
											<label
												key={entityType}
												className="flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-1.5 text-slate-700 text-sm hover:bg-slate-200/70"
												title={entityType}
											>
												<input
													type="checkbox"
													checked={isSelected}
													onChange={() => toggleEntityType(entityType)}
													className="h-3.5 w-3.5"
												/>
												<span className="truncate">{entityType}</span>
											</label>
										);
									})}
									{visibleEntityTypeOptions.length === 0 ? (
										<p className="px-2 py-1 text-slate-500 text-sm">Brak wyników.</p>
									) : null}
								</div>
							</div>
						</details>

						<details
							className="group relative"
							onToggle={(event) => handleFilterToggle(event.currentTarget)}
						>
							<summary className="inline-flex h-8 w-44 cursor-pointer list-none items-center justify-between rounded-md border border-slate-500/80 bg-[#1f3658] px-3 py-1 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#294673]">
								<span className="truncate">
									{getSelectionLabel("Podmioty", selectedPlants.length, allPlants.length)}
								</span>
								<ChevronDown
									size={14}
									className="shrink-0 text-slate-300 transition-transform duration-150 group-open:rotate-180"
								/>
							</summary>
							<div className="absolute left-0 z-30 mt-2 w-80 rounded-lg border border-slate-300 bg-slate-100 p-2 shadow-[0_14px_28px_rgba(2,8,23,0.24)]">
								<input
									type="text"
									value={plantSearch}
									onChange={(event) => setPlantSearch(event.target.value)}
									placeholder="Szukaj zakładu"
									className="w-full rounded-md border border-slate-300 bg-white px-2.5 py-2 text-slate-700 text-sm outline-none placeholder:text-slate-400 focus:border-slate-400"
								/>
								<div className="subtle-vertical-scroll mt-2 max-h-36 space-y-1 overflow-auto pr-1">
									{visiblePlantOptions.map((plant) => {
										const isSelected = selectedPlants.includes(plant);
										return (
											<label
												key={plant}
												className="flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-1.5 text-slate-700 text-sm hover:bg-slate-200/70"
												title={plant}
											>
												<input
													type="checkbox"
													checked={isSelected}
													onChange={() => togglePlant(plant)}
													className="h-3.5 w-3.5"
												/>
												<span className="truncate">{plant}</span>
											</label>
										);
									})}
									{visiblePlantOptions.length === 0 ? (
										<p className="px-2 py-1 text-slate-500 text-sm">Brak wyników.</p>
									) : null}
								</div>
							</div>
						</details>

						<details
							className="group relative"
							onToggle={(event) => handleFilterToggle(event.currentTarget)}
						>
							<summary className="inline-flex h-8 w-44 cursor-pointer list-none items-center justify-between rounded-md border border-slate-500/80 bg-[#1f3658] px-3 py-1 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#294673]">
								<span className="truncate">
									{yearSelectionLabel}
								</span>
								<ChevronDown
									size={14}
									className="shrink-0 text-slate-300 transition-transform duration-150 group-open:rotate-180"
								/>
							</summary>
							<div className="absolute left-0 z-30 mt-2 w-56 rounded-lg border border-slate-300 bg-slate-100 p-2 shadow-[0_14px_28px_rgba(2,8,23,0.24)]">
								<input
									type="text"
									value={yearSearch}
									onChange={(event) => setYearSearch(event.target.value)}
									placeholder="Szukaj roku"
									className="w-full rounded-md border border-slate-300 bg-white px-2.5 py-2 text-slate-700 text-sm outline-none placeholder:text-slate-400 focus:border-slate-400"
								/>
								<div className="subtle-vertical-scroll mt-2 max-h-36 space-y-1 overflow-auto pr-1">
									{visibleYearOptions.map((year) => {
										const isSelected = selectedYears.includes(year);
										return (
											<label
												key={year}
												className="flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-1.5 text-slate-700 text-sm hover:bg-slate-200/70"
											>
												<input
													type="checkbox"
													checked={isSelected}
													onChange={() => toggleYear(year)}
													className="h-3.5 w-3.5"
												/>
												<span>{year}</span>
											</label>
										);
									})}
									{visibleYearOptions.length === 0 ? (
										<p className="px-2 py-1 text-slate-500 text-sm">Brak wyników.</p>
									) : null}
								</div>
							</div>
						</details>

						{mapViewMode === "table" ? (
							<>
								<button
									type="button"
									onClick={() => setIsHeatmapEnabled((prev) => !prev)}
									className={`inline-flex h-8 min-w-36 shrink-0 items-center justify-center rounded-md border px-3 py-1 font-semibold text-xs transition-colors ${
										isHeatmapEnabled
											? "border-emerald-300/80 bg-emerald-300/25 text-emerald-100 hover:bg-emerald-300/35"
											: "border-slate-500/80 bg-[#1f3658] text-slate-100 hover:bg-[#294673]"
									}`}
								>
									Intensywność
								</button>
								{isHeatmapEnabled ? (
									<div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-200">
										<span className="rounded-md border border-[#4f6284] bg-[#1a3458] px-2 py-0.5 font-medium">
											Legenda
										</span>
										{rowIntensityLegend.hasZero ? (
											<span className="rounded-md border border-[#d1dae7] bg-[#f2f5f9] px-1.5 py-0.5 text-[#526278]">
												0
											</span>
										) : null}
										{rowIntensityLegend.bin1Label ? (
											<span className="rounded-md border border-[#c3d8f6] bg-[#e2eeff] px-1.5 py-0.5 text-[#204874]">
												{rowIntensityLegend.bin1Label}
											</span>
										) : null}
										{rowIntensityLegend.bin2Label ? (
											<span className="rounded-md border border-[#a6c9f8] bg-[#bbd8ff] px-1.5 py-0.5 text-[#113f75]">
												{rowIntensityLegend.bin2Label}
											</span>
										) : null}
										{rowIntensityLegend.bin3Label ? (
											<span className="rounded-md border border-[#8dbaf5] bg-[#9cc3f3] px-1.5 py-0.5 text-[#0f3a6d]">
												{rowIntensityLegend.bin3Label}
											</span>
										) : null}
										{rowIntensityLegend.bin4Label ? (
											<span className="rounded-md border border-[#79a9e8] bg-[#8dbaf5] px-1.5 py-0.5 text-[#0d2e57]">
												{rowIntensityLegend.bin4Label}
											</span>
										) : null}
									</div>
								) : null}
							</>
						) : null}
							</div>
						</div>
					</div>

					<div className="ml-auto flex items-center gap-2">
						<button
							type="button"
							onClick={() => setIsFullscreen((previous) => !previous)}
							className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-[#5d7eaf] bg-[#243b61] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#2c4875]"
						>
							{isFullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
							{isFullscreen ? "Zamknij pełny ekran" : "Pełny ekran"}
						</button>

						{mapViewMode === "table" ? (
							<button
								type="button"
								onClick={handleExportToExcel}
								disabled={isLoading || isExporting || tableFilteredRows.length === 0}
								className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#285186] px-3.5 font-medium text-sm text-slate-100 transition-colors hover:bg-[#3563a1] disabled:cursor-not-allowed disabled:opacity-70"
							>
								<Download size={14} />
								{isExporting ? "Eksportowanie..." : "Eksportuj"}
							</button>
						) : null}
					</div>
				</div>

				<div className="flex flex-wrap items-end justify-between gap-2 border-[#2a4772] border-b pt-1">
					<div className="flex flex-wrap items-end gap-2">
						<button
							type="button"
							onClick={() => setMapViewMode("table")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								mapViewMode === "table"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Tabela
						</button>
						<button
							type="button"
							onClick={() => setMapViewMode("chart")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								mapViewMode === "chart"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Wykres
						</button>
					</div>
				</div>


				</div>
			) : null}

			{error ? (
				<p className="rounded-lg border border-rose-300/60 bg-rose-100/90 px-3 py-2 text-rose-800 text-sm">
					{error}
				</p>
			) : null}

			{!isFullscreen ? (
				<div className="flex justify-end px-1">
					<button
						type="button"
						onClick={clearFilters}
						disabled={
							selectedPlants.length === 0 &&
							selectedEntityTypes.length === 0 &&
							selectedYears.length === 0 &&
							selectedInspectionScopes.length === 0 &&
							controlsCountSortDirection === "none" &&
							tableEntityFilter.trim().length === 0 &&
							tableControlsFilter.trim().length === 0 &&
							selectedTableEntities.length === 0 &&
							Object.values(selectedTableYearScopes).every((scopes) => scopes.length === 0) &&
							Object.values(tableYearFilters).every((value) => value.trim().length === 0) &&
							!isHeatmapEnabled
						}
						className={`inline-flex h-7 items-center rounded px-1.5 transition-colors disabled:cursor-not-allowed ${
							selectedPlants.length > 0 ||
							selectedEntityTypes.length > 0 ||
							selectedYears.length > 0 ||
							selectedInspectionScopes.length > 0 ||
							controlsCountSortDirection !== "none" ||
							tableEntityFilter.trim().length > 0 ||
							tableControlsFilter.trim().length > 0 ||
							selectedTableEntities.length > 0 ||
							Object.values(selectedTableYearScopes).some((scopes) => scopes.length > 0) ||
							Object.values(tableYearFilters).some((value) => value.trim().length > 0) ||
							isHeatmapEnabled
								? "font-semibold text-blue-300 text-sm hover:text-blue-200"
								: "font-medium text-slate-500 text-xs"
						}`}
					>
						Wyczyść filtry
					</button>
				</div>
			) : null}

			{mapViewMode === "table" ? (
				<>
				<div
					ref={tableWrapperRef}
					className="relative mt-1 subtle-horizontal-scroll subtle-vertical-scroll table-scroll-gutter-right min-h-0 flex-1 w-full max-w-full overflow-x-auto overflow-y-auto rounded-xl border border-slate-400 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]"
				>
				{isLoading ? <TableLoadingOverlay /> : null}
				<table className="w-full min-w-max border-collapse text-slate-900 text-sm">
					<thead>
						<tr className="bg-slate-100 text-slate-800">
							<th
								className="sticky top-0 left-0 z-20 h-11 whitespace-nowrap border-slate-300 border-b border-r bg-slate-100 px-3 py-2 text-left font-semibold"
								style={{ width: `${firstColumnWidthCh}ch`, minWidth: `${firstColumnWidthCh}ch` }}
							>
									<div className="group relative flex w-full items-center gap-1.5 pr-8">
										<span className="truncate">Nazwa podmiotu</span>
										<button
											type="button"
											onClick={toggleTableEntitySortDirection}
											className="absolute top-1/2 right-0 inline-flex h-6 w-5 -translate-y-1/2 items-center justify-center rounded text-sm text-slate-500 leading-none transition-colors hover:text-slate-700"
											aria-label="Sortuj kolumnę Nazwa podmiotu"
										>
											{tableEntitySortDirection === "asc"
												? "▲"
												: tableEntitySortDirection === "desc"
													? "▼"
													: "↕"}
										</button>
									</div>
							</th>
							<th
								className="sticky top-0 z-10 h-11 border-slate-300 border-b bg-slate-100 px-1.5 py-2 text-center font-semibold text-[11px] leading-[1.15]"
								style={{
									width: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
									minWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
									maxWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
								}}
							>
									<div className="group relative flex w-full items-center justify-center gap-1 pr-6">
										<span>Liczba kontroli</span>
										<button
											type="button"
											onClick={toggleControlsSortDirection}
											className="absolute top-1/2 right-0 inline-flex h-6 w-5 -translate-y-1/2 items-center justify-center rounded text-sm text-slate-500 leading-none transition-colors hover:text-slate-700"
											aria-label="Sortuj kolumnę Liczba kontroli"
										>
											{controlsCountSortDirection === "asc"
												? "▲"
												: controlsCountSortDirection === "desc"
													? "▼"
													: "↕"}
										</button>
									</div>
							</th>
							{visibleYears.map((year) => (
								<th
									key={year}
									className="sticky top-0 z-10 h-11 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-2.5 py-2 text-left font-semibold"
									style={{
										width: `${yearColumnWidthByYearPx[year] ?? 160}px`,
										minWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
										maxWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
									}}
								>
									{year}
								</th>
							))}
						</tr>
						<tr className="bg-white text-slate-700 font-normal">
							<th
								className="sticky top-11 left-0 z-[25] border-slate-200 border-b border-r bg-white px-2 py-2 font-normal overflow-visible"
								style={{ width: `${firstColumnWidthCh}ch`, minWidth: `${firstColumnWidthCh}ch` }}
							>
								<div className="flex items-center gap-1">
									<input
										type="text"
										value={tableEntityFilter}
										onChange={(event) => setTableEntityFilter(event.target.value)}
										placeholder="Filtruj..."
										className="min-w-0 flex-1 rounded-md border border-slate-300 bg-white px-2 py-1 font-normal text-xs text-slate-800 outline-none transition-colors placeholder:font-normal focus:border-blue-400"
									/>
									<button
										type="button"
										onClick={(event) =>
											openTableHeaderAdvancedFilter(
												{ kind: "entity" },
												event.currentTarget,
											)
										}
										aria-label="Filtruj kolumnę Nazwa podmiotu"
										className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
											selectedTableEntities.length > 0
												? "border-blue-400 bg-blue-50 text-blue-700"
												: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
										}`}
									>
										<ChevronDown size={12} />
									</button>
								</div>
							</th>
							<th
								className="sticky top-11 z-[15] border-slate-200 border-b bg-white px-1 py-2 font-normal"
								style={{
									width: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
									minWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
									maxWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
								}}
							>
								<input
									type="text"
									inputMode="numeric"
									value={tableControlsFilter}
									onChange={(event) => setTableControlsFilter(event.target.value)}
									placeholder="Filtruj..."
									className="w-full rounded-md border border-slate-300 bg-white px-2 py-1 font-normal text-xs text-slate-800 outline-none transition-colors placeholder:font-normal focus:border-blue-400"
								/>
							</th>
							{visibleYears.map((year) => (
								<th
									key={`${year}-filter`}
									className="sticky top-11 z-[15] border-slate-200 border-b bg-white px-2 py-2 font-normal overflow-visible"
									style={{
										width: `${yearColumnWidthByYearPx[year] ?? 160}px`,
										minWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
										maxWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
									}}
								>
									<div className="flex items-center gap-1">
										<input
											type="text"
											value={tableYearFilters[year] ?? ""}
											onChange={(event) =>
												handleTableYearFilterChange(year, event.target.value)
											}
											placeholder="Filtruj..."
											className="min-w-0 flex-1 rounded-md border border-slate-300 bg-white px-2 py-1 font-normal text-xs text-slate-800 outline-none transition-colors placeholder:font-normal focus:border-blue-400"
										/>
										<button
											type="button"
											onClick={(event) =>
												openTableHeaderAdvancedFilter(
													{ kind: "year", year },
													event.currentTarget,
												)
											}
											aria-label={`Filtruj kolumnę ${year}`}
											className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
												(selectedTableYearScopes[year] ?? []).length > 0
													? "border-blue-400 bg-blue-50 text-blue-700"
													: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
											}`}
										>
											<ChevronDown size={12} />
										</button>
									</div>
								</th>
							))}
						</tr>
					</thead>

					<tbody>
						{tableFilteredRows.map((row, rowIndex) => (
							(() => {
								const rowControlsCount = getTotalControlsForRow(row);
								const rowIntensityClass = getRowIntensityClass(rowControlsCount);

								return (
							<tr
								key={row.nazwaPodmiotu}
								className="border-slate-200 border-b bg-white transition-colors hover:bg-slate-50 last:border-b-0"
							>
								<td
									className={`sticky left-0 z-10 align-top whitespace-nowrap border-slate-200 border-r px-3 py-2.5 text-slate-900 ${
										rowIntensityClass || "bg-white"
									}`}
									title={row.nazwaPodmiotu}
									style={{ width: `${firstColumnWidthCh}ch`, maxWidth: `${firstColumnWidthCh}ch` }}
								>
									<span className="block truncate">{row.nazwaPodmiotu}</span>
								</td>
								<td
									className={`px-1.5 py-2.5 text-right font-semibold text-slate-800 ${rowIntensityClass}`}
									style={{
										width: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
										minWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
										maxWidth: `${REPORTS_MAP_COUNT_COLUMN_WIDTH_PX}px`,
									}}
								>
									{rowControlsCount}
								</td>
								{visibleYears.map((year) => (
									<td
										key={`${row.nazwaPodmiotu}-${year}`}
										className="px-2.5 py-2.5 align-top whitespace-normal wrap-break-word"
										style={{
											width: `${yearColumnWidthByYearPx[year] ?? 160}px`,
											minWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
											maxWidth: `${yearColumnWidthByYearPx[year] ?? 160}px`,
										}}
									>
										{(() => {
											const cellEntries = row.cells[year] ?? [];
											const yearQuery = (tableYearFilters[year] ?? "")
												.trim()
												.toLowerCase();
											if (cellEntries.length === 0) {
												const controls = getControlsForCell(row, year);
												if (controls.length === 0) {
													return "-";
												}

												const sortedFallbackControls = [...controls].sort((left, right) => {
													const rankDiff = getControlTypeRank(left) - getControlTypeRank(right);
													if (rankDiff !== 0) {
														return rankDiff;
													}

													return left.localeCompare(right, "pl", { sensitivity: "base" });
												});
												const visibleFallbackControls =
													yearQuery.length > 0
														? sortedFallbackControls.filter((controlLabel) => {
															const parsed = parseControlLabel(controlLabel);
															const shortScopesLabel = parsed.scopesLabel.toLowerCase();
															return (`${parsed.type}: ${shortScopesLabel}`).includes(yearQuery);
														})
														: sortedFallbackControls;
												if (visibleFallbackControls.length === 0) {
													return "-";
												}

												return (
													<div className="space-y-2" title={visibleFallbackControls.join("\n")}>
														{visibleFallbackControls.map((controlLabel, index) => {
															const parsed = parseControlLabel(controlLabel);
															const fallbackDetails = getFallbackDetailForLegacyCell(
																row,
																year,
																controlLabel,
															);
															const shouldOpenTooltipUp =
																		rowIndex >= Math.floor(tableFilteredRows.length / 2);
															const typeLabelClass =
																parsed.type === "WN"
																	? "font-bold text-violet-800"
																	: "font-bold text-purple-800";
															const tooltipKey = `${row.nazwaPodmiotu}|${year}|legacy|${controlLabel}|${index}`;
															const isTooltipOpen = activeControlTooltipKey === tooltipKey;
															const tooltipPoczatekRaw = fallbackDetails?.poczatekInspekcji || "";
															const tooltipKoniecRaw = fallbackDetails?.koniecInspekcji || "";
															const tooltipPoczatek =
																formatIsoDateForDisplay(tooltipPoczatekRaw) || tooltipPoczatekRaw || "-";
															const tooltipKoniec =
																formatIsoDateForDisplay(tooltipKoniecRaw) || tooltipKoniecRaw || "-";
															const tooltipStatus = fallbackDetails?.statusInspekcji || "-";
																			const tooltipScopes = normalizeTooltipScopes(
																				fallbackDetails?.scopes ?? [],
																			);

															return (
																<div
																	key={`${controlLabel}-${index}`}
																	className="relative whitespace-normal break-words text-[15px] leading-[1.35] text-slate-900"
																>
																	{fallbackDetails ? (
																		<button
																			type="button"
																				data-tooltip-interactive="true"
																			onClick={(event) => {
																				event.stopPropagation();
																				setActiveControlTooltipKey((previous) =>
																					previous === tooltipKey ? null : tooltipKey,
																				);
																			}}
																				className="cursor-pointer text-left transition-colors hover:text-[#1d4f8f]"
																		>
																				<span
																					className={`${typeLabelClass} underline decoration-dotted decoration-slate-500/70 underline-offset-2`}
																				>
																					{parsed.type}:
																				</span>{" "}
																				<span>{parsed.scopesLabel}</span>
																		</button>
																	) : (
																			<>
																				<span className={typeLabelClass}>{parsed.type}:</span>{" "}
																				<span>{parsed.scopesLabel}</span>
																			</>
																	)}{" "}

																	{fallbackDetails && isTooltipOpen ? (
																		<div
																					data-tooltip-interactive="true"
																			className={`absolute left-0 z-50 w-[min(26rem,78vw)] rounded-xl border border-[#b8cbe3] bg-gradient-to-b from-white to-[#f5f9ff] px-3 py-2 text-[#1d3557] text-[13px] leading-5 shadow-[0_14px_30px_rgba(15,35,70,0.18)] ${
																				shouldOpenTooltipUp
																					? "bottom-full mb-2 before:absolute before:-bottom-1.5 before:left-4 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-r before:border-b before:bg-[#f5f9ff] before:content-['']"
																					: "top-full mt-2 before:absolute before:-top-1.5 before:left-4 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-l before:border-t before:bg-white before:content-['']"
																			}`}
																			onClick={(event) => event.stopPropagation()}
																		>
																			<p>
																					<strong>Kontrola:</strong>{" "}
																				{fallbackDetails.inspectionCode ? (
																					<button
																						type="button"
																						onClick={() => {
																							openInspectionFromDashboard(fallbackDetails.inspectionCode);
																							setActiveControlTooltipKey(null);
																						}}
																						className="cursor-pointer font-semibold text-[#1d4f8f] underline decoration-dotted decoration-[#1d4f8f]/70 underline-offset-2 transition-colors hover:text-[#163a69]"
																					>
																						{fallbackDetails.inspectionCode}
																					</button>
																				) : (
																					"-"
																				)}
																			</p>
																			<p><strong>Początek:</strong> {tooltipPoczatek}</p>
																			<p><strong>Koniec:</strong> {tooltipKoniec}</p>
																					{tooltipScopes.length <= 1 ? (
																						<p><strong>Zakres inspekcji:</strong> {tooltipScopes[0]}</p>
																					) : (
																						<div>
																							<p><strong>Zakres inspekcji:</strong></p>
																							<div className="pl-1">
																								{tooltipScopes.map((scope, scopeIndex) => (
																									<p key={`${tooltipKey}-legacy-scope-${scopeIndex}`}>
																										<strong>{scopeIndex + 1}.</strong> {scope}
																									</p>
																								))}
																							</div>
																						</div>
																					)}
																					<p><strong>Status:</strong> {tooltipStatus}</p>
																		</div>
																	) : null}
																</div>
															);
														})}
													</div>
												);
											}

											const visibleEntries = cellEntries.filter((entry) => {
												if (
													selectedInspectionScopesSet.size > 0 &&
													!matchesInspectionScopeFilter(entry)
												) {
													return false;
												}

												if (!yearQuery) {
													return true;
												}

												const shortScopesLabel =
													entry.scopes.length > 0
														? entry.scopes.join(", ")
														: entry.zakresInspekcji || "Brak zakresu";
												return (`${entry.type}: ${shortScopesLabel}`)
													.toLowerCase()
													.includes(yearQuery);
											});
											if (visibleEntries.length === 0) {
												return "-";
											}

											const sortedEntries = [...visibleEntries].sort((left, right) => {
												if (left.type !== right.type) {
													return left.type === "K" ? -1 : 1;
												}

												const leftScopes = left.scopes.join(", ").trim();
												const rightScopes = right.scopes.join(", ").trim();
												return leftScopes.localeCompare(rightScopes, "pl", {
													sensitivity: "base",
												});
											});

											return (
												<div className="space-y-2">
													{sortedEntries.map((entry, index) => {
																	const scopesLabel = getMatrixEntryScopesLabel(entry);
														const shouldOpenTooltipUp =
																		rowIndex >= Math.floor(tableFilteredRows.length / 2);
														const typeLabelClass =
															entry.type === "WN"
																? "font-bold text-violet-800"
																: "font-bold text-purple-800";

														const entryToken =
															(entry.kodInspekcji && entry.kodInspekcji !== "-"
																? entry.kodInspekcji
																: entry.inspectionId
																	? String(entry.inspectionId)
																	: "").trim();
																const detailsByInspectionId =
																	typeof entry.inspectionId === "number" &&
																	Number.isFinite(entry.inspectionId)
																		? inspectionDetailsByCode[`id:${entry.inspectionId}`]
																		: undefined;
																const detailsByInspectionCode =
																	getInspectionCodeLookupKeys(entryToken)
																		.map((lookupKey) => inspectionDetailsByCode[lookupKey])
																		.find((item) => Boolean(item));
																const details = detailsByInspectionId ?? detailsByInspectionCode ?? null;

														const tooltipKey = `${row.nazwaPodmiotu}|${year}|${entryToken}|${index}`;
														const isTooltipOpen = activeControlTooltipKey === tooltipKey;
														const tooltipInspectionId = details?.inspectionCode || entryToken || "-";
																	const tooltipPoczatekRaw = details?.poczatekInspekcji || entry.startDate || "";
																	const tooltipKoniecRaw = details?.koniecInspekcji || entry.endDate || "";
														const tooltipPoczatek =
															formatIsoDateForDisplay(tooltipPoczatekRaw) || tooltipPoczatekRaw || "-";
														const tooltipKoniec =
															formatIsoDateForDisplay(tooltipKoniecRaw) || tooltipKoniecRaw || "-";
																	const tooltipStatus =
																		details?.statusInspekcji || entry.status || entry.statusShort || "-";
																	const tooltipScopes = normalizeTooltipScopes(getMatrixEntryScopes(entry));

														return (
															<div
																key={`${entry.kodInspekcji}-${entry.inspectionId ?? "none"}-${index}`}
																className="relative whitespace-normal break-words text-[15px] leading-[1.35] text-slate-900"
															>
																<button
																	type="button"
																				data-tooltip-interactive="true"
																	onClick={(event) => {
																		event.stopPropagation();
																		setActiveControlTooltipKey((previous) =>
																			previous === tooltipKey ? null : tooltipKey,
																		);
																	}}
																				className="cursor-pointer text-left transition-colors hover:text-[#1d4f8f]"
																>
																				<span
																					className={`${typeLabelClass} underline decoration-dotted decoration-slate-500/70 underline-offset-2`}
																				>
																					{entry.type}:
																				</span>{" "}
																				<span>{scopesLabel}</span>
																			</button>

																{isTooltipOpen ? (
																	<div
																				data-tooltip-interactive="true"
																		className={`absolute left-0 z-50 w-[min(26rem,78vw)] rounded-xl border border-[#b8cbe3] bg-gradient-to-b from-white to-[#f5f9ff] px-3 py-2 text-[#1d3557] text-[13px] leading-5 shadow-[0_14px_30px_rgba(15,35,70,0.18)] ${
																			shouldOpenTooltipUp
																				? "bottom-full mb-2 before:absolute before:-bottom-1.5 before:left-4 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-r before:border-b before:bg-[#f5f9ff] before:content-['']"
																				: "top-full mt-2 before:absolute before:-top-1.5 before:left-4 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-l before:border-t before:bg-white before:content-['']"
																		}`}
																		onClick={(event) => event.stopPropagation()}
																	>
																		<p>
																					<strong>Kontrola:</strong>{" "}
																			{entryToken ? (
																				<button
																					type="button"
																					onClick={() => {
																					openInspectionFromDashboard(entryToken);
																					setActiveControlTooltipKey(null);
																				}}
																					className="cursor-pointer font-semibold text-[#1d4f8f] underline decoration-dotted decoration-[#1d4f8f]/70 underline-offset-2 transition-colors hover:text-[#163a69]"
																				>
																					{tooltipInspectionId}
																				</button>
																			) : (
																				tooltipInspectionId
																			)}
																		</p>
																		<p><strong>Początek:</strong> {tooltipPoczatek}</p>
																		<p><strong>Koniec:</strong> {tooltipKoniec}</p>
																					{tooltipScopes.length <= 1 ? (
																						<p><strong>Zakres inspekcji:</strong> {tooltipScopes[0]}</p>
																					) : (
																						<div>
																							<p><strong>Zakres inspekcji:</strong></p>
																							<div className="pl-1">
																								{tooltipScopes.map((scope, scopeIndex) => (
																									<p key={`${tooltipKey}-scope-${scopeIndex}`}>
																										<strong>{scopeIndex + 1}.</strong> {scope}
																									</p>
																								))}
																							</div>
																						</div>
																					)}
																					<p><strong>Status:</strong> {tooltipStatus}</p>
																	</div>
																) : null}
															</div>
														);
													})}
												</div>
											);
										})()}
									</td>
								))}
							</tr>
								);
							})()
						))}

						{!isLoading && tableFilteredRows.length === 0 ? (
							<tr>
								<td
									colSpan={Math.max(1, visibleYears.length + 2)}
									className="px-3 py-6 text-center text-slate-500 text-sm"
								>
										{selectedPlants.length > 0 ||
									selectedEntityTypes.length > 0 ||
										selectedYears.length > 0 ||
										selectedInspectionScopes.length > 0 ||
										tableEntityFilter.trim().length > 0 ||
										tableControlsFilter.trim().length > 0 ||
										selectedTableEntities.length > 0 ||
										Object.values(selectedTableYearScopes).some((scopes) => scopes.length > 0) ||
										Object.values(tableYearFilters).some((value) => value.trim().length > 0)
										? "Brak rekordów dla wybranych filtrów."
										: "Brak rekordów raportu."}
								</td>
							</tr>
						) : null}

						{isLoading ? (
							<tr>
								<td
									colSpan={Math.max(1, visibleYears.length + 2)}
									className="px-3 py-6 text-center text-slate-500 text-sm"
								>
									Ładowanie danych raportu...
								</td>
							</tr>
						) : null}
					</tbody>
				</table>
				</div>
				<TableAdvancedFilterModal
					isOpen={isTableHeaderAdvancedFilterModalOpen}
					anchor={tableHeaderAdvancedFilterAnchor}
					columnLabel={tableHeaderAdvancedFilterColumnLabel}
					searchValue={tableHeaderAdvancedFilterSearch}
					visibleValues={visibleTableHeaderAdvancedFilterValues}
					selectedValues={selectedTableHeaderAdvancedFilterValues}
					onClose={() => {
						setIsTableHeaderAdvancedFilterModalOpen(false);
						setTableHeaderAdvancedFilterTarget(null);
					}}
					onSearchChange={setTableHeaderAdvancedFilterSearch}
					onSelectAllVisible={selectAllVisibleTableHeaderAdvancedFilterValues}
					onClearSelectedColumn={clearSelectedTableHeaderAdvancedFilterValues}
					onToggleValue={toggleTableHeaderAdvancedFilterValue}
					onClearAllFilters={clearFilters}
				/>
				</>
			) : (
				<div className="mt-1 min-h-0 flex-1 rounded-xl border border-slate-400 bg-white p-2 shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
					{isLoading ? (
						<div className="flex h-full items-center justify-center text-slate-500 text-sm">
							Ładowanie danych raportu...
						</div>
					) : chartRows.length === 0 ? (
						<p className="py-6 text-center text-slate-500 text-sm">
							{selectedPlants.length > 0 ||
							selectedEntityTypes.length > 0 ||
							selectedYears.length > 0
								? "Brak rekordów dla wybranych filtrów."
								: "Brak rekordów raportu."}
						</p>
					) : (
						<div className="subtle-vertical-scroll h-full space-y-1 overflow-y-auto pr-0.5">
							{chartRows.map((chartRow) => {
								const widthPercent =
									maxChartControlsCount > 0
										? Math.max(
											6,
											Math.round((chartRow.controlsCount / maxChartControlsCount) * 100),
										)
										: 0;

								return (
									<div
										key={chartRow.entityName}
										className="grid grid-cols-[minmax(10rem,1fr)_minmax(12rem,2fr)] items-center gap-2 rounded-md border border-slate-200 px-2 py-1"
									>
										<p
											className="truncate font-medium text-[13px] text-slate-800"
											title={chartRow.entityName}
										>
											{chartRow.entityName}
										</p>
										<div className="flex items-center gap-1.5">
											<div className="h-4 flex-1 overflow-hidden rounded bg-slate-100">
												<div
													className="h-full rounded bg-gradient-to-r from-[#7fb2f4] via-[#4f86cb] to-[#2f5f9c]"
													style={{ width: `${widthPercent}%` }}
												/>
											</div>
											<span className="w-8 text-right font-semibold text-[13px] text-slate-800">
												{chartRow.controlsCount}
											</span>
										</div>
									</div>
								);
							})}
						</div>
					)}
				</div>
			)}
		</TableFullscreenContainer>
	);
}
