import type {
	Schedule,
	ScheduleControlType,
	ScheduleDaysComparisonMode,
	ScheduleDateFieldItem,
	ScheduleDispatch,
	ScheduleDispatchFilters,
	ScheduleDispatchKpi,
	ScheduleStatusFieldItem,
	ScheduleTemplateVariable,
} from "@/features/schedules/types";

function inferRecipientStrategyFromDateFields(
	dateFieldA: string,
	checkEmptyField: string,
) {
	const left = dateFieldA.toUpperCase();
	const right = checkEmptyField.toUpperCase();

	const isInspectionField = (value: string) => value.startsWith("INSPECTION.");
	const isRecommendationField = (value: string) =>
		value.startsWith("RECOMMENDATION.") || value.startsWith("ZALECEN");
	const isRiskField = (value: string) =>
		value.startsWith("RISK_EXPOSURE.") || value.startsWith("WNIOSEK");

	if (
		(isInspectionField(left) && (isRecommendationField(right) || isRiskField(right))) ||
		(isInspectionField(right) && (isRecommendationField(left) || isRiskField(left)))
	) {
		return "inspection_context" as const;
	}

	if (
		(isRecommendationField(left) && isRecommendationField(right)) ||
		(isRiskField(left) && isRiskField(right))
	) {
		return "author_only" as const;
	}

	return "inspection_context" as const;
}

type ApiErrorResult = {
	ok: false;
	error: string;
	status: number;
};

async function readApiError(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown };
		if (typeof payload.detail === "string") {
			return payload.detail;
		}

		if (Array.isArray(payload.detail)) {
			return payload.detail
				.map((item) => {
					if (!item || typeof item !== "object") {
						return "";
					}

					const detail = (item as Record<string, unknown>).msg;
					return typeof detail === "string" ? detail : "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

function buildHeaders(operatorLogin: string) {
	return {
		"Content-Type": "application/json",
		"X-Operator-Login": operatorLogin,
	};
}

function toErrorMessage(status: number, fallback: string, detail: string) {
	if (detail) {
		return detail;
	}

	if (status === 403) {
		return "Brak uprawnień do tej operacji.";
	}

	if (status === 404) {
		return "Nie znaleziono wskazanego elementu.";
	}

	if (status === 409) {
		return "Konflikt danych. Sprawdź, czy harmonogram nie koliduje z istniejącą konfiguracją.";
	}

	if (status === 422) {
		return "Nieprawidłowe dane wejściowe (422).";
	}

	if (status === 500) {
		return "Błąd serwera. Spróbuj ponownie.";
	}

	return `${fallback} (${status}).`;
}

function parseScheduleDateField(item: unknown): ScheduleDateFieldItem | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const code = typeof source.code === "string" ? source.code.trim() : "";
	const label = typeof source.label === "string" ? source.label.trim() : "";
	if (!code || !label) {
		return null;
	}

	return { code, label };
}

function parseScheduleStatusOption(item: unknown) {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const code =
		typeof source.code === "string"
			? source.code.trim()
			: typeof source.value === "string"
				? source.value.trim()
				: "";
	const label =
		typeof source.label === "string"
			? source.label.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: "";

	if (!code || !label) {
		return null;
	}

	return { code, label };
}

function parseScheduleStatusField(item: unknown): ScheduleStatusFieldItem | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const code =
		typeof source.code === "string"
			? source.code.trim()
			: typeof source.statusFieldCode === "string"
				? source.statusFieldCode.trim()
				: "";
	const label =
		typeof source.label === "string"
			? source.label.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: "";
	const rawOptions = Array.isArray(source.options)
		? source.options
		: Array.isArray(source.values)
			? source.values
			: [];
	const options = rawOptions
		.map((option) => parseScheduleStatusOption(option))
		.filter((option): option is { code: string; label: string } => option !== null);

	if (!code || !label) {
		return null;
	}

	return { code, label, options };
}

function parseSchedule(item: unknown): Schedule | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id = typeof source.id === "number" ? source.id : null;
	const name = typeof source.name === "string" ? source.name.trim() : "";
	const dateFieldA =
		typeof source.dateFieldA === "string" ? source.dateFieldA.trim() : "";
	const checkEmptyField =
		typeof source.checkEmptyField === "string"
			? source.checkEmptyField.trim()
			: "";
	const statusFieldCode =
		typeof source.statusFieldCode === "string"
			? source.statusFieldCode.trim()
			: "";
	const expectedStatusCode =
		typeof source.expectedStatusCode === "string"
			? source.expectedStatusCode.trim()
			: "";
	const expectedStatusCodes = Array.isArray(source.expectedStatusCodes)
		? source.expectedStatusCodes
				.map((item) => (typeof item === "string" ? item.trim() : ""))
				.filter((item) => item !== "")
		: expectedStatusCode
			? [expectedStatusCode]
			: [];
	const rawControlType =
		typeof source.controlType === "string" ? source.controlType : "";
	const controlType: ScheduleControlType =
		rawControlType === "status_equals" || statusFieldCode
			? "status_equals"
			: "empty_field";
	const daysDifference =
		typeof source.daysDifference === "number" ? source.daysDifference : NaN;
	const rawDaysComparisonMode =
		typeof source.daysComparisonMode === "number" ? source.daysComparisonMode : null;
	const daysComparisonMode: ScheduleDaysComparisonMode =
		rawDaysComparisonMode === 1 || rawDaysComparisonMode === 2
			? rawDaysComparisonMode
			: 0;
	const subjectTemplate =
		typeof source.subjectTemplate === "string" ? source.subjectTemplate : "";
	const bodyTemplate =
		typeof source.bodyTemplate === "string" ? source.bodyTemplate : "";
	const sendHour = typeof source.sendHour === "number" ? source.sendHour : NaN;
	const sendMinute =
		typeof source.sendMinute === "number" ? source.sendMinute : NaN;
	const rawRecipientStrategy =
		typeof source.recipientStrategy === "string" ? source.recipientStrategy : "";
	const recipientStrategy =
		rawRecipientStrategy === "author_only" ||
		rawRecipientStrategy === "inspection_context"
			? rawRecipientStrategy
			: inferRecipientStrategyFromDateFields(dateFieldA, checkEmptyField);

	if (
		!id ||
		!name ||
		!dateFieldA ||
		(controlType === "empty_field" && !checkEmptyField) ||
		(controlType === "status_equals" && !statusFieldCode) ||
		!Number.isInteger(daysDifference) ||
		subjectTemplate.trim() === "" ||
		bodyTemplate.trim() === "" ||
		!Number.isInteger(sendHour) ||
		!Number.isInteger(sendMinute)
	) {
		return null;
	}

	return {
		id,
		name,
		moduleType: typeof source.moduleType === "string" ? source.moduleType : undefined,
		controlType,
		dateFieldA,
		checkEmptyField,
		statusFieldCode,
		expectedStatusCode: expectedStatusCode || expectedStatusCodes[0] || "",
		expectedStatusCodes,
		daysComparisonMode,
		daysDifference,
		subjectTemplate,
		bodyTemplate,
		sendHour,
		sendMinute,
		targetInspectionLeader: source.targetInspectionLeader === true,
		targetInspectionTeam: source.targetInspectionTeam === true,
		fallbackRecipient: "author",
		recipientStrategy,
		enabled: source.enabled !== false,
		createdByUserId:
			typeof source.createdByUserId === "number" ? source.createdByUserId : null,
		lastRunDate: typeof source.lastRunDate === "string" ? source.lastRunDate : null,
		createdAt: typeof source.createdAt === "string" ? source.createdAt : null,
		updatedAt: typeof source.updatedAt === "string" ? source.updatedAt : null,
	};
}

function parseDispatch(item: unknown): ScheduleDispatch | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id = typeof source.id === "number" ? source.id : null;
	const scheduleId = typeof source.scheduleId === "number" ? source.scheduleId : null;
	const ruleId = typeof source.ruleId === "number" ? source.ruleId : null;
	const moduleType = typeof source.moduleType === "string" ? source.moduleType : "";
	const recordId = typeof source.recordId === "number" ? source.recordId : null;
	const inspectionId =
		typeof source.inspectionId === "string"
			? source.inspectionId
			: typeof source.inspectionId === "number"
				? String(source.inspectionId)
				: null;
	const recommendationId =
		typeof source.recommendationId === "string"
			? source.recommendationId
			: typeof source.recommendationId === "number"
				? String(source.recommendationId)
				: null;
	const sanctionRequestId =
		typeof source.sanctionRequestId === "string"
			? source.sanctionRequestId
			: typeof source.sanctionRequestId === "number"
				? String(source.sanctionRequestId)
				: null;
	const recipientEmail =
		typeof source.recipientEmail === "string" ? source.recipientEmail : "";
	const recipientType =
		typeof source.recipientType === "string" ? source.recipientType : "";
	const status = typeof source.status === "string" ? source.status : "";
	const createdAt = typeof source.createdAt === "string" ? source.createdAt : "";

	if (
		!id ||
		!scheduleId ||
		!moduleType ||
		recordId === null ||
		!recipientEmail ||
		!status ||
		!createdAt
	) {
		return null;
	}

	return {
		id,
		scheduleId,
		ruleId,
		moduleType,
		recordId,
		inspectionId,
		recommendationId,
		sanctionRequestId,
		recipientEmail,
		recipientType,
		status,
		errorMessage:
			typeof source.errorMessage === "string" ? source.errorMessage : null,
		renderedSubject:
			typeof source.renderedSubject === "string" ? source.renderedSubject : null,
		renderedBody:
			typeof source.renderedBody === "string" ? source.renderedBody : null,
		createdAt,
	};
}

function parseKpi(payload: unknown): ScheduleDispatchKpi | null {
	if (!payload || typeof payload !== "object") {
		return null;
	}

	const source = payload as Record<string, unknown>;
	const scheduleId = typeof source.scheduleId === "number" ? source.scheduleId : null;
	const total = typeof source.total === "number" ? source.total : null;
	const sent = typeof source.sent === "number" ? source.sent : null;
	const failed = typeof source.failed === "number" ? source.failed : null;
	const successRate =
		typeof source.successRate === "number" ? source.successRate : null;

	if (
		scheduleId === null ||
		total === null ||
		sent === null ||
		failed === null ||
		successRate === null
	) {
		return null;
	}

	const readBucket = (value: unknown): Record<string, number> => {
		if (!value || typeof value !== "object") {
			return {};
		}

		return Object.entries(value as Record<string, unknown>).reduce(
			(accumulator, [key, bucketValue]) => {
				if (typeof bucketValue === "number") {
					accumulator[key] = bucketValue;
				}
				return accumulator;
			},
			{} as Record<string, number>,
		);
	};

	return {
		scheduleId,
		total,
		sent,
		failed,
		successRate,
		byModule: readBucket(source.byModule),
		byRecipientType: readBucket(source.byRecipientType),
	};
}

function buildDispatchQuery(filters?: ScheduleDispatchFilters) {
	const query = new URLSearchParams();
	if (!filters) {
		query.set("limit", "100");
		return query;
	}

	const limit =
		typeof filters.limit === "number"
			? Math.max(1, Math.min(1000, Math.trunc(filters.limit)))
			: 100;
	query.set("limit", String(limit));

	if (filters.period) {
		query.set("period", filters.period);
	}
	if (filters.status) {
		query.set("status", filters.status);
	}
	if (filters.recipientEmail?.trim()) {
		query.set("recipientEmail", filters.recipientEmail.trim());
	}
	if (filters.recipientType) {
		query.set("recipientType", filters.recipientType);
	}
	if (filters.dateFrom?.trim()) {
		query.set("dateFrom", filters.dateFrom.trim());
	}
	if (filters.dateTo?.trim()) {
		query.set("dateTo", filters.dateTo.trim());
	}

	return query;
}

function parseTemplateVariable(item: unknown): ScheduleTemplateVariable | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const token = typeof source.token === "string" ? source.token.trim() : "";
	const label = typeof source.label === "string" ? source.label.trim() : "";

	if (!token || !label) {
		return null;
	}

	return { token, label };
}

async function toErrorResult(
	response: Response,
	fallback: string,
): Promise<ApiErrorResult> {
	const detail = await readApiError(response);
	return {
		ok: false,
		error: toErrorMessage(response.status, fallback, detail),
		status: response.status,
	};
}

export async function fetchScheduleDateFields(operatorLogin: string) {
	const response = await fetch("/api/admin/schedules/date-fields", {
		method: "GET",
		headers: buildHeaders(operatorLogin),
		cache: "no-store",
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać pól dat");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseScheduleDateField(item))
				.filter((item): item is ScheduleDateFieldItem => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchScheduleStatusFields(operatorLogin: string) {
	const response = await fetch("/api/admin/schedules/status-fields", {
		method: "GET",
		headers: buildHeaders(operatorLogin),
		cache: "no-store",
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać pól statusów");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseScheduleStatusField(item))
				.filter((item): item is ScheduleStatusFieldItem => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchSchedules(operatorLogin: string) {
	const response = await fetch("/api/admin/schedules", {
		method: "GET",
		headers: buildHeaders(operatorLogin),
		cache: "no-store",
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać harmonogramów");
	}

	const payload = (await response.json()) as unknown;
	const schedules = Array.isArray(payload)
		? payload
				.map((item) => parseSchedule(item))
				.filter((item): item is Schedule => item !== null)
		: [];

	return { ok: true as const, schedules };
}

export async function createSchedule(
	operatorLogin: string,
	payload: {
		name: string;
		controlType: ScheduleControlType;
		daysComparisonMode: ScheduleDaysComparisonMode;
		dateFieldA: string;
		checkEmptyField?: string;
		statusFieldCode?: string;
		expectedStatusCode?: string;
		expectedStatusCodes?: string[];
		daysDifference: number;
		subjectTemplate: string;
		bodyTemplate: string;
		sendHour: number;
		sendMinute: number;
		targetInspectionLeader: boolean;
		targetInspectionTeam: boolean;
		fallbackRecipient: "author";
		enabled: boolean;
	},
) {
	const response = await fetch("/api/admin/schedules", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się utworzyć harmonogramu");
	}

	const item = parseSchedule((await response.json()) as unknown);
	if (!item) {
		return {
			ok: false as const,
			error: "Backend zwrócił nieprawidłowe dane harmonogramu.",
			status: 500,
		};
	}

	return { ok: true as const, schedule: item };
}

export async function updateSchedule(
	operatorLogin: string,
	scheduleId: number,
	payload: Partial<{
		name: string;
		controlType: ScheduleControlType;
		daysComparisonMode: ScheduleDaysComparisonMode;
		dateFieldA: string;
		checkEmptyField: string;
		statusFieldCode: string;
		expectedStatusCode: string;
		expectedStatusCodes: string[];
		daysDifference: number;
		subjectTemplate: string;
		bodyTemplate: string;
		sendHour: number;
		sendMinute: number;
		targetInspectionLeader: boolean;
		targetInspectionTeam: boolean;
		fallbackRecipient: "author";
		enabled: boolean;
	}>,
) {
	const response = await fetch(`/api/admin/schedules/${scheduleId}`, {
		method: "PUT",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się zaktualizować harmonogramu");
	}

	const item = parseSchedule((await response.json()) as unknown);
	if (!item) {
		return {
			ok: false as const,
			error: "Backend zwrócił nieprawidłowe dane harmonogramu.",
			status: 500,
		};
	}

	return { ok: true as const, schedule: item };
}

export async function deleteSchedule(operatorLogin: string, scheduleId: number) {
	const response = await fetch(`/api/admin/schedules/${scheduleId}`, {
		method: "DELETE",
		headers: buildHeaders(operatorLogin),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się usunąć harmonogramu");
	}

	return { ok: true as const };
}

export async function fetchScheduleDispatches(
	operatorLogin: string,
	scheduleId: number,
	filters?: ScheduleDispatchFilters,
) {
	const query = buildDispatchQuery(filters);
	const response = await fetch(
		`/api/admin/schedules/${scheduleId}/dispatches?${query.toString()}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać historii wysyłek");
	}

	const payload = (await response.json()) as unknown;
	const dispatches = Array.isArray(payload)
		? payload
				.map((item) => parseDispatch(item))
				.filter((item): item is ScheduleDispatch => item !== null)
		: [];

	return { ok: true as const, dispatches };
}

export async function fetchScheduleDispatchesKpi(
	operatorLogin: string,
	scheduleId: number,
	filters?: ScheduleDispatchFilters,
) {
	const query = buildDispatchQuery(filters);
	const response = await fetch(
		`/api/admin/schedules/${scheduleId}/dispatches/kpi?${query.toString()}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać statystyk wysyłek");
	}

	const kpi = parseKpi((await response.json()) as unknown);
	if (!kpi) {
		return {
			ok: false as const,
			error: "Backend zwrócił nieprawidłowe dane statystyk wysyłek.",
			status: 500,
		};
	}

	return { ok: true as const, kpi };
}

export async function fetchScheduleTemplateVariables(
	operatorLogin: string,
	params: {
		dateFieldA: string;
		controlType: ScheduleControlType;
		checkEmptyField?: string;
		statusFieldCode?: string;
	},
) {
	const query = new URLSearchParams({
		dateFieldA: params.dateFieldA,
		controlType: params.controlType,
	});
	if (params.controlType === "status_equals") {
		if (params.statusFieldCode?.trim()) {
			query.set("statusFieldCode", params.statusFieldCode.trim());
		}
	} else if (params.checkEmptyField?.trim()) {
		query.set("checkEmptyField", params.checkEmptyField.trim());
	}
	const response = await fetch(
		`/api/admin/schedules/template-variables?${query.toString()}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać zmiennych szablonu");
	}

	const responsePayload = (await response.json()) as unknown;
	const items = Array.isArray(responsePayload)
		? responsePayload
				.map((item) => parseTemplateVariable(item))
				.filter((item): item is ScheduleTemplateVariable => item !== null)
		: [];

	return { ok: true as const, items };
}
