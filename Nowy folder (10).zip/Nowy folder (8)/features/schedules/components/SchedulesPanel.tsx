"use client";

import { Pencil, Plus, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
createSchedule,
deleteSchedule,
fetchScheduleDateFields,
fetchScheduleStatusFields,
fetchSchedules,
fetchScheduleTemplateVariables,
updateSchedule,
} from "@/features/schedules/api";
import type {
Schedule,
ScheduleControlType,
ScheduleFormValues,
ScheduleRecipientStrategy,
ScheduleStatusFieldItem,
ScheduleTemplateVariable,
} from "@/features/schedules/types";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";
import { TableSurface } from "@/shared/components/table/TableSurface";

type SchedulesPanelProps = {
operatorLogin: string;
authRole: AuthRole;
};

const EMPTY_SCHEDULE_FORM: ScheduleFormValues = {
name: "",
dateFieldA: "",
checkEmptyField: "",
statusFieldCode: "",
expectedStatusCode: "",
expectedStatusCodes: [],
daysComparisonMode: "0",
daysDifference: "0",
subjectTemplate: "",
bodyTemplate: "",
sendHour: "7",
sendMinute: "0",
targetInspectionLeader: true,
targetInspectionTeam: false,
enabled: true,
};

const HIDDEN_TEMPLATE_TOKENS = new Set([
	"scheduleName",
	"recordId",
	"authorUserId",
	"dateB",
	"checkFieldCode",
]);

const STATUS_LIST_TEMPLATE_TOKEN = "checkFieldStatus";

function isHiddenTemplateToken(token: string) {
	if (HIDDEN_TEMPLATE_TOKENS.has(token)) {
		return true;
	}

	// Keep only user-friendly check-field variable in the picker.
	if (token.startsWith("checkField") && token !== "checkFieldLabel") {
		return true;
	}

	return false;
}

function toScheduleFormValues(schedule: Schedule): ScheduleFormValues {
return {
name: schedule.name,
dateFieldA: schedule.dateFieldA,
checkEmptyField: schedule.checkEmptyField,
statusFieldCode: schedule.statusFieldCode,
expectedStatusCode:
schedule.expectedStatusCode || schedule.expectedStatusCodes[0] || "",
expectedStatusCodes:
schedule.expectedStatusCodes.length > 0
? schedule.expectedStatusCodes
: schedule.expectedStatusCode
? [schedule.expectedStatusCode]
: [],
daysComparisonMode: String(schedule.daysComparisonMode) as "0" | "1" | "2",
daysDifference: String(schedule.daysDifference),
subjectTemplate: schedule.subjectTemplate,
bodyTemplate: schedule.bodyTemplate,
sendHour: String(schedule.sendHour),
sendMinute: String(schedule.sendMinute),
targetInspectionLeader: schedule.targetInspectionLeader,
targetInspectionTeam: schedule.targetInspectionTeam,
enabled: schedule.enabled,
};
}

function getDateFieldPrefix(label: string) {
const trimmed = label.trim();
if (trimmed.startsWith("I ") || trimmed.startsWith("I-")) {
return "I" as const;
}

if (trimmed.startsWith("Z ") || trimmed.startsWith("Z-")) {
return "Z" as const;
}

if (trimmed.startsWith("WN ") || trimmed.startsWith("WN-")) {
return "WN" as const;
}

return "";
}

function toControlKind(controlType: ScheduleControlType) {
return controlType === "status_equals" ? "status" : "date";
}

function inferRecipientStrategyFromLabels(
dateFieldALabel: string,
checkEmptyFieldLabel: string,
): ScheduleRecipientStrategy | null {
const prefixA = getDateFieldPrefix(dateFieldALabel);
const prefixB = getDateFieldPrefix(checkEmptyFieldLabel);

if (!prefixA || !prefixB) {
return null;
}

if (
(prefixA === "I" && (prefixB === "Z" || prefixB === "WN")) ||
(prefixB === "I" && (prefixA === "Z" || prefixA === "WN"))
) {
return "inspection_context";
}

if (prefixA === "I" && prefixB === "I") {
return "inspection_context";
}

if ((prefixA === "Z" && prefixB === "Z") || (prefixA === "WN" && prefixB === "WN")) {
return "author_only";
}

return null;
}

function appendTemplateToken(value: string, token: string) {
const placeholder = `{{${token}}}`;
if (!value.trim()) {
return placeholder;
}

return `${value} ${placeholder}`;
}

function polishLabel(value: string) {
return value
	.replaceAll("Data A", "Data odniesienia")
.replaceAll("Roznica", "Różnica")
.replaceAll("roznica", "różnica")
.replaceAll("wiadomosci", "wiadomości")
.replaceAll("Wiadomosci", "Wiadomości")
.replaceAll("wysylki", "wysyłki")
.replaceAll("Wysylki", "Wysyłki")
.replaceAll("Kierujacy", "Kierujący")
.replaceAll("kierujacy", "kierujący")
.replaceAll("Zespol", "Zespół")
.replaceAll("zespol", "zespół");
}

function simplifyStatusOptionLabel(value: string, statusFieldCode: string) {
const label = value.trim();
const withoutVerbosePrefix = label
.replace(/^I\s*-\s*Status\s+inspekcji\s*:\s*/i, "")
.replace(/^Z\s*-\s*Status\s+zalece[nń]\s*:\s*/i, "")
.replace(/^Status\s+inspekcji\s*:\s*/i, "")
.replace(/^Status\s+zalece[nń]\s*:\s*/i, "");

const normalizedFieldCode = statusFieldCode.trim().toLowerCase();
if (normalizedFieldCode.includes("inspection")) {
return `I - ${withoutVerbosePrefix}`.trim();
}

if (normalizedFieldCode.includes("recommendation") || normalizedFieldCode.includes("zalecen")) {
return `Z - ${withoutVerbosePrefix}`.trim();
}

return withoutVerbosePrefix;
}

function toDaysComparisonLabel(mode: "0" | "1" | "2") {
if (mode === "1") {
return ">";
}

if (mode === "2") {
return ">=";
}

return "=";
}

function toDaysComparisonLabelFromNumber(mode: number) {
if (mode === 1) {
return ">";
}

if (mode === 2) {
return ">=";
}

return "=";
}

export function SchedulesPanel({ operatorLogin, authRole }: SchedulesPanelProps) {
const [isLoading, setIsLoading] = useState(true);
const [isBusy, setIsBusy] = useState(false);
const [error, setError] = useState<string | null>(null);
const [successMessage, setSuccessMessage] = useState<string | null>(null);

const [dateFields, setDateFields] = useState<Array<{ code: string; label: string }>>(
[],
);
const [statusFields, setStatusFields] = useState<ScheduleStatusFieldItem[]>([]);
const [schedules, setSchedules] = useState<Schedule[]>([]);
	const [isDeleteConfirmModalOpen, setIsDeleteConfirmModalOpen] = useState(false);
	const [scheduleToDelete, setScheduleToDelete] = useState<Schedule | null>(null);
	const [isDeletingSchedule, setIsDeletingSchedule] = useState(false);

const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
const [scheduleForm, setScheduleForm] = useState<ScheduleFormValues>(EMPTY_SCHEDULE_FORM);
const [checkFieldKind, setCheckFieldKind] = useState<"date" | "status">("date");
const [isStatusMultiSelectOpen, setIsStatusMultiSelectOpen] = useState(false);
const [scheduleFormError, setScheduleFormError] = useState<string | null>(null);

const [templateVariables, setTemplateVariables] = useState<ScheduleTemplateVariable[]>([]);
const [templateVariablesError, setTemplateVariablesError] = useState<string | null>(null);
const [isTemplateVariablesLoading, setIsTemplateVariablesLoading] = useState(false);

const dateFieldLabelMap = useMemo(
() => new Map(dateFields.map((item) => [item.code, item.label])),
[dateFields],
);

const dateFieldCodes = useMemo(
() => new Set(dateFields.map((item) => item.code)),
[dateFields],
);

const checkFieldOptions = useMemo(
() => dateFields,
[dateFields],
);

const checkFieldCodes = useMemo(
() => new Set(checkFieldOptions.map((item) => item.code)),
[checkFieldOptions],
);

const statusFieldLabelMap = useMemo(
() => new Map(statusFields.map((item) => [item.code, item.label])),
[statusFields],
);

const statusControlOptions = useMemo(
() =>
statusFields.flatMap((field) =>
field.options.map((option) => ({
value: `${field.code}::${option.code}`,
label: simplifyStatusOptionLabel(option.label, field.code),
statusFieldCode: field.code,
expectedStatusCode: option.code,
})),
),
[statusFields],
);

const statusControlOptionMap = useMemo(
() => new Map(statusControlOptions.map((item) => [item.value, item])),
[statusControlOptions],
);

const statusControlByField = useMemo(() => {
const map = new Map<string, typeof statusControlOptions>();
for (const option of statusControlOptions) {
const existing = map.get(option.statusFieldCode) ?? [];
map.set(option.statusFieldCode, [...existing, option]);
}
return map;
}, [statusControlOptions]);

const validStatusControlPairs = useMemo(
() =>
new Set(
statusControlOptions.map(
(item) => `${item.statusFieldCode}::${item.expectedStatusCode}`,
),
),
[statusControlOptions],
);

const selectedStatusControlValues = useMemo(
() =>
scheduleForm.expectedStatusCodes
.map((statusCode) => `${scheduleForm.statusFieldCode}::${statusCode}`)
.filter((value) => statusControlOptionMap.has(value)),
[scheduleForm.expectedStatusCodes, scheduleForm.statusFieldCode, statusControlOptionMap],
);

const selectedStatusControlLabels = useMemo(
() =>
selectedStatusControlValues
.map((value) => statusControlOptionMap.get(value)?.label ?? "")
.filter(Boolean),
[selectedStatusControlValues, statusControlOptionMap],
);

const allStatusOptionLabelMap = useMemo(() => {
const map = new Map<string, string>();
for (const field of statusFields) {
for (const option of field.options) {
if (!map.has(option.code)) {
map.set(option.code, option.label);
}
}
}
return map;
}, [statusFields]);

const activeControlType: ScheduleControlType =
checkFieldKind === "status" ? "status_equals" : "empty_field";

const activeControlFieldLabel =
activeControlType === "status_equals"
? statusFieldLabelMap.get(scheduleForm.statusFieldCode) ?? ""
: dateFieldLabelMap.get(scheduleForm.checkEmptyField) ?? "";

const inferredRecipientStrategy = useMemo(() => {
const labelA = dateFieldLabelMap.get(scheduleForm.dateFieldA) ?? "";
const labelB = activeControlFieldLabel;
return inferRecipientStrategyFromLabels(labelA, labelB);
}, [activeControlFieldLabel, dateFieldLabelMap, scheduleForm.dateFieldA]);

const activeFormRecipientStrategy =
inferredRecipientStrategy ?? editingSchedule?.recipientStrategy ?? "inspection_context";

const visibleTemplateVariables = useMemo(() => {
return templateVariables.filter(
	(item) =>
		item.token !== STATUS_LIST_TEMPLATE_TOKEN &&
		!isHiddenTemplateToken(item.token),
);
}, [templateVariables]);

const statusListTemplateVariable = useMemo(() => {
	return templateVariables.find(
		(item) => item.token === STATUS_LIST_TEMPLATE_TOKEN,
	);
}, [templateVariables]);

const hasControlFieldsSelected =
activeControlType === "status_equals"
? scheduleForm.dateFieldA.trim() !== "" &&
scheduleForm.statusFieldCode.trim() !== "" &&
scheduleForm.expectedStatusCodes.length > 0
: scheduleForm.dateFieldA.trim() !== "" && scheduleForm.checkEmptyField.trim() !== "";

useEffect(() => {
if (checkFieldKind === "date") {
if (!scheduleForm.checkEmptyField) {
return;
}

const isStillAllowed = checkFieldCodes.has(scheduleForm.checkEmptyField);
if (isStillAllowed) {
return;
}

setScheduleForm((previous) => ({ ...previous, checkEmptyField: "" }));
return;
}

if (!scheduleForm.statusFieldCode) {
return;
}

const isStillAllowed = statusFields.some(
(item) => item.code === scheduleForm.statusFieldCode,
);
if (isStillAllowed) {
return;
}

setScheduleForm((previous) => ({
...previous,
statusFieldCode: "",
expectedStatusCode: "",
expectedStatusCodes: [],
}));
}, [
checkFieldCodes,
checkFieldKind,
scheduleForm.checkEmptyField,
scheduleForm.statusFieldCode,
statusFields,
]);

useEffect(() => {
if (checkFieldKind !== "status") {
return;
}

if (!scheduleForm.statusFieldCode || scheduleForm.expectedStatusCodes.length === 0) {
return;
}

if (
scheduleForm.expectedStatusCodes.every((statusCode) =>
validStatusControlPairs.has(`${scheduleForm.statusFieldCode}::${statusCode}`),
)
) {
return;
}

setScheduleForm((previous) => ({
...previous,
statusFieldCode: "",
expectedStatusCode: "",
expectedStatusCodes: [],
}));
}, [
checkFieldKind,
scheduleForm.expectedStatusCodes,
scheduleForm.statusFieldCode,
validStatusControlPairs,
]);

const reloadSchedules = useCallback(async () => {
const response = await fetchSchedules(operatorLogin);
if (!response.ok) {
setError(response.error);
if (response.status === 403) {
setSchedules([]);
}
return false;
}

setSchedules(response.schedules);
return true;
}, [operatorLogin]);

useEffect(() => {
if (authRole !== "director") {
setIsLoading(false);
return;
}

const loadInitial = async () => {
setIsLoading(true);
setError(null);

const [dateFieldsResponse, statusFieldsResponse, schedulesResponse] = await Promise.all([
fetchScheduleDateFields(operatorLogin),
fetchScheduleStatusFields(operatorLogin),
fetchSchedules(operatorLogin),
]);

if (!dateFieldsResponse.ok) {
setError(dateFieldsResponse.error);
setDateFields([]);
} else {
setDateFields(dateFieldsResponse.items);
}

if (!statusFieldsResponse.ok) {
setError((previous) => previous ?? statusFieldsResponse.error);
setStatusFields([]);
} else {
setStatusFields(statusFieldsResponse.items);
}

if (!schedulesResponse.ok) {
setError((previous) => previous ?? schedulesResponse.error);
setSchedules([]);
} else {
setSchedules(schedulesResponse.schedules);
}

setIsLoading(false);
};

void loadInitial();
}, [authRole, operatorLogin]);

useEffect(() => {
if (!isScheduleModalOpen) {
return;
}

const hasRequiredControlField =
activeControlType === "status_equals"
? scheduleForm.statusFieldCode.trim() !== ""
: scheduleForm.checkEmptyField.trim() !== "";

if (!scheduleForm.dateFieldA || !hasRequiredControlField) {
setTemplateVariables([]);
setTemplateVariablesError(null);
return;
}

let isCancelled = false;
const loadTemplateVariables = async () => {
setIsTemplateVariablesLoading(true);
setTemplateVariablesError(null);
const response = await fetchScheduleTemplateVariables(
operatorLogin,
{
dateFieldA: scheduleForm.dateFieldA,
controlType: activeControlType,
checkEmptyField:
activeControlType === "empty_field"
? scheduleForm.checkEmptyField
: undefined,
statusFieldCode:
activeControlType === "status_equals"
? scheduleForm.statusFieldCode
: undefined,
},
);
if (isCancelled) {
return;
}

if (!response.ok) {
setTemplateVariables([]);
setTemplateVariablesError(response.error);
setIsTemplateVariablesLoading(false);
return;
}

setTemplateVariables(response.items);
setIsTemplateVariablesLoading(false);
};

void loadTemplateVariables();

return () => {
isCancelled = true;
};
}, [
isScheduleModalOpen,
operatorLogin,
scheduleForm.dateFieldA,
scheduleForm.checkEmptyField,
scheduleForm.statusFieldCode,
activeControlType,
]);

const openCreateScheduleModal = () => {
setEditingSchedule(null);
setScheduleForm(EMPTY_SCHEDULE_FORM);
setCheckFieldKind("date");
setIsStatusMultiSelectOpen(false);
setScheduleFormError(null);
setTemplateVariables([]);
setTemplateVariablesError(null);
setIsScheduleModalOpen(true);
};

const openEditScheduleModal = (schedule: Schedule) => {
setEditingSchedule(schedule);
setScheduleForm(toScheduleFormValues(schedule));
setCheckFieldKind(toControlKind(schedule.controlType));
setIsStatusMultiSelectOpen(false);
setScheduleFormError(null);
setTemplateVariables([]);
setTemplateVariablesError(null);
setIsScheduleModalOpen(true);
};

const closeScheduleModal = () => {
setIsScheduleModalOpen(false);
setEditingSchedule(null);
setIsStatusMultiSelectOpen(false);
setScheduleFormError(null);
setTemplateVariables([]);
setTemplateVariablesError(null);
};

const insertSubjectToken = (token: string) => {
setScheduleForm((previous) => ({
...previous,
subjectTemplate: appendTemplateToken(previous.subjectTemplate, token),
}));
};

const insertBodyToken = (token: string) => {
setScheduleForm((previous) => ({
...previous,
bodyTemplate: appendTemplateToken(previous.bodyTemplate, token),
}));
};

const handleToggleStatusControlValue = (value: string) => {
const selectedOption = statusControlOptionMap.get(value);
if (!selectedOption) {
return;
}

setScheduleForm((previous) => {
const switchingField =
previous.statusFieldCode && previous.statusFieldCode !== selectedOption.statusFieldCode;
if (switchingField) {
return {
...previous,
statusFieldCode: selectedOption.statusFieldCode,
expectedStatusCode: selectedOption.expectedStatusCode,
expectedStatusCodes: [selectedOption.expectedStatusCode],
};
}

const nextCodes = new Set(previous.expectedStatusCodes);
if (nextCodes.has(selectedOption.expectedStatusCode)) {
nextCodes.delete(selectedOption.expectedStatusCode);
} else {
nextCodes.add(selectedOption.expectedStatusCode);
}

const sortedOptions =
statusControlByField.get(selectedOption.statusFieldCode) ?? [];
const orderedCodes = sortedOptions
.map((option) => option.expectedStatusCode)
.filter((code) => nextCodes.has(code));

return {
...previous,
statusFieldCode:
orderedCodes.length > 0 ? selectedOption.statusFieldCode : "",
expectedStatusCode: orderedCodes[0] ?? "",
expectedStatusCodes: orderedCodes,
};
});
};

const validateSchedulePayload = () => {
const name = scheduleForm.name.trim();
const sendHour = Number(scheduleForm.sendHour);
const sendMinute = Number(scheduleForm.sendMinute);
const daysDifference = Number(scheduleForm.daysDifference);
const daysComparisonMode = Number(scheduleForm.daysComparisonMode);
const subjectTemplate = scheduleForm.subjectTemplate.trim();
const bodyTemplate = scheduleForm.bodyTemplate.trim();

if (!name) {
return { ok: false as const, error: "Nazwa harmonogramu jest wymagana." };
}

if (!dateFieldCodes.has(scheduleForm.dateFieldA)) {
return {
ok: false as const,
error: "Wybierz poprawne pole Data odniesienia z listy.",
};
}

if (
activeControlType === "empty_field" &&
!checkFieldCodes.has(scheduleForm.checkEmptyField)
) {
return {
ok: false as const,
error:
"Wybierz poprawną datę do kontroli z listy.",
};
}

if (activeControlType === "status_equals") {
if (!scheduleForm.statusFieldCode.trim()) {
return {
ok: false as const,
error: "Wybierz poprawny status do kontroli z listy.",
};
}

if (scheduleForm.expectedStatusCodes.length === 0) {
return {
ok: false as const,
error: "Wybierz co najmniej jeden status do kontroli.",
};
}

const hasInvalidCode = scheduleForm.expectedStatusCodes.some(
(statusCode) =>
!validStatusControlPairs.has(`${scheduleForm.statusFieldCode}::${statusCode}`),
);
if (hasInvalidCode) {
return {
ok: false as const,
error: "Wybierz poprawne statusy do kontroli z listy.",
};
}
}

if (!Number.isInteger(daysDifference) || daysDifference < 0) {
return {
ok: false as const,
error: "Różnica dni musi być liczbą całkowitą większą lub równą 0.",
};
}

if (
daysComparisonMode !== 0 &&
daysComparisonMode !== 1 &&
daysComparisonMode !== 2
) {
return {
ok: false as const,
error: "Wybierz poprawny operator porównania dni.",
};
}

if (!subjectTemplate) {
return { ok: false as const, error: "Temat wiadomości jest wymagany." };
}

if (!bodyTemplate) {
return { ok: false as const, error: "Treść wiadomości jest wymagana." };
}

if (!Number.isInteger(sendHour) || sendHour < 0 || sendHour > 23) {
return {
ok: false as const,
error: "Godzina wysyłki musi być liczbą całkowitą w zakresie 0-23.",
};
}

if (!Number.isInteger(sendMinute) || sendMinute < 0 || sendMinute > 59) {
return {
ok: false as const,
error: "Minuta wysyłki musi być liczbą całkowitą w zakresie 0-59.",
};
}

if (
activeFormRecipientStrategy === "inspection_context" &&
!scheduleForm.targetInspectionLeader &&
!scheduleForm.targetInspectionTeam
) {
return {
ok: false as const,
error: "Pole Odbiorcy jest wymagane. Wybierz co najmniej jednego odbiorcę.",
};
}

return {
ok: true as const,
payload: {
name,
controlType: activeControlType,
daysComparisonMode: daysComparisonMode as 0 | 1 | 2,
dateFieldA: scheduleForm.dateFieldA,
...(activeControlType === "empty_field"
? {
checkEmptyField: scheduleForm.checkEmptyField,
}
: {
statusFieldCode: scheduleForm.statusFieldCode,
expectedStatusCode: scheduleForm.expectedStatusCodes[0] ?? "",
expectedStatusCodes: scheduleForm.expectedStatusCodes,
}),
daysDifference,
subjectTemplate,
bodyTemplate,
sendHour,
sendMinute,
targetInspectionLeader:
activeFormRecipientStrategy === "author_only"
? false
: scheduleForm.targetInspectionLeader,
targetInspectionTeam:
activeFormRecipientStrategy === "author_only"
? false
: scheduleForm.targetInspectionTeam,
fallbackRecipient: "author" as const,
enabled: scheduleForm.enabled,
},
};
};

const handleSaveSchedule = async (event: React.FormEvent<HTMLFormElement>) => {
event.preventDefault();
setScheduleFormError(null);
setSuccessMessage(null);
setError(null);

const validation = validateSchedulePayload();
if (!validation.ok) {
setScheduleFormError(validation.error);
return;
}

setIsBusy(true);

if (!editingSchedule) {
const response = await createSchedule(operatorLogin, validation.payload);
if (!response.ok) {
setScheduleFormError(response.error);
setIsBusy(false);
return;
}

setSchedules((previous) => [response.schedule, ...previous]);
setIsBusy(false);
setSuccessMessage("Harmonogram został utworzony.");
closeScheduleModal();
return;
}

const response = await updateSchedule(
operatorLogin,
editingSchedule.id,
validation.payload,
);

if (!response.ok) {
setScheduleFormError(response.error);
if (response.status === 404) {
void reloadSchedules();
}
setIsBusy(false);
return;
}

setSchedules((previous) =>
previous.map((item) =>
item.id === response.schedule.id ? response.schedule : item,
),
);
setIsBusy(false);
setSuccessMessage("Harmonogram został zapisany.");
closeScheduleModal();
};

	const handleOpenDeleteConfirmModal = (schedule: Schedule) => {
		setScheduleToDelete(schedule);
		setIsDeleteConfirmModalOpen(true);
	};

	const handleDeleteSchedule = async () => {
		if (!scheduleToDelete) {
			return;
		}

setError(null);
setSuccessMessage(null);
		setIsDeletingSchedule(true);
		const response = await deleteSchedule(operatorLogin, scheduleToDelete.id);
if (!response.ok) {
setError(response.error);
if (response.status === 404) {
void reloadSchedules();
}
			setIsDeletingSchedule(false);
			setIsDeleteConfirmModalOpen(false);
			setScheduleToDelete(null);
return;
}

		setSchedules((previous) =>
			previous.filter((item) => item.id !== scheduleToDelete.id),
		);
		setIsDeletingSchedule(false);
		setIsDeleteConfirmModalOpen(false);
		setScheduleToDelete(null);
setSuccessMessage("Harmonogram został usunięty.");
};

if (authRole !== "director") {
return (
<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
<p className="rounded-lg border border-amber-300/45 bg-amber-950/30 px-3 py-2 text-amber-200 text-sm">
Tylko dyrektor może zarządzać harmonogramami.
</p>
</section>
);
}

if (isLoading) {
return (
<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-6">
<p className="text-slate-300 text-sm">Ładowanie harmonogramów...</p>
</section>
);
}

return (
<section className="relative flex h-full min-h-0 flex-col rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
<div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-slate-700/70 border-b pb-3">
<div>
<h2 className="font-semibold text-lg text-slate-100">Harmonogramy</h2>
</div>
</div>

<div className="mb-3 flex justify-end">
<button
type="button"
onClick={openCreateScheduleModal}
disabled={isBusy || dateFields.length === 0}
className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#8bc0aa] bg-[#c8f0dc] px-3 font-semibold text-[#1d5038] text-sm transition-colors hover:bg-[#b4e8cf] disabled:cursor-not-allowed disabled:opacity-60"
>
<Plus size={14} />
Dodaj harmonogram
</button>
</div>

{error ? (
<p className="mb-3 rounded-lg border border-rose-300/45 bg-rose-950/25 px-3 py-2 font-medium text-rose-200 text-sm">
{error}
</p>
) : null}

{successMessage ? (
<p className="mb-3 rounded-lg border border-emerald-300/45 bg-emerald-950/25 px-3 py-2 font-medium text-emerald-200 text-sm">
{successMessage}
</p>
) : null}

<div className="min-h-0 flex-1">
<TableSurface containerClassName="h-full min-h-0" scrollAreaClassName="h-full min-h-0">
<table className="w-max min-w-full border-collapse text-slate-900 text-sm">
<thead className="sticky top-0 z-10">
<tr>
<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Nazwa</th>
							<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Data odniesienia</th>
							<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Pole kontroli</th>
<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Różnica dni</th>
<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Godzina</th>
<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Status</th>
<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Odbiorcy</th>
							<th className="min-w-[10rem] whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Akcje</th>
</tr>
</thead>
<tbody>
{schedules.length === 0 ? (
<tr>
							<td colSpan={8} className="px-3 py-6 text-center text-slate-500 text-sm">
Brak harmonogramów.
</td>
</tr>
) : (
schedules.map((schedule) => {
const recipients =
schedule.recipientStrategy === "author_only"
? "Osoba wprowadzająca wpis"
: [
schedule.targetInspectionLeader ? "Kierujący" : "",
schedule.targetInspectionTeam ? "Zespół" : "",
]
.filter(Boolean)
.join(", ");

const controlFieldLabel =
dateFieldLabelMap.get(schedule.checkEmptyField) ?? schedule.checkEmptyField;

const statusFieldLabel =
statusFieldLabelMap.get(schedule.statusFieldCode) ?? schedule.statusFieldCode;

const statusLabels = (
schedule.expectedStatusCodes.length > 0
? schedule.expectedStatusCodes
: schedule.expectedStatusCode
? [schedule.expectedStatusCode]
: []
)
.map((code) => allStatusOptionLabelMap.get(code) ?? code)
.filter(Boolean);

const daysDifferenceLabel =
`${toDaysComparisonLabelFromNumber(schedule.daysComparisonMode)} ${schedule.daysDifference}`;

return (
<tr key={schedule.id} className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50">
<td className="px-3 py-2.5 font-medium">{schedule.name}</td>
								<td className="px-3 py-2.5">
									{dateFieldLabelMap.get(schedule.dateFieldA) ?? schedule.dateFieldA}
								</td>
								<td className="px-3 py-2.5 text-slate-700 text-xs sm:text-sm">
									{schedule.controlType === "status_equals" ? (
										statusLabels.length > 1 ? (
											<div className="space-y-1">
												<p className="font-medium text-slate-700 text-xs sm:text-sm">{statusFieldLabel}</p>
												<ol className="list-inside list-decimal space-y-0.5 text-slate-700">
													{statusLabels.map((label) => (
														<li key={`${schedule.id}-${label}`}>{label}</li>
													))}
												</ol>
											</div>
										) : (
											[statusFieldLabel, statusLabels[0]].filter(Boolean).join(" = ")
										)
									) : (
										controlFieldLabel
									)}
								</td>
	<td className="px-3 py-2.5">{daysDifferenceLabel}</td>
<td className="px-3 py-2.5">{String(schedule.sendHour).padStart(2, "0")}:{String(schedule.sendMinute).padStart(2, "0")}</td>
<td className="px-3 py-2.5">
{schedule.enabled ? "Włączony" : "Wyłączony"}
</td>
<td className="px-3 py-2.5 text-slate-700">{recipients}</td>
<td className="min-w-[10rem] px-3 py-2.5">
<div className="flex flex-wrap gap-2">
<button
type="button"
onClick={() => openEditScheduleModal(schedule)}
className="rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
>
<Pencil size={12} className="inline mr-1" />
Edytuj
</button>
<button
type="button"
onClick={() => handleOpenDeleteConfirmModal(schedule)}
disabled={isBusy || isDeletingSchedule}
className="rounded-md border border-rose-300 px-2 py-1 font-semibold text-rose-700 text-xs transition-colors hover:bg-rose-50 disabled:opacity-60"
>
Usuń
</button>
</div>
</td>
</tr>
);
})
)}
</tbody>
</table>
</TableSurface>
</div>

{isDeleteConfirmModalOpen ? (
	<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
		<button
			type="button"
			aria-label="Zamknij okno usuwania harmonogramu"
			className="absolute inset-0 bg-slate-950/65"
			onClick={() => {
				if (isDeletingSchedule) {
					return;
				}

				setIsDeleteConfirmModalOpen(false);
				setScheduleToDelete(null);
			}}
		/>

		<div
			role="dialog"
			aria-modal="true"
			aria-label="Potwierdzenie usunięcia harmonogramu"
			className="relative z-10 w-full max-w-xl rounded-2xl border border-slate-300 bg-white p-5 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)]"
		>
			<h3 className="font-semibold text-base text-slate-900">Usuń harmonogram</h3>
			<p className="mt-2 text-slate-700 text-sm leading-6">
				Czy na pewno chcesz usunąć ten harmonogram?
			</p>
			{scheduleToDelete ? (
				<p className="mt-2 text-slate-500 text-xs">Nazwa: {scheduleToDelete.name}</p>
			) : null}

			<div className="mt-5 flex items-center justify-end gap-2">
				<button
					type="button"
					onClick={() => {
						setIsDeleteConfirmModalOpen(false);
						setScheduleToDelete(null);
					}}
					disabled={isDeletingSchedule}
					className="inline-flex h-10 items-center rounded-lg border border-slate-300 bg-white px-4 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-60"
				>
					Anuluj
				</button>
				<button
					type="button"
					onClick={() => void handleDeleteSchedule()}
					disabled={isDeletingSchedule}
					className="inline-flex h-10 items-center rounded-lg border border-[#f2a3a3] bg-[#6f2a36] px-4 font-semibold text-[#ffe5e8] text-sm transition-colors hover:bg-[#833242] disabled:cursor-not-allowed disabled:opacity-60"
				>
					{isDeletingSchedule ? "Usuwanie..." : "Usuń harmonogram"}
				</button>
			</div>
		</div>
	</div>
) : null}

{isScheduleModalOpen ? (
<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />
<div className="relative z-10 w-full max-w-6xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5">
<div className="mb-4 flex items-center justify-between border-slate-200 border-b pb-3">
<h3 className="font-semibold text-base text-slate-900">
{editingSchedule ? "Edycja harmonogramu" : "Nowy harmonogram"}
</h3>
<button
type="button"
onClick={closeScheduleModal}
className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 hover:bg-slate-100"
>
<X size={14} />
</button>
</div>

<form className="space-y-4" onSubmit={handleSaveSchedule}>
<div className="grid gap-4 xl:grid-cols-[minmax(0,1.08fr)_minmax(0,0.9fr)_minmax(0,1.22fr)]">
<section className="h-full space-y-3 rounded-lg border border-slate-200 p-3">
<p className="font-semibold text-slate-800 text-sm">Ustawienia harmonogramu</p>
<label className="block text-slate-700 text-sm">
<span className="mb-1 block">Nazwa *</span>
<input
value={scheduleForm.name}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
name: event.target.value,
}))
}
className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
/>
</label>

<div className="space-y-4">
<SingleSelectPortalField
label="Data odniesienia *"
value={scheduleForm.dateFieldA}
options={dateFields.map((field) => ({
value: field.code,
label: field.label,
}))}
placeholder="Wybierz"
onChange={(next) =>
setScheduleForm((previous) => ({
...previous,
dateFieldA: next,
}))
}
/>
<div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3">
<div className="space-y-2">
<p className="text-slate-700 text-sm">Typ pola kontroli *</p>
<div className="flex flex-wrap gap-4">
<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
<input
type="checkbox"
checked={checkFieldKind === "date"}
onChange={() => {
if (checkFieldKind === "date") {
return;
}

setCheckFieldKind("date");
setIsStatusMultiSelectOpen(false);
setScheduleForm((previous) => ({
...previous,
checkEmptyField: "",
statusFieldCode: "",
expectedStatusCode: "",
expectedStatusCodes: [],
}));
}}
/>
Daty
</label>
<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
<input
type="checkbox"
checked={checkFieldKind === "status"}
onChange={() => {
if (checkFieldKind === "status") {
return;
}

setCheckFieldKind("status");
setIsStatusMultiSelectOpen(false);
setScheduleForm((previous) => ({
...previous,
checkEmptyField: "",
statusFieldCode: "",
expectedStatusCode: "",
expectedStatusCodes: [],
}));
}}
/>
Statusy
</label>
</div>
</div>
{checkFieldKind === "date" ? (
	<SingleSelectPortalField
	label="Wskaż datę do kontroli (czy uzupełniona) *"
	value={scheduleForm.checkEmptyField}
	options={checkFieldOptions.map((field) => ({
	value: field.code,
	label: field.label,
	}))}
	placeholder="Wybierz datę"
	onChange={(next) =>
	setScheduleForm((previous) => ({
	...previous,
	checkEmptyField: next,
	}))
	}
	/>
) : (
	<div className="space-y-3">
		<div className="space-y-1.5">
			<span className="text-slate-700 text-sm">Wskaż status do sprawdzenia *</span>
			<div className="relative">
				<button
					type="button"
					onClick={() => setIsStatusMultiSelectOpen((previous) => !previous)}
					className="flex h-10 w-full items-center justify-between rounded-lg border border-slate-300 bg-white px-3 text-left text-sm"
				>
					<span className="truncate text-slate-700">
						{selectedStatusControlLabels.length > 0
							? `${selectedStatusControlLabels.length} wybranych`
							: "Wybierz status"}
					</span>
					<span className="text-slate-500 text-xs">
						{isStatusMultiSelectOpen ? "Zwiń" : "Rozwiń"}
					</span>
				</button>
				{isStatusMultiSelectOpen ? (
					<div className="absolute z-20 mt-1 max-h-56 w-full overflow-y-auto rounded-lg border border-slate-300 bg-white p-2 shadow-lg">
						<div className="space-y-2">
							{statusControlOptions.map((option) => {
								const isChecked = selectedStatusControlValues.includes(option.value);
								return (
									<label
										key={option.value}
										className="flex cursor-pointer items-start gap-2 rounded-md px-2 py-1.5 text-slate-700 text-sm hover:bg-slate-50"
									>
										<input
											type="checkbox"
											checked={isChecked}
											onChange={() => handleToggleStatusControlValue(option.value)}
										/>
										<span className="leading-snug">{option.label}</span>
									</label>
								);
							})}
						</div>
					</div>
				) : null}
			</div>
		</div>
	</div>
)}
{(checkFieldKind === "date" ? checkFieldOptions.length : statusFields.length) === 0 ? (
<p className="rounded border border-amber-200 bg-amber-50 px-2 py-1.5 text-amber-800 text-xs">
{checkFieldKind === "status"
? "Brak dostępnych pól statusu do kontroli."
: "Brak dostępnych pól daty do kontroli."}
</p>
) : null}
</div>
</div>

<label className="block text-slate-700 text-sm">
<span className="mb-1 block">Liczba dni (data bieżąca - data odniesienia)</span>
<div className="grid grid-cols-[5.25rem_minmax(0,1fr)] gap-2">
<select
value={scheduleForm.daysComparisonMode}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
daysComparisonMode: event.target.value as "0" | "1" | "2",
}))
}
className="h-10 rounded-lg border border-slate-300 bg-white px-2 text-sm"
>
<option value="0">=</option>
<option value="1">&gt;</option>
<option value="2">&gt;=</option>
</select>
<input
type="number"
min={0}
value={scheduleForm.daysDifference}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
daysDifference: event.target.value,
}))
}
className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
/>
</div>
</label>

<div className="grid gap-2 sm:grid-cols-2">
<label className="block text-slate-700 text-sm">
<span className="mb-1 block whitespace-nowrap text-[13px]">Godzina wysyłki (0-23) *</span>
<input
type="number"
min={0}
max={23}
value={scheduleForm.sendHour}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
sendHour: event.target.value,
}))
}
className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
/>
</label>
<label className="block text-slate-700 text-sm">
<span className="mb-1 block whitespace-nowrap text-[13px]">Minuta wysyłki (0-59) *</span>
<input
type="number"
min={0}
max={59}
value={scheduleForm.sendMinute}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
sendMinute: event.target.value,
}))
}
className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
/>
</label>
</div>

{activeFormRecipientStrategy === "author_only" ? (
<p className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-2 text-slate-700 text-sm">
Odbiorca: osoba wprowadzająca wpis.
</p>
) : (
<div className="space-y-2">
<p className="text-slate-700 text-sm">Odbiorcy *</p>
<div className="flex flex-col gap-1.5">
<label className="flex items-center gap-2 text-slate-700 text-sm">
<input
type="checkbox"
checked={scheduleForm.targetInspectionLeader}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
targetInspectionLeader: event.target.checked,
}))
}
/>
Kierujący inspekcją
</label>
<label className="flex items-center gap-2 text-slate-700 text-sm">
<input
type="checkbox"
checked={scheduleForm.targetInspectionTeam}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
targetInspectionTeam: event.target.checked,
}))
}
/>
Zespół inspekcji
</label>
</div>
</div>
)}
</section>

<section className="h-full space-y-3 rounded-lg border border-slate-200 p-3 xl:min-h-[29.7rem]">
<p className="font-semibold text-slate-800 text-sm">Dostępne zmienne</p>
{!hasControlFieldsSelected ? (
null
) : null}
{isTemplateVariablesLoading ? (
<p className="text-slate-600 text-sm">Ładowanie zmiennych...</p>
) : templateVariablesError ? (
<p className="text-rose-600 text-sm">{templateVariablesError}</p>
) : visibleTemplateVariables.length === 0 &&
	!(activeControlType === "status_equals" && statusListTemplateVariable) ? (
<p className="text-slate-600 text-sm">Brak zmiennych dla wybranego kontekstu.</p>
) : (
<div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50/80 p-3">
<div className="subtle-vertical-scroll max-h-[29.5rem] space-y-2.5 overflow-y-auto pr-1">
{activeControlType === "status_equals" && statusListTemplateVariable ? (
<div className="space-y-2 rounded-lg border border-slate-200 bg-white px-2.5 py-2 shadow-sm">
<p className="leading-snug font-medium text-slate-700 text-sm">
Wybrane statusy do sprawdzenia (lista)
</p>
<div className="flex flex-wrap gap-2">
<button
type="button"
onClick={() => insertBodyToken(statusListTemplateVariable.token)}
className="rounded-md border border-slate-300 bg-white px-2 py-1 font-medium text-[11px] text-slate-700 transition-colors hover:border-blue-300 hover:bg-blue-50"
>
Do treści
</button>
</div>
<span className="inline-block rounded-md border border-blue-200 bg-blue-50 px-2 py-0.5 font-semibold text-[11px] text-blue-800">
{`{{${statusListTemplateVariable.token}}}`}
</span>
</div>
) : null}
{visibleTemplateVariables.map((item) => (
<div key={item.token} className="space-y-2 rounded-lg border border-slate-200 bg-white px-2.5 py-2 shadow-sm">
<p className="leading-snug font-medium text-slate-700 text-sm">{polishLabel(item.label)}</p>
<div className="flex flex-wrap gap-2">
<button
type="button"
onClick={() => insertSubjectToken(item.token)}
className="rounded-md border border-slate-300 bg-white px-2 py-1 font-medium text-[11px] text-slate-700 transition-colors hover:border-blue-300 hover:bg-blue-50"
>
Do tematu
</button>
<button
type="button"
onClick={() => insertBodyToken(item.token)}
className="rounded-md border border-slate-300 bg-white px-2 py-1 font-medium text-[11px] text-slate-700 transition-colors hover:border-blue-300 hover:bg-blue-50"
>
Do treści
</button>
</div>
<span className="inline-block rounded-md border border-blue-200 bg-blue-50 px-2 py-0.5 font-semibold text-[11px] text-blue-800">
{`{{${item.token}}}`}
</span>
</div>
))}
</div>
</div>
)}
</section>

<section className="h-full space-y-3 rounded-lg border border-slate-200 p-3 xl:min-h-[29.7rem]">
<p className="font-semibold text-slate-800 text-sm">Treść wiadomości</p>
<label className="block text-slate-700 text-sm">
<span className="mb-1 block">Temat wiadomości *</span>
<input
value={scheduleForm.subjectTemplate}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
subjectTemplate: event.target.value,
}))
}
className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm"
/>
</label>
<label className="block text-slate-700 text-sm">
<span className="mb-1 block">Treść wiadomości *</span>
<textarea
value={scheduleForm.bodyTemplate}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
bodyTemplate: event.target.value,
}))
}
rows={11}
className="min-h-[19rem] w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
/>
</label>
</section>
</div>

{scheduleFormError ? (
<p className="font-medium text-rose-600 text-sm">{scheduleFormError}</p>
) : null}

<div className="flex items-center justify-between gap-3 border-slate-200 border-t pt-3">
<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
<input
type="checkbox"
checked={scheduleForm.enabled}
onChange={(event) =>
setScheduleForm((previous) => ({
...previous,
enabled: event.target.checked,
}))
}
/>
Aktywny harmonogram
</label>

<div className="flex justify-end gap-2">
<button
type="button"
onClick={closeScheduleModal}
className="inline-flex h-9 items-center rounded-lg border border-slate-300 px-3 font-semibold text-slate-700 text-sm hover:bg-slate-100"
>
Anuluj
</button>
<button
type="submit"
disabled={isBusy}
className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm hover:bg-[#375f99] disabled:opacity-70"
>
{isBusy ? "Zapisywanie..." : "Zapisz"}
</button>
</div>
</div>
</form>
</div>
</div>
) : null}
</section>
);
}
