"use client";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import { AdminUsersPanel } from "@/features/admin-users/components/AdminUsersPanel";

type UsersPanelProps = {
	operatorLogin: string;
	authRole: AuthRole;
};

export function UsersPanel({ operatorLogin, authRole }: UsersPanelProps) {
	return (
		<AdminUsersPanel
			operatorLogin={operatorLogin}
			authRole={authRole}
			title="Użytkownicy"
			subtitle="Wspólna tabela użytkowników. Typ konta wybierzesz w formularzu dodawania."
		/>
	);
}
