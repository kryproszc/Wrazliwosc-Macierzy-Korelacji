"use client";

import { UserPlus } from "lucide-react";
import { useEffect, useState } from "react";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import { AddAdminUserModal } from "@/features/admin-users/components/AddAdminUserModal";
import { AdminUsersTable } from "@/features/admin-users/components/AdminUsersTable";
import { EditAdminUserModal } from "@/features/admin-users/components/EditAdminUserModal";
import { ProfileHistoryModal } from "@/features/admin-users/components/ProfileHistoryModal";
import { useAdminUsersPanel } from "@/features/admin-users/hooks/useAdminUsersPanel";
import { fetchAdminUserProfileHistoryEvents } from "@/features/admin-users/api";
import type {
	AdminUser,
	AdminUserProfileHistoryEvent,
} from "@/features/admin-users/types";
import { fetchDictionaryEntries } from "@/features/dictionaries/api";
import {
	createExternalUser,
	fetchExternalUserPermissions,
	fetchPermissionsCatalog,
	updateExternalUserPermissions,
} from "@/features/external-users/api";
import type {
	CreateExternalUserForm,
	ExternalPermissionCatalogItem,
} from "@/features/external-users/types";
import { DeleteSuccessModal } from "@/shared/components/DeleteSuccessModal";
import { clearStoredAuthSession } from "@/features/auth/session";

type AdminUsersPanelProps = {
	operatorLogin: string;
	authRole: AuthRole;
	title?: string;
	subtitle?: string;
};

type DepartmentOption = {
	value: string;
	label: string;
};

const DEFAULT_OBSERVER_FORM: CreateExternalUserForm = {
	login: "",
	imie: "",
	nazwisko: "",
	email: "",
	aktywny: true,
	permissions: [],
};

const TEAM_LEAD_OBSERVER_PERMISSION_KEYS = new Set([
	"registry.inspections.read",
	"registry.recommendations.read",
	"registry.obligating_decisions.read",
	"registry.risk_exposure.read",
	"reports.executed_inspections.read",
]);

export function AdminUsersPanel({
	operatorLogin,
	authRole,
	title = "Dodaj użytkownika",
	subtitle = "Zarządzanie kontami i ich przypisaniem do ról oraz zespołów.",
}: AdminUsersPanelProps) {
	const isTeamLead = authRole === "team_lead";
	const [isAddUserSuccessModalOpen, setIsAddUserSuccessModalOpen] =
		useState(false);
	const [observerForm, setObserverForm] =
		useState<CreateExternalUserForm>(DEFAULT_OBSERVER_FORM);
	const [observerError, setObserverError] = useState<string | null>(null);
	const [isCreatingObserver, setIsCreatingObserver] = useState(false);
	const [observerPermissionsCatalog, setObserverPermissionsCatalog] = useState<
		ExternalPermissionCatalogItem[]
	>([]);
	const [departmentOptions, setDepartmentOptions] = useState<DepartmentOption[]>([]);
	const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);
	const [historyUser, setHistoryUser] = useState<AdminUser | null>(null);
	const [historyEvents, setHistoryEvents] = useState<AdminUserProfileHistoryEvent[]>([]);
	const [isHistoryOpen, setIsHistoryOpen] = useState(false);
	const [isHistoryLoading, setIsHistoryLoading] = useState(false);
	const [historyError, setHistoryError] = useState<string | null>(null);
	const [editObserverPermissions, setEditObserverPermissions] = useState<string[]>([]);
	const [isEditObserverPermissionsLoading, setIsEditObserverPermissionsLoading] =
		useState(false);
	const [editObserverPermissionsError, setEditObserverPermissionsError] =
		useState<string | null>(null);

	const {
		users,
		usersError,
		isUsersLoading,
		loadUsers,
		ensureUsersLoaded,
		isAddModalOpen,
		openAddModal,
		closeAddModal,
		isAddingUser,
		addUserError,
		addUserForm,
		setAddUserForm,
		isTeamRequired,
		isRoleLocked,
		isTeamLocked,
		availableTeams,
		lockedTeamLabel,
		isTeamsLoading,
		submitAddUser,
		editingUser,
		isEditModalOpen,
		isUpdatingUser,
		editUserError,
		editUserForm,
		setEditUserForm,
		openEditModal,
		closeEditModal,
		submitEditUser,
		canEditUser,
		inviteError,
	} = useAdminUsersPanel({ operatorLogin, authRole });

	useEffect(() => {
		ensureUsersLoaded();
	}, [ensureUsersLoaded]);

	const loadObserverCatalog = async () => {
		if (observerPermissionsCatalog.length > 0) {
			return;
		}

		const catalogResult = await fetchPermissionsCatalog(operatorLogin);

		const applyTeamLeadScope = (catalog: ExternalPermissionCatalogItem[]) =>
			catalog.filter((permission) =>
				TEAM_LEAD_OBSERVER_PERMISSION_KEYS.has(permission.key),
			);

		if (!catalogResult.ok) {
			if (isTeamLead) {
				const fallbackCatalog: ExternalPermissionCatalogItem[] = [
					{
						key: "registry.inspections.read",
						label: "Rejestr: Inspekcje",
						description: "Podgląd inspekcji",
					},
					{
						key: "registry.recommendations.read",
						label: "Rejestr: Zalecenia",
						description: "Podgląd zaleceń",
					},
					{
						key: "registry.obligating_decisions.read",
						label: "Rejestr: Decyzje zobowiązujące",
						description: "Podgląd decyzji zobowiązujących",
					},
					{
						key: "registry.risk_exposure.read",
						label: "Rejestr: Wnioski sankcyjne",
						description: "Podgląd wniosków sankcyjnych",
					},
					{
						key: "reports.executed_inspections.read",
						label: "Raporty: Mapa inspekcji",
						description: "Podgląd raportu wykonanych inspekcji",
					},
				];

				setObserverPermissionsCatalog(fallbackCatalog);
			}
			return;
		}

		setObserverPermissionsCatalog(
			isTeamLead
				? applyTeamLeadScope(catalogResult.permissions)
				: catalogResult.permissions,
		);
	};

	const loadDepartmentOptions = async (forceRefresh = false) => {
		if (!forceRefresh && departmentOptions.length > 0) {
			return;
		}

		setIsDepartmentsLoading(true);
		try {
			const result = await fetchDictionaryEntries("department_ogolne", operatorLogin);
			if (!result.ok) {
				setDepartmentOptions([]);
				return;
			}

			const options = result.data
				.map((entry) => ({
					value: entry.kodPozycji,
					label:
						entry.skrotPozycji?.trim() ||
						entry.kodPozycji ||
						entry.nazwaPozycji,
				}))
				.filter((item) => item.value.trim() && item.label.trim())
				.sort((left, right) =>
					left.label.localeCompare(right.label, "pl", { sensitivity: "base" }),
				);

			setDepartmentOptions(options);
		} catch {
			setDepartmentOptions([]);
		} finally {
			setIsDepartmentsLoading(false);
		}
	};

	const handleReloginRequired = (detail?: string) => {
		const errorMessage = detail || "Sesja wygasła. Zaloguj się ponownie.";
		setEditObserverPermissionsError(errorMessage);
		clearStoredAuthSession();

		if (typeof window !== "undefined") {
			window.location.assign("/login");
		}
	};

	const handleOpenAddModal = async () => {
		setObserverForm(DEFAULT_OBSERVER_FORM);
		setObserverError(null);
		await openAddModal();
		await Promise.all([loadObserverCatalog(), loadDepartmentOptions(true)]);
	};

	const handleOpenEditModal = async (user: Parameters<typeof openEditModal>[0]) => {
		openEditModal(user);
		setEditObserverPermissionsError(null);
		setEditObserverPermissions([]);

		await Promise.all([loadDepartmentOptions(true), loadObserverCatalog()]);

		if (user.accountType !== "observer") {
			return;
		}

		setIsEditObserverPermissionsLoading(true);
		try {
			const permissionsResult = await fetchExternalUserPermissions(
				operatorLogin,
				user.id,
			);
			if (!permissionsResult.ok) {
				setEditObserverPermissionsError(permissionsResult.error);
				return;
			}

			setEditObserverPermissions(permissionsResult.permissions);
		} catch {
			setEditObserverPermissionsError(
				"Nie udało się pobrać uprawnień obserwatora.",
			);
		} finally {
			setIsEditObserverPermissionsLoading(false);
		}
	};

	const handleOpenProfileHistory = async (user: AdminUser) => {
		setHistoryUser(user);
		setHistoryEvents([]);
		setHistoryError(null);
		setIsHistoryOpen(true);
		setIsHistoryLoading(true);

		try {
			const result = await fetchAdminUserProfileHistoryEvents({
				operatorLogin,
				userId: user.id,
			});
			if (!result.ok) {
				setHistoryError(result.error);
				return;
			}

			setHistoryEvents(result.events);
		} catch {
			setHistoryError("Nie udało się pobrać historii profilu.");
		} finally {
			setIsHistoryLoading(false);
		}
	};

	const handleAddUserSubmit = async (
		event: React.FormEvent<HTMLFormElement>,
	) => {
		event.preventDefault();
		const result = await submitAddUser();
		if (result.ok && result.inviteSent) {
			setIsAddUserSuccessModalOpen(true);
		}
	};

	const handleAddObserverSubmit = async (
		event: React.FormEvent<HTMLFormElement>,
	) => {
		event.preventDefault();

		if (
			!observerForm.login.trim() ||
			!observerForm.imie.trim() ||
			!observerForm.nazwisko.trim() ||
			!observerForm.email.trim()
		) {
			setObserverError(
				"Uzupełnij wymagane pola: login, imię, nazwisko i e-mail.",
			);
			return;
		}

		if (observerForm.permissions.length === 0) {
			setObserverError("Wybierz przynajmniej jedno uprawnienie widoczności.");
			return;
		}

		setObserverError(null);
		setIsCreatingObserver(true);

		try {
			const frontendInviteUrl =
				typeof window !== "undefined"
					? `${window.location.origin}/set-password`
					: "http://localhost:3002/set-password";

			const result = await createExternalUser(operatorLogin, {
				login: observerForm.login.trim(),
				imie: observerForm.imie.trim(),
				nazwisko: observerForm.nazwisko.trim(),
				email: observerForm.email.trim(),
				permissions: observerForm.permissions,
				aktywny: observerForm.aktywny,
				frontendInviteUrl,
			});

			if (!result.ok) {
				setObserverError(result.error);
				return;
			}

			closeAddModal();
			await loadUsers();
			setIsAddUserSuccessModalOpen(true);
		} catch {
			setObserverError("Nie udało się utworzyć użytkownika obserwatora.");
		} finally {
			setIsCreatingObserver(false);
		}
	};

	const handleEditUserSubmit = async (
		event: React.FormEvent<HTMLFormElement>,
	) => {
		event.preventDefault();
		setEditObserverPermissionsError(null);

		const isObserverEdit =
			editingUser !== null && editUserForm.accountType === "observer";
		if (isObserverEdit && editObserverPermissions.length === 0) {
			setEditObserverPermissionsError(
				"Wybierz przynajmniej jedno uprawnienie widoczności modułów.",
			);
			return;
		}

		const updateResult = await submitEditUser({ skipClose: true });
		if (!updateResult.ok) {
			if (updateResult.requiresRelogin) {
				handleReloginRequired(
					"Zmiana profilu została odrzucona, ponieważ sesja operatora wygasła. Zaloguj się ponownie.",
				);
			}
			return;
		}

		if (isObserverEdit && editingUser) {
			const permissionsResult = await updateExternalUserPermissions(
				operatorLogin,
				editingUser.id,
				editObserverPermissions,
			);
			if (!permissionsResult.ok) {
				if (permissionsResult.status === 401) {
					handleReloginRequired(
						"Zmiana uprawnień została odrzucona, ponieważ sesja operatora wygasła. Zaloguj się ponownie.",
					);
					return;
				}

				setEditObserverPermissionsError(permissionsResult.error);
				return;
			}
		}

		closeEditModal();
		await loadUsers();
	};

	return (
		<section className="relative flex h-[calc(100vh-2.2rem)] min-h-[40rem] flex-col rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
			<div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-slate-700/70 border-b pb-3">
				<div>
					<h2 className="font-semibold text-lg text-slate-100">
						{title}
					</h2>
				</div>
			</div>

			<div className="mb-3 flex justify-end">
				<button
					type="button"
					onClick={() => void handleOpenAddModal()}
					className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#8ec5a1] bg-[#b9e8c9] px-3.5 font-semibold text-[#1f5130] text-sm shadow-[inset_0_1px_0_rgba(255,255,255,0.45)] transition-colors hover:bg-[#a5debb]"
				>
					<UserPlus size={15} />
					Dodaj użytkownika
				</button>
			</div>

			<div className="min-h-0 flex-1">
				<AdminUsersTable
					className="h-full min-h-0"
					users={users}
					usersError={usersError}
					isUsersLoading={isUsersLoading}
					canEditUser={canEditUser}
					onEditUser={handleOpenEditModal}
					onViewHistory={(user) => void handleOpenProfileHistory(user)}
				/>
			</div>

			{inviteError ? (
				<p className="mt-3 rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-rose-700 text-sm">
					{inviteError}
				</p>
			) : null}

			<AddAdminUserModal
				isOpen={isAddModalOpen}
				isAddingUser={isAddingUser}
				isCreatingObserver={isCreatingObserver}
				isTeamRequired={isTeamRequired}
				isRoleLocked={isRoleLocked}
				isTeamLocked={isTeamLocked}
				isTeamsLoading={isTeamsLoading}
				addUserError={addUserError}
				observerError={observerError}
				addUserForm={addUserForm}
				observerForm={observerForm}
				observerPermissionsCatalog={observerPermissionsCatalog}
				departmentOptions={departmentOptions}
				isDepartmentsLoading={isDepartmentsLoading}
				availableTeams={availableTeams}
				lockedTeamLabel={lockedTeamLabel}
				onClose={closeAddModal}
				onSubmit={handleAddUserSubmit}
				onSubmitObserver={handleAddObserverSubmit}
				onFormChange={setAddUserForm}
				onObserverFormChange={setObserverForm}
				onToggleObserverPermission={(permissionKey) =>
					setObserverForm((previous) => ({
						...previous,
						permissions: previous.permissions.includes(permissionKey)
							? previous.permissions.filter((item) => item !== permissionKey)
							: [...previous.permissions, permissionKey],
					}))
				}
			/>

			<EditAdminUserModal
				isOpen={isEditModalOpen}
				isSubmitting={isUpdatingUser}
				isTeamRequired={editUserForm.rolaId === 1 || editUserForm.rolaId === 2}
				isRoleLocked={isRoleLocked}
				isTeamLocked={isTeamLocked}
				isTeamsLoading={isTeamsLoading}
				error={editUserError}
				form={editUserForm}
				user={editingUser}
				availableTeams={availableTeams}
				lockedTeamLabel={lockedTeamLabel}
				departmentOptions={departmentOptions}
				isDepartmentsLoading={isDepartmentsLoading}
				observerPermissionsCatalog={observerPermissionsCatalog}
				observerPermissions={editObserverPermissions}
				isObserverPermissionsLoading={isEditObserverPermissionsLoading}
				observerPermissionsError={editObserverPermissionsError}
				onClose={closeEditModal}
				onSubmit={handleEditUserSubmit}
				onFormChange={setEditUserForm}
				onToggleObserverPermission={(permissionKey) =>
					setEditObserverPermissions((previous) =>
						previous.includes(permissionKey)
							? previous.filter((item) => item !== permissionKey)
							: [...previous, permissionKey],
					)
				}
			/>

			<DeleteSuccessModal
				isOpen={isAddUserSuccessModalOpen}
				heading="Konto użytkownika zostało dodane"
				detailsMessage="Link z możliwością utworzenia hasła został wysłany"
				onClose={() => setIsAddUserSuccessModalOpen(false)}
			/>

			<ProfileHistoryModal
				isOpen={isHistoryOpen}
				user={historyUser}
				isLoading={isHistoryLoading}
				error={historyError}
				events={historyEvents}
				onClose={() => {
					setIsHistoryOpen(false);
					setHistoryUser(null);
					setHistoryEvents([]);
					setHistoryError(null);
				}}
			/>

			{isAddingUser || isCreatingObserver ? (
				<div className="fixed inset-0 z-70 flex items-center justify-center bg-slate-950/35 backdrop-blur-[1px]">
					<div className="w-full max-w-sm rounded-2xl border border-[#43628f] bg-[#1a2f53] px-5 py-4 shadow-[0_16px_40px_rgba(2,8,23,0.45)]">
						<div className="flex items-center gap-3">
							<span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#2f4f83]">
								<span className="h-4 w-4 animate-spin rounded-full border-2 border-sky-100 border-t-transparent" />
							</span>
							<div>
								<p className="font-semibold text-slate-100 text-sm">Trwa dodawanie użytkownika</p>
								<p className="text-slate-300/90 text-xs">
									{isCreatingObserver
										? "Zapisywanie konta obserwatora i wysyłanie linku do utworzenia hasła..."
										: "Zapisywanie konta i wysyłanie linku do utworzenia hasła..."}
								</p>
							</div>
						</div>
					</div>
				</div>
			) : null}
		</section>
	);
}
