import { Save, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { ROLE_OPTIONS } from "@/features/admin-users/constants";
import type {
	AddUserForm,
	AdminTeam,
	AdminUser,
} from "@/features/admin-users/types";
import type { ExternalPermissionCatalogItem } from "@/features/external-users/types";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";

function normalizeEmailPart(value: string) {
	return value
		.trim()
		.toLowerCase()
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, "")
		.replace(/[^a-z0-9]+/g, ".")
		.replace(/^\.+|\.+$/g, "");
}

function buildSuggestedEmail(imie: string, nazwisko: string) {
	const first = normalizeEmailPart(imie);
	const last = normalizeEmailPart(nazwisko);

	if (!first || !last) {
		return "";
	}

	return `${first}.${last}@gmail.com`;
}

type EditAdminUserModalProps = {
	isOpen: boolean;
	isSubmitting: boolean;
	isTeamRequired: boolean;
	isRoleLocked: boolean;
	isTeamLocked: boolean;
	isTeamsLoading: boolean;
	error: string | null;
	form: AddUserForm;
	user: AdminUser | null;
	availableTeams: AdminTeam[];
	lockedTeamLabel: string | null;
	departmentOptions: Array<{ value: string; label: string }>;
	isDepartmentsLoading: boolean;
	observerPermissionsCatalog: ExternalPermissionCatalogItem[];
	observerPermissions: string[];
	isObserverPermissionsLoading: boolean;
	observerPermissionsError: string | null;
	onClose: () => void;
	onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
	onFormChange: (updater: (previous: AddUserForm) => AddUserForm) => void;
	onToggleObserverPermission: (permissionKey: string) => void;
};

type DiuDraftState = {
	rolaId: number;
	zespolId: number | null;
	listVisibility: "visible" | "hidden";
};

export function EditAdminUserModal({
	isOpen,
	isSubmitting,
	isTeamRequired,
	isRoleLocked,
	isTeamLocked,
	isTeamsLoading,
	error,
	form,
	user,
	availableTeams,
	lockedTeamLabel,
	departmentOptions,
	isDepartmentsLoading,
	observerPermissionsCatalog,
	observerPermissions,
	isObserverPermissionsLoading,
	observerPermissionsError,
	onClose,
	onSubmit,
	onFormChange,
	onToggleObserverPermission,
}: EditAdminUserModalProps) {
	const [diuDraft, setDiuDraft] = useState<DiuDraftState | null>(null);
	const listVisibilityOptions = [
		{ value: "visible", label: "Widoczny" },
		{ value: "hidden", label: "Ukryty" },
	];

	const isObserverAccount = form.accountType === "observer";
	const isTechnicalAccount = form.accountType === "technical";
	const isDiuAccount = form.accountType === "diu";
	const isActiveAccount = form.aktywny;
	const isObserverTypeDisabled = !isActiveAccount;
	const isTechnicalTypeDisabled = isActiveAccount;
	const isTeamRequiredForCurrentType = isDiuAccount && isTeamRequired;
	const isDiuSelected = isDiuAccount;
	const isObserversSelected = isObserverAccount;
	const isTechnicalSelected = isTechnicalAccount;
	const normalizedDepartmentOptions = departmentOptions.map((item) => ({
		value: item.value,
		label: item.label,
	}));

	useEffect(() => {
		if (!isOpen || form.departmentCode || !user?.departmentLabel) {
			return;
		}

		const normalizedTarget = user.departmentLabel.trim().toLowerCase();
		if (!normalizedTarget) {
			return;
		}

		const matchedDepartment = normalizedDepartmentOptions.find((option) => {
			const normalizedValue = option.value.trim().toLowerCase();
			const normalizedLabel = option.label.trim().toLowerCase();
			return (
				normalizedValue === normalizedTarget ||
				normalizedLabel === normalizedTarget
			);
		});

		if (!matchedDepartment) {
			return;
		}

		onFormChange((previous) =>
			previous.departmentCode === matchedDepartment.value
				? previous
				: {
						...previous,
						departmentCode: matchedDepartment.value,
				  },
		);
	}, [
		form.departmentCode,
		isOpen,
		normalizedDepartmentOptions,
		onFormChange,
		user?.departmentLabel,
	]);

	const sortedObserverPermissions = useMemo(
		() =>
			[...observerPermissionsCatalog].sort((left, right) =>
				left.label.localeCompare(right.label, "pl", { sensitivity: "base" }),
			),
		[observerPermissionsCatalog],
	);

	const observerPermissionSections = useMemo(() => {
		const reports = sortedObserverPermissions.filter((permission) =>
			permission.key.startsWith("reports."),
		);
		const registries = sortedObserverPermissions.filter((permission) =>
			permission.key.startsWith("registry."),
		);
		const other = sortedObserverPermissions.filter(
			(permission) =>
				!permission.key.startsWith("reports.") &&
				!permission.key.startsWith("registry."),
		);

		const sections: Array<{
			id: string;
			title: string;
			permissions: ExternalPermissionCatalogItem[];
		}> = [];

		if (reports.length > 0) {
			sections.push({ id: "reports", title: "Raporty", permissions: reports });
		}

		if (registries.length > 0) {
			sections.push({ id: "registry", title: "Rejestry", permissions: registries });
		}

		if (other.length > 0) {
			sections.push({ id: "other", title: "Pozostałe", permissions: other });
		}

		return sections;
	}, [sortedObserverPermissions]);

	useEffect(() => {
		if (!isTechnicalAccount) {
			return;
		}

		if (form.aktywny) {
			onFormChange((previous) => ({
				...previous,
				aktywny: false,
			}));
		}
	}, [form.aktywny, isTechnicalAccount, onFormChange]);

	useEffect(() => {
		if (!isObserverAccount || form.aktywny) {
			return;
		}

		onFormChange((previous) => ({
			...previous,
			aktywny: true,
		}));
	}, [form.aktywny, isObserverAccount, onFormChange]);

	useEffect(() => {
		if (!isDiuAccount || form.departmentCode === "DIU") {
			return;
		}

		onFormChange((previous) => ({
			...previous,
			departmentCode: "DIU",
		}));
	}, [form.departmentCode, isDiuAccount, onFormChange]);

	useEffect(() => {
		if (!isOpen || !isDiuAccount) {
			return;
		}

		setDiuDraft({
			rolaId: form.rolaId,
			zespolId: form.zespolId,
			listVisibility:
				form.listVisibility === "hidden" ? "hidden" : "visible",
		});
	}, [
		form.listVisibility,
		form.rolaId,
		form.zespolId,
		isDiuAccount,
		isOpen,
	]);

	if (!isOpen || !user) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
			<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Edytuj użytkownika"
				className="relative z-10 w-full max-w-6xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">
							Edytuj użytkownika
						</h3>
						<p className="mt-1 text-slate-600 text-sm">ID: {user.id}</p>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				<form className="flex max-h-[82vh] flex-col" onSubmit={onSubmit}>
					<div className="space-y-4 overflow-y-auto pr-1">
						<div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
						<div className="grid gap-3 lg:grid-cols-12">
							<div className="lg:col-span-4">
								<div className="rounded-lg border border-slate-200 bg-white px-2.5 py-2">
									<p className="mb-2 font-semibold text-slate-800 text-sm">Dostęp do konta</p>
									<div className="inline-flex rounded-lg border border-slate-300 bg-white p-1">
										<button
											type="button"
											onClick={() =>
												onFormChange((previous) => ({ ...previous, aktywny: true }))
											}
											disabled={isTechnicalAccount}
											className={`rounded-md px-3 py-1.5 font-semibold text-sm transition-colors ${
												isTechnicalAccount
													? "cursor-not-allowed text-slate-400"
													: form.aktywny
													? "bg-[#345689] text-white"
													: "text-slate-700 hover:bg-slate-100"
											}`}
										>
											Aktywny
										</button>
										<button
											type="button"
											onClick={() =>
												onFormChange((previous) => ({
													...previous,
													aktywny: false,
													login: previous.accountType === "diu" ? "" : previous.login,
													email: previous.accountType === "diu" ? "" : previous.email,
												}))
											}
											disabled={isObserverAccount}
											className={`rounded-md px-3 py-1.5 font-semibold text-sm transition-colors ${
												isObserverAccount
													? "cursor-not-allowed text-slate-400"
													: !form.aktywny
													? "bg-[#345689] text-white"
													: "text-slate-700 hover:bg-slate-100"
											}`}
										>
											Nieaktywny
										</button>
									</div>
								</div>
							</div>

							<div className="lg:col-span-8">
								<div className="rounded-lg border border-slate-200 bg-white px-2.5 py-2">
									<p className="mb-2 font-semibold text-slate-800 text-sm">Typ użytkownika</p>
									<div className="grid gap-2 sm:grid-cols-3">
										<button
											type="button"
											onClick={() => {
												onFormChange((previous) => ({
													...previous,
													accountType: "diu",
													departmentCode: "DIU",
													rolaId: diuDraft?.rolaId ?? previous.rolaId,
													zespolId: diuDraft?.zespolId ?? previous.zespolId,
													listVisibility:
														diuDraft?.listVisibility ?? previous.listVisibility,
												}));
											}}
											className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
												isDiuAccount
													? "border-[#84b0f2] bg-[#345689] text-white"
													: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
											}`}
										>
											<span className="block text-center leading-[1.05]">
												Pracownicy
												<br />
												DIU
											</span>
										</button>
										<button
											type="button"
											onClick={() => {
												if (form.accountType === "diu") {
													setDiuDraft({
														rolaId: form.rolaId,
														zespolId: form.zespolId,
														listVisibility:
															form.listVisibility === "hidden" ? "hidden" : "visible",
													});
												}

												onFormChange((previous) => ({
													...previous,
													accountType: "observer",
													aktywny: true,
													zespolId: null,
												}));
											}}
											disabled={isObserverTypeDisabled}
											className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
												isObserverTypeDisabled
													? "cursor-not-allowed border-slate-300 bg-slate-100 text-slate-400"
													: isObserverAccount
													? "border-[#84b0f2] bg-[#345689] text-white"
													: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
											}`}
										>
											<span className="block text-center leading-[1.05]">
												Użytkownicy
												<br />
												obserwatorzy
											</span>
										</button>
										<button
											type="button"
											onClick={() => {
												if (form.accountType === "diu") {
													setDiuDraft({
														rolaId: form.rolaId,
														zespolId: form.zespolId,
														listVisibility:
															form.listVisibility === "hidden" ? "hidden" : "visible",
													});
												}

												onFormChange((previous) => ({
													...previous,
													accountType: "technical",
													aktywny: false,
													zespolId: null,
												}));
											}}
											disabled={isTechnicalTypeDisabled}
											className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
												isTechnicalTypeDisabled
													? "cursor-not-allowed border-slate-300 bg-slate-100 text-slate-400"
													: isTechnicalAccount
													? "border-[#84b0f2] bg-[#345689] text-white"
													: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
											}`}
										>
											<span className="block text-center leading-[1.05]">
												Użytkownicy
												<br />
												techniczni
											</span>
										</button>
									</div>
								</div>
							</div>
						</div>
						</div>

						<div className="rounded-lg border border-slate-200 p-3">
							<p className="mb-2 font-semibold text-slate-800 text-sm">Dane podstawowe</p>
							<div className="grid gap-3 sm:grid-cols-2">
						<label className="text-slate-700 text-sm">
							<span className="mb-1 block">
								Login {isObserversSelected || (isDiuSelected && isActiveAccount) ? "*" : ""}
							</span>
							<input
								required={isObserversSelected || (isDiuSelected && isActiveAccount)}
								value={form.login}
								onChange={(event) =>
									onFormChange((previous) => ({
										...previous,
										login: event.target.value,
									}))
								}
								disabled={isTechnicalSelected || (isDiuSelected && !isActiveAccount)}
								className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500"
							/>
						</label>

						<label className="text-slate-700 text-sm">
							<span className="mb-1 block">Imię *</span>
							<input
								required
								value={form.imie}
								onChange={(event) =>
									onFormChange((previous) => {
										const nextImie = event.target.value;
										const previousSuggestedEmail = buildSuggestedEmail(
											previous.imie,
											previous.nazwisko,
										);
										const nextSuggestedEmail = buildSuggestedEmail(
											nextImie,
											previous.nazwisko,
										);

										return {
											...previous,
											imie: nextImie,
											email:
												!previous.email || previous.email === previousSuggestedEmail
													? nextSuggestedEmail
													: previous.email,
										};
									})
								}
								className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
							/>
						</label>

						<label className="text-slate-700 text-sm">
							<span className="mb-1 block">Nazwisko *</span>
							<input
								required
								value={form.nazwisko}
								onChange={(event) =>
									onFormChange((previous) => {
										const nextNazwisko = event.target.value;
										const previousSuggestedEmail = buildSuggestedEmail(
											previous.imie,
											previous.nazwisko,
										);
										const nextSuggestedEmail = buildSuggestedEmail(
											previous.imie,
											nextNazwisko,
										);

										return {
											...previous,
											nazwisko: nextNazwisko,
											email:
												!previous.email || previous.email === previousSuggestedEmail
													? nextSuggestedEmail
													: previous.email,
										};
									})
								}
								className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
							/>
						</label>

						<label className="text-slate-700 text-sm">
							<span className="mb-1 block">E-mail {isObserversSelected ? "*" : ""}</span>
							<input
								type="email"
								required={isObserversSelected}
								value={form.email}
								onChange={(event) =>
									onFormChange((previous) => ({
										...previous,
										email: event.target.value,
									}))
								}
								disabled={isTechnicalSelected || (isDiuSelected && !isActiveAccount)}
								className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500"
							/>
						</label>
							</div>
						</div>

						<div className="grid gap-4 xl:grid-cols-2">
							<div className="space-y-4">
								<fieldset
									disabled={!isDiuSelected}
									className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
										isDiuSelected ? "" : "opacity-60"
									}`}
								>
									<p className="font-semibold text-slate-800 text-sm">Pracownicy DIU</p>
									<div className="grid gap-3 sm:grid-cols-2">
										<div className="text-slate-700 text-sm">
											<SingleSelectPortalField
												label="Rola *"
												value={isDiuSelected ? String(form.rolaId) : ""}
												options={ROLE_OPTIONS.map((role) => ({
													value: String(role.id),
													label: role.label,
												}))}
												placeholder="Wybierz rolę"
												onChange={(next) => {
													if (!next) {
														return;
													}
													const nextRoleId = Number(next);
													onFormChange((previous) => ({
														...previous,
														rolaId: nextRoleId,
														zespolId: nextRoleId === 3 ? null : previous.zespolId,
													}));
												}}
												disabled={!isDiuSelected || isRoleLocked}
											/>
											{isRoleLocked ? (
												<p className="mt-1 text-slate-500 text-xs">
													Rola ustawiona przez uprawnienia kierownika zespołu.
												</p>
											) : null}
										</div>

										<div className="text-slate-700 text-sm">
											<SingleSelectPortalField
												label={`Zespół ${isTeamRequiredForCurrentType ? "*" : ""}`}
												value={
													isDiuSelected && form.zespolId
														? String(form.zespolId)
														: ""
												}
												options={availableTeams.map((team) => ({
													value: String(team.id),
													label: team.skroconaNazwa,
												}))}
												placeholder={
													isTeamRequiredForCurrentType
														? "Wybierz zespół"
														: "Nie dotyczy dla typu konta"
												}
												onChange={(next) =>
													onFormChange((previous) => ({
														...previous,
														zespolId: next ? Number(next) : null,
													}))
												}
												disabled={
													!isDiuSelected ||
													!isTeamRequiredForCurrentType ||
													isTeamsLoading ||
													isTeamLocked
												}
											/>
											{isTeamLocked && lockedTeamLabel ? (
												<p className="mt-1 text-slate-500 text-xs">
													Przypisanie tylko do zespołu: {lockedTeamLabel}
												</p>
											) : null}
										</div>
									</div>

									<div className="grid gap-3 sm:grid-cols-2">
										<SingleSelectPortalField
											label="Departament *"
											value={isDiuSelected ? (form.departmentCode ?? "DIU") : ""}
											options={normalizedDepartmentOptions}
											placeholder={isDiuSelected ? "Departament DIU" : "Wybierz departament"}
											onChange={() => undefined}
											disabled
										/>
										<SingleSelectPortalField
											label="Widoczność na liście *"
											value={isDiuSelected ? form.listVisibility : ""}
											options={listVisibilityOptions}
											placeholder="Wybierz"
											onChange={(next) =>
												onFormChange((previous) => ({
													...previous,
													listVisibility: next === "hidden" ? "hidden" : "visible",
												}))
											}
											disabled={!isDiuSelected}
										/>
									</div>
								</fieldset>

								<fieldset
									disabled={!isTechnicalSelected}
									className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
										isTechnicalSelected ? "" : "opacity-60"
									}`}
								>
									<p className="font-semibold text-slate-800 text-sm">Użytkownicy techniczni</p>
									<div className="grid gap-3 sm:grid-cols-2">
										<div>
											<SingleSelectPortalField
												label="Departament *"
												value={isTechnicalSelected ? (form.departmentCode ?? "") : ""}
												options={normalizedDepartmentOptions}
												placeholder={
													isDepartmentsLoading
														? "Ładowanie departamentów..."
														: "Wybierz departament"
												}
												onChange={(next) =>
													onFormChange((previous) => ({
														...previous,
														departmentCode: next || null,
													}))
												}
												disabled={
													!isTechnicalSelected ||
													isDepartmentsLoading ||
													normalizedDepartmentOptions.length === 0
												}
											/>
										</div>
										<div>
											<SingleSelectPortalField
												label="Widoczność na liście *"
												value={isTechnicalSelected ? form.listVisibility : ""}
												options={listVisibilityOptions}
												placeholder="Wybierz"
												onChange={(next) =>
													onFormChange((previous) => ({
														...previous,
														listVisibility: next === "hidden" ? "hidden" : "visible",
													}))
												}
												disabled={!isTechnicalSelected}
											/>
										</div>
									</div>
								</fieldset>
							</div>

							<div>
								<fieldset
									disabled={!isObserversSelected || !isActiveAccount}
									className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
										isObserversSelected && isActiveAccount ? "" : "opacity-60"
									}`}
								>
									<p className="font-semibold text-slate-800 text-sm">Użytkownicy obserwatorzy</p>
									<div className="grid gap-3 sm:grid-cols-2">
										<SingleSelectPortalField
											label="Departament *"
											value={form.departmentCode ?? ""}
											options={normalizedDepartmentOptions}
											placeholder={
												isDepartmentsLoading
													? "Ładowanie departamentów..."
													: "Wybierz departament"
											}
											onChange={(next) =>
												onFormChange((previous) => ({
													...previous,
													departmentCode: next || null,
												}))
											}
											disabled={
												!isObserversSelected ||
												!isActiveAccount ||
												isDepartmentsLoading ||
												normalizedDepartmentOptions.length === 0
											}
										/>
										<SingleSelectPortalField
											label="Widoczność na liście *"
											value={form.listVisibility}
											options={listVisibilityOptions}
											placeholder="Wybierz"
											onChange={(next) =>
												onFormChange((previous) => ({
													...previous,
													listVisibility: next === "hidden" ? "hidden" : "visible",
												}))
											}
											disabled={!isObserversSelected || !isActiveAccount}
										/>
									</div>

									<div className="rounded-lg border border-slate-200 p-3 max-h-[360px] overflow-y-auto">
										<p className="mb-2 font-semibold text-slate-800 text-sm">Widoczność modułów *</p>
										{isObserverPermissionsLoading ? (
											<p className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-2 text-slate-600 text-xs">
												Ładowanie uprawnień obserwatora...
											</p>
										) : sortedObserverPermissions.length === 0 ? (
											<p className="rounded-md border border-amber-300 bg-amber-50 px-2.5 py-2 text-amber-800 text-xs">
												Nie udało się odczytać katalogu uprawnień z backendu.
											</p>
										) : (
											<div className="space-y-3">
												{observerPermissionSections.map((section) => (
													<div key={section.id} className="space-y-2">
														<p className="font-semibold text-slate-700 text-xs uppercase tracking-[0.06em]">
															{section.title}
														</p>
														<div className="grid gap-x-4 gap-y-1 sm:grid-cols-2">
															{section.permissions.map((permission) => {
																const checked = observerPermissions.includes(permission.key);
																return (
																	<label
																		key={permission.key}
																		className={`flex items-start gap-2 py-1 text-sm leading-5 transition-colors ${
																			checked
																				? "text-[#1f4d8f]"
																				: "text-slate-700 hover:text-slate-900"
																		}`}
																	>
																		<input
																			type="checkbox"
																			checked={checked}
																			disabled={
																				!isObserversSelected ||
																				!isActiveAccount ||
																				isObserverPermissionsLoading
																			}
																			onChange={() => onToggleObserverPermission(permission.key)}
																			className="mt-0.5 h-3.5 w-3.5 accent-[#345689]"
																		/>
																		<span className="min-w-0 pr-1">
																			<span className="block font-medium text-sm">
																				{permission.label}
																			</span>
																		</span>
																	</label>
																);
															})}
														</div>
													</div>
												))}
											</div>
										)}
									</div>
								</fieldset>
							</div>
						</div>

						{error ? (
							<p className="font-medium text-rose-600 text-sm">{error}</p>
						) : null}

						{observerPermissionsError ? (
							<p className="font-medium text-rose-600 text-sm">{observerPermissionsError}</p>
						) : null}
					</div>

					<div className="mt-4 flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
						<button
							type="button"
							onClick={onClose}
							className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
						>
							Anuluj
						</button>

						<button
							type="submit"
							disabled={isSubmitting}
							className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
						>
							<Save size={14} />
							{isSubmitting ? "Zapisywanie..." : "Zapisz zmiany"}
						</button>
					</div>
				</form>
			</div>
		</div>
	);
}
