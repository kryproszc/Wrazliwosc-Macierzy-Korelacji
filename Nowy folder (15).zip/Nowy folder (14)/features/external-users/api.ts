import type {
	ExternalPermissionCatalogItem,
	ExternalUser,
} from "@/features/external-users/types";

const FALLBACK_EXTERNAL_PERMISSIONS: ExternalPermissionCatalogItem[] = [
	{
		key: "registry.inspections.read",
		label: "Rejestr: Inspekcje",
		description: "Podgląd inspekcji",
	},
	{
		key: "registry.recommendations.read",
		label: "Rejestr: Zalecenia",
		description: "Podgląd zaleceń",
	},
	{
		key: "registry.obligating_decisions.read",
		label: "Rejestr: Decyzje zobowiązujące",
		description: "Podgląd decyzji zobowiązujących",
	},
	{
		key: "registry.risk_exposure.read",
		label: "Rejestr: Wnioski sankcyjne",
		description: "Podgląd wniosków sankcyjnych",
	},
	{
		key: "reports.executed_inspections.read",
		label: "Raporty: Mapa inspekcji",
		description: "Podgląd raportu wykonanych inspekcji",
	},
	{
		key: "reports.protocol_time.read",
		label: "Raporty: Czas protokołu",
		description: "Podgląd raportu czasu protokołu",
	},
	{
		key: "reports.report_time.read",
		label: "Raporty: Czas sprawozdania",
		description: "Podgląd raportu czasu sprawozdania",
	},
];

type RawExternalUser = {
	id?: unknown;
	login?: unknown;
	imie?: unknown;
	nazwisko?: unknown;
	email?: unknown;
	aktywny?: unknown;
	rola?: unknown;
	rolaId?: unknown;
	zespolId?: unknown;
	permissions?: unknown;
	effectivePermissions?: unknown;
};

function normalizeStringArray(value: unknown) {
	if (!Array.isArray(value)) {
		return [] as string[];
	}

	return value
		.filter((item): item is string => typeof item === "string")
		.map((item) => item.trim())
		.filter(Boolean);
}

function extractPermissionsFromResponse(payload: unknown): string[] {
	if (Array.isArray(payload)) {
		return normalizeStringArray(payload);
	}

	if (!payload || typeof payload !== "object") {
		return [];
	}

	const source = payload as Record<string, unknown>;

	const fromKnownKeys = [
		source.permissions,
		source.effectivePermissions,
		(source.data as Record<string, unknown> | undefined)?.permissions,
		(source.data as Record<string, unknown> | undefined)?.effectivePermissions,
		(source.result as Record<string, unknown> | undefined)?.permissions,
		(source.result as Record<string, unknown> | undefined)?.effectivePermissions,
	];

	for (const candidate of fromKnownKeys) {
		const normalized = normalizeStringArray(candidate);
		if (normalized.length > 0) {
			return normalized;
		}
	}

	// Support map-like payloads, e.g. { permissions: { "registry.inspections.read": true } }
	const mapCandidates = [
		source.permissions,
		source.effectivePermissions,
		(source.data as Record<string, unknown> | undefined)?.permissions,
		(source.data as Record<string, unknown> | undefined)?.effectivePermissions,
	];

	for (const mapCandidate of mapCandidates) {
		if (!mapCandidate || typeof mapCandidate !== "object") {
			continue;
		}

		const keys = Object.entries(mapCandidate as Record<string, unknown>)
			.filter(([, value]) => value === true)
			.map(([key]) => key.trim())
			.filter(Boolean);

		if (keys.length > 0) {
			return keys;
		}
	}

	return [];
}

function normalizeExternalUser(raw: RawExternalUser): ExternalUser | null {
	const id = typeof raw.id === "number" && Number.isFinite(raw.id) ? raw.id : null;
	const login = typeof raw.login === "string" ? raw.login.trim() : "";
	if (!id || !login) {
		return null;
	}

	const role = typeof raw.rola === "string" ? raw.rola.trim().toLowerCase() : "";
	if (role !== "external_user") {
		return null;
	}

	const permissionsFromUser = normalizeStringArray(raw.permissions);
	const permissionsFromEffective = normalizeStringArray(raw.effectivePermissions);

	return {
		id,
		login,
		imie: typeof raw.imie === "string" ? raw.imie : "",
		nazwisko: typeof raw.nazwisko === "string" ? raw.nazwisko : "",
		email: typeof raw.email === "string" && raw.email.trim() ? raw.email.trim() : null,
		rolaId:
			typeof raw.rolaId === "number" && Number.isFinite(raw.rolaId)
				? raw.rolaId
				: null,
		zespolId:
			typeof raw.zespolId === "number" && Number.isFinite(raw.zespolId)
				? raw.zespolId
				: null,
		aktywny: raw.aktywny !== false,
		permissions:
			permissionsFromUser.length > 0
				? permissionsFromUser
				: permissionsFromEffective,
	};
}

function normalizeCatalogItem(item: unknown): ExternalPermissionCatalogItem | null {
	if (typeof item === "string") {
		const key = item.trim();
		if (!key) {
			return null;
		}

		return {
			key,
			label: key,
			description: "",
		};
	}

	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const key =
		typeof source.key === "string"
			? source.key.trim()
			: typeof source.permission === "string"
				? source.permission.trim()
				: "";
	if (!key) {
		return null;
	}

	const label =
		typeof source.label === "string" && source.label.trim()
			? source.label.trim()
			: key;
	const description =
		typeof source.description === "string" ? source.description : "";

	return { key, label, description };
}

function extractCatalogItems(payload: unknown): unknown[] {
	if (Array.isArray(payload)) {
		return payload;
	}

	if (!payload || typeof payload !== "object") {
		return [];
	}

	const source = payload as Record<string, unknown>;
	const directArrayKeys = [
		"permissions",
		"catalog",
		"items",
		"results",
		"data",
	];

	for (const key of directArrayKeys) {
		if (Array.isArray(source[key])) {
			return source[key] as unknown[];
		}
	}

	// Support map-like payloads, e.g. { "registry.inspections.read": "Label" }
	return Object.entries(source)
		.filter(([key]) => key.includes("."))
		.map(([key, value]) => {
			if (typeof value === "string") {
				return { key, label: value, description: "" };
			}

			if (value && typeof value === "object") {
				return { key, ...(value as Record<string, unknown>) };
			}

			return { key, label: key, description: "" };
		});
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown; message?: unknown };
		const detail = payload.detail ?? payload.message;
		return typeof detail === "string" ? detail : "";
	} catch {
		return "";
	}
}

export async function fetchExternalUsers(operatorLogin: string) {
	const response = await fetch("/api/admin/users", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || `Nie udało się pobrać użytkowników zewnętrznych (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const users = Array.isArray(payload)
		? payload
				.map((item) => normalizeExternalUser((item ?? {}) as RawExternalUser))
				.filter((user): user is ExternalUser => user !== null)
		: [];

	return { ok: true as const, users };
}

export async function fetchPermissionsCatalog(operatorLogin: string) {
	const response = await fetch("/api/admin/permissions/catalog", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || `Nie udało się pobrać katalogu uprawnień (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const sourceList = extractCatalogItems(payload);

	const permissions = sourceList
		.map((item) => normalizeCatalogItem(item))
		.filter((item): item is ExternalPermissionCatalogItem => item !== null);

	const uniquePermissions = Array.from(
		new Map(permissions.map((item) => [item.key, item])).values(),
	);

	return {
		ok: true as const,
		permissions:
			uniquePermissions.length > 0
				? uniquePermissions
				: FALLBACK_EXTERNAL_PERMISSIONS,
	};
}

export async function createExternalUser(
	operatorLogin: string,
	payload: {
		login: string;
		imie: string;
		nazwisko: string;
		email: string;
		permissions: string[];
		aktywny: boolean;
		frontendInviteUrl: string;
	},
) {
	const response = await fetch("/api/admin/users/external", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || `Nie udało się utworzyć użytkownika zewnętrznego (${response.status}).`,
		};
	}

	const data = (await response.json()) as {
		invite?: {
			expiresAt?: unknown;
			delivery?: unknown;
			inviteLink?: unknown;
		};
	};

	return {
		ok: true as const,
		invite: {
			expiresAt:
				typeof data.invite?.expiresAt === "string" ? data.invite.expiresAt : "",
			delivery: data.invite?.delivery === "smtp" ? "smtp" : "log",
			inviteLink:
				typeof data.invite?.inviteLink === "string" ? data.invite.inviteLink : undefined,
		},
	};
}

export async function fetchExternalUserPermissions(
	operatorLogin: string,
	userId: number,
) {
	const response = await fetch(`/api/admin/users/${userId}/permissions`, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || `Nie udało się pobrać uprawnień użytkownika (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const permissions = extractPermissionsFromResponse(payload);

	return { ok: true as const, permissions };
}

export async function updateExternalUserPermissions(
	operatorLogin: string,
	userId: number,
	permissions: string[],
) {
	const response = await fetch(`/api/admin/users/${userId}/permissions`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({ permissions }),
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || `Nie udało się zapisać uprawnień (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const, status: response.status };
}

export async function updateExternalUserStatus(
	operatorLogin: string,
	user: ExternalUser,
	aktywny: boolean,
) {
	if (!user.rolaId) {
		return {
			ok: false as const,
			error:
				"Brakuje identyfikatora roli użytkownika zewnętrznego. Odśwież listę i spróbuj ponownie.",
		};
	}

	const response = await fetch(`/api/admin/users/${user.id}`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			login: user.login,
			imie: user.imie,
			nazwisko: user.nazwisko,
			email: user.email,
			rolaId: user.rolaId,
			zespolId: user.zespolId,
			aktywny,
		}),
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail ||
				`Nie udało się zmienić statusu aktywności użytkownika (${response.status}).`,
		};
	}

	return { ok: true as const };
}
