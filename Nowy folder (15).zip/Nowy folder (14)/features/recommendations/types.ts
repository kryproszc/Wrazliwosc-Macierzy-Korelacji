export type RecommendationRead = {
	id: number;
	lp: number;
	kodZalecenia?: string | null;
	canEdit: boolean;
	inspectionId: number | null;
	inspectionLp?: number | null;
	inspectionKod?: string | null;
	kodInspekcji?: string | null;
	pozycja: number;
	nazwaPodmiotu: string;
	nazwaPodmiotuSkrocona: string | null;
	dataZalecen: string | null;
	terminyWykonaniaZalecenList: string[];
	// Legacy fields kept for backward compatibility with older backend responses.
	terminWykonaniaZalecen: string | null;
	status: string | null;
	statusSkrocona: string | null;
	komentarz: string | null;
	dataZalecenList: string[];
	dataAkceptacjiNotyWeryfikacjiList: string[];
	brakTerminowWykonaniaZalecen?: boolean | null;
	brakDatAkceptacjiNotyWeryfikacji?: boolean | null;
	utworzonoO: string | null;
	zaktualizowanoO: string | null;
};

export type RecommendationListResponse = {
	items: RecommendationRead[];
	total: number;
};

export type RecommendationWrite = {
	inspectionId: number | null;
	pozycja: number;
	nazwaPodmiotu: string;
	dataZalecen: string | null;
	terminyWykonaniaZalecenList: string[];
	brakTerminowWykonaniaZalecen: boolean;
	brakDatAkceptacjiNotyWeryfikacji: boolean;
	// Legacy fields kept temporarily for backend compatibility.
	terminWykonaniaZalecen: string | null;
	status: string | null;
	komentarz: string | null;
	dataZalecenList: string[];
	dataAkceptacjiNotyWeryfikacjiList: string[];
};

export type RecommendationFilters = {
	inspectionId?: number;
	status?: string;
	nazwaPodmiotu?: string;
	sortBy?:
		| "id"
		| "pozycja"
		| "terminWykonaniaZalecen"
		| "utworzonoO"
		| "zaktualizowanoO";
	sortOrder?: "asc" | "desc";
};
