export type SanctionRequestRead = {
	id: number;
	lp: number;
	kodSankcji?: string | null;
	canEdit: boolean;
	inspectionId: number | null;
	inspectionLp?: number | null;
	inspectionKod?: string | null;
	kodInspekcji?: string | null;
	nazwaPodmiotuObjetegoInspekcja: string | null;
	nazwaPodmiotuObjetegoInspekcjaSkrocona: string | null;
	nazwaPodmiotuObjetegoSankcjaList: string[];
	nazwaPodmiotuObjetegoSankcjaListSkrocona: string[];
	dataWniosku: string | null;
	wniosekDo: string | null;
	wniosekDoSkrocona: string | null;
	sankcjaList: string[];
	sankcjaListSkrocona: string[];
	podstawaPrawnaSankcjiList: string[];
	podstawaPrawnaSankcjiListSkrocona: string[];
	naruszeniaSkutkujaceSankcjaList: string[];
	naruszeniaSkutkujaceSankcjaListSkrocona: string[];
	czyMamyInformacjeOWszczeciuPostepowania: string | null;
	czyMamyInformacjeOWszczeciuPostepowaniaSkrocona: string | null;
	rozstrzygniecie: string | null;
	rozstrzygniecieSkrocona: string | null;
	komentarz: string | null;
	utworzonoO: string | null;
	zaktualizowanoO: string | null;
};

export type SanctionRequestListResponse = {
	items: SanctionRequestRead[];
	total: number;
};

export type SanctionRequestWrite = {
	inspectionId: number | null;
	nazwaPodmiotuObjetegoInspekcja: string | null;
	nazwaPodmiotuObjetegoSankcjaList: string[];
	dataWniosku: string | null;
	wniosekDo: string | null;
	sankcjaList: string[];
	podstawaPrawnaSankcjiList: string[];
	naruszeniaSkutkujaceSankcjaList: string[];
	czyMamyInformacjeOWszczeciuPostepowania: string | null;
	rozstrzygniecie: string | null;
	komentarz: string | null;
};

export type SanctionRequestFilters = {
	inspectionId?: number;
	sortBy?: "id" | "lp" | "dataWniosku" | "utworzonoO" | "zaktualizowanoO";
	sortOrder?: "asc" | "desc";
};
