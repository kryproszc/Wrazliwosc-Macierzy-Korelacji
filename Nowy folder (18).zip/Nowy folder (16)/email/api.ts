import type {
	EmailInspection,
	EmailSendHistoryItem,
	EmailSendHistoryStatus,
	EmailTemplate,
	EmailTemplateRenderPreview,
	EmailTemplateVariableDefinition,
	EmailTemplateVariableType,
	EmailRecipientsPreview,
	EmailRecipientPreviewItem,
	EmailUser,
	PreviewEmailRecipientsPayload,
	PreviewTemplateEmailPayload,
	SendEmailPayload,
	SendTemplateEmailPayload,
} from "@/features/email/types";

type ApiErrorResult = {
	ok: false;
	error: string;
	status: number;
};

function buildHeaders(operatorLogin: string) {
	return {
		"Content-Type": "application/json",
		"X-Operator-Login": operatorLogin,
	};
}

async function readApiError(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown; message?: unknown };
		if (typeof payload.detail === "string") {
			return payload.detail;
		}

		if (typeof payload.message === "string") {
			return payload.message;
		}

		if (Array.isArray(payload.detail)) {
			return payload.detail
				.map((item) => {
					if (!item || typeof item !== "object") {
						return "";
					}

					const detail = (item as Record<string, unknown>).msg;
					return typeof detail === "string" ? detail : "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

function toErrorMessage(status: number, fallback: string, detail: string) {
	if (detail) {
		return detail;
	}

	if (status === 403) {
		return "Brak uprawnień do tej operacji.";
	}

	if (status === 404) {
		return "Nie znaleziono wskazanego zasobu.";
	}

	if (status === 422) {
		return "Nieprawidłowe dane wejściowe (422).";
	}

	if (status === 500) {
		return "Błąd serwera. Spróbuj ponownie.";
	}

	return `${fallback} (${status}).`;
}

async function toErrorResult(
	response: Response,
	fallback: string,
): Promise<ApiErrorResult> {
	const detail = await readApiError(response);
	return {
		ok: false,
		error: toErrorMessage(response.status, fallback, detail),
		status: response.status,
	};
}

function parseEmailUser(item: unknown): EmailUser | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id = typeof source.id === "number" ? source.id : null;
	const login = typeof source.login === "string" ? source.login.trim() : "";
	const email =
		typeof source.email === "string"
			? source.email.trim()
			: typeof source.mail === "string"
				? source.mail.trim()
				: "";
	const displayName =
		typeof source.displayName === "string"
			? source.displayName.trim()
			: typeof source.fullName === "string"
				? source.fullName.trim()
				: `${typeof source.imie === "string" ? source.imie.trim() : ""} ${typeof source.nazwisko === "string" ? source.nazwisko.trim() : ""}`.trim();

	if (!id || !email) {
		return null;
	}

	return {
		id,
		login,
		email,
		displayName: displayName || login || email,
	};
}

function parseInspection(item: unknown): EmailInspection | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id =
		typeof source.id === "string"
			? source.id.trim()
			: typeof source.id === "number"
				? String(source.id)
				: "";
	const code =
		typeof source.code === "string"
			? source.code.trim()
			: typeof source.inspectionCode === "string"
				? source.inspectionCode.trim()
				: "";
	const label =
		typeof source.label === "string"
			? source.label.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: code || id;

	if (!id) {
		return null;
	}

	return {
		id,
		label: code ? `${code}${label && label !== code ? ` - ${label}` : ""}` : label,
	};
}

function parsePreviewItem(item: unknown): EmailRecipientPreviewItem | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const email = typeof source.email === "string" ? source.email.trim() : "";
	if (!email) {
		return null;
	}

	const userId = typeof source.userId === "number" ? source.userId : null;
	const displayName =
		typeof source.displayName === "string"
			? source.displayName.trim()
			: typeof source.name === "string"
				? source.name.trim()
				: email;
	const sourceLabel =
		typeof source.source === "string"
			? source.source.trim()
			: typeof source.origin === "string"
				? source.origin.trim()
				: "";

	return {
		userId,
		displayName: displayName || email,
		email,
		source: sourceLabel,
	};
}

function parseBoolean(value: unknown, fallback: boolean) {
	if (typeof value === "boolean") {
		return value;
	}

	if (typeof value === "number") {
		return value !== 0;
	}

	if (typeof value === "string") {
		const normalized = value.trim().toLowerCase();
		if (["1", "true", "yes", "tak"].includes(normalized)) {
			return true;
		}
		if (["0", "false", "no", "nie"].includes(normalized)) {
			return false;
		}
	}

	return fallback;
}

function parseNonNegativeInteger(value: unknown, fallback: number) {
	if (typeof value === "number" && Number.isFinite(value)) {
		return Math.max(0, Math.trunc(value));
	}

	if (typeof value === "string") {
		const parsed = Number(value.trim());
		if (Number.isFinite(parsed)) {
			return Math.max(0, Math.trunc(parsed));
		}
	}

	return fallback;
}

function parseTemplateVariableType(value: unknown): EmailTemplateVariableType {
	if (value === "date" || value === "time" || value === "datetime" || value === "text") {
		return value;
	}

	return "text";
}

function parseTemplateVariable(item: unknown): EmailTemplateVariableDefinition | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const key = typeof source.key === "string" ? source.key.trim() : "";
	if (!key) {
		return null;
	}

	const label = typeof source.label === "string" ? source.label.trim() : key;
	const helpText = typeof source.helpText === "string" ? source.helpText.trim() : "";

	return {
		key,
		label,
		type: parseTemplateVariableType(source.type),
		required: parseBoolean(source.required, true),
		helpText,
	};
}

function parseTemplate(item: unknown): EmailTemplate | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id = typeof source.id === "string" ? source.id.trim() : "";
	if (!id) {
		return null;
	}

	const recipientModeRaw =
		typeof source.recipientMode === "string"
			? source.recipientMode.trim()
			: typeof source.defaultRecipientMode === "string"
				? source.defaultRecipientMode.trim()
				: "selected_users";
	const recipientMode =
		recipientModeRaw === "inspection_members" || recipientModeRaw === "all_users"
			? recipientModeRaw
			: "selected_users";

	const selectedUserIdsSource =
		Array.isArray(source.selectedUserIds) && source.selectedUserIds.length > 0
			? source.selectedUserIds
			: Array.isArray(source.defaultSelectedUserIds)
				? source.defaultSelectedUserIds
				: [];
	const selectedUserIds = selectedUserIdsSource
		.map((entry) => parseNonNegativeInteger(entry, -1))
		.filter((value) => value > 0);

	const inspectionId =
		typeof source.inspectionId === "string"
			? source.inspectionId.trim()
			: typeof source.defaultInspectionId === "string"
				? source.defaultInspectionId.trim()
				: "";

	const variablesSource = Array.isArray(source.variables) ? source.variables : [];
	const variables = variablesSource
		.map((entry) => parseTemplateVariable(entry))
		.filter((entry): entry is EmailTemplateVariableDefinition => entry !== null);

	return {
		id,
		name: typeof source.name === "string" ? source.name.trim() : id,
		description: typeof source.description === "string" ? source.description.trim() : "",
		subjectTemplate:
			typeof source.subjectTemplate === "string"
				? source.subjectTemplate
				: typeof source.subject === "string"
					? source.subject
					: "",
		bodyTemplate:
			typeof source.bodyTemplate === "string"
				? source.bodyTemplate
				: typeof source.body === "string"
					? source.body
					: "",
		variables,
		recipientPreset: {
			recipientMode,
			selectedUserIds,
			inspectionId,
			label:
				typeof source.recipientLabel === "string"
					? source.recipientLabel.trim()
					: typeof source.defaultRecipientLabel === "string"
						? source.defaultRecipientLabel.trim()
						: "",
		},
		isActive: parseBoolean(source.isActive, true),
		updatedAt: typeof source.updatedAt === "string" ? source.updatedAt.trim() : "",
	};
}

function parseHistoryStatus(value: unknown): EmailSendHistoryStatus {
	if (
		value === "queued" ||
		value === "processing" ||
		value === "sent" ||
		value === "partial" ||
		value === "failed"
	) {
		return value;
	}

	return "queued";
}

function parseHistoryRecipients(source: Record<string, unknown>) {
	const rawRecipientEntries: unknown[] = [];

	const recipientsDirect = source.recipients;
	if (Array.isArray(recipientsDirect)) {
		rawRecipientEntries.push(...recipientsDirect);
	} else if (recipientsDirect && typeof recipientsDirect === "object") {
		const nestedItems = (recipientsDirect as Record<string, unknown>).items;
		if (Array.isArray(nestedItems)) {
			rawRecipientEntries.push(...nestedItems);
		}
	}

	const recipientPreview = source.recipientPreview;
	if (Array.isArray(recipientPreview)) {
		rawRecipientEntries.push(...recipientPreview);
	}

	const recipientsPreview = source.recipientsPreview;
	if (Array.isArray(recipientsPreview)) {
		rawRecipientEntries.push(...recipientsPreview);
	} else if (recipientsPreview && typeof recipientsPreview === "object") {
		const nestedItems = (recipientsPreview as Record<string, unknown>).items;
		if (Array.isArray(nestedItems)) {
			rawRecipientEntries.push(...nestedItems);
		}
	}

	const parsedRecipients = rawRecipientEntries
		.map((entry) => parsePreviewItem(entry))
		.filter((entry): entry is EmailRecipientPreviewItem => entry !== null);

	if (parsedRecipients.length > 0) {
		const deduplicated = new Map<string, EmailRecipientPreviewItem>();
		for (const recipient of parsedRecipients) {
			const key = `${recipient.email.toLowerCase()}|${recipient.displayName.toLowerCase()}`;
			if (!deduplicated.has(key)) {
				deduplicated.set(key, recipient);
			}
		}

		return [...deduplicated.values()];
	}

	const rawEmails =
		typeof source.recipientEmails === "string"
			? source.recipientEmails
			: typeof source.recipientsEmails === "string"
				? source.recipientsEmails
				: typeof source.emails === "string"
					? source.emails
					: "";

	if (!rawEmails.trim()) {
		return [];
	}

	return rawEmails
		.split(/[;,\n]/)
		.map((entry) => entry.trim())
		.filter(Boolean)
		.map((email) => ({
			userId: null,
			displayName: email,
			email,
			source: "",
		}));
}

function parseHistoryItem(item: unknown): EmailSendHistoryItem | null {
	if (!item || typeof item !== "object") {
		return null;
	}

	const source = item as Record<string, unknown>;
	const id =
		typeof source.id === "string"
			? source.id.trim()
			: typeof source.messageId === "string"
				? source.messageId.trim()
				: "";

	if (!id) {
		return null;
	}

	return {
		id,
		templateId:
			typeof source.templateId === "string" ? source.templateId.trim() : "",
		templateName:
			typeof source.templateName === "string" ? source.templateName.trim() : "Wiadomość ręczna",
		subject: typeof source.subject === "string" ? source.subject.trim() : "",
		body:
			typeof source.body === "string"
				? source.body
				: typeof source.messageBody === "string"
					? source.messageBody
					: typeof source.content === "string"
						? source.content
						: typeof source.tresc === "string"
							? source.tresc
							: "",
		recipientCount: parseNonNegativeInteger(source.recipientCount, 0),
		recipients: parseHistoryRecipients(source),
		status: parseHistoryStatus(source.status),
		requestedAt:
			typeof source.requestedAt === "string"
				? source.requestedAt.trim()
				: typeof source.createdAt === "string"
					? source.createdAt.trim()
					: "",
		requestedBy:
			typeof source.requestedBy === "string"
				? source.requestedBy.trim()
				: typeof source.operatorLogin === "string"
					? source.operatorLogin.trim()
					: "",
		jobId:
			typeof source.jobId === "string"
				? source.jobId.trim()
				: typeof source.queueId === "string"
					? source.queueId.trim()
					: "",
		errorSummary:
			typeof source.errorSummary === "string"
				? source.errorSummary.trim()
				: typeof source.error === "string"
					? source.error.trim()
					: "",
	};
}

export async function fetchEmailUsers(operatorLogin: string, query?: string) {
	const params = new URLSearchParams();
	if (query?.trim()) {
		params.set("q", query.trim());
	}

	const response = await fetch(
		`/api/admin/email/users${params.toString() ? `?${params.toString()}` : ""}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać użytkowników");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseEmailUser(item))
				.filter((item): item is EmailUser => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchEmailInspections(operatorLogin: string, query?: string) {
	const params = new URLSearchParams();
	if (query?.trim()) {
		params.set("q", query.trim());
	}

	const response = await fetch(
		`/api/admin/email/inspections${params.toString() ? `?${params.toString()}` : ""}`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać listy inspekcji");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseInspection(item))
				.filter((item): item is EmailInspection => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function fetchEmailInspectionMembers(
	operatorLogin: string,
	inspectionId: string,
) {
	const response = await fetch(
		`/api/admin/email/inspections/${encodeURIComponent(inspectionId)}/members`,
		{
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		},
	);

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać członków inspekcji");
	}

	const payload = (await response.json()) as unknown;
	const items = Array.isArray(payload)
		? payload
				.map((item) => parseEmailUser(item))
				.filter((item): item is EmailUser => item !== null)
		: [];

	return { ok: true as const, items };
}

export async function previewEmailRecipients(
	operatorLogin: string,
	payload: PreviewEmailRecipientsPayload,
) {
	const response = await fetch("/api/admin/email/recipients/preview", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać podglądu odbiorców");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const rawItems = Array.isArray(source.items) ? source.items : [];
	const items = rawItems
		.map((item) => parsePreviewItem(item))
		.filter((item): item is EmailRecipientPreviewItem => item !== null);
	const total =
		typeof source.total === "number" && Number.isFinite(source.total)
			? Math.max(0, Math.trunc(source.total))
			: items.length;

	const preview: EmailRecipientsPreview = {
		total,
		items,
	};

	return { ok: true as const, preview };
}

export async function sendEmailMessage(
	operatorLogin: string,
	payload: SendEmailPayload,
) {
	const response = await fetch("/api/admin/email/send", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się wysłać wiadomości");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const jobId =
		typeof source.jobId === "string"
			? source.jobId
			: typeof source.id === "string"
				? source.id
				: "";

	return { ok: true as const, jobId };
}

export async function fetchEmailTemplates(operatorLogin: string) {
	const response = await fetch("/api/admin/email/templates", {
		method: "GET",
		headers: buildHeaders(operatorLogin),
		cache: "no-store",
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać szablonów e-mail");
	}

	const payload = (await response.json()) as unknown;
	const source =
		payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
	const rawItems = Array.isArray(source.items)
		? source.items
		: Array.isArray(payload)
			? payload
			: [];
	const items = rawItems
		.map((item) => parseTemplate(item))
		.filter((item): item is EmailTemplate => item !== null);

	return { ok: true as const, items };
}

export async function previewTemplateEmail(
	operatorLogin: string,
	payload: PreviewTemplateEmailPayload,
) {
	const response = await fetch("/api/admin/email/templates/preview", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się przygotować podglądu szablonu");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const recipientsRaw =
		source.recipients && typeof source.recipients === "object"
			? (source.recipients as Record<string, unknown>)
			: source;
	const recipientItemsRaw = Array.isArray(recipientsRaw.items) ? recipientsRaw.items : [];
	const recipientItems = recipientItemsRaw
		.map((item) => parsePreviewItem(item))
		.filter((item): item is EmailRecipientPreviewItem => item !== null);
	const recipientTotal = parseNonNegativeInteger(recipientsRaw.total, recipientItems.length);

	const preview: EmailTemplateRenderPreview = {
		subject:
			typeof source.subject === "string"
				? source.subject
				: typeof source.renderedSubject === "string"
					? source.renderedSubject
					: "",
		body:
			typeof source.body === "string"
				? source.body
				: typeof source.renderedBody === "string"
					? source.renderedBody
					: "",
		recipients: {
			total: recipientTotal,
			items: recipientItems,
		},
	};

	return { ok: true as const, preview };
}

export async function sendTemplateEmail(
	operatorLogin: string,
	payload: SendTemplateEmailPayload,
) {
	const response = await fetch("/api/admin/email/templates/send", {
		method: "POST",
		headers: buildHeaders(operatorLogin),
		body: JSON.stringify(payload),
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się wysłać wiadomości z szablonu");
	}

	const raw = (await response.json()) as unknown;
	const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	const jobId =
		typeof source.jobId === "string"
			? source.jobId.trim()
			: typeof source.id === "string"
				? source.id.trim()
				: "";

	return { ok: true as const, jobId };
}

export async function fetchEmailSendHistory(operatorLogin: string, limit = 100) {
	const params = new URLSearchParams();
	params.set("limit", String(Math.max(1, Math.min(500, Math.trunc(limit)))));

	const response = await fetch(`/api/admin/email/history?${params.toString()}`, {
		method: "GET",
		headers: buildHeaders(operatorLogin),
		cache: "no-store",
	});

	if (!response.ok) {
		return toErrorResult(response, "Nie udało się pobrać historii wysyłek");
	}

	const payload = (await response.json()) as unknown;
	const source =
		payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
	const rawItems = Array.isArray(source.items)
		? source.items
		: Array.isArray(payload)
			? payload
			: [];
	const items = rawItems
		.map((item) => parseHistoryItem(item))
		.filter((item): item is EmailSendHistoryItem => item !== null);

	return { ok: true as const, items };
}
