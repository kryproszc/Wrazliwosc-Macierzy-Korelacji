"use client";

import { Mail, RefreshCw, Send } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
	Alert,
	Box,
	Button,
	Card,
	CardContent,
	Checkbox,
	Chip,
	CircularProgress,
	Divider,
	FormControlLabel,
	Radio,
	RadioGroup,
	Stack,
	Tab,
	Tabs,
	TextField,
	Typography,
} from "@mui/material";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
	fetchEmailInspectionMembers,
	fetchEmailInspections,
	fetchEmailSendHistory,
	fetchEmailUsers,
	sendEmailMessage,
} from "@/features/email/api";
import type {
	EmailInspection,
	EmailRecipientMode,
	EmailSendHistoryItem,
	EmailUser,
} from "@/features/email/types";
import { EntitySuccessModal } from "@/shared/components/EntitySuccessModal";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";

type EmailPanelProps = {
	operatorLogin: string;
	authRole: AuthRole;
};

type EmailTab = "compose" | "history";

const RECIPIENT_MODE_OPTIONS: Array<{
	id: EmailRecipientMode;
	label: string;
	description: string;
}> = [
	{
		id: "selected_users",
		label: "Wybrani użytkownicy",
		description: "Ręczny wybór konkretnych osób z listy użytkowników.",
	},
	{
		id: "inspection_members",
		label: "Użytkownicy z inspekcji",
		description: "Automatyczny dobór odbiorców z wybranej inspekcji.",
	},
	{
		id: "all_users",
		label: "Wszyscy z bazy",
		description: "Wysłanie do wszystkich aktywnych adresów w bazie.",
	},
];

const STATUS_LABELS: Record<EmailSendHistoryItem["status"], string> = {
	queued: "W kolejce",
	processing: "W trakcie",
	sent: "Wysłano",
	partial: "Częściowo",
	failed: "Błąd",
};

const STATUS_BADGE_CLASSES: Record<EmailSendHistoryItem["status"], string> = {
	queued: "bg-slate-200 text-slate-700",
	processing: "bg-blue-100 text-blue-800",
	sent: "bg-emerald-100 text-emerald-800",
	partial: "bg-amber-100 text-amber-800",
	failed: "bg-rose-100 text-rose-800",
};

function buildUserLabel(user: EmailUser) {
	const details = [user.login, user.email].filter(Boolean).join(" | ");
	return details ? `${user.displayName} (${details})` : user.displayName;
}

function formatDateTimeLabel(raw: string) {
	if (!raw) {
		return "-";
	}

	const parsed = new Date(raw);
	if (Number.isNaN(parsed.getTime())) {
		return raw;
	}

	return parsed.toLocaleString("pl-PL", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
	});
}

export function EmailPanel({ operatorLogin, authRole }: EmailPanelProps) {
	const [activeTab, setActiveTab] = useState<EmailTab>("compose");

	const [isLoading, setIsLoading] = useState(true);
	const [isSending, setIsSending] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [isSendSuccessModalOpen, setIsSendSuccessModalOpen] = useState(false);

	const [recipientMode, setRecipientMode] =
		useState<EmailRecipientMode>("selected_users");
	const [users, setUsers] = useState<EmailUser[]>([]);
	const [inspections, setInspections] = useState<EmailInspection[]>([]);
	const [inspectionMembers, setInspectionMembers] = useState<EmailUser[]>([]);
	const [selectedUserIds, setSelectedUserIds] = useState<number[]>([]);
	const [selectedInspectionId, setSelectedInspectionId] = useState("");
	const [subject, setSubject] = useState("");
	const [body, setBody] = useState("");
	const [formError, setFormError] = useState<string | null>(null);
	const [usersSearch, setUsersSearch] = useState("");

	const [historyItems, setHistoryItems] = useState<EmailSendHistoryItem[]>([]);
	const [historyError, setHistoryError] = useState<string | null>(null);
	const [isHistoryLoading, setIsHistoryLoading] = useState(false);
	const [isAllUsersConfirmModalOpen, setIsAllUsersConfirmModalOpen] =
		useState(false);
	const [historyPreviewItem, setHistoryPreviewItem] =
		useState<EmailSendHistoryItem | null>(null);

	const userById = useMemo(
		() => new Map(users.map((user) => [user.id, user])),
		[users],
	);

	const selectedUsersLabel = useMemo(() => {
		if (selectedUserIds.length === 0) {
			return "Brak wybranych użytkowników";
		}

		if (selectedUserIds.length === 1) {
			const firstSelectedId = selectedUserIds[0];
			if (firstSelectedId === undefined) {
				return "1 użytkownik";
			}

			const user = userById.get(firstSelectedId);
			return user ? buildUserLabel(user) : "1 użytkownik";
		}

		return `${selectedUserIds.length} wybranych użytkowników`;
	}, [selectedUserIds, userById]);

	const filteredUsers = useMemo(() => {
		const query = usersSearch.trim().toLowerCase();
		if (!query) {
			return users;
		}

		return users.filter((user) => {
			const searchable = `${user.displayName} ${user.login} ${user.email}`.toLowerCase();
			return searchable.includes(query);
		});
	}, [users, usersSearch]);

	const validateComposeForm = useCallback(() => {
		if (!subject.trim()) {
			return "Temat wiadomości jest wymagany.";
		}

		if (!body.trim()) {
			return "Treść wiadomości jest wymagana.";
		}

		if (recipientMode === "selected_users" && selectedUserIds.length === 0) {
			return "Wybierz co najmniej jednego użytkownika.";
		}

		if (recipientMode === "inspection_members" && !selectedInspectionId.trim()) {
			return "Wybierz inspekcję dla odbiorców.";
		}

		return null;
	}, [body, recipientMode, selectedInspectionId, selectedUserIds.length, subject]);

	const buildRecipientsPayload = useCallback(() => {
		if (recipientMode === "selected_users") {
			return {
				recipientMode,
				selectedUserIds,
			};
		}

		if (recipientMode === "inspection_members") {
			return {
				recipientMode,
				inspectionId: selectedInspectionId,
			};
		}

		return {
			recipientMode,
		};
	}, [recipientMode, selectedInspectionId, selectedUserIds]);

	const loadHistory = useCallback(async () => {
		setIsHistoryLoading(true);
		setHistoryError(null);

		const response = await fetchEmailSendHistory(operatorLogin, 100);
		if (!response.ok) {
			setHistoryError(response.error);
			setHistoryItems([]);
			setIsHistoryLoading(false);
			return;
		}

		setHistoryItems(response.items);
		setIsHistoryLoading(false);
	}, [operatorLogin]);

	useEffect(() => {
		const loadInitial = async () => {
			setIsLoading(true);
			setError(null);

			const [usersResponse, inspectionsResponse] = await Promise.all([
				fetchEmailUsers(operatorLogin),
				fetchEmailInspections(operatorLogin),
			]);

			if (!usersResponse.ok) {
				setError(usersResponse.error);
				setUsers([]);
			} else {
				setUsers(usersResponse.items);
			}

			if (!inspectionsResponse.ok) {
				setError((previous) => previous ?? inspectionsResponse.error);
				setInspections([]);
			} else {
				setInspections(inspectionsResponse.items);
			}

			setIsLoading(false);
		};

		void loadInitial();
	}, [operatorLogin]);

	useEffect(() => {
		if (recipientMode !== "inspection_members" || !selectedInspectionId.trim()) {
			setInspectionMembers([]);
			return;
		}

		let isCancelled = false;
		const loadMembers = async () => {
			const response = await fetchEmailInspectionMembers(
				operatorLogin,
				selectedInspectionId,
			);

			if (isCancelled) {
				return;
			}

			if (!response.ok) {
				setInspectionMembers([]);
				setError((previous) => previous ?? response.error);
				return;
			}

			setInspectionMembers(response.items);
		};

		void loadMembers();

		return () => {
			isCancelled = true;
		};
	}, [operatorLogin, recipientMode, selectedInspectionId]);

	useEffect(() => {
		if (activeTab !== "history") {
			return;
		}

		void loadHistory();
	}, [activeTab, loadHistory]);

	const handleToggleUser = (userId: number) => {
		setSelectedUserIds((previous) => {
			if (previous.includes(userId)) {
				return previous.filter((id) => id !== userId);
			}

			return [...previous, userId];
		});
	};

	const handleSendRequest = async () => {
		setIsSending(true);
		const response = await sendEmailMessage(operatorLogin, {
			...buildRecipientsPayload(),
			subject: subject.trim(),
			body: body.trim(),
		});
		setIsSending(false);

		if (!response.ok) {
			setError(response.error);
			return;
		}

		setIsSendSuccessModalOpen(true);
	};

	const handleSendEmail = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		setFormError(null);
		setError(null);
		setIsSendSuccessModalOpen(false);

		const validationError = validateComposeForm();
		if (validationError) {
			setFormError(validationError);
			return;
		}

		if (recipientMode === "all_users") {
			setIsAllUsersConfirmModalOpen(true);
			return;
		}

		await handleSendRequest();
	};

	const handleConfirmSendToAllUsers = async () => {
		setIsAllUsersConfirmModalOpen(false);
		await handleSendRequest();
	};

	if (authRole !== "director") {
		return (
			<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
				<p className="rounded-lg border border-amber-300/45 bg-amber-950/30 px-3 py-2 text-amber-200 text-sm">
					Tylko dyrektor może wysyłać wiadomości e-mail.
				</p>
			</section>
		);
	}

	if (isLoading) {
		return (
			<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-6">
				<p className="text-slate-300 text-sm">Ładowanie panelu e-mail...</p>
			</section>
		);
	}

	return (
		<section className="relative flex h-full min-h-0 flex-col rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
			<Stack spacing={2.5} className="min-h-0 flex-1">
				<Box className="flex items-center gap-2 border-slate-700/70 border-b pb-3">
					<Mail size={16} className="text-slate-200" />
					<Typography variant="h6" sx={{ color: "#e2e8f0", fontWeight: 700 }}>
						E-mail
					</Typography>
				</Box>

				<Tabs
					value={activeTab}
					onChange={(_, next: EmailTab) => setActiveTab(next)}
					textColor="inherit"
					indicatorColor="primary"
					sx={{
						".MuiTab-root": { color: "#cbd5e1", textTransform: "none", fontWeight: 600 },
						".Mui-selected": { color: "#f8fafc" },
					}}
				>
					<Tab value="compose" label="Nowa wiadomość" />
					<Tab value="history" label="Historia wysłanych wiadomości" />
				</Tabs>

				{activeTab === "compose" ? (
					<form className="min-h-0 flex-1" onSubmit={handleSendEmail}>
						<Stack spacing={2.5} className="min-h-0 h-full">
							{error ? <Alert severity="error">{error}</Alert> : null}

							<Box
								sx={{
									display: "grid",
									gap: 16,
									gridTemplateColumns: {
										xs: "minmax(0, 1fr)",
										xl: "minmax(0, 1.05fr) minmax(0, 1.2fr)",
									},
								}}
							>
								<Card variant="outlined" sx={{ borderRadius: 3 }}>
									<CardContent>
										<Stack spacing={2}>
											<Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
												Odbiorcy
											</Typography>

											<RadioGroup
												name="recipient-mode"
												value={recipientMode}
												onChange={(event) => {
													setRecipientMode(event.target.value as EmailRecipientMode);
												}}
											>
												<Stack spacing={1}>
													{RECIPIENT_MODE_OPTIONS.map((option) => (
														<Box
															key={option.id}
															sx={{
																border: "1px solid",
																borderColor:
																	recipientMode === option.id ? "primary.main" : "divider",
																borderRadius: 2,
																px: 1.25,
																py: 1,
																bgcolor:
																	recipientMode === option.id ? "action.selected" : "background.paper",
															}}
														>
															<FormControlLabel
																value={option.id}
																control={<Radio size="small" />}
																label={
																	<Box>
																		<Typography variant="body2" sx={{ fontWeight: 600 }}>
																			{option.label}
																		</Typography>
																		<Typography variant="caption" color="text.secondary">
																			{option.description}
																		</Typography>
																	</Box>
																}
																sx={{ m: 0, alignItems: "flex-start" }}
															/>
														</Box>
													))}
												</Stack>
											</RadioGroup>

											{recipientMode === "selected_users" ? (
												<Stack spacing={1.25} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
													<TextField
														size="small"
														label="Szukaj użytkownika"
														value={usersSearch}
														onChange={(event) => setUsersSearch(event.target.value)}
														placeholder="Nazwisko, login lub e-mail"
													/>
													<Box
														sx={{
															maxHeight: 240,
															overflowY: "auto",
															border: "1px solid",
															borderColor: "divider",
															borderRadius: 2,
															p: 1,
															bgcolor: "#f8fafc",
														}}
													>
														{filteredUsers.length === 0 ? (
															<Typography variant="caption" color="text.secondary">
																Brak użytkowników.
															</Typography>
														) : (
															<Stack spacing={0.25}>
																{filteredUsers.map((user) => {
																	const checked = selectedUserIds.includes(user.id);
																	return (
																		<FormControlLabel
																			key={user.id}
																			control={
																				<Checkbox
																					size="small"
																					checked={checked}
																					onChange={() => handleToggleUser(user.id)}
																				/>
																			}
																			label={
																				<Typography variant="caption" sx={{ lineHeight: 1.35 }}>
																					{buildUserLabel(user)}
																				</Typography>
																			}
																			sx={{ m: 0, width: "100%" }}
																		/>
																	);
																})}
															</Stack>
														)}
													</Box>
													<Chip
														size="small"
														variant="outlined"
														label={selectedUsersLabel}
														sx={{ alignSelf: "flex-start" }}
													/>
												</Stack>
											) : null}

											{recipientMode === "inspection_members" ? (
												<Stack spacing={1.25} sx={{ border: "1px solid", borderColor: "divider", borderRadius: 2, p: 1.5 }}>
													<SingleSelectPortalField
														label="Inspekcja"
														value={selectedInspectionId}
														options={inspections.map((inspection) => ({
															value: inspection.id,
															label: inspection.label,
														}))}
														placeholder="Wybierz inspekcję"
														onChange={(next) => {
															setSelectedInspectionId(next);
														}}
														enableSearch
														searchPlaceholder="Szukaj inspekcji..."
													/>
													<Alert severity="info" sx={{ py: 0 }}>
														Liczba członków wybranej inspekcji: {inspectionMembers.length}
													</Alert>
														<Box
															className="subtle-vertical-scroll"
															sx={{
																maxHeight: 180,
																overflowY: "auto",
																overflowX: "hidden",
																bgcolor: "background.paper",
																border: "1px solid",
																borderColor: "divider",
																borderRadius: 2,
																p: 1,
																pr: 0.75,
																scrollbarWidth: "thin",
																"&::-webkit-scrollbar": {
																	width: 6,
																},
																"&::-webkit-scrollbar-track": {
																	backgroundColor: "transparent",
																},
																"&::-webkit-scrollbar-thumb": {
																	backgroundColor: "rgba(148, 163, 184, 0.55)",
																	borderRadius: 999,
																},
																"&::-webkit-scrollbar-thumb:hover": {
																	backgroundColor: "rgba(100, 116, 139, 0.75)",
																},
															}}
														>
															{inspectionMembers.length === 0 ? (
																<Typography variant="caption" color="text.secondary">
																	Brak użytkowników w wybranej inspekcji.
																</Typography>
															) : (
																<Box
																	component="ol"
																	sx={{
																		m: 0,
																		pl: 2.5,
																		pr: 0.5,
																		"& li": { mb: 0.35 },
																		"& li:last-child": { mb: 0 },
																	}}
																>
																	{inspectionMembers.map((member) => (
																		<li key={member.id}>
																			<Typography variant="body2" sx={{ fontSize: 13, lineHeight: 1.45 }}>
																				{member.displayName}
																				{member.email ? ` (${member.email})` : ""}
																			</Typography>
																		</li>
																	))}
																</Box>
															)}
														</Box>
												</Stack>
											) : null}

										</Stack>
									</CardContent>
								</Card>

								<Card variant="outlined" sx={{ borderRadius: 3 }}>
									<CardContent>
										<Stack spacing={2}>
											<Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
												Treść wiadomości
											</Typography>

											<TextField
												required
												size="small"
												label="Temat wiadomości"
												value={subject}
												onChange={(event) => setSubject(event.target.value)}
											/>

											<TextField
												required
												label="Treść wiadomości"
												value={body}
												onChange={(event) => setBody(event.target.value)}
												multiline
														minRows={16}
														sx={{
															"& .MuiInputBase-input.MuiInputBase-inputMultiline": {
																resize: "vertical",
															},
														}}
											/>
										</Stack>
									</CardContent>
								</Card>
							</Box>

							{formError ? <Alert severity="error">{formError}</Alert> : null}

							<Divider sx={{ borderColor: "rgba(148, 163, 184, 0.45)" }} />

							<Box className="flex justify-end">
								<Button
									type="submit"
									disabled={isSending}
									variant="contained"
									startIcon={
										isSending ? <CircularProgress size={14} color="inherit" /> : <Send size={14} />
									}
									sx={{
										textTransform: "none",
										fontWeight: 700,
										px: 2,
										bgcolor: "#2d4d7f",
										"&:hover": { bgcolor: "#375f99" },
									}}
								>
									{isSending ? "Wysyłanie..." : "Wyślij wiadomość"}
								</Button>
							</Box>
						</Stack>
					</form>
				) : null}

			<EntitySuccessModal
				isOpen={isSendSuccessModalOpen}
				heading="Wiadomość została wysłana"
				detailsMessage=""
				onClose={() => {
					setIsSendSuccessModalOpen(false);
				}}
			/>

			{isSending ? (
				<div className="fixed inset-0 z-70 flex items-center justify-center bg-slate-950/35 backdrop-blur-[1px]">
					<div className="w-full max-w-sm rounded-2xl border border-[#43628f] bg-[#1a2f53] px-5 py-4 shadow-[0_16px_40px_rgba(2,8,23,0.45)]">
						<div className="flex items-center gap-3">
							<span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#2f4f83]">
								<span className="h-4 w-4 animate-spin rounded-full border-2 border-sky-100 border-t-transparent" />
							</span>
							<div>
								<p className="font-semibold text-slate-100 text-sm">Trwa wysyłanie wiadomości</p>
							</div>
						</div>
					</div>
				</div>
			) : null}

			{isAllUsersConfirmModalOpen ? (
				<div className="fixed inset-0 z-70 flex items-center justify-center p-4">
					<button
						type="button"
						aria-label="Zamknij potwierdzenie wysyłki do wszystkich"
						className="absolute inset-0 bg-slate-950/65"
						onClick={() => setIsAllUsersConfirmModalOpen(false)}
					/>

					<div
						role="dialog"
						aria-modal="true"
						aria-label="Potwierdzenie wysyłki wiadomości"
						className="relative z-10 w-full max-w-xl rounded-2xl border border-slate-300 bg-white p-5 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)]"
					>
						<h3 className="font-semibold text-base text-slate-900">
							Wysłać wiadomość do wszystkich?
						</h3>
						<p className="mt-2 text-slate-700 text-sm leading-6">
							Wiadomość zostanie wysłana do wszystkich aktywnych odbiorców z bazy.
							Czy chcesz kontynuować?
						</p>

						<div className="mt-5 flex items-center justify-end gap-2">
							<button
								type="button"
								onClick={() => setIsAllUsersConfirmModalOpen(false)}
								className="inline-flex h-10 items-center rounded-lg border border-slate-300 bg-white px-4 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
							>
								Anuluj
							</button>
							<button
								type="button"
								onClick={() => void handleConfirmSendToAllUsers()}
								className="inline-flex h-10 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-4 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99]"
							>
								Wyślij
							</button>
						</div>
					</div>
				</div>
			) : null}

				{activeTab === "history" ? (
					<Stack spacing={2} className="min-h-0 flex-1">
						{historyError ? <Alert severity="error">{historyError}</Alert> : null}

						<Box className="flex items-center justify-between gap-2">
							<Typography variant="subtitle1" sx={{ color: "#e2e8f0", fontWeight: 700 }}>
								Historia wysłanych wiadomości
							</Typography>
							<button
								type="button"
								onClick={() => void loadHistory()}
								disabled={isHistoryLoading}
								className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-300 bg-white px-2.5 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-60"
							>
								{isHistoryLoading ? (
									<CircularProgress size={13} color="inherit" />
								) : (
									<RefreshCw size={12} />
								)}
								Odśwież
							</button>
						</Box>

						<Box className="subtle-vertical-scroll min-h-0 flex-1 overflow-y-auto rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
							<table className="w-max min-w-full border-collapse text-slate-900 text-sm">
								<thead className="sticky top-0 z-10">
									<tr className="bg-slate-100 text-slate-800">
										<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Data</th>
										<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Temat</th>
										<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Odbiorcy</th>
										<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Status</th>
										<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Nadawca</th>
										<th className="min-w-[8rem] whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">Szczegóły</th>
									</tr>
								</thead>
								<tbody>
									{historyItems.map((item) => (
										<tr
											key={item.id}
											className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
										>
											<td className="whitespace-nowrap px-3 py-2.5">{formatDateTimeLabel(item.requestedAt)}</td>
											<td className="px-3 py-2.5">
												<div
													title={item.subject || "-"}
													className="max-w-[44rem] overflow-hidden text-ellipsis whitespace-nowrap"
												>
													{item.subject || "-"}
												</div>
											</td>
											<td className="whitespace-nowrap px-3 py-2.5">{item.recipientCount}</td>
											<td className="whitespace-nowrap px-3 py-2.5">
												<span
													className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${STATUS_BADGE_CLASSES[item.status]}`}
												>
													{STATUS_LABELS[item.status]}
												</span>
											</td>
											<td className="whitespace-nowrap px-3 py-2.5">{item.requestedBy || "-"}</td>
											<td className="min-w-[8rem] whitespace-nowrap px-3 py-2.5">
												<button
													type="button"
													onClick={() => setHistoryPreviewItem(item)}
													className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
												>
													Szczegóły
												</button>
											</td>
										</tr>
									))}

									{!isHistoryLoading && historyItems.length === 0 ? (
										<tr>
											<td colSpan={6} className="px-3 py-6 text-center text-slate-500 text-sm">
												Brak historii wysyłek.
											</td>
										</tr>
									) : null}
								</tbody>
							</table>
						</Box>
					</Stack>
				) : null}

					{historyPreviewItem ? (
						<div className="fixed inset-0 z-70 flex items-center justify-center p-4">
							<button
								type="button"
								aria-label="Zamknij podgląd historii wysyłki"
								className="absolute inset-0 bg-slate-950/65"
								onClick={() => setHistoryPreviewItem(null)}
							/>

							<div
								role="dialog"
								aria-modal="true"
								aria-label="Podgląd wysłanej wiadomości"
								className="relative z-10 flex max-h-[85vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-slate-300 bg-white p-5 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)]"
							>
								<div className="flex items-start gap-3">
									<div>
										<h3 className="font-semibold text-base text-slate-900">
											Podgląd wysłanej wiadomości
										</h3>
										<p className="mt-1 text-slate-600 text-xs">
											{formatDateTimeLabel(historyPreviewItem.requestedAt)} | {historyPreviewItem.requestedBy || "-"}
										</p>
									</div>
								</div>

								<div className="subtle-vertical-scroll mt-4 min-h-0 flex-1 overflow-y-auto pr-1">
									<div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.8fr)]">
									<div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
										<p className="font-semibold text-slate-800 text-sm">Do kogo wysłane</p>
										<p className="mt-0.5 text-slate-600 text-xs">
											Liczba odbiorców: {historyPreviewItem.recipientCount}
										</p>
										<div className="subtle-vertical-scroll mt-2 max-h-72 overflow-y-auto rounded-lg border border-slate-200 bg-white p-2">
											{historyPreviewItem.recipients.length === 0 ? (
												<div className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-slate-600 text-sm">
													API historii zwraca tylko liczbę odbiorców ({historyPreviewItem.recipientCount}) bez listy osób.
												</div>
											) : (
												<ol className="list-decimal space-y-1 pl-5 text-slate-700 text-sm">
													{historyPreviewItem.recipients.map((recipient, index) => (
														<li key={`${historyPreviewItem.id}-${recipient.email}-${index}`}>
															{recipient.displayName}
															{recipient.email ? ` (${recipient.email})` : ""}
														</li>
													))}
												</ol>
											)}
										</div>
									</div>

									<div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
										<p className="font-semibold text-slate-800 text-sm">Tytuł i treść</p>
										<div className="mt-2 rounded-lg border border-slate-200 bg-white p-3">
											<p className="font-semibold text-slate-900 text-sm">
												{historyPreviewItem.subject || "(brak tematu)"}
											</p>
											<div className="subtle-vertical-scroll mt-2 max-h-72 overflow-y-auto">
												{historyPreviewItem.body ? (
													<p className="whitespace-pre-wrap text-slate-700 text-sm leading-6">
														{historyPreviewItem.body}
													</p>
												) : (
													<div className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-slate-600 text-sm">
														API historii nie zwraca treści wiadomości dla tego wpisu.
													</div>
												)}
											</div>
										</div>
									</div>
									</div>
								</div>

								<div className="mt-4 flex items-center justify-end border-slate-200 border-t pt-3">
									<button
										type="button"
										onClick={() => setHistoryPreviewItem(null)}
										className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-4 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
									>
										Zamknij
									</button>
								</div>
							</div>
						</div>
					) : null}
			</Stack>
		</section>
	);
}