export type EmailRecipientMode = "selected_users" | "inspection_members" | "all_users";

export type EmailUser = {
	id: number;
	login: string;
	displayName: string;
	email: string;
};

export type EmailInspection = {
	id: string;
	label: string;
};

export type EmailRecipientPreviewItem = {
	userId: number | null;
	displayName: string;
	email: string;
	source: string;
};

export type EmailRecipientsPreview = {
	total: number;
	items: EmailRecipientPreviewItem[];
};

export type PreviewEmailRecipientsPayload = {
	recipientMode: EmailRecipientMode;
	selectedUserIds?: number[];
	inspectionId?: string;
};

export type SendEmailPayload = PreviewEmailRecipientsPayload & {
	subject: string;
	body: string;
};

export type EmailTemplateVariableType = "text" | "date" | "time" | "datetime";

export type EmailTemplateVariableDefinition = {
	key: string;
	label: string;
	type: EmailTemplateVariableType;
	required: boolean;
	helpText: string;
};

export type EmailTemplateRecipientPreset = {
	recipientMode: EmailRecipientMode;
	selectedUserIds: number[];
	inspectionId: string;
	label: string;
};

export type EmailTemplate = {
	id: string;
	name: string;
	description: string;
	subjectTemplate: string;
	bodyTemplate: string;
	variables: EmailTemplateVariableDefinition[];
	recipientPreset: EmailTemplateRecipientPreset;
	isActive: boolean;
	updatedAt: string;
};

export type EmailTemplateRenderPreview = {
	subject: string;
	body: string;
	recipients: EmailRecipientsPreview;
};

export type PreviewTemplateEmailPayload = {
	templateId: string;
	variables: Record<string, string>;
};

export type SendTemplateEmailPayload = PreviewTemplateEmailPayload;

export type EmailSendHistoryStatus =
	| "queued"
	| "processing"
	| "sent"
	| "partial"
	| "failed";

export type EmailSendHistoryItem = {
	id: string;
	templateId: string;
	templateName: string;
	subject: string;
	body: string;
	recipientCount: number;
	recipients: EmailRecipientPreviewItem[];
	status: EmailSendHistoryStatus;
	requestedAt: string;
	requestedBy: string;
	jobId: string;
	errorSummary: string;
};
