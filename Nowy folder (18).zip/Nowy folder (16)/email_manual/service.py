from __future__ import annotations

from datetime import datetime, timezone
from email.message import EmailMessage
import json
import os
from pathlib import Path
import re
import smtplib
import sqlite3
from typing import Any
from uuid import uuid4

from fastapi import HTTPException


RECIPIENT_MODE_SELECTED_USERS = "selected_users"
RECIPIENT_MODE_INSPECTION_MEMBERS = "inspection_members"
RECIPIENT_MODE_ALL_USERS = "all_users"
RECIPIENT_MODES = {
    RECIPIENT_MODE_SELECTED_USERS,
    RECIPIENT_MODE_INSPECTION_MEMBERS,
    RECIPIENT_MODE_ALL_USERS,
}

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _normalize_email(value: Any) -> str:
    return str(value or "").strip().lower()


def _is_valid_email(value: Any) -> bool:
    email = _normalize_email(value)
    if not email:
        return False
    return EMAIL_REGEX.match(email) is not None


def resolve_operator(conn: sqlite3.Connection, x_operator_login: str) -> dict[str, Any]:
    login = (x_operator_login or "").strip()
    if not login:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    row = conn.execute(
        """
        SELECT id, login, rola_id, aktywny
        FROM users
        WHERE lower(login)=lower(?)
        LIMIT 1
        """,
        (login,),
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    operator = dict(row)
    if int(operator["aktywny"]) != 1:
        raise HTTPException(status_code=403, detail="Operator jest nieaktywny")
    if int(operator["rola_id"]) not in {2, 3}:
        raise HTTPException(status_code=403, detail="Brak uprawnien")
    return operator


def _display_name(row: dict[str, Any]) -> str:
    first = str(row.get("imie") or "").strip()
    last = str(row.get("nazwisko") or "").strip()
    full = f"{first} {last}".strip()
    if full:
        return full
    return str(row.get("login") or "").strip()


def _dedupe_recipients(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for item in items:
        email = _normalize_email(item.get("email"))
        if not _is_valid_email(email):
            continue
        if email in seen:
            continue
        seen.add(email)
        copied = dict(item)
        copied["email"] = email
        result.append(copied)
    return result


def list_users(conn: sqlite3.Connection, q: str | None) -> list[dict[str, Any]]:
    query = (q or "").strip().lower()
    rows = conn.execute(
        """
        SELECT id, login, imie, nazwisko, email
        FROM users
        WHERE aktywny = 1
          AND email IS NOT NULL
          AND trim(email) <> ''
        ORDER BY nazwisko COLLATE NOCASE ASC, imie COLLATE NOCASE ASC, login COLLATE NOCASE ASC
        """
    ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        email = _normalize_email(data.get("email"))
        if not _is_valid_email(email):
            continue
        item = {
            "id": int(data["id"]),
            "login": str(data.get("login") or ""),
            "displayName": _display_name(data),
            "email": email,
        }
        if query:
            haystack = " ".join(
                [
                    str(item["login"] or "").lower(),
                    str(item["displayName"] or "").lower(),
                    email,
                ]
            )
            if query not in haystack:
                continue
        items.append(item)

    return items


def list_inspections(conn: sqlite3.Connection, q: str | None) -> list[dict[str, str]]:
    query = (q or "").strip().lower()
    rows = conn.execute(
        """
        SELECT i.kod_inspekcji AS inspection_code,
               COALESCE(np.nazwa_pozycji, '') AS entity_name
        FROM inspections i
        LEFT JOIN slownik_pozycje np ON np.id = i.nazwa_podmiotu_id
        WHERE i.kod_inspekcji IS NOT NULL
          AND trim(i.kod_inspekcji) <> ''
        ORDER BY i.kod_inspekcji DESC
        """
    ).fetchall()

    result: list[dict[str, str]] = []
    for row in rows:
        code = str(row["inspection_code"] or "").strip()
        if not code:
            continue
        entity = str(row["entity_name"] or "").strip()
        label = code if not entity else f"{code} - {entity}"
        if query and query not in f"{code} {entity}".lower():
            continue
        result.append({"id": code, "label": label})
    return result


def _inspection_exists(conn: sqlite3.Connection, inspection_code: str) -> bool:
    row = conn.execute(
        "SELECT id FROM inspections WHERE lower(kod_inspekcji)=lower(?) LIMIT 1",
        (inspection_code,),
    ).fetchone()
    return row is not None


def list_inspection_members(conn: sqlite3.Connection, inspection_code: str) -> list[dict[str, Any]]:
    normalized_code = (inspection_code or "").strip()
    if not normalized_code:
        raise HTTPException(status_code=422, detail="inspectionId jest wymagane")
    if not _inspection_exists(conn, normalized_code):
        raise HTTPException(status_code=404, detail="Inspekcja nie istnieje")

    rows = conn.execute(
        """
        SELECT DISTINCT u.id, u.login, u.imie, u.nazwisko, u.email
        FROM inspections i
        JOIN inspection_members im ON im.inspection_id = i.id
        JOIN users u ON u.id = im.user_id
        WHERE lower(i.kod_inspekcji)=lower(?)
          AND u.aktywny = 1
          AND u.email IS NOT NULL
          AND trim(u.email) <> ''
        ORDER BY u.nazwisko COLLATE NOCASE ASC, u.imie COLLATE NOCASE ASC, u.login COLLATE NOCASE ASC
        """,
        (normalized_code,),
    ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        email = _normalize_email(data.get("email"))
        if not _is_valid_email(email):
            continue
        items.append(
            {
                "id": int(data["id"]),
                "login": str(data.get("login") or ""),
                "displayName": _display_name(data),
                "email": email,
            }
        )

    return items


def _list_selected_users(conn: sqlite3.Connection, selected_user_ids: list[int]) -> list[dict[str, Any]]:
    if not selected_user_ids:
        raise HTTPException(status_code=422, detail="selectedUserIds jest wymagane i nie moze byc puste")

    unique_ids = sorted({int(item) for item in selected_user_ids})
    placeholders = ", ".join(["?"] * len(unique_ids))
    rows = conn.execute(
        f"""
        SELECT id, login, imie, nazwisko, email
        FROM users
        WHERE id IN ({placeholders})
          AND aktywny = 1
          AND email IS NOT NULL
          AND trim(email) <> ''
        ORDER BY nazwisko COLLATE NOCASE ASC, imie COLLATE NOCASE ASC, login COLLATE NOCASE ASC
        """,
        tuple(unique_ids),
    ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        email = _normalize_email(data.get("email"))
        if not _is_valid_email(email):
            continue
        items.append(
            {
                "userId": int(data["id"]),
                "displayName": _display_name(data),
                "email": email,
                "source": RECIPIENT_MODE_SELECTED_USERS,
            }
        )
    return items


def _list_all_users(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT id, login, imie, nazwisko, email
        FROM users
        WHERE aktywny = 1
          AND email IS NOT NULL
          AND trim(email) <> ''
        ORDER BY nazwisko COLLATE NOCASE ASC, imie COLLATE NOCASE ASC, login COLLATE NOCASE ASC
        """
    ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        email = _normalize_email(data.get("email"))
        if not _is_valid_email(email):
            continue
        items.append(
            {
                "userId": int(data["id"]),
                "displayName": _display_name(data),
                "email": email,
                "source": RECIPIENT_MODE_ALL_USERS,
            }
        )
    return items


def build_recipients(
    conn: sqlite3.Connection,
    recipient_mode: str,
    selected_user_ids: list[int] | None,
    inspection_id: str | None,
) -> list[dict[str, Any]]:
    mode = str(recipient_mode or "").strip()
    if mode not in RECIPIENT_MODES:
        raise HTTPException(status_code=422, detail="Niepoprawny recipientMode")

    if mode == RECIPIENT_MODE_SELECTED_USERS:
        items = _list_selected_users(conn, selected_user_ids or [])
    elif mode == RECIPIENT_MODE_INSPECTION_MEMBERS:
        if not (inspection_id or "").strip():
            raise HTTPException(status_code=422, detail="inspectionId jest wymagane")
        members = list_inspection_members(conn, inspection_id or "")
        items = [
            {
                "userId": int(item["id"]),
                "displayName": str(item["displayName"]),
                "email": str(item["email"]),
                "source": RECIPIENT_MODE_INSPECTION_MEMBERS,
            }
            for item in members
        ]
    else:
        items = _list_all_users(conn)

    deduped = _dedupe_recipients(items)
    return [
        {
            "userId": item.get("userId"),
            "displayName": str(item.get("displayName") or ""),
            "email": str(item.get("email") or ""),
            "source": str(item.get("source") or mode),
        }
        for item in deduped
    ]


def _load_smtp_password() -> str:
    direct = os.getenv("SMTP_PASS") or ""
    if direct:
        return direct
    secret_file = (os.getenv("SMTP_PASS_FILE") or "").strip()
    if not secret_file:
        return ""
    return Path(secret_file).read_text(encoding="utf-8").strip()


def _send_email(to_email: str, subject: str, body: str) -> tuple[str, str | None]:
    mode = (os.getenv("EMAIL_SEND_MODE") or os.getenv("INVITE_EMAIL_MODE") or "log").strip().lower()
    if mode not in {"log", "smtp"}:
        mode = "log"

    if mode == "log":
        print("[ADMIN-EMAIL]", f"to={to_email}", f"subject={subject}", f"body={body}")
        return "sent", None

    smtp_host = (os.getenv("SMTP_HOST") or "").strip()
    smtp_port_raw = (os.getenv("SMTP_PORT") or "465").strip()
    smtp_login = (os.getenv("SMTP_LOGIN") or "").strip()
    smtp_pass = _load_smtp_password()
    smtp_login_mail = (os.getenv("SMTP_LOGIN_MAIL") or "").strip()
    from_email = (os.getenv("FROM_EMAIL") or smtp_login_mail or "").strip()
    smtp_security = (os.getenv("SMTP_SECURITY") or "starttls").strip().lower()

    if not smtp_host or not smtp_login or not smtp_pass or not from_email:
        raise RuntimeError("Missing SMTP configuration")

    smtp_port = int(smtp_port_raw)

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.set_content(body)

    if smtp_security == "ssl":
        with smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=30) as server:
            server.login(smtp_login, smtp_pass)
            response = server.send_message(msg)
    else:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
            server.ehlo()
            if smtp_security == "starttls":
                server.starttls()
                server.ehlo()
            server.login(smtp_login, smtp_pass)
            response = server.send_message(msg)

    provider_message_id = None
    if isinstance(response, dict) and response:
        provider_message_id = json.dumps(response, ensure_ascii=True)
    return "sent", provider_message_id


def _insert_status_audit(conn: sqlite3.Connection, job_id: str, old_status: str | None, new_status: str, reason: str) -> None:
    conn.execute(
        """
        INSERT INTO email_job_status_audit (job_id, old_status, new_status, changed_at, reason)
        VALUES (?, ?, ?, ?, ?)
        """,
        (job_id, old_status, new_status, now_utc_iso(), reason),
    )


def _update_job_status(conn: sqlite3.Connection, job_id: str, old_status: str | None, new_status: str, reason: str) -> None:
    conn.execute(
        """
        UPDATE email_jobs
        SET status = ?,
            error_summary = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE job_id = ?
        """,
        (new_status, reason, job_id),
    )
    _insert_status_audit(conn, job_id, old_status, new_status, reason)


def send_manual_email(
    conn: sqlite3.Connection,
    requested_by_login: str,
    recipient_mode: str,
    selected_user_ids: list[int] | None,
    inspection_id: str | None,
    subject: str,
    body: str,
) -> str:
    subject_text = str(subject or "").strip()
    body_text = str(body or "").strip()
    if not subject_text:
        raise HTTPException(status_code=422, detail="subject jest wymagane")
    if not body_text:
        raise HTTPException(status_code=422, detail="body jest wymagane")
    if len(subject_text) > 255:
        raise HTTPException(status_code=422, detail="subject przekracza limit 255 znakow")
    if len(body_text) > 20000:
        raise HTTPException(status_code=422, detail="body przekracza limit 20000 znakow")

    recipients = build_recipients(conn, recipient_mode, selected_user_ids, inspection_id)
    if not recipients:
        raise HTTPException(status_code=422, detail="Brak odbiorcow spelniajacych warunki")

    now = datetime.now(timezone.utc)
    job_id = f"mailjob_{now.strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}"
    requested_at = now_utc_iso()
    snapshot_text = json.dumps(recipients, ensure_ascii=True)

    conn.execute(
        """
        INSERT INTO email_jobs (
            job_id, requested_by_login, requested_at, subject, body_snapshot,
            recipient_mode, status, recipient_count, error_summary,
            template_id, template_name, recipients_snapshot
        ) VALUES (?, ?, ?, ?, ?, ?, 'queued', ?, '', '', 'Wiadomosc reczna', ?)
        """,
        (job_id, requested_by_login, requested_at, subject_text, body_text, recipient_mode, len(recipients), snapshot_text),
    )
    _insert_status_audit(conn, job_id, None, "queued", "utworzono zlecenie")

    for recipient in recipients:
        conn.execute(
            """
            INSERT INTO email_job_recipients (
                job_id, user_id, email, display_name, source,
                delivery_status, provider_message_id, error_message, delivered_at
            ) VALUES (?, ?, ?, ?, ?, 'pending', NULL, NULL, NULL)
            """,
            (
                job_id,
                recipient.get("userId"),
                recipient["email"],
                recipient["displayName"],
                recipient["source"],
            ),
        )

    _update_job_status(conn, job_id, "queued", "processing", "rozpoczeto wysylke")

    sent_count = 0
    failed_count = 0
    error_messages: list[str] = []

    rows = conn.execute(
        """
        SELECT id, email
        FROM email_job_recipients
        WHERE job_id = ?
        ORDER BY id ASC
        """,
        (job_id,),
    ).fetchall()

    for row in rows:
        recipient_id = int(row["id"])
        email = str(row["email"])
        try:
            _status, provider_message_id = _send_email(email, subject_text, body_text)
            conn.execute(
                """
                UPDATE email_job_recipients
                SET delivery_status = 'sent',
                    provider_message_id = ?,
                    delivered_at = ?,
                    error_message = NULL
                WHERE id = ?
                """,
                (provider_message_id, now_utc_iso(), recipient_id),
            )
            sent_count += 1
        except Exception as exc:  # noqa: BLE001
            message = str(exc)
            conn.execute(
                """
                UPDATE email_job_recipients
                SET delivery_status = 'failed',
                    provider_message_id = NULL,
                    delivered_at = NULL,
                    error_message = ?
                WHERE id = ?
                """,
                (message, recipient_id),
            )
            failed_count += 1
            if message and message not in error_messages:
                error_messages.append(message)

    if sent_count > 0 and failed_count == 0:
        final_status = "sent"
    elif sent_count > 0 and failed_count > 0:
        final_status = "partial"
    else:
        final_status = "failed"

    error_summary = ""
    if error_messages:
        error_summary = " | ".join(error_messages[:5])

    _update_job_status(conn, job_id, "processing", final_status, error_summary or "zakonczono")

    return job_id


def get_history(conn: sqlite3.Connection, limit: int) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT id, job_id, template_id, template_name, subject, body_snapshot, recipients_snapshot,
               recipient_count, status, requested_at, requested_by_login, error_summary
        FROM email_jobs
        ORDER BY requested_at DESC
        LIMIT ?
        """,
        (int(limit),),
    ).fetchall()

    items: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        recipients: list[dict[str, Any]] = []
        raw_snapshot = str(data.get("recipients_snapshot") or "").strip()
        if raw_snapshot:
            try:
                loaded = json.loads(raw_snapshot)
                if isinstance(loaded, list):
                    for entry in loaded:
                        if not isinstance(entry, dict):
                            continue
                        recipients.append(
                            {
                                "userId": entry.get("userId"),
                                "displayName": str(entry.get("displayName") or ""),
                                "email": str(entry.get("email") or ""),
                                "source": str(entry.get("source") or ""),
                            }
                        )
            except json.JSONDecodeError:
                recipients = []

        if not recipients:
            recipient_rows = conn.execute(
                """
                SELECT user_id, display_name, email, source
                FROM email_job_recipients
                WHERE job_id = ?
                ORDER BY id ASC
                """,
                (str(data.get("job_id") or ""),),
            ).fetchall()
            for rec in recipient_rows:
                recipients.append(
                    {
                        "userId": rec[0],
                        "displayName": str(rec[1] or ""),
                        "email": str(rec[2] or ""),
                        "source": str(rec[3] or ""),
                    }
                )

        items.append(
            {
                "id": f"history_{int(data['id'])}",
                "templateId": str(data.get("template_id") or ""),
                "templateName": str(data.get("template_name") or "Wiadomosc reczna"),
                "subject": str(data.get("subject") or ""),
                "body": str(data.get("body_snapshot") or ""),
                "recipientCount": len(recipients),
                "recipients": recipients,
                "status": str(data.get("status") or "failed"),
                "requestedAt": str(data.get("requested_at") or ""),
                "requestedBy": str(data.get("requested_by_login") or ""),
                "jobId": str(data.get("job_id") or ""),
                "errorSummary": str(data.get("error_summary") or ""),
            }
        )
    return items
