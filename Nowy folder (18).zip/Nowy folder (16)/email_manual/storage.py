from __future__ import annotations

import sqlite3


CREATE_EMAIL_JOBS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS email_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL UNIQUE,
    requested_by_login TEXT NOT NULL,
    requested_at TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_snapshot TEXT NOT NULL,
    recipient_mode TEXT NOT NULL CHECK (recipient_mode IN ('selected_users', 'inspection_members', 'all_users')),
    status TEXT NOT NULL CHECK (status IN ('queued', 'processing', 'sent', 'partial', 'failed')),
    recipient_count INTEGER NOT NULL DEFAULT 0,
    error_summary TEXT NOT NULL DEFAULT '',
    template_id TEXT NOT NULL DEFAULT '',
    template_name TEXT NOT NULL DEFAULT 'Wiadomosc reczna',
    recipients_snapshot TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
"""

CREATE_EMAIL_JOB_RECIPIENTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS email_job_recipients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL,
    user_id INTEGER,
    email TEXT NOT NULL,
    display_name TEXT NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('selected_users', 'inspection_members', 'all_users')),
    delivery_status TEXT NOT NULL CHECK (delivery_status IN ('pending', 'sent', 'failed')),
    provider_message_id TEXT,
    error_message TEXT,
    delivered_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES email_jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)
"""

CREATE_EMAIL_JOB_STATUS_AUDIT_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS email_job_status_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    reason TEXT,
    FOREIGN KEY (job_id) REFERENCES email_jobs(job_id) ON DELETE CASCADE
)
"""

CREATE_INDEX_EMAIL_JOBS_REQUESTED_AT_SQL = """
CREATE INDEX IF NOT EXISTS idx_email_jobs_requested_at
ON email_jobs(requested_at DESC)
"""

CREATE_INDEX_EMAIL_JOB_RECIPIENTS_JOB_ID_SQL = """
CREATE INDEX IF NOT EXISTS idx_email_job_recipients_job_id
ON email_job_recipients(job_id)
"""

CREATE_INDEX_EMAIL_JOB_STATUS_AUDIT_JOB_ID_SQL = """
CREATE INDEX IF NOT EXISTS idx_email_job_status_audit_job_id
ON email_job_status_audit(job_id)
"""


def ensure_email_tables(conn: sqlite3.Connection) -> None:
    conn.execute(CREATE_EMAIL_JOBS_TABLE_SQL)
    conn.execute(CREATE_EMAIL_JOB_RECIPIENTS_TABLE_SQL)
    conn.execute(CREATE_EMAIL_JOB_STATUS_AUDIT_TABLE_SQL)
    conn.execute(CREATE_INDEX_EMAIL_JOBS_REQUESTED_AT_SQL)
    conn.execute(CREATE_INDEX_EMAIL_JOB_RECIPIENTS_JOB_ID_SQL)
    conn.execute(CREATE_INDEX_EMAIL_JOB_STATUS_AUDIT_JOB_ID_SQL)
