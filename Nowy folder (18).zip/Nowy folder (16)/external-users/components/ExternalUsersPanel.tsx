"use client";

import { Pencil, UserPlus, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
	createExternalUser,
	fetchExternalUserPermissions,
	fetchExternalUsers,
	fetchPermissionsCatalog,
	updateExternalUserStatus,
	updateExternalUserPermissions,
} from "@/features/external-users/api";
import type {
	CreateExternalUserForm,
	ExternalPermissionCatalogItem,
	ExternalUser,
} from "@/features/external-users/types";
import { EntitySuccessModal } from "@/shared/components/EntitySuccessModal";

type ExternalUsersPanelProps = {
	operatorLogin: string;
	authRole: AuthRole;
};

const DEFAULT_CREATE_FORM: CreateExternalUserForm = {
	login: "",
	imie: "",
	nazwisko: "",
	email: "",
	aktywny: true,
	permissions: [],
};

function normalizeEmailPart(value: string) {
	return value
		.trim()
		.toLowerCase()
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, "")
		.replace(/[^a-z0-9]+/g, ".")
		.replace(/^\.+|\.+$/g, "");
}

function buildSuggestedEmail(imie: string, nazwisko: string) {
	const first = normalizeEmailPart(imie);
	const last = normalizeEmailPart(nazwisko);

	if (!first || !last) {
		return "";
	}

	return `${first}.${last}@gmail.com`;
}

export function ExternalUsersPanel({
	operatorLogin,
	authRole,
}: ExternalUsersPanelProps) {
	type SuccessModalMode = "create" | "edit";

	const [users, setUsers] = useState<ExternalUser[]>([]);
	const [permissionsCatalog, setPermissionsCatalog] = useState<
		ExternalPermissionCatalogItem[]
	>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);

	const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
	const [isCreating, setIsCreating] = useState(false);
	const [createError, setCreateError] = useState<string | null>(null);
	const [createForm, setCreateForm] = useState<CreateExternalUserForm>(
		DEFAULT_CREATE_FORM,
	);

	const [isPermissionsModalOpen, setIsPermissionsModalOpen] = useState(false);
	const [permissionsError, setPermissionsError] = useState<string | null>(null);
	const [editingUser, setEditingUser] = useState<ExternalUser | null>(null);
	const [editingPermissions, setEditingPermissions] = useState<string[]>([]);
	const [editingIsActive, setEditingIsActive] = useState(true);
	const [isSavingPermissions, setIsSavingPermissions] = useState(false);

	const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
	const [successModalMode, setSuccessModalMode] = useState<SuccessModalMode>("create");
	const [successUserLabel, setSuccessUserLabel] = useState("");

	const loadData = useCallback(async () => {
		setIsLoading(true);
		setError(null);

		try {
			const [usersResult, catalogResult] = await Promise.all([
				fetchExternalUsers(operatorLogin),
				fetchPermissionsCatalog(operatorLogin),
			]);

			if (!usersResult.ok) {
				setError(usersResult.error);
				setUsers([]);
				setPermissionsCatalog([]);
				return;
			}

			if (!catalogResult.ok) {
				setError(catalogResult.error);
				setUsers(usersResult.users);
				setPermissionsCatalog([]);
				return;
			}

			setUsers(usersResult.users);
			setPermissionsCatalog(catalogResult.permissions);
		} catch {
			setError("Nie udało się pobrać danych użytkowników zewnętrznych.");
			setUsers([]);
			setPermissionsCatalog([]);
		} finally {
			setIsLoading(false);
		}
	}, [operatorLogin]);

	useEffect(() => {
		void loadData();
	}, [loadData]);

	const sortedPermissionsCatalog = useMemo(
		() =>
			[...permissionsCatalog].sort((left, right) =>
				left.label.localeCompare(right.label, "pl", { sensitivity: "base" }),
			),
		[permissionsCatalog],
	);

	const permissionSections = useMemo(() => {
		const reports = sortedPermissionsCatalog.filter((permission) =>
			permission.key.startsWith("reports."),
		);
		const registries = sortedPermissionsCatalog.filter((permission) =>
			permission.key.startsWith("registry."),
		);
		const other = sortedPermissionsCatalog.filter(
			(permission) =>
				!permission.key.startsWith("reports.") && !permission.key.startsWith("registry."),
		);

		const sections: Array<{
			id: string;
			title: string;
			permissions: ExternalPermissionCatalogItem[];
		}> = [];

		if (reports.length > 0) {
			sections.push({ id: "reports", title: "Raporty", permissions: reports });
		}

		if (registries.length > 0) {
			sections.push({ id: "registry", title: "Rejestry", permissions: registries });
		}

		if (other.length > 0) {
			sections.push({ id: "other", title: "Pozostałe", permissions: other });
		}

		return sections;
	}, [sortedPermissionsCatalog]);

	if (authRole !== "director") {
		return (
			<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
				<p className="rounded-lg border border-amber-300/45 bg-amber-950/30 px-3 py-2 text-amber-200 text-sm">
					Tylko dyrektor może zarządzać użytkownikami zewnętrznymi.
				</p>
			</section>
		);
	}

	const openCreateModal = () => {
		setCreateForm(DEFAULT_CREATE_FORM);
		setCreateError(null);
		setIsCreateModalOpen(true);
	};

	const closeCreateModal = () => {
		setIsCreateModalOpen(false);
		setIsCreating(false);
		setCreateError(null);
	};

	const toggleCreatePermission = (permissionKey: string) => {
		setCreateForm((previous) => ({
			...previous,
			permissions: previous.permissions.includes(permissionKey)
				? previous.permissions.filter((item) => item !== permissionKey)
				: [...previous.permissions, permissionKey],
		}));
	};

	const submitCreate = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		if (
			!createForm.login.trim() ||
			!createForm.imie.trim() ||
			!createForm.nazwisko.trim() ||
			!createForm.email.trim()
		) {
			setCreateError("Uzupełnij wymagane pola: login, imię, nazwisko i e-mail.");
			return;
		}

		if (createForm.permissions.length === 0) {
			setCreateError("Wybierz przynajmniej jedno uprawnienie widoczności.");
			return;
		}

		setCreateError(null);
		setIsCreating(true);

		try {
			const frontendInviteUrl =
				typeof window !== "undefined"
					? `${window.location.origin}/set-password`
					: "http://localhost:3002/set-password";

			const result = await createExternalUser(operatorLogin, {
				login: createForm.login.trim(),
				imie: createForm.imie.trim(),
				nazwisko: createForm.nazwisko.trim(),
				email: createForm.email.trim(),
				permissions: createForm.permissions,
				aktywny: createForm.aktywny,
				frontendInviteUrl,
			});

			if (!result.ok) {
				setCreateError(result.error);
				return;
			}

			closeCreateModal();
			await loadData();
			setSuccessModalMode("create");
			setSuccessUserLabel(`${createForm.imie.trim()} ${createForm.nazwisko.trim()}`.trim());
			setIsSuccessModalOpen(true);
		} catch {
			setCreateError("Nie udało się utworzyć użytkownika zewnętrznego.");
		} finally {
			setIsCreating(false);
		}
	};

	const openPermissionsModal = async (user: ExternalUser) => {
		setPermissionsError(null);
		setEditingUser(user);
		setEditingPermissions(user.permissions);
		setEditingIsActive(user.aktywny);
		setIsPermissionsModalOpen(true);

		const result = await fetchExternalUserPermissions(operatorLogin, user.id);
		if (!result.ok) {
			setPermissionsError(result.error);
			return;
		}

		setEditingPermissions(result.permissions);
	};

	const closePermissionsModal = () => {
		setIsPermissionsModalOpen(false);
		setIsSavingPermissions(false);
		setPermissionsError(null);
		setEditingUser(null);
		setEditingPermissions([]);
		setEditingIsActive(true);
	};

	const toggleEditingPermission = (permissionKey: string) => {
		setEditingPermissions((previous) =>
			previous.includes(permissionKey)
				? previous.filter((item) => item !== permissionKey)
				: [...previous, permissionKey],
		);
	};

	const savePermissions = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		if (!editingUser) {
			return;
		}

		setPermissionsError(null);
		setIsSavingPermissions(true);

		try {
			const permissionsResult = await updateExternalUserPermissions(
				operatorLogin,
				editingUser.id,
				editingPermissions,
			);
			if (!permissionsResult.ok) {
				setPermissionsError(permissionsResult.error);
				return;
			}

			const statusResult = await updateExternalUserStatus(
				operatorLogin,
				editingUser,
				editingIsActive,
			);
			if (!statusResult.ok) {
				setPermissionsError(statusResult.error);
				return;
			}

			setSuccessModalMode("edit");
			setSuccessUserLabel(
				`${editingUser.imie.trim()} ${editingUser.nazwisko.trim()}`.trim() || editingUser.login,
			);
			setIsSuccessModalOpen(true);
			closePermissionsModal();
			await loadData();
		} catch {
			setPermissionsError("Nie udało się zapisać uprawnień lub statusu aktywności.");
		} finally {
			setIsSavingPermissions(false);
		}
	};

	return (
		<section className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5">
			<div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-slate-700/70 border-b pb-3">
				<div>
					<h2 className="font-semibold text-lg text-slate-100">Użytkownicy zewnętrzni</h2>
					<p className="mt-1 text-slate-300/85 text-sm">
						Dyrektor tworzy konta zewnętrzne i nadaje widoczność modułów.
					</p>
				</div>

				<button
					type="button"
					onClick={openCreateModal}
					className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#8ec5a1] bg-[#b9e8c9] px-3.5 font-semibold text-[#1f5130] text-sm shadow-[inset_0_1px_0_rgba(255,255,255,0.45)] transition-colors hover:bg-[#a5debb]"
				>
					<UserPlus size={15} />
					Dodaj użytkownika zewnętrznego
				</button>
			</div>

			{error ? (
				<p className="mb-3 rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-rose-700 text-sm">
					{error}
				</p>
			) : null}

			{isLoading ? (
				<p className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-slate-600 text-sm">
					Ładowanie użytkowników zewnętrznych...
				</p>
			) : (
				<div className="subtle-horizontal-scroll subtle-vertical-scroll h-[calc(100vh-19rem)] min-h-96 overflow-x-auto overflow-y-auto rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
					<table className="min-w-full border-collapse text-slate-900 text-sm">
						<thead>
							<tr className="bg-slate-100 text-slate-800">
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Login</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Imię i nazwisko</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">E-mail</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Widoczność</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold">Status</th>
								<th className="border-slate-300 border-b px-3 py-2 text-left font-semibold" />
							</tr>
						</thead>
						<tbody>
							{users.map((user) => (
								<tr
									key={user.id}
									className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
								>
									<td className="whitespace-nowrap px-3 py-2.5 font-medium">{user.login}</td>
									<td className="whitespace-nowrap px-3 py-2.5">{user.imie} {user.nazwisko}</td>
									<td className="whitespace-nowrap px-3 py-2.5">{user.email ?? "-"}</td>
									<td className="whitespace-nowrap px-3 py-2.5">{user.permissions.length}</td>
									<td className="whitespace-nowrap px-3 py-2.5">
										<span
											className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${
												user.aktywny
													? "bg-emerald-100 text-emerald-800"
													: "bg-slate-200 text-slate-700"
											}`}
										>
											{user.aktywny ? "Aktywny" : "Nieaktywny"}
										</span>
									</td>
									<td className="whitespace-nowrap px-3 py-2.5">
										<button
											type="button"
											onClick={() => void openPermissionsModal(user)}
											className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
										>
											<Pencil size={12} />
											Uprawnienia
										</button>
									</td>
								</tr>
							))}

							{users.length === 0 ? (
								<tr>
									<td colSpan={6} className="px-3 py-8 text-center text-slate-500">
										Brak użytkowników zewnętrznych.
									</td>
								</tr>
							) : null}
						</tbody>
					</table>
				</div>
			)}

			{isCreateModalOpen ? (
				<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
					<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />

					<div className="relative z-10 w-full max-w-3xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5">
						<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
							<div>
								<h3 className="font-semibold text-base text-slate-900">Nowy użytkownik zewnętrzny</h3>
							</div>
							<button
								type="button"
								onClick={closeCreateModal}
								className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
							>
								<X size={14} />
							</button>
						</div>

						<form className="space-y-4" onSubmit={submitCreate}>
							<div className="grid gap-3 sm:grid-cols-2">
								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">Login *</span>
									<input
										required
										value={createForm.login}
										onChange={(event) =>
											setCreateForm((previous) => ({ ...previous, login: event.target.value }))
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>
								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">Imię *</span>
									<input
										required
										value={createForm.imie}
										onChange={(event) =>
											setCreateForm((previous) => {
												const nextImie = event.target.value;
												const previousSuggestedEmail = buildSuggestedEmail(
													previous.imie,
													previous.nazwisko,
												);
												const nextSuggestedEmail = buildSuggestedEmail(
													nextImie,
													previous.nazwisko,
												);

												return {
													...previous,
													imie: nextImie,
													email:
														!previous.email || previous.email === previousSuggestedEmail
															? nextSuggestedEmail
															: previous.email,
												};
											})
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>
								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">Nazwisko *</span>
									<input
										required
										value={createForm.nazwisko}
										onChange={(event) =>
											setCreateForm((previous) => {
												const nextNazwisko = event.target.value;
												const previousSuggestedEmail = buildSuggestedEmail(
													previous.imie,
													previous.nazwisko,
												);
												const nextSuggestedEmail = buildSuggestedEmail(
													previous.imie,
													nextNazwisko,
												);

												return {
													...previous,
													nazwisko: nextNazwisko,
													email:
														!previous.email || previous.email === previousSuggestedEmail
															? nextSuggestedEmail
															: previous.email,
												};
											})
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>
								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">E-mail *</span>
									<input
										type="email"
										required
										value={createForm.email}
										onChange={(event) =>
											setCreateForm((previous) => ({ ...previous, email: event.target.value }))
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>
							</div>

							<div className="rounded-lg border border-slate-200 p-3">
								<p className="mb-2 font-semibold text-slate-800 text-sm">Widoczność modułów *</p>
								{sortedPermissionsCatalog.length === 0 ? (
									<p className="mb-2 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-2 text-amber-800 text-xs">
										Nie udało się odczytać katalogu uprawnień z backendu. Skontaktuj się z administratorem API.
									</p>
								) : null}
								<div className="space-y-3">
									{permissionSections.map((section) => (
										<div key={section.id} className="space-y-2">
											<p className="font-semibold text-slate-700 text-xs uppercase tracking-wide">
												{section.title}
											</p>
											<div className="grid gap-2 sm:grid-cols-2">
												{section.permissions.map((permission) => (
													<label
														key={permission.key}
														className="flex cursor-pointer items-start gap-2 rounded-md border border-slate-200 px-2.5 py-2 text-slate-700 text-sm hover:bg-slate-50"
													>
														<input
															type="checkbox"
															checked={createForm.permissions.includes(permission.key)}
															onChange={() => toggleCreatePermission(permission.key)}
															className="mt-0.5"
														/>
														<span className="block font-medium">{permission.label}</span>
													</label>
												))}
											</div>
										</div>
									))}
								</div>
							</div>

							<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
								<input
									type="checkbox"
									checked={createForm.aktywny}
									onChange={(event) =>
										setCreateForm((previous) => ({ ...previous, aktywny: event.target.checked }))
									}
								/>
								Konto aktywne
							</label>

							{createError ? (
								<p className="font-medium text-rose-600 text-sm">{createError}</p>
							) : null}

							<div className="flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
								<button
									type="button"
									onClick={closeCreateModal}
									className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
								>
									Anuluj
								</button>
								<button
									type="submit"
									disabled={isCreating}
									className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
								>
									{isCreating ? "Zapisywanie..." : "Dodaj"}
								</button>
							</div>
						</form>
					</div>
				</div>
			) : null}

			{isPermissionsModalOpen && editingUser ? (
				<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
					<button
						type="button"
						aria-label="Zamknij modal uprawnień"
						className="absolute inset-0 bg-slate-950/65"
						onClick={closePermissionsModal}
					/>

					<div className="relative z-10 w-full max-w-3xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5">
						<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
							<div>
								<h3 className="font-semibold text-base text-slate-900">Widoczność modułów</h3>
								<p className="mt-1 text-slate-600 text-sm">Użytkownik: {editingUser.login}</p>
							</div>
							<button
								type="button"
								onClick={closePermissionsModal}
								className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
							>
								<X size={14} />
							</button>
						</div>

						<form className="space-y-4" onSubmit={savePermissions}>
							<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
								<input
									type="checkbox"
									checked={editingIsActive}
									onChange={(event) => setEditingIsActive(event.target.checked)}
								/>
								Konto aktywne
							</label>

							<div className="space-y-3">
								{permissionSections.map((section) => (
									<div key={section.id} className="space-y-2">
										<p className="font-semibold text-slate-700 text-xs uppercase tracking-wide">
											{section.title}
										</p>
										<div className="grid gap-2 sm:grid-cols-2">
											{section.permissions.map((permission) => (
												<label
													key={permission.key}
													className="flex cursor-pointer items-start gap-2 rounded-md border border-slate-200 px-2.5 py-2 text-slate-700 text-sm hover:bg-slate-50"
												>
													<input
														type="checkbox"
														checked={editingPermissions.includes(permission.key)}
														onChange={() => toggleEditingPermission(permission.key)}
														className="mt-0.5"
													/>
													<span className="block font-medium">{permission.label}</span>
												</label>
											))}
										</div>
									</div>
								))}
							</div>

							{permissionsError ? (
								<p className="font-medium text-rose-600 text-sm">{permissionsError}</p>
							) : null}

							<div className="flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
								<button
									type="button"
									onClick={closePermissionsModal}
									className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
								>
									Anuluj
								</button>
								<button
									type="submit"
									disabled={isSavingPermissions}
									className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
								>
									{isSavingPermissions ? "Zapisywanie..." : "Zapisz uprawnienia"}
								</button>
							</div>
						</form>
					</div>
				</div>
			) : null}

			<EntitySuccessModal
				isOpen={isSuccessModalOpen}
				heading={
					successModalMode === "edit"
						? "Konto użytkownika zewnętrznego zostało zaktualizowane"
						: "Konto użytkownika zewnętrznego zostało dodane"
				}
				detailsMessage={
					successModalMode === "edit"
						? successUserLabel
							? `Dla użytkownika ${successUserLabel}.`
							: "Zmiany zostały zapisane w tabeli."
						: "Link z możliwością utworzenia hasła został wysłany"
				}
				onClose={() => {
					setIsSuccessModalOpen(false);
					setSuccessModalMode("create");
					setSuccessUserLabel("");
				}}
			/>
		</section>
	);
}
