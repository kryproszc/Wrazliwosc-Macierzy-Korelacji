const DEFAULT_API_PORT = '8011';

const LOCAL_HOSTNAMES = new Set(['localhost', '127.0.0.1', '::1']);

function isLocalHostname(hostname: string): boolean {
  return LOCAL_HOSTNAMES.has(hostname.toLowerCase());
}

function trimTrailingSlash(value: string): string {
  return value.replace(/\/+$/, '');
}

export function getApiBaseUrl(): string {
  const envUrl = process.env.NEXT_PUBLIC_API_URL?.trim();
  const browserHostname = typeof window !== 'undefined' ? window.location.hostname : undefined;
  const browserProtocol = typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'https:' : 'http:';

  if (envUrl) {
    try {
      const parsed = new URL(envUrl);

      if (
        browserHostname &&
        isLocalHostname(parsed.hostname) &&
        !isLocalHostname(browserHostname)
      ) {
        parsed.hostname = browserHostname;
      }

      if (!parsed.port) {
        parsed.port = DEFAULT_API_PORT;
      }

      return trimTrailingSlash(parsed.toString());
    } catch {
      return trimTrailingSlash(envUrl);
    }
  }

  if (browserHostname) {
    return `${browserProtocol}//${browserHostname}:${DEFAULT_API_PORT}`;
  }

  return `http://localhost:${DEFAULT_API_PORT}`;
}

export function buildApiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `${getApiBaseUrl()}${normalizedPath}`;
}
