'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import { useExposureStore } from '@/stores/exposureStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useParamsymStore } from '@/stores/paramsymStore';
import { useDeterministicIncurredResultsStore } from '@/stores/deterministicIncurredResultsStore';
import { CalculationLayout, EmptyState } from '@/shared/components/calculation';
import { DataTableView } from '@/shared/ui/molecules/DataTableView';
import { processSelectedRow, processSelectedValues } from '@/shared/utils';
import { useDataValidation } from '@/shared/hooks';
import { getApiBaseUrl } from '@/lib/apiBaseUrl';

const API_URL = getApiBaseUrl();

const roundPayloadNumbers = <T,>(value: T): T => {
	if (typeof value === 'number' && Number.isFinite(value)) {
		return Number(value.toFixed(15)) as T;
	}

	if (Array.isArray(value)) {
		return value.map((item) => roundPayloadNumbers(item)) as T;
	}

	if (value && typeof value === 'object') {
		const entries = Object.entries(value as Record<string, unknown>).map(([key, nested]) => [
			key,
			roundPayloadNumbers(nested),
		]);
		return Object.fromEntries(entries) as T;
	}

	return value;
};

export function DeterministicIncurredTab() {
	const hasTrianglesWatcherInitialized = useRef(false);
	const previousPaidTriangleRef = useRef<(number | null)[][] | undefined>(undefined);
	const previousIncurredTriangleRef = useRef<(number | null)[][] | undefined>(undefined);

	const methodType = useDeterministicIncurredResultsStore((s) => s.methodType);
	const setMethodType = useDeterministicIncurredResultsStore((s) => s.setMethodType);
	const kChange = useDeterministicIncurredResultsStore((s) => s.kChange);
	const setKChange = useDeterministicIncurredResultsStore((s) => s.setKChange);
	const calculationResults = useDeterministicIncurredResultsStore((s) => s.results);
	const setCalculationResults = useDeterministicIncurredResultsStore((s) => s.setResults);
	const clearCalculationResults = useDeterministicIncurredResultsStore((s) => s.clearResults);

	const [isSending, setIsSending] = useState(false);
	const [lastSendMessage, setLastSendMessage] = useState<string>('Jeszcze nic nie wysłano.');

	const userId = useUserStore((s: any) => s.userId);
	const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);

	const {
		incurredTriangle,
		selectedValuesCL,
		combinedDevJSummary,
		devJ,
		rJPaidToIncurred,
		varJPaidToIncurred,
		selectedValuesRJPaidToIncurred,
		selectedValuesVarJPaidToIncurred,
		combinedRJPaidToIncurredSummary,
		combinedVarJPaidToIncurredSummary,
	} = useTrainDevideStoreIncurred();

	const {
		addJ,
		combinedAddLRSummary,
	} = useAddIncurredCoefficientsStore();

	const {
		exposureTriangle,
		selectedExposureLine,
		availableExposureLines,
	} = useExposureStore();

	const discountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
	const selectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

	const paramsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
	const selectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);

	const { isDiscountRatesLoaded, isNettoBruttoLoaded, canSelectBrutto, canSelectBruttoDysk, canSelectNettoDysk } =
		useDataValidation(incurredTriangle, discountRatesTriangle, paramsymTriangle);

	const isIncurredTriangleLoaded = () => Array.isArray(incurredTriangle) && incurredTriangle.length > 0;

	const exposureArray = useMemo(() => {
		if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) return [];
		if (selectedExposureLine === null) return [];

		const selectedLine = availableExposureLines.find((line) => line.index === selectedExposureLine);
		if (!selectedLine) return [];

		return selectedLine.values;
	}, [exposureTriangle, selectedExposureLine, availableExposureLines]);

	const canSend = useMemo(() => {
		return Boolean(userId) && Array.isArray(incurredTriangle) && incurredTriangle.length > 0;
	}, [userId, incurredTriangle]);

	const vectorF = useMemo(() => {
		return processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
	}, [selectedValuesCL, combinedDevJSummary, devJ]);

	const vectorLr = useMemo(() => {
		return processSelectedValues([], combinedAddLRSummary, addJ as any[], 1.0);
	}, [combinedAddLRSummary, addJ]);

	const hasAnyFiniteNumber = (input: unknown): boolean => {
		if (Array.isArray(input)) {
			return input.some((item) => hasAnyFiniteNumber(item));
		}

		if (typeof input === 'string') {
			const parsed = Number(input);
			return Number.isFinite(parsed);
		}

		return typeof input === 'number' && Number.isFinite(input);
	};

	const hasCl = hasAnyFiniteNumber(selectedValuesCL);
	const hasLr = hasAnyFiniteNumber(combinedAddLRSummary) || hasAnyFiniteNumber(addJ);
	const hasRj =
		hasAnyFiniteNumber(selectedValuesRJPaidToIncurred)
		|| hasAnyFiniteNumber(combinedRJPaidToIncurredSummary)
		|| hasAnyFiniteNumber(rJPaidToIncurred);

	const vectorFLength = vectorF.length;
	const vectorLrLength = vectorLr.length;
	const isMultiplikatywnaDisabled = !hasRj || !hasCl;
	const isAddytywnaDisabled = !hasRj || !hasLr;
	const isMixDisabled = !hasRj || !hasCl || !hasLr;
	const isCurrentMethodUnavailable =
		(methodType === 'multiplikatywna' && isMultiplikatywnaDisabled)
		|| (methodType === 'addytywna' && isAddytywnaDisabled)
		|| (methodType === 'mix' && isMixDisabled);
	const parsedKChange = Number(kChange);
	const isMixMethod = methodType === 'mix';
	const isMixKInvalid = isMixMethod && (!Number.isFinite(parsedKChange) || parsedKChange > vectorFLength);

	useEffect(() => {
		if (!isCurrentMethodUnavailable) {
			return;
		}

		if (!isMultiplikatywnaDisabled) {
			setMethodType('multiplikatywna');
			return;
		}

		if (!isAddytywnaDisabled) {
			setMethodType('addytywna');
			return;
		}

		if (!isMixDisabled) {
			setMethodType('mix');
		}
	}, [
		isCurrentMethodUnavailable,
		isMultiplikatywnaDisabled,
		isAddytywnaDisabled,
		isMixDisabled,
		setMethodType,
	]);

	const lightResultsTableData = useMemo(() => {
		if (!calculationResults) return null;

		const formatWholeNumber = (value: number) =>
			Math.round(value)
				.toLocaleString('pl-PL', {
					minimumFractionDigits: 0,
					maximumFractionDigits: 0,
					useGrouping: true,
				})
				.replace(/\u00A0/g, ' ');

		const headers = ['OKRES', 'Brutto', 'Brutto jednoroczne zdyskontowane', 'Netto jednoroczne zdyskontowane'];
		const maxLength = Math.max(
			calculationResults.last_col_incurred.length,
			calculationResults.cum_trian_incurred.length,
			calculationResults.ult_net_disc_incurred.length,
		);

		const lastColSum = calculationResults.last_col_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const cumTrianSum = calculationResults.cum_trian_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const ultNetDiscSum = calculationResults.ult_net_disc_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);

		const rows: string[][] = [headers];

		for (let index = 0; index < maxLength; index += 1) {
			const lastColValue = calculationResults.last_col_incurred[index];
			const cumTrianValue = calculationResults.cum_trian_incurred[index];
			const ultNetDiscValue = calculationResults.ult_net_disc_incurred[index];

			rows.push([
				String(index + 1),
				typeof lastColValue === 'number' ? formatWholeNumber(lastColValue) : '-',
				typeof cumTrianValue === 'number' ? formatWholeNumber(cumTrianValue) : '-',
				typeof ultNetDiscValue === 'number' ? formatWholeNumber(ultNetDiscValue) : '-',
			]);
		}

		rows.push([
			'SUMA',
			formatWholeNumber(lastColSum),
			formatWholeNumber(cumTrianSum),
			formatWholeNumber(ultNetDiscSum),
		]);

		return rows;
	}, [calculationResults]);

	const handleSend = async () => {
		const selectedValueCl = vectorF;
		const selectedValueLr = vectorLr;

		let computedKChange: number;

		if (methodType === 'multiplikatywna') {
			computedKChange = -1;
		} else if (methodType === 'addytywna') {
			computedKChange = vectorLrLength;
		} else {
			let mixK = Number(kChange);

			if (!Number.isFinite(mixK)) {
				const promptValue = window.prompt('Podaj parametr k dla trybu Mix metod:', kChange || '0');
				if (promptValue === null) {
					setLastSendMessage('Anulowano wprowadzanie parametru k dla trybu Mix.');
					return;
				}
				setKChange(promptValue);
				mixK = Number(promptValue);
			}

			if (!Number.isFinite(mixK)) {
				setLastSendMessage('Parametr k dla trybu Mix musi być liczbą.');
				return;
			}

			if (mixK > vectorFLength) {
				setLastSendMessage(`Parametr k dla trybu Mix nie może być większy od: ${vectorFLength}`);
				return;
			}

			computedKChange = mixK;
		}

		if (!userId) {
			setLastSendMessage('Brak user_id - nie wysłano.');
			console.error('❌ [DeterministicIncurredTab] Brak user_id');
			return;
		}

		if (!Array.isArray(incurredTriangle) || incurredTriangle.length === 0) {
			setLastSendMessage('Brak incurred_triangle - nie wysłano.');
			console.error('❌ [DeterministicIncurredTab] Brak incurred_triangle');
			return;
		}

		if (isCurrentMethodUnavailable) {
			setLastSendMessage('Brak wymaganych danych CL/LR/RJ dla wybranej metody.');
			return;
		}

		const rjFinal = processSelectedValues(
			selectedValuesRJPaidToIncurred,
			combinedRJPaidToIncurredSummary as any[],
			rJPaidToIncurred as any[],
			1.0,
		);
		const varjFinal = processSelectedValues(
			selectedValuesVarJPaidToIncurred,
			combinedVarJPaidToIncurredSummary as any[],
			varJPaidToIncurred as any[],
			1.0,
		);
		const discountRates = processSelectedRow(discountRatesTriangle, selectedDiscountRateLine);
		const nettoDysk = processSelectedRow(paramsymTriangle, selectedParamsymLine, true);
		const rjCalculated = Array.isArray(rJPaidToIncurred) ? rJPaidToIncurred : [];
		const varjCalculated = Array.isArray(varJPaidToIncurred) ? varJPaidToIncurred : [];
		const paidTriangleForPayload = Array.isArray(paidTriangle) && paidTriangle.length > 0 ? paidTriangle : undefined;

		const rawPayload = {
			user_id: userId,
			paid_triangle: paidTriangleForPayload,
			incurred_triangle: incurredTriangle,
			selected_value_cl: selectedValueCl,
			selected_value_lr: selectedValueLr,
			r_i_calculated: rjCalculated,
			var_j_calculated: varjCalculated,
			r_i_final: rjFinal,
			var_j_final: varjFinal,
			ekspozycja: exposureArray,
			k_change: computedKChange,
			discount_rates: discountRates,
			netto_dysk: nettoDysk,
			calculation_options: {
				brutto: canSelectBrutto,
				brutto_dysk: canSelectBruttoDysk,
				netto_dysk: canSelectNettoDysk,
			},
		};

		const payload = roundPayloadNumbers(rawPayload);

		const requestBody = JSON.stringify(payload);

		console.log('📤 [DeterministicIncurredTab] URL:', `${API_URL}/calc_change_method/execute_calculations_incurred`);
		console.log('📤 [DeterministicIncurredTab] Method:', 'POST');
		console.log('📤 [DeterministicIncurredTab] Headers:', { 'Content-Type': 'application/json' });
		console.log('📤 [DeterministicIncurredTab] Wysyłany payload (object):', payload);
		console.log('📤 [DeterministicIncurredTab] Wysyłany payload (JSON pretty):', JSON.stringify(payload, null, 2));
		console.log('📤 [DeterministicIncurredTab] Wysyłane body dokładnie:', requestBody);
		console.log('📤 [DeterministicIncurredTab] Klucze payloadu:', Object.keys(payload));

		try {
			setIsSending(true);
			setLastSendMessage('Wysyłanie...');

			const response = await fetch(`${API_URL}/calc_change_method/execute_calculations_incurred`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: requestBody,
			});

			const responseBody = await response.json().catch(() => null);

			console.log('📥 [DeterministicIncurredTab] Status odpowiedzi:', response.status);
			console.log('📥 [DeterministicIncurredTab] Odpowiedź backendu:', responseBody);

			if (!response.ok) {
				const detail =
					typeof responseBody?.detail === 'string'
						? responseBody.detail
						: responseBody?.detail
							? JSON.stringify(responseBody.detail)
							: responseBody?.message
								? String(responseBody.message)
								: 'Brak szczegółów błędu';
				setLastSendMessage(`Błąd wysyłki: ${response.status} - ${detail}`);
				return;
			}

			const vectors = responseBody?.vectors ?? responseBody ?? {};
			setCalculationResults({
				last_col_incurred: Array.isArray(vectors.last_col_incurred)
					? vectors.last_col_incurred
					: Array.isArray(vectors.last_col)
						? vectors.last_col
						: [],
				cum_trian_incurred: Array.isArray(vectors.cum_trian_incurred)
					? vectors.cum_trian_incurred
					: Array.isArray(vectors.cum_trian)
						? vectors.cum_trian
						: [],
				ult_net_disc_incurred: Array.isArray(vectors.ult_net_disc_incurred)
					? vectors.ult_net_disc_incurred
					: Array.isArray(vectors.ult_net_disc)
						? vectors.ult_net_disc
						: [],
				userId: userId,
				shouldShowResults: true,
			});

			setLastSendMessage('Wysłano poprawnie.');
		} catch (error) {
			console.error('❌ [DeterministicIncurredTab] Błąd podczas wysyłki:', error);
			setLastSendMessage(`Błąd wysyłki: ${error}`);
		} finally {
			setIsSending(false);
		}
	};

	useEffect(() => {
		if (!hasTrianglesWatcherInitialized.current) {
			hasTrianglesWatcherInitialized.current = true;
			previousPaidTriangleRef.current = paidTriangle;
			previousIncurredTriangleRef.current = incurredTriangle;
			return;
		}

		const hasPaidTriangleChanged = previousPaidTriangleRef.current !== paidTriangle;
		const hasIncurredTriangleChanged = previousIncurredTriangleRef.current !== incurredTriangle;

		previousPaidTriangleRef.current = paidTriangle;
		previousIncurredTriangleRef.current = incurredTriangle;

		if ((!hasPaidTriangleChanged && !hasIncurredTriangleChanged) || !calculationResults) {
			return;
		}

		clearCalculationResults();
		setLastSendMessage('Wyczyszczono wyniki po zmianie danych Trójkąta Paid/Incurred.');
	}, [paidTriangle, incurredTriangle, calculationResults, clearCalculationResults]);

	return (
		<CalculationLayout
			sidebarWidth="w-48"
			sidebarPadding="p-3"
			mainPadding="p-4 md:p-5"
			sidebar={
				<div className="space-y-4">
					<div className="space-y-3 rounded-lg bg-gray-800 p-3">
						<label className="mb-1 block text-sm font-medium text-white">Wybór metody:</label>
						<div className="space-y-2">
							<label className={`flex items-center gap-2 text-sm font-medium ${isMultiplikatywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'multiplikatywna'}
									onChange={() => setMethodType('multiplikatywna')}
									disabled={isMultiplikatywnaDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Multiplikatywna</span>
							</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isAddytywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'addytywna'}
									onChange={() => setMethodType('addytywna')}
									disabled={isAddytywnaDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Addytywna</span>
							</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isMixDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'mix'}
									onChange={() => setMethodType('mix')}
									disabled={isMixDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Mix metod</span>
							</label>
						</div>
					</div>

					{isMixMethod && (
						<div>
							<label htmlFor="kChangeIncurred" className="mb-2 block text-xs font-medium text-white">
								Parametr k (Mix):
							</label>
							<input
								id="kChangeIncurred"
								type="number"
								step="0.01"
								value={kChange}
								onChange={(event) => setKChange(event.target.value)}
								className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
							/>
						</div>
					)}

					<hr className="border-gray-600" />
					<div className="mx-auto flex w-fit flex-col gap-3">
						<button
							onClick={handleSend}
							disabled={isSending || !canSend || isMixKInvalid || isCurrentMethodUnavailable}
							className={`h-8 w-40 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl ${
								isSending || !canSend || isMixKInvalid || isCurrentMethodUnavailable ? 'opacity-60 cursor-not-allowed hover:scale-100' : ''
							}`}
						>
							{isSending ? 'Wysyłanie...' : 'Oblicz'}
						</button>

						<button
							onClick={() => {}}
							disabled={isCurrentMethodUnavailable}
							className={`h-8 w-40 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl ${
								isCurrentMethodUnavailable ? 'opacity-60 cursor-not-allowed hover:scale-100' : ''
							}`}
						>
							Eksportuj do Excela
						</button>
					</div>
				</div>
			}
		>
			<div className="space-y-6">
				{calculationResults ? (
					<DataTableView
						title="Wyniki"
						className="[&_*_table]:text-[11px]"
						lightHeaderClassName="bg-gradient-to-r from-gray-100 to-gray-50 px-3 py-1 border-b border-gray-300 rounded-t-2xl"
						lightTitleClassName="font-bold text-gray-800 text-sm tracking-tight"
						tableWrapperClassName="w-full overflow-auto max-h-[calc(100vh-8.5rem)]"
						data={lightResultsTableData}
						noDataMessage="Brak danych wynikowych do wyświetlenia"
						variant="light"
					/>
				) : (
					<EmptyState
						title=""
						description={'Dla wybranej metody kliknij "Oblicz".'}
					/>
				)}
			</div>
		</CalculationLayout>
	);
}
