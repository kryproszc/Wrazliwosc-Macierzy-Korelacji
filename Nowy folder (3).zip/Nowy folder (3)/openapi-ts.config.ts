import { defineConfig } from '@hey-api/openapi-ts';

const openApiInputUrl = process.env.OPENAPI_INPUT_URL ?? 'http://localhost:8011/openapi.json';

export default defineConfig({
  input: openApiInputUrl,
  output: 'src/client',
  plugins: [
    '@hey-api/client-fetch',
    '@hey-api/schemas',
    '@hey-api/sdk',
    {
      enums: 'javascript',
      name: '@hey-api/typescript',
    },
    '@tanstack/react-query',
  ],
});
