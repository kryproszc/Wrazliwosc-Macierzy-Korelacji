"use client";

import {
	CartesianGrid,
	ComposedChart,
	Line,
	ReferenceArea,
	ResponsiveContainer,
	Scatter,
	XAxis,
	YAxis,
} from "recharts";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";

import { getStoredAuthSession } from "@/features/auth/session";
import { normalizeAuthRole } from "@/features/auth/types";
import { fetchInspectionsTimeAnalytics } from "@/features/reports/api";
import { TableAdvancedFilterModal } from "@/shared/components/table/TableAdvancedFilterModal";
import { TablePagination } from "@/shared/components/table/TablePagination";
import { getFloatingPanelAnchor } from "@/shared/utils/floating-panel";
import type {
	ReportInspectionDetailedRow,
	TimeReportBreakdownValue,
	TimeReportOverallColumn,
	TimeReportOverallRow,
	TimeReportScatterRow,
	TimeReportSummaryPivotRow,
	TimeReportYearCountByTeamRow,
	TimeReportYearCountRow,
	TimeReportTrendMode,
	TimeReportTrendRow,
} from "@/features/reports/types";

type TimeReportPanelProps = {
	operatorLogin: string;
	title: string;
	inspectionType: "K" | "W";
};

type TrendMode = TimeReportTrendMode;
type TimeRibbonTab = "inspection-data" | "time-summary" | "visualization";
type DetailSortDirection = "asc" | "desc";

type ChartPointPayload = {
	year: number;
	time: number;
	nazwaPodmiotu: string;
	kontrola: string;
	osobaKierujaca: string;
	zespol: string;
};

type ChartClickTooltipState =
	| {
			kind: "point";
			x: number;
			y: number;
			data: {
				year: number;
				time: number;
				nazwaPodmiotu: string;
				kontrola: string;
				osobaKierujaca: string;
				zespol: string;
			};
	  }
	| {
			kind: "trend";
			x: number;
			y: number;
			year: number;
			trend: number | null;
	  }
	| {
			kind: "department";
			x: number;
			y: number;
			year: number;
			value: number | null;
			label: string;
	  }
	| null;

const INSPECTIONS_CHANGED_EVENT = "inspections:changed";
const DASHBOARD_OPEN_INSPECTION_EVENT = "dashboard:open-inspection";
const DASHBOARD_OPEN_INSPECTION_CODE_KEY = "triangle.dashboard.openInspectionCode";
const YEAR_BOX_HALF_WIDTH = 0.26;
const CHART_SCROLL_THRESHOLD_YEARS = 6;
const CHART_YEAR_SLOT_WIDTH_PX = 260;
const HISTOGRAM_BINS_PER_YEAR = 8;
const HISTOGRAM_INSET_X = 0.012;
const HISTOGRAM_WIDTH_SHARE = 0.75;
const DETAIL_TABLE_PAGE_SIZE_OPTIONS = [20, 30, 50, 70, 100];

type PaginationItem = number | "ellipsis";

function createRange(start: number, end: number) {
	const length = end - start + 1;
	return Array.from({ length }, (_, index) => index + start);
}

function buildPaginationItems(
	currentPage: number,
	totalPages: number,
	siblingCount = 1,
): PaginationItem[] {
	const totalPageNumbers = siblingCount + 5;

	if (totalPageNumbers >= totalPages) {
		return createRange(1, totalPages);
	}

	const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
	const rightSiblingIndex = Math.min(currentPage + siblingCount, totalPages);

	const shouldShowLeftDots = leftSiblingIndex > 2;
	const shouldShowRightDots = rightSiblingIndex < totalPages - 2;

	if (!shouldShowLeftDots && shouldShowRightDots) {
		const leftItemCount = 3 + 2 * siblingCount;
		const leftRange = createRange(1, leftItemCount);
		return [...leftRange, "ellipsis", totalPages];
	}

	if (shouldShowLeftDots && !shouldShowRightDots) {
		const rightItemCount = 3 + 2 * siblingCount;
		const rightRange = createRange(totalPages - rightItemCount + 1, totalPages);
		return [1, "ellipsis", ...rightRange];
	}

	if (shouldShowLeftDots && shouldShowRightDots) {
		const middleRange = createRange(leftSiblingIndex, rightSiblingIndex);
		return [1, "ellipsis", ...middleRange, "ellipsis", totalPages];
	}

	return createRange(1, totalPages);
}

function TableLoadingOverlay() {
	return (
		<div className="absolute inset-0 z-20 flex items-center justify-center bg-white/70 backdrop-blur-[1px]">
			<div className="flex items-center gap-3 rounded-full border border-slate-200 bg-white/90 px-4 py-2 shadow-[0_8px_20px_rgba(2,8,23,0.15)]">
				<span className="h-4 w-4 animate-spin rounded-full border-2 border-[#7aa5dc] border-t-[#255087]" />
				<span className="font-medium text-slate-700 text-sm">Ładowanie danych...</span>
			</div>
		</div>
	);
}

function openInspectionFromDashboard(inspectionCode: string) {
	const normalizedCode = inspectionCode.trim();
	if (!normalizedCode || typeof window === "undefined") {
		return;
	}

	window.sessionStorage.setItem(
		DASHBOARD_OPEN_INSPECTION_CODE_KEY,
		normalizedCode,
	);
	window.dispatchEvent(
		new CustomEvent(DASHBOARD_OPEN_INSPECTION_EVENT, {
			detail: { inspectionCode: normalizedCode },
		}),
	);
}

function resolveDetailRowInspectionCode(row: ReportInspectionDetailedRow) {
	const fromCode = String(row.kodInspekcji ?? "").trim();
	if (fromCode && fromCode !== "-") {
		return fromCode;
	}

	const fromControl = String(row.kontrola ?? "").trim();
	if (fromControl && fromControl !== "-") {
		return fromControl;
	}

	return "";
}

const DETAIL_COLUMNS: Array<{
	key: keyof ReportInspectionDetailedRow;
	label: string;
	width: string;
}> = [
	{ key: "nazwaPodmiotu", label: "Nazwa podmiotu", width: "min-w-56" },
	{ key: "kontrola", label: "Kontrola", width: "min-w-40" },
	{ key: "rokPoczatku", label: "Rok", width: "min-w-28" },
	{ key: "osobaKierujaca", label: "Osoba kierująca", width: "min-w-44" },
	{ key: "zespol", label: "Zespół osoby kierującej", width: "min-w-40" },
	{ key: "zespolyInspekcji", label: "Zespoły", width: "min-w-32" },
	{ key: "czas", label: "Czas (dni)", width: "min-w-20" },
];

export function TimeReportPanel({
	operatorLogin,
	title,
	inspectionType,
}: TimeReportPanelProps) {
	const trendModeStorageKey = `reports:time-trend-mode:${inspectionType}`;
	const [detailRows, setDetailRows] = useState<ReportInspectionDetailedRow[]>([]);
	const [summaryPivotYears, setSummaryPivotYears] = useState<string[]>([]);
	const [summaryPivotRows, setSummaryPivotRows] = useState<TimeReportSummaryPivotRow[]>([]);
	const [yearCountColumns, setYearCountColumns] = useState<string[]>([]);
	const [yearCountRows, setYearCountRows] = useState<TimeReportYearCountRow[]>([]);
	const [yearCountByTeamColumns, setYearCountByTeamColumns] = useState<string[]>([]);
	const [yearCountByTeamRows, setYearCountByTeamRows] = useState<TimeReportYearCountByTeamRow[]>([]);
	const [overallColumns, setOverallColumns] = useState<TimeReportOverallColumn[]>([]);
	const [overallRows, setOverallRows] = useState<TimeReportOverallRow[]>([]);
	const [departmentMinTime, setDepartmentMinTime] = useState<number | null>(null);
	const [departmentMaxTime, setDepartmentMaxTime] = useState<number | null>(null);
	const [departmentMinTimeByYear, setDepartmentMinTimeByYear] = useState<
		Record<string, number | null>
	>({});
	const [departmentMaxTimeByYear, setDepartmentMaxTimeByYear] = useState<
		Record<string, number | null>
	>({});
	const [myCountByYear, setMyCountByYear] = useState<Record<string, number | null>>({});
	const [myMetricByYearBreakdown, setMyMetricByYearBreakdown] = useState<
		Record<string, TimeReportBreakdownValue>
	>({});
	const [myCountByYearBreakdown, setMyCountByYearBreakdown] = useState<
		Record<string, TimeReportBreakdownValue>
	>({});
	const [myMetricAllYearsBreakdown, setMyMetricAllYearsBreakdown] =
		useState<TimeReportBreakdownValue | null>(null);
	const [myCountAllYearsBreakdown, setMyCountAllYearsBreakdown] =
		useState<TimeReportBreakdownValue | null>(null);
	const [selectedMetricLabel, setSelectedMetricLabel] = useState("Średni czas");
	const [trendRows, setTrendRows] = useState<TimeReportTrendRow[]>([]);
	const [scatterRows, setScatterRows] = useState<TimeReportScatterRow[]>([]);
	const [leaderDisplayNameByLogin, setLeaderDisplayNameByLogin] = useState<
		Record<string, string>
	>({});
	const [teamOptions, setTeamOptions] = useState<string[]>([]);
	const [startYearOptions, setStartYearOptions] = useState<string[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);
	const [trendMode, setTrendMode] = useState<TrendMode>(() => {
		if (typeof window === "undefined") {
			return "average";
		}

		const storedTrendMode = window.sessionStorage.getItem(trendModeStorageKey);
		return storedTrendMode === "median" ? "median" : "average";
	});
	const [selectedTeams, setSelectedTeams] = useState<string[]>([]);
	const [selectedStartYears, setSelectedStartYears] = useState<string[]>([]);
	const [teamSearch, setTeamSearch] = useState("");
	const [yearSearch, setYearSearch] = useState("");
	const [detailColumnFilters, setDetailColumnFilters] = useState<
		Partial<Record<keyof ReportInspectionDetailedRow, string>>
	>({});
	const [detailSortColumnKey, setDetailSortColumnKey] = useState<
		keyof ReportInspectionDetailedRow | null
	>(null);
	const [detailSortDirection, setDetailSortDirection] =
		useState<DetailSortDirection | null>(null);
	const [detailCurrentPage, setDetailCurrentPage] = useState(1);
	const [detailPageSize, setDetailPageSize] = useState(30);
	const [detailAdvancedFilters, setDetailAdvancedFilters] = useState<
		Partial<Record<keyof ReportInspectionDetailedRow, string[]>>
	>({});
	const [isDetailAdvancedFilterModalOpen, setIsDetailAdvancedFilterModalOpen] =
		useState(false);
	const [detailAdvancedFilterColumnKey, setDetailAdvancedFilterColumnKey] =
		useState<keyof ReportInspectionDetailedRow>("nazwaPodmiotu");
	const [detailAdvancedFilterSearch, setDetailAdvancedFilterSearch] = useState("");
	const [detailAdvancedFilterAnchor, setDetailAdvancedFilterAnchor] = useState({
		top: 120,
		left: 120,
	});
	const [activeRibbonTab, setActiveRibbonTab] = useState<TimeRibbonTab>(
		"inspection-data",
	);
	const [showHistogram, setShowHistogram] = useState(false);
	const [showScatterPoints, setShowScatterPoints] = useState(true);
	const [chartClickTooltip, setChartClickTooltip] =
		useState<ChartClickTooltipState>(null);
	const authRole = useMemo(() => {
		const storedRole = getStoredAuthSession()?.user?.rola;
		return normalizeAuthRole(storedRole);
	}, []);

	const isManagerView = authRole === "director" || authRole === "team_lead";

	useEffect(() => {
		if (isManagerView) {
			return;
		}

		setSelectedTeams([]);
		setTeamSearch("");
	}, [isManagerView]);

	useEffect(() => {
		if (isManagerView) {
			return;
		}

		setShowHistogram(false);
		setShowScatterPoints(true);
	}, [isManagerView]);

	useEffect(() => {
		let isActive = true;

		const loadPeopleOptions = async () => {
			try {
				const response = await fetch("/api/inspections/people-options", {
					method: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Operator-Login": operatorLogin,
					},
					cache: "no-store",
				});

				if (!response.ok) {
					if (isActive) {
						setLeaderDisplayNameByLogin({});
					}
					return;
				}

				const payload = (await response.json()) as unknown;
				const users = Array.isArray(payload)
					? payload
					: Array.isArray((payload as { items?: unknown[] })?.items)
						? (((payload as { items?: unknown[] }).items ?? []) as unknown[])
						: [];

				const next: Record<string, string> = {};
				for (const user of users) {
					const source = (user ?? {}) as {
						login?: unknown;
						displayName?: unknown;
						imie?: unknown;
						nazwisko?: unknown;
					};
					const login =
						typeof source.login === "string" ? source.login.trim().toLowerCase() : "";
					if (!login) {
						continue;
					}

					const firstName = typeof source.imie === "string" ? source.imie.trim() : "";
					const lastName =
						typeof source.nazwisko === "string" ? source.nazwisko.trim() : "";
					const fullName = `${firstName} ${lastName}`.trim();
					const displayName =
						typeof source.displayName === "string" ? source.displayName.trim() : "";

					next[login] = fullName || displayName || login;
				}

				if (isActive) {
					setLeaderDisplayNameByLogin(next);
				}
			} catch {
				if (isActive) {
					setLeaderDisplayNameByLogin({});
				}
			}
		};

		void loadPeopleOptions();

		return () => {
			isActive = false;
		};
	}, [operatorLogin]);

	const resolveLeaderDisplayName = useCallback(
		(value: string) => {
			const normalized = value.trim();
			if (!normalized || normalized === "-") {
				return "-";
			}

			return leaderDisplayNameByLogin[normalized.toLowerCase()] ?? normalized;
		},
		[leaderDisplayNameByLogin],
	);

	const detailRowsWithDisplayNames = useMemo(
		() =>
			detailRows.map((row) => ({
				...row,
				osobaKierujaca: resolveLeaderDisplayName(row.osobaKierujaca),
			})),
		[detailRows, resolveLeaderDisplayName],
	);

	const scatterRowsWithDisplayNames = useMemo(
		() =>
			scatterRows.map((row) => ({
				...row,
				osobaKierujaca: resolveLeaderDisplayName(row.osobaKierujaca),
			})),
		[resolveLeaderDisplayName, scatterRows],
	);

	const loadReport = useCallback(async () => {
		setIsLoading(true);
		setError(null);

		const teamsForRequest = isManagerView ? selectedTeams : [];

		const result = await fetchInspectionsTimeAnalytics(operatorLogin, {
			inspectionType,
			trendMode,
			teams: teamsForRequest,
			years: selectedStartYears,
		});
		if (!result.ok) {
			setDetailRows([]);
			setSummaryPivotYears([]);
			setSummaryPivotRows([]);
			setYearCountColumns([]);
			setYearCountRows([]);
			setYearCountByTeamColumns([]);
			setYearCountByTeamRows([]);
			setOverallColumns([]);
			setOverallRows([]);
			setDepartmentMinTime(null);
			setDepartmentMaxTime(null);
			setDepartmentMinTimeByYear({});
			setDepartmentMaxTimeByYear({});
			setMyCountByYear({});
			setMyMetricByYearBreakdown({});
			setMyCountByYearBreakdown({});
			setMyMetricAllYearsBreakdown(null);
			setMyCountAllYearsBreakdown(null);
			setSelectedMetricLabel(trendMode === "average" ? "Średni czas" : "Mediana czasu");
			setTrendRows([]);
			setScatterRows([]);
			setTeamOptions([]);
			setStartYearOptions([]);
			setError(result.error);
			setIsLoading(false);
			return;
		}

		setDetailRows(result.data.detailRows);
		setSummaryPivotYears(result.data.summaryPivotYears);
		setSummaryPivotRows(result.data.summaryPivotRows);
		setYearCountColumns(result.data.yearCountColumns);
		setYearCountRows(result.data.yearCountRows);
		setYearCountByTeamColumns(result.data.yearCountByTeamColumns);
		setYearCountByTeamRows(result.data.yearCountByTeamRows);
		setOverallColumns(result.data.overallColumns);
		setOverallRows(result.data.overallRows);
		setDepartmentMinTime(result.data.departmentMinTime);
		setDepartmentMaxTime(result.data.departmentMaxTime);
		setDepartmentMinTimeByYear(result.data.departmentMinTimeByYear);
		setDepartmentMaxTimeByYear(result.data.departmentMaxTimeByYear);
		setMyCountByYear(result.data.myCountByYear);
		setMyMetricByYearBreakdown(result.data.myMetricByYearBreakdown);
		setMyCountByYearBreakdown(result.data.myCountByYearBreakdown);
		setMyMetricAllYearsBreakdown(result.data.myMetricAllYearsBreakdown);
		setMyCountAllYearsBreakdown(result.data.myCountAllYearsBreakdown);
		setSelectedMetricLabel(result.data.selectedMetricLabel);
		setTrendRows(result.data.trendRows);
		setScatterRows(result.data.scatterRows);
		setTeamOptions(result.data.teamOptions);
		setStartYearOptions(result.data.yearOptions);
		setIsLoading(false);
	}, [
		isManagerView,
		inspectionType,
		operatorLogin,
		selectedStartYears,
		selectedTeams,
		trendMode,
	]);

	useEffect(() => {
		loadReport();
	}, [loadReport]);

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		window.sessionStorage.setItem(trendModeStorageKey, trendMode);
	}, [trendMode, trendModeStorageKey]);

	useEffect(() => {
		setChartClickTooltip(null);
	}, [activeRibbonTab, showScatterPoints, trendMode, trendRows, scatterRows]);

	useEffect(() => {
		const handleInspectionsChanged = () => {
			void loadReport();
		};

		window.addEventListener(INSPECTIONS_CHANGED_EVENT, handleInspectionsChanged);
		return () => {
			window.removeEventListener(INSPECTIONS_CHANGED_EVENT, handleInspectionsChanged);
		};
	}, [loadReport]);

	const clearFilters = useCallback(() => {
		setSelectedTeams([]);
		setSelectedStartYears([]);
		setTeamSearch("");
		setYearSearch("");
		setDetailColumnFilters({});
		setDetailAdvancedFilters({});
		setDetailAdvancedFilterSearch("");
		setIsDetailAdvancedFilterModalOpen(false);
	}, []);

	const handleDetailColumnFilterChange = useCallback(
		(columnKey: keyof ReportInspectionDetailedRow, value: string) => {
			setDetailColumnFilters((previous) => ({
				...previous,
				[columnKey]: value,
			}));
		},
		[],
	);

	const handleDetailSortByColumn = useCallback(
		(columnKey: keyof ReportInspectionDetailedRow) => {
			if (detailSortColumnKey !== columnKey) {
				setDetailSortColumnKey(columnKey);
				setDetailSortDirection("asc");
				return;
			}

			if (detailSortDirection === "asc") {
				setDetailSortDirection("desc");
				return;
			}

			if (detailSortDirection === "desc") {
				setDetailSortColumnKey(null);
				setDetailSortDirection(null);
				return;
			}

			setDetailSortDirection("asc");
		},
		[detailSortColumnKey, detailSortDirection],
	);

	const hasActiveDetailColumnFilters = useMemo(
		() =>
			Object.values(detailColumnFilters).some(
				(value) => typeof value === "string" && value.trim().length > 0,
			),
		[detailColumnFilters],
	);

	const hasActiveDetailAdvancedFilters = useMemo(
		() =>
			Object.values(detailAdvancedFilters).some(
				(values) => Array.isArray(values) && values.length > 0,
			),
		[detailAdvancedFilters],
	);

	const canClearDetailFilters = useMemo(
		() => hasActiveDetailColumnFilters || hasActiveDetailAdvancedFilters,
		[hasActiveDetailAdvancedFilters, hasActiveDetailColumnFilters],
	);

	const detailAdvancedFilterValuesByColumn = useMemo(() => {
		const next: Partial<Record<keyof ReportInspectionDetailedRow, string[]>> = {};

		for (const column of DETAIL_COLUMNS) {
			const uniqueValues = Array.from(
				new Set(
					detailRowsWithDisplayNames.map((row) => {
						const normalized = String(row[column.key] ?? "").trim();
						return normalized || "(puste)";
					}),
				),
			).sort((left, right) =>
				left.localeCompare(right, "pl", { sensitivity: "base", numeric: true }),
			);

			next[column.key] = uniqueValues;
		}

		return next;
	}, [detailRowsWithDisplayNames]);

	const selectedDetailAdvancedFilterValues = useMemo(
		() => detailAdvancedFilters[detailAdvancedFilterColumnKey] ?? [],
		[detailAdvancedFilterColumnKey, detailAdvancedFilters],
	);

	const visibleDetailAdvancedFilterValues = useMemo(() => {
		const values = detailAdvancedFilterValuesByColumn[detailAdvancedFilterColumnKey] ?? [];
		const query = detailAdvancedFilterSearch.trim().toLowerCase();

		if (!query) {
			return values;
		}

		return values.filter((value) => value.toLowerCase().includes(query));
	}, [
		detailAdvancedFilterColumnKey,
		detailAdvancedFilterSearch,
		detailAdvancedFilterValuesByColumn,
	]);

	const openDetailAdvancedFilterForColumn = useCallback(
		(columnKey: keyof ReportInspectionDetailedRow, triggerElement: HTMLElement) => {
			setDetailAdvancedFilterAnchor(getFloatingPanelAnchor(triggerElement));
			setDetailAdvancedFilterColumnKey(columnKey);
			setDetailAdvancedFilterSearch("");
			setIsDetailAdvancedFilterModalOpen(true);
		},
		[],
	);

	const toggleDetailAdvancedFilterValue = useCallback(
		(value: string) => {
			setDetailAdvancedFilters((previous) => {
				const currentValues = previous[detailAdvancedFilterColumnKey] ?? [];
				const nextValues = currentValues.includes(value)
					? currentValues.filter((item) => item !== value)
					: [...currentValues, value];

				return {
					...previous,
					[detailAdvancedFilterColumnKey]: nextValues,
				};
			});
		},
		[detailAdvancedFilterColumnKey],
	);

	const selectAllVisibleDetailAdvancedFilterValues = useCallback(() => {
		setDetailAdvancedFilters((previous) => {
			const currentValues = new Set(previous[detailAdvancedFilterColumnKey] ?? []);
			for (const value of visibleDetailAdvancedFilterValues) {
				currentValues.add(value);
			}

			return {
				...previous,
				[detailAdvancedFilterColumnKey]: Array.from(currentValues),
			};
		});
	}, [detailAdvancedFilterColumnKey, visibleDetailAdvancedFilterValues]);

	const clearDetailAdvancedFilterForSelectedColumn = useCallback(() => {
		setDetailAdvancedFilters((previous) => ({
			...previous,
			[detailAdvancedFilterColumnKey]: [],
		}));
	}, [detailAdvancedFilterColumnKey]);

	const yearBuckets = useMemo(
		() =>
			Array.from(new Set(trendRows.map((point) => point.year))).sort(
				(left, right) => left - right,
			),
		[trendRows],
	);

	const yearToIndex = useMemo(
		() => new Map(yearBuckets.map((year, index) => [year, index])),
		[yearBuckets],
	);

	const chartPointsData = useMemo(() => {
		const pointsByYear = new Map<number, typeof scatterRowsWithDisplayNames>();

		for (const point of scatterRowsWithDisplayNames) {
			const bucket = pointsByYear.get(point.year) ?? [];
			bucket.push(point);
			pointsByYear.set(point.year, bucket);
		}

		return Array.from(pointsByYear.entries()).flatMap(([year, points]) => {
			const yearIndex = yearToIndex.get(year) ?? 0;
			const pointsCenterX = yearIndex;

			return points
				.slice()
				.sort((left, right) => left.time - right.time)
				.map((point) => ({
					...point,
					x: pointsCenterX,
				}));
		});
	}, [scatterRowsWithDisplayNames, yearToIndex]);

	const departmentTrendByYear = useMemo(() => {
		const toNumeric = (value: string | number | null | undefined) => {
			if (typeof value === "number" && Number.isFinite(value)) {
				return value;
			}

			if (typeof value === "string") {
				const parsed = Number(value.replace(",", ".").trim());
				if (Number.isFinite(parsed)) {
					return parsed;
				}
			}

			return null;
		};

		const departmentRow = summaryPivotRows.find((row) =>
			row.zespol.trim().toLowerCase().includes("departament"),
		);
		if (!departmentRow) {
			return new Map<number, number | null>();
		}

		return new Map(
			Object.entries(departmentRow.values)
				.map(([year, value]) => [Number(year), toNumeric(value)] as const)
				.filter(([year]) => Number.isFinite(year)),
		);
	}, [summaryPivotRows]);

	const chartTrendData = useMemo(
		() =>
			trendRows.map((row) => ({
				...row,
				x: yearToIndex.get(row.year) ?? 0,
				departmentTrend: departmentTrendByYear.get(row.year) ?? null,
			})),
		[departmentTrendByYear, trendRows, yearToIndex],
	);

	const handleChartBackgroundClick = useCallback(() => {
		setChartClickTooltip(null);
	}, []);

	const openPointTooltip = useCallback(
		(point: ChartPointPayload, x: number, y: number) => {
			setChartClickTooltip({
				kind: "point",
				x,
				y,
				data: point,
			});
		},
		[],
	);

	const openTrendTooltip = useCallback(
		(point: { year: number; trend: number | null }, x: number, y: number) => {
			setChartClickTooltip({
				kind: "trend",
				x,
				y,
				year: point.year,
				trend: point.trend,
			});
		},
		[],
	);

	const openDepartmentTooltip = useCallback(
		(
			point: { year: number; departmentTrend: number | null },
			x: number,
			y: number,
			label: string,
		) => {
			setChartClickTooltip({
				kind: "department",
				x,
				y,
				year: point.year,
				value: point.departmentTrend,
				label,
			});
		},
		[],
	);

	const renderScatterPoint = useCallback(
		(rawProps: unknown) => {
			const props = rawProps as {
				cx?: number;
				cy?: number;
				payload?: ChartPointPayload;
				index?: number;
			};
			const scatterKey = props.payload
				? `scatter-${props.payload.year}-${props.payload.nazwaPodmiotu}-${props.payload.kontrola}-${props.payload.time}`
				: `scatter-empty-${props.index ?? "unknown"}`;
			if (
				typeof props.cx !== "number" ||
				typeof props.cy !== "number" ||
				!props.payload
			) {
				return <g key={scatterKey} />;
			}

			return (
				<g
					key={scatterKey}
					style={{ cursor: "pointer" }}
					onClick={(event) => {
						event.stopPropagation();
						openPointTooltip(
							props.payload as ChartPointPayload,
							props.cx as number,
							props.cy as number,
						);
					}}
				>
					{isManagerView ? (
						<>
							<circle cx={props.cx} cy={props.cy} r={8.5} fill="#5d8fc9" fillOpacity={0.22} />
							<circle
								cx={props.cx}
								cy={props.cy}
								r={6}
								fill="#3f6ea8"
								stroke="#f8fbff"
								strokeWidth={1.7}
							/>
							<circle cx={props.cx} cy={props.cy} r={1.9} fill="#dbeafe" />
						</>
					) : (
						<circle
							cx={props.cx}
							cy={props.cy}
							r={6}
							fill="#3f6ea8"
							stroke="#f8fbff"
							strokeWidth={1.6}
						/>
					)}
				</g>
			);
		},
		[isManagerView, openPointTooltip],
	);

	const renderTrendDot = useCallback(
		(rawProps: unknown) => {
			const props = rawProps as {
				cx?: number;
				cy?: number;
				payload?: { year: number; trend: number | null };
				index?: number;
			};
			const trendKey = props.payload
				? `trend-${props.payload.year}`
				: `trend-empty-${props.index ?? "unknown"}`;
			if (
				typeof props.cx !== "number" ||
				typeof props.cy !== "number" ||
				!props.payload
			) {
				return <g key={trendKey} />;
			}

			if (props.payload.trend === null) {
				return <g key={trendKey} />;
			}

			return (
				<path
					key={trendKey}
					d={`M ${props.cx} ${props.cy - 7} L ${props.cx - 6.2} ${props.cy + 5} L ${props.cx + 6.2} ${props.cy + 5} Z`}
					fill="#255087"
					style={{ cursor: "pointer" }}
					onClick={(event) => {
						event.stopPropagation();
						openTrendTooltip(props.payload as { year: number; trend: number | null }, props.cx as number, props.cy as number);
					}}
				/>
			);
		},
		[openTrendTooltip],
	);

	const renderDepartmentTrendDot = useCallback((rawProps: unknown) => {
		const props = rawProps as {
			cx?: number;
			cy?: number;
			payload?: { year: number; departmentTrend?: number | null };
			index?: number;
		};
		const key = `department-trend-${props.index ?? "unknown"}`;
		if (
			typeof props.cx !== "number" ||
			typeof props.cy !== "number" ||
			!props.payload ||
			props.payload.departmentTrend === null ||
			props.payload.departmentTrend === undefined
		) {
			return <g key={key} />;
		}

		return (
			<rect
				key={key}
				x={props.cx - 5.5}
				y={props.cy - 5.5}
				width={11}
				height={11}
				fill="#dc2626"
				rx={1.3}
				style={{ cursor: "pointer" }}
				onClick={(event) => {
					event.stopPropagation();
					openDepartmentTooltip(
						{
							year: props.payload?.year ?? 0,
							departmentTrend: props.payload?.departmentTrend ?? null,
						},
						props.cx as number,
						props.cy as number,
						`${trendMode === "average" ? "Średnia" : "Mediana"} departamentu`,
					);
				}}
			/>
		);
	}, [openDepartmentTooltip, trendMode]);

	const renderDepartmentRangeDot = useCallback(
		(rawProps: unknown) => {
			const props = rawProps as {
				cx?: number;
				cy?: number;
				payload?: { year?: number; value?: number | null; label?: string };
				index?: number;
			};

			if (
				typeof props.cx !== "number" ||
				typeof props.cy !== "number" ||
				!props.payload ||
				typeof props.payload.value !== "number" ||
				!Number.isFinite(props.payload.value)
			) {
				return <g key={`department-range-empty-${props.index ?? "unknown"}`} />;
			}

			const markerKey = `department-range-${props.payload.year ?? props.index ?? "unknown"}-${props.payload.label ?? "value"}`;
			const arm = 5;
			const dashGap = 7;
			const dashLength = 10;

			return (
				<g
					key={markerKey}
					style={{ cursor: "pointer" }}
					onClick={(event) => {
						event.stopPropagation();
						openDepartmentTooltip(
							{
								year: props.payload?.year ?? 0,
								departmentTrend: props.payload?.value ?? null,
							},
							props.cx as number,
							props.cy as number,
							props.payload?.label ?? "Wartość departamentu",
						);
					}}
				>
					<line
						x1={props.cx - arm}
						y1={props.cy - arm}
						x2={props.cx + arm}
						y2={props.cy + arm}
						stroke="#dc2626"
						strokeWidth={2.2}
						strokeLinecap="round"
					/>
					<line
						x1={props.cx - arm}
						y1={props.cy + arm}
						x2={props.cx + arm}
						y2={props.cy - arm}
						stroke="#dc2626"
						strokeWidth={2.2}
						strokeLinecap="round"
					/>
					<line
						x1={props.cx - dashGap - dashLength}
						y1={props.cy}
						x2={props.cx - dashGap}
						y2={props.cy}
						stroke="#ea580c"
						strokeWidth={3}
						strokeLinecap="round"
					/>
					<line
						x1={props.cx + dashGap}
						y1={props.cy}
						x2={props.cx + dashGap + dashLength}
						y2={props.cy}
						stroke="#ea580c"
						strokeWidth={3}
						strokeLinecap="round"
					/>
				</g>
			);
		},
		[openDepartmentTooltip],
	);

	const shouldEnableChartScroll = useMemo(
		() => yearBuckets.length > CHART_SCROLL_THRESHOLD_YEARS,
		[yearBuckets.length],
	);

	const chartScrollableWidthPx = useMemo(
		() => yearBuckets.length * CHART_YEAR_SLOT_WIDTH_PX,
		[yearBuckets.length],
	);

	const xAxisDomain = useMemo<[number, number]>(() => {
		if (yearBuckets.length === 0) {
			return [-0.5, 0.5];
		}

		if (yearBuckets.length === 1) {
			return [-0.6, 0.6];
		}

		return [-0.5, yearBuckets.length - 0.5];
	}, [yearBuckets]);

	const yAxisDomain = useMemo<[number, number]>(() => {
		const scatterValues = scatterRowsWithDisplayNames.map((point) => point.time);
		const departmentExtremes =
			departmentMinTime !== null && departmentMaxTime !== null
				? [departmentMinTime, departmentMaxTime]
				: [];
		const departmentYearExtremes = [
			...Object.values(departmentMinTimeByYear),
			...Object.values(departmentMaxTimeByYear),
		].filter((value): value is number => typeof value === "number" && Number.isFinite(value));
		const trendExtremes = chartTrendData.flatMap((point) => {
			const minValue = point.departmentMinTime ?? point.min;
			const maxValue = point.departmentMaxTime ?? point.max;
			if (minValue === null || maxValue === null) {
				return [] as number[];
			}

			return [minValue, maxValue];
		});
		const values = [
			...scatterValues,
			...departmentExtremes,
			...departmentYearExtremes,
			...trendExtremes,
		];

		if (values.length === 0) {
			return [0, 10];
		}
		const minValue = Math.min(...values);
		const maxValue = Math.max(...values);

		if (minValue === maxValue) {
			return [Math.max(0, minValue - 10), maxValue + 10];
		}

		const range = maxValue - minValue;
		const padding = Math.max(6, Math.round(range * 0.12));
		return [Math.max(0, minValue - padding), maxValue + padding];
	}, [
		chartTrendData,
		departmentMaxTime,
		departmentMaxTimeByYear,
		departmentMinTime,
		departmentMinTimeByYear,
		scatterRowsWithDisplayNames,
	]);

	const yearRangeAreas = useMemo(() => {
		return chartTrendData.flatMap((yearData) => {
			const yearKey = String(yearData.year);
			const minSource = departmentMinTimeByYear[yearKey] ?? null;
			const maxSource = departmentMaxTimeByYear[yearKey] ?? null;

			if (minSource === null || maxSource === null) {
				return [];
			}

			const y1 = Math.min(minSource, maxSource);
			const y2 = Math.max(minSource, maxSource);
			const top = y1 === y2 ? y2 + 1 : y2;

			return {
				key: `range-${yearData.year}`,
				year: yearData.year,
				x: yearData.x,
				y1,
				y2: top,
			};
		});
	}, [
		chartTrendData,
		departmentMaxTimeByYear,
		departmentMinTimeByYear,
	]);

	const departmentRangePoints = useMemo(
		() =>
			yearRangeAreas.flatMap((area) => [
				{
					key: `department-min-${area.year}`,
					year: area.year,
					x: area.x,
					value: area.y1,
					label: "Minimum departamentu",
				},
				{
					key: `department-max-${area.year}`,
					year: area.year,
					x: area.x,
					value: area.y2,
					label: "Maksimum departamentu",
				},
			]),
		[yearRangeAreas],
	);

	const histogramAreas = useMemo(() => {
		if (yearRangeAreas.length === 0 || scatterRowsWithDisplayNames.length === 0) {
			return [] as Array<{
				key: string;
				x1: number;
				x2: number;
				y1: number;
				y2: number;
				opacity: number;
			}>;
		}

		const pointsByYear = new Map<number, number[]>();

		for (const point of scatterRowsWithDisplayNames) {
			const yearPoints = pointsByYear.get(point.year) ?? [];
			yearPoints.push(point.time);
			pointsByYear.set(point.year, yearPoints);
		}

		const areas: Array<{
			key: string;
			x1: number;
			x2: number;
			y1: number;
			y2: number;
			opacity: number;
		}> = [];

		for (const rangeArea of yearRangeAreas) {
			const times = pointsByYear.get(rangeArea.year) ?? [];
			if (times.length === 0) {
				continue;
			}

			const innerLeft = rangeArea.x - YEAR_BOX_HALF_WIDTH + HISTOGRAM_INSET_X;
			const innerRight = rangeArea.x + YEAR_BOX_HALF_WIDTH - HISTOGRAM_INSET_X;
			const innerWidth = Math.max(0.001, innerRight - innerLeft);
			const histogramRight = innerLeft + innerWidth * HISTOGRAM_WIDTH_SHARE;
			const histogramWidth = Math.max(0.001, histogramRight - innerLeft);
			const valueMin = Math.min(rangeArea.y1, rangeArea.y2);
			const valueMax = Math.max(rangeArea.y1, rangeArea.y2);
			const valueRange = Math.max(1e-6, valueMax - valueMin);
			const counts = Array.from({ length: HISTOGRAM_BINS_PER_YEAR }, () => 0);

			for (const time of times) {
				const clampedTime = Math.min(valueMax - 1e-6, Math.max(valueMin, time));
				const normalized = Math.min(0.999999, Math.max(0, (clampedTime - valueMin) / valueRange));
				const binIndex = Math.floor(normalized * HISTOGRAM_BINS_PER_YEAR);
				counts[binIndex]! += 1;
			}

			const maxCount = Math.max(...counts, 1);

			for (let binIndex = 0; binIndex < HISTOGRAM_BINS_PER_YEAR; binIndex += 1) {
				const count = counts[binIndex] ?? 0;
				if (count === 0) {
					continue;
				}

				const ratio = count / maxCount;
				const barWidth = Math.max(0.004, histogramWidth * ratio);
				const y1 = valueMin + (binIndex / HISTOGRAM_BINS_PER_YEAR) * valueRange;
				const y2 = valueMin + ((binIndex + 1) / HISTOGRAM_BINS_PER_YEAR) * valueRange;

				areas.push({
					key: `hist-${rangeArea.year}-${binIndex}`,
					x1: innerLeft,
					x2: Math.min(histogramRight, innerLeft + barWidth),
					y1,
					y2,
					opacity: 0.14 + ratio * 0.26,
				});
			}
		}

		return areas;
	}, [scatterRowsWithDisplayNames, yearRangeAreas]);

	const formatMetricValue = useCallback((value: number) => {
		return Number.isFinite(value) ? value.toFixed(1) : "0.0";
	}, []);

	const formatSummaryCellValue = useCallback(
		(value: string | number | null) => {
			if (value === null || value === undefined || value === "") {
				return "-";
			}

			if (typeof value === "number") {
				return formatMetricValue(value);
			}

			if (value.trim() !== "") {
				const parsed = Number(value.replace(",", "."));
				if (Number.isFinite(parsed)) {
					return formatMetricValue(parsed);
				}
			}

			return value;
		},
		[formatMetricValue],
	);

		const formatCountCellValue = useCallback((value: string | number | null) => {
			if (value === null || value === undefined || value === "") {
				return "-";
			}

			if (typeof value === "number") {
				return Number.isInteger(value) ? String(value) : String(value);
			}

			const normalized = value.trim();
			if (!normalized) {
				return "-";
			}

			const parsed = Number(normalized.replace(",", "."));
			if (Number.isFinite(parsed)) {
				return Number.isInteger(parsed) ? String(parsed) : String(parsed);
			}

			return normalized;
		}, []);

		const formatMetricBreakdownPair = useCallback(
			(breakdown?: TimeReportBreakdownValue | null) => {
				const leader = breakdown?.leader ?? null;
				const member = breakdown?.member ?? null;
				const combined = breakdown?.combined ?? null;
				const hasLeader = leader !== null;
				const hasMember = member !== null;

				if (hasLeader || hasMember) {
					return `${hasLeader ? formatMetricValue(leader) : "-"} / ${
						hasMember ? formatMetricValue(member) : "-"
					}`;
				}

				if (combined !== null) {
					return formatMetricValue(combined);
				}

				return "-";
			},
			[formatMetricValue],
		);

		const formatCountBreakdownPair = useCallback(
			(breakdown?: TimeReportBreakdownValue | null) => {
				const leader = breakdown?.leader ?? null;
				const member = breakdown?.member ?? null;
				const combined = breakdown?.combined ?? null;
				const hasLeader = leader !== null;
				const hasMember = member !== null;

				if (hasLeader || hasMember) {
					return `${hasLeader ? formatCountCellValue(leader) : "-"} / ${
						hasMember ? formatCountCellValue(member) : "-"
					}`;
				}

				if (combined !== null) {
					return formatCountCellValue(combined);
				}

				return "-";
			},
			[formatCountCellValue],
		);

	const renderInspectorSplitValue = useCallback((value: string) => {
		const [leftRaw, rightRaw, ...rest] = value.split("/");
		if (rest.length > 0) {
			return value;
		}

		const left = String(leftRaw ?? "").trim();
		const right = String(rightRaw ?? "").trim();
		if (!left || !right) {
			return value;
		}

		return (
			<span className="inline-flex items-center gap-1.5 whitespace-nowrap">
				<span className="rounded-md bg-[#d8ecff] px-1.5 py-0.5 font-semibold text-[#184f81]">
					{left}
				</span>
				<span className="text-slate-500">/</span>
				<span className="rounded-md bg-[#ffe8c8] px-1.5 py-0.5 font-semibold text-[#8a4f08]">
					{right}
				</span>
			</span>
		);
	}, []);

	const sortedDetailRows = useMemo(() => {
		const normalizedFilters = DETAIL_COLUMNS.map((column) => ({
			key: column.key,
			value: (detailColumnFilters[column.key] ?? "").trim().toLowerCase(),
		})).filter((entry) => entry.value.length > 0);

		const advancedFilters = DETAIL_COLUMNS.map((column) => ({
			key: column.key,
			selectedValues: detailAdvancedFilters[column.key] ?? [],
		})).filter((entry) => entry.selectedValues.length > 0);

		const filteredRows = detailRowsWithDisplayNames.filter((row) => {
			const matchesTextFilters = normalizedFilters.every((filterEntry) => {
				const cellValue = String(row[filterEntry.key] ?? "").toLowerCase();
				return cellValue.includes(filterEntry.value);
			});

			if (!matchesTextFilters) {
				return false;
			}

			return advancedFilters.every((filterEntry) => {
				const normalized = String(row[filterEntry.key] ?? "").trim();
				const comparableCellValue = normalized || "(puste)";
				return filterEntry.selectedValues.includes(comparableCellValue);
			});
		});

		if (!detailSortColumnKey || !detailSortDirection) {
			return filteredRows;
		}

		const directionMultiplier = detailSortDirection === "asc" ? 1 : -1;

		return [...filteredRows].sort((leftRow, rightRow) => {
			const leftValue = String(leftRow[detailSortColumnKey] ?? "");
			const rightValue = String(rightRow[detailSortColumnKey] ?? "");

			return (
				leftValue.localeCompare(rightValue, "pl", {
					numeric: true,
					sensitivity: "base",
				}) * directionMultiplier
			);
		});
	}, [
		detailAdvancedFilters,
		detailColumnFilters,
		detailRowsWithDisplayNames,
		detailSortColumnKey,
		detailSortDirection,
	]);

	const detailTotalPages = useMemo(
		() => Math.max(1, Math.ceil(sortedDetailRows.length / detailPageSize)),
		[detailPageSize, sortedDetailRows.length],
	);

	useEffect(() => {
		setDetailCurrentPage(1);
	}, [
		detailAdvancedFilters,
		detailColumnFilters,
		detailSortColumnKey,
		detailSortDirection,
		sortedDetailRows.length,
		detailTotalPages,
	]);

	useEffect(() => {
		setDetailCurrentPage((previous) => Math.min(Math.max(previous, 1), detailTotalPages));
	}, [detailTotalPages]);

	const detailPaginatedRows = useMemo(() => {
		const startIndex = (detailCurrentPage - 1) * detailPageSize;
		const endIndex = startIndex + detailPageSize;
		return sortedDetailRows.slice(startIndex, endIndex);
	}, [detailCurrentPage, detailPageSize, sortedDetailRows]);

	const detailPaginationItems = useMemo(
		() => buildPaginationItems(detailCurrentPage, detailTotalPages),
		[detailCurrentPage, detailTotalPages],
	);

	const handleDetailPageChange = useCallback(
		(nextPage: number) => {
			if (!Number.isFinite(nextPage)) {
				return;
			}

			const normalizedPage = Math.trunc(nextPage);
			const boundedPage = Math.min(Math.max(normalizedPage, 1), detailTotalPages);
			setDetailCurrentPage(boundedPage);
		},
		[detailTotalPages],
	);

	const handleDetailPageSizeChange = useCallback((nextPageSize: number) => {
		if (!Number.isFinite(nextPageSize)) {
			return;
		}

		const normalizedPageSize = Math.max(1, Math.trunc(nextPageSize));
		setDetailPageSize(normalizedPageSize);
	}, []);

	const metricLegendLabel = trendMode === "average" ? "Mój średni czas" : "Moja mediana";
	const metricLegendTitleLabel = trendMode === "average" ? "Średnia" : "Mediana";
	const shouldScrollSummaryTable = summaryPivotRows.length > 10;
	const metricColumnKey = trendMode === "average" ? "average" : "median";
	const metricColumnLabel = trendMode === "average" ? "Średnia" : "Mediana";
	const documentLabelGenitive = inspectionType === "K" ? "protokołu" : "sprawozdania";
	const volumeLabel = inspectionType === "K" ? "kontroli" : "wizyt nadzorczych";
	const yearlyTimeSectionTitle = `${metricColumnLabel} czasu przygotowania ${documentLabelGenitive} wg roku`;
	const yearlyCountSectionTitle = `Liczba ${volumeLabel} wg roku`;
	const allYearsSectionTitle = "Statystyka i liczba dla wszystkich lat w całym Departamencie";
	const summaryPivotColumns = useMemo(() => {
		return summaryPivotYears
			.filter((key) => key !== "allYears")
			.map((key) => ({
			key,
			label: key,
		}));
	}, [summaryPivotYears]);

	const displaySummaryPivotRows = useMemo(() => {
		if (isManagerView) {
			return summaryPivotRows;
		}

		const hasMetricBreakdown = summaryPivotColumns.some((column) => {
			const breakdown = myMetricByYearBreakdown[column.key];
			return (
				breakdown !== undefined &&
				(breakdown.leader !== null ||
					breakdown.member !== null ||
					breakdown.combined !== null)
			);
		});

		if (!hasMetricBreakdown) {
			return summaryPivotRows;
		}

		const normalizeLabel = (value: string) => value.trim().toLowerCase();
		const isDepartment = (value: string) => normalizeLabel(value).includes("departament");
		const isMyTime = (value: string) => {
			const normalized = normalizeLabel(value);
			return normalized.includes("mój czas") || normalized.includes("moj czas");
		};

		const departmentRow = summaryPivotRows.find((row) => isDepartment(row.zespol)) ?? null;
		const teamRows = summaryPivotRows.filter(
			(row) => !isDepartment(row.zespol) && !isMyTime(row.zespol),
		);

		const myTimeValues: Record<string, string | number | null> = {};
		for (const column of summaryPivotColumns) {
			const breakdown = myMetricByYearBreakdown[column.key];
			myTimeValues[column.key] = formatMetricBreakdownPair(breakdown);
		}

		const rows: TimeReportSummaryPivotRow[] = [];
		if (departmentRow) {
			rows.push(departmentRow);
		}
		if (teamRows.length > 0) {
			rows.push(...teamRows);
		}

		rows.push({ zespol: "Mój czas", values: myTimeValues });

		return rows;
	}, [
		formatMetricBreakdownPair,
		isManagerView,
		myMetricByYearBreakdown,
		summaryPivotColumns,
		summaryPivotRows,
	]);

	const resolvedYearCountColumns = useMemo(() => {
		if (yearCountByTeamColumns.length > 0) {
			return yearCountByTeamColumns;
		}

		if (yearCountColumns.length > 0) {
			return yearCountColumns;
		}

		if (summaryPivotColumns.length > 0) {
			return summaryPivotColumns.map((column) => column.key);
		}

		return [] as string[];
	}, [summaryPivotColumns, yearCountByTeamColumns, yearCountColumns]);

	const resolvedYearCountRows = useMemo(() => {
		if (yearCountByTeamRows.length > 0) {
			return yearCountByTeamRows
				.filter((row) => row.inspekcja === inspectionType)
				.map((row) => ({
				label: row.zespol,
				values: row.values,
				}));
		}

		return yearCountRows.map((row) => ({
			label: row.label.split(" - ")[0]?.trim() || row.label,
			values: row.values,
		}));
	}, [inspectionType, yearCountByTeamRows, yearCountRows]);

	const orderedYearCountRows = useMemo(() => {
		if (isManagerView) {
			return resolvedYearCountRows;
		}

		const normalizeLabel = (value: string) => value.trim().toLowerCase();
		const isDepartment = (value: string) => normalizeLabel(value).includes("departament");
		const isMyCount = (value: string) => {
			const normalized = normalizeLabel(value);
			return (
				normalized.includes("mój czas") ||
				normalized.includes("moj czas") ||
				normalized.includes("moja liczba")
			);
		};
		const isTeamLike = (value: string) => !isDepartment(value) && !isMyCount(value);
		const hasCountBreakdown = resolvedYearCountColumns.some((year) => {
			const breakdown = myCountByYearBreakdown[year];
			return (
				breakdown !== undefined &&
				(breakdown.leader !== null ||
					breakdown.member !== null ||
					breakdown.combined !== null)
			);
		});

		const departmentRow =
			resolvedYearCountRows.find((row) => isDepartment(row.label)) ?? null;
		const myCountRowFromApi =
			resolvedYearCountRows.find((row) => isMyCount(row.label)) ?? null;

		const preferredTeamLabels = summaryPivotRows
			.filter((row) => isTeamLike(row.zespol))
			.map((row) => normalizeLabel(row.zespol));

		const teamRows =
			preferredTeamLabels.length > 0
				? resolvedYearCountRows.filter((row) =>
						preferredTeamLabels.includes(normalizeLabel(row.label)),
					)
				: resolvedYearCountRows.filter((row) => isTeamLike(row.label));

		const inferredMyCountValues: Record<string, string | number | null> = {};
		for (const year of resolvedYearCountColumns) {
			inferredMyCountValues[year] = 0;
		}

		for (const row of detailRows) {
			const year = String(row.rokPoczatku ?? "").trim();
			if (!year || !resolvedYearCountColumns.includes(year)) {
				continue;
			}

			if (row.isMemberCurrentUser || row.isLeaderCurrentUser) {
				const currentValue = inferredMyCountValues[year];
				const numericCurrentValue = typeof currentValue === "number" ? currentValue : 0;
				inferredMyCountValues[year] = numericCurrentValue + 1;
			}
		}

		const myCountRow =
			myCountRowFromApi ??
			{
				label: "Moja liczba",
				values:
					Object.keys(myCountByYear).length > 0
						? resolvedYearCountColumns.reduce<Record<string, string | number | null>>(
								(accumulator, year) => {
									accumulator[year] = myCountByYear[year] ?? 0;
									return accumulator;
								},
								{},
							)
						: inferredMyCountValues,
			};

		const prioritized: Array<(typeof resolvedYearCountRows)[number]> = [];
		if (departmentRow) {
			prioritized.push(departmentRow);
		}
		if (teamRows.length > 0) {
			prioritized.push(...teamRows);
		}

		if (hasCountBreakdown) {
			const myCountValues: Record<string, string | number | null> = {};
			for (const year of resolvedYearCountColumns) {
				myCountValues[year] = formatCountBreakdownPair(myCountByYearBreakdown[year]);
			}

			prioritized.push({
				label: "Moja liczba",
				values: myCountValues,
			});
			return prioritized;
		}

		if (myCountRow) {
			prioritized.push(myCountRow);
		}

		return prioritized;
	}, [
		detailRows,
		formatCountBreakdownPair,
		isManagerView,
		myCountByYear,
		myCountByYearBreakdown,
		resolvedYearCountColumns,
		resolvedYearCountRows,
		summaryPivotRows,
	]);

	const resolvedOverallColumns = useMemo(() => {
		const normalizeOverallColumnLabel = (key: string, label: string) => {
			const normalizedLabel = label.trim().toLowerCase();
			if (key === "zespol" || normalizedLabel === "zespol") return "Zespół";
			if (key === "average" || normalizedLabel === "srednia") return "Średnia";
			if (key === "median" || normalizedLabel === "mediana") return "Mediana";
			if (key === "count" || normalizedLabel === "liczba") return "Liczba";
			return label;
		};

		if (overallColumns.length > 0) {
			return overallColumns.map((column) => ({
				...column,
				label: normalizeOverallColumnLabel(column.key, column.label),
			}));
		}

		if (overallRows.length > 0) {
			const firstRow = overallRows[0];
			if (!firstRow) {
				return [];
			}

			const toLabel = (key: string) => {
				if (key === "zespol") return "Zespół";
				if (key === "count") return "Liczba";
				if (key === "average") return "Średnia";
				if (key === "median") return "Mediana";
				return key;
			};

			const toRank = (key: string) => {
				if (key === "zespol") return 0;
				if (key === "median") return 1;
				if (key === "average") return 1;
				if (key === "count") return 2;
				return 10;
			};

			return Object.keys(firstRow)
				.map((key) => ({ key, label: toLabel(key) }))
				.sort((left, right) => toRank(left.key) - toRank(right.key));
		}

		if (summaryPivotRows.length > 0) {
			return [
				{ key: "zespol", label: "Zespół" },
				{ key: metricColumnKey, label: metricColumnLabel },
				{ key: "count", label: "Liczba" },
			];
		}

		return [];
	}, [metricColumnKey, metricColumnLabel, overallColumns, overallRows, summaryPivotRows.length]);

	const resolvedOverallRows = useMemo(() => {
		if (overallRows.length > 0) {
			return overallRows;
		}

		if (summaryPivotRows.length === 0) {
			return [] as TimeReportOverallRow[];
		}

		return summaryPivotRows.map((row) => ({
			zespol: row.zespol,
			[metricColumnKey]: row.values.allYears ?? null,
			count: null,
		}));
	}, [metricColumnKey, overallRows, summaryPivotRows]);

	const displayOverallRows = useMemo(() => {
		if (isManagerView) {
			return resolvedOverallRows;
		}

		const hasAllYearsBreakdown =
			myMetricAllYearsBreakdown !== null || myCountAllYearsBreakdown !== null;
		if (!hasAllYearsBreakdown) {
			return resolvedOverallRows;
		}

		const normalizeLabel = (value: string) => value.trim().toLowerCase();
		const isDepartment = (value: string) => normalizeLabel(value).includes("departament");
		const isMyRow = (value: string) => {
			const normalized = normalizeLabel(value);
			return (
				normalized.includes("mój czas") ||
				normalized.includes("moj czas") ||
				normalized.includes("moja liczba")
			);
		};

		const departmentRow =
			resolvedOverallRows.find((row) => isDepartment(String(row.zespol ?? ""))) ?? null;
		const teamRows = resolvedOverallRows.filter(
			(row) =>
				!isDepartment(String(row.zespol ?? "")) &&
				!isMyRow(String(row.zespol ?? "")),
		);

		const createSplitRow = (
			label: string,
			metricValue: string | number | null,
			countValue: string | number | null,
		) => {
			const row: TimeReportOverallRow = {};
			for (const column of resolvedOverallColumns) {
				if (column.key === "zespol") {
					row[column.key] = label;
					continue;
				}

				if (column.key === "count") {
					row[column.key] = countValue;
					continue;
				}

				if (column.key === metricColumnKey || column.key === "metric") {
					row[column.key] = metricValue;
					continue;
				}

				row[column.key] = null;
			}

			return row;
		};

		const rows: TimeReportOverallRow[] = [];
		if (departmentRow) {
			rows.push(departmentRow);
		}
		if (teamRows.length > 0) {
			rows.push(...teamRows);
		}

		rows.push(
			createSplitRow(
				"Mój czas",
				formatMetricBreakdownPair(myMetricAllYearsBreakdown),
				formatCountBreakdownPair(myCountAllYearsBreakdown),
			),
		);

		return rows;
	}, [
		formatCountBreakdownPair,
		formatMetricBreakdownPair,
		isManagerView,
		metricColumnKey,
		myCountAllYearsBreakdown,
		myMetricAllYearsBreakdown,
		resolvedOverallColumns,
		resolvedOverallRows,
	]);

	const hasYearCountData =
		resolvedYearCountColumns.length > 0 && orderedYearCountRows.length > 0;

	return (
		<section className="flex h-full min-h-0 w-full flex-col gap-3 rounded-2xl border border-slate-700/70 bg-[#101f39] px-2 pt-4 pb-2 sm:px-2 sm:pt-5 sm:pb-2">
			<header className="flex min-h-10 items-center justify-between gap-3">
				<h2 className="font-semibold text-slate-100 text-xl leading-none">{title}</h2>
				{isManagerView ? (
					<div
						className={`inline-flex items-center gap-1 rounded-md border border-[#3f5f8c] bg-[#173761] p-1 ${
							activeRibbonTab === "inspection-data" ? "invisible" : ""
						}`}
						aria-hidden={activeRibbonTab === "inspection-data"}
					>
						<span className="px-1 font-semibold text-[#d2e3f9] text-xs">Statystyka:</span>
						<button
							type="button"
							onClick={() => setTrendMode("average")}
							className={`inline-flex h-7 items-center rounded px-2.5 font-semibold text-xs transition-colors ${
								trendMode === "average"
									? "bg-[#f8fbff] text-slate-900"
									: "text-[#d2e3f9] hover:bg-[#2a4772]"
							}`}
						>
							Średnia
						</button>
						<button
							type="button"
							onClick={() => setTrendMode("median")}
							className={`inline-flex h-7 items-center rounded px-2.5 font-semibold text-xs transition-colors ${
								trendMode === "median"
									? "bg-[#f8fbff] text-slate-900"
									: "text-[#d2e3f9] hover:bg-[#2a4772]"
							}`}
						>
							Mediana
						</button>
					</div>
				) : null}
			</header>

			{error ? (
				<p className="rounded-lg border border-rose-300/60 bg-rose-100/90 px-3 py-2 text-rose-800 text-sm">
					{error}
				</p>
			) : null}

			{isManagerView ? (
				<div className="flex flex-wrap items-end justify-between gap-2 border-[#2a4772] border-b">
					<div className="flex flex-wrap items-end gap-2">
						<button
							type="button"
							onClick={() => setActiveRibbonTab("inspection-data")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "inspection-data"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Dane Inspekcji
						</button>
						<button
							type="button"
							onClick={() => setActiveRibbonTab("time-summary")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "time-summary"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Zestawienie czasu
						</button>
						<button
							type="button"
							onClick={() => setActiveRibbonTab("visualization")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "visualization"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Wizualizacja czasów
						</button>
					</div>
				</div>
			) : (
				<div className="flex flex-wrap items-end justify-between gap-2 border-[#2a4772] border-b">
					<div className="flex flex-wrap items-end gap-2">
						<button
							type="button"
							onClick={() => setActiveRibbonTab("inspection-data")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "inspection-data"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Dane Inspekcji
						</button>
						<button
							type="button"
							onClick={() => setActiveRibbonTab("time-summary")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "time-summary"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Zestawienie czasu
						</button>
						<button
							type="button"
							onClick={() => setActiveRibbonTab("visualization")}
							className={`-mb-px inline-flex h-9 items-center rounded-t-md border px-3.5 font-semibold text-sm transition-colors ${
								activeRibbonTab === "visualization"
									? "border-[#8fb6ee] border-b-[#101f39] bg-[#f8fbff] text-slate-900"
									: "border-transparent bg-transparent text-white hover:bg-[#18365a]/35 hover:text-white"
							}`}
						>
							Wizualizacja czasów
						</button>
					</div>
					{activeRibbonTab !== "inspection-data" ? (
						<div className="mb-1 inline-flex items-center gap-1 rounded-md border border-[#3f5f8c] bg-[#173761] p-1">
							<span className="px-1 font-semibold text-[#d2e3f9] text-xs">Statystyka:</span>
							<button
								type="button"
								onClick={() => setTrendMode("average")}
								className={`inline-flex h-7 items-center rounded px-2.5 font-semibold text-xs transition-colors ${
									trendMode === "average"
										? "bg-[#f8fbff] text-slate-900"
										: "text-[#d2e3f9] hover:bg-[#2a4772]"
								}`}
							>
								Średnia
							</button>
							<button
								type="button"
								onClick={() => setTrendMode("median")}
								className={`inline-flex h-7 items-center rounded px-2.5 font-semibold text-xs transition-colors ${
									trendMode === "median"
										? "bg-[#f8fbff] text-slate-900"
										: "text-[#d2e3f9] hover:bg-[#2a4772]"
								}`}
							>
								Mediana
							</button>
						</div>
					) : null}
				</div>
			)}

			{activeRibbonTab === "inspection-data" ? (
				<div className="flex min-h-0 flex-1 flex-col space-y-2">
					<div className="flex justify-end px-1">
						<button
							type="button"
							onClick={clearFilters}
							disabled={!canClearDetailFilters}
							className={`inline-flex h-7 items-center rounded px-1.5 transition-colors disabled:cursor-not-allowed ${
								canClearDetailFilters
									? "font-semibold text-blue-300 text-sm hover:text-blue-200"
									: "font-medium text-slate-500 text-xs"
							}`}
						>
							Wyczyść filtry
						</button>
					</div>

				<div className="relative flex h-[calc(96vh-8rem)] min-h-88 w-full max-w-full flex-col overflow-hidden rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
					{isLoading ? <TableLoadingOverlay /> : null}
					<div className="subtle-horizontal-scroll subtle-vertical-scroll table-scroll-gutter-right min-h-0 flex-1 overflow-x-auto overflow-y-auto">
					<table className="w-full min-w-max border-collapse text-slate-900 text-sm">
					<thead>
						<tr className="bg-slate-100 text-slate-800">
							{DETAIL_COLUMNS.map((column) => (
								(() => {
									const sortIndicator =
										detailSortColumnKey === column.key
											? detailSortDirection === "asc"
												? "▲"
												: detailSortDirection === "desc"
													? "▼"
													: "↕"
											: "↕";

									return (
								<th
									key={column.key}
									aria-sort={
										detailSortColumnKey === column.key
											? detailSortDirection === "asc"
												? "ascending"
												: detailSortDirection === "desc"
													? "descending"
													: "none"
											: "none"
									}
									className={`${column.width} sticky top-0 z-20 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold`}
								>
									<div className="group relative flex w-full items-center gap-1.5 pr-8">
										<span className="truncate">{column.label}</span>
										<button
											type="button"
											onClick={() => handleDetailSortByColumn(column.key)}
											className="absolute top-1/2 right-0 inline-flex h-6 w-5 -translate-y-1/2 items-center justify-center rounded text-sm text-slate-500 leading-none transition-colors hover:text-slate-700"
											aria-label={`Sortuj kolumnę ${column.label}`}
										>
											{sortIndicator}
										</button>
									</div>
								</th>
									);
								})()
							))}
						</tr>
						<tr className="bg-white text-slate-700">
							{DETAIL_COLUMNS.map((column) => (
								<th
									key={`${column.key}-filter`}
									className={`${column.width} border-slate-200 border-b bg-white px-2 py-2`}
								>
									<div className="flex items-center gap-1">
										<input
											type="text"
											value={detailColumnFilters[column.key] ?? ""}
											onChange={(event) =>
												handleDetailColumnFilterChange(
														column.key,
														event.target.value,
													)
											}
											placeholder="Filtruj..."
											className="min-w-0 flex-1 rounded-md border border-slate-300 bg-white px-2 py-1 text-xs text-slate-800 outline-none transition-colors focus:border-blue-400"
										/>
										<button
											type="button"
											onClick={(event) =>
												openDetailAdvancedFilterForColumn(column.key, event.currentTarget)
											}
											aria-label={`Filtruj kolumnę ${column.label}`}
											className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
												(detailAdvancedFilters[column.key] ?? []).length > 0
													? "border-blue-400 bg-blue-50 text-blue-700"
													: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
											}`}
										>
											<ChevronDown size={12} />
										</button>
									</div>
								</th>
							))}
						</tr>
					</thead>

					<tbody>
						{detailPaginatedRows.map((row, index) => (
							<tr
								key={`${row.nazwaPodmiotu}-${row.kontrola}-${index}`}
								className="border-slate-200 border-b bg-white last:border-b-0"
							>
								{DETAIL_COLUMNS.map((column) => {
									const inspectionCode = resolveDetailRowInspectionCode(row);
									const isControlColumn = column.key === "kontrola";
									const canOpenInspection = isControlColumn && Boolean(inspectionCode);
									const cellValue = row[column.key];

									return (
										<td
											key={`${row.nazwaPodmiotu}-${column.key}-${index}`}
											className={`${column.width} px-3 py-2.5 align-top whitespace-normal wrap-break-word text-slate-900`}
										>
											{canOpenInspection ? (
												<button
													type="button"
													onClick={(event) => {
														event.stopPropagation();
														openInspectionFromDashboard(inspectionCode);
													}}
													className="cursor-pointer border-0 bg-transparent p-0 text-left text-[#1459c5] underline underline-offset-2 hover:text-[#0f4396]"
													title={`Otwórz inspekcję ${inspectionCode}`}
												>
													{cellValue}
												</button>
											) : (
												cellValue
											)}
										</td>
									);
								})}
							</tr>
						))}

						{!isLoading && sortedDetailRows.length === 0 ? (
							<tr>
								<td colSpan={DETAIL_COLUMNS.length} className="px-3 py-6 text-center text-slate-500 text-sm">
									Brak rekordów raportu.
								</td>
							</tr>
						) : null}
					</tbody>
					</table>
					</div>
					<div className="border-slate-200 border-t bg-gradient-to-b from-slate-50 to-white">
						<TablePagination
							currentPage={detailCurrentPage}
							totalPages={detailTotalPages}
							paginationItems={detailPaginationItems}
							totalItems={sortedDetailRows.length}
							pageSize={detailPageSize}
							onPageChange={handleDetailPageChange}
							pageSizeOptions={DETAIL_TABLE_PAGE_SIZE_OPTIONS}
							onPageSizeChange={handleDetailPageSizeChange}
							showWhenSinglePage
						/>
					</div>
				</div>
				<TableAdvancedFilterModal
					isOpen={isDetailAdvancedFilterModalOpen}
					anchor={detailAdvancedFilterAnchor}
					columnLabel={
						DETAIL_COLUMNS.find((column) => column.key === detailAdvancedFilterColumnKey)
							?.label ?? "Kolumna"
					}
					searchValue={detailAdvancedFilterSearch}
					visibleValues={visibleDetailAdvancedFilterValues}
					selectedValues={selectedDetailAdvancedFilterValues}
					onClose={() => setIsDetailAdvancedFilterModalOpen(false)}
					onSearchChange={setDetailAdvancedFilterSearch}
					onSelectAllVisible={selectAllVisibleDetailAdvancedFilterValues}
					onClearSelectedColumn={clearDetailAdvancedFilterForSelectedColumn}
					onToggleValue={toggleDetailAdvancedFilterValue}
					onClearAllFilters={clearFilters}
				/>
				</div>
			) : null}

			{activeRibbonTab === "time-summary" ? (
				<div className="flex min-h-0 flex-1 flex-col gap-3">
					<div className="subtle-vertical-scroll min-h-0 flex-1 overflow-y-auto pr-1">
						{!isManagerView ? (
							<div className="mx-1 mb-3 rounded-lg border border-[#4d6f9d] bg-[#173761] px-3 py-2 text-[#dce9fa] text-xs">
								<span className="font-semibold">Legenda wartości X / Y:</span>{" "}
								<span className="rounded-md bg-[#d8ecff] px-1.5 py-0.5 font-semibold text-[#184f81]">X</span>{" "}
								- gdy jesteś osobą kierującą, {" "}
								<span className="rounded-md bg-[#ffe8c8] px-1.5 py-0.5 font-semibold text-[#8a4f08]">Y</span>{" "}
								- gdy jesteś w składzie zespołu.
							</div>
						) : null}
			<div className="space-y-3">
				<div className="px-1">
					<h3 className="font-semibold text-[#dce9fa] text-sm">
						{isManagerView ? yearlyTimeSectionTitle : "Zestawienie statystyczne czasu"}
					</h3>
				</div>
				<div
					className="subtle-horizontal-scroll table-scroll-gutter-right w-full max-w-full overflow-x-auto overflow-y-hidden rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]"
				>
					{isLoading ? <TableLoadingOverlay /> : null}
					<table className="w-full min-w-max border-collapse text-slate-900 text-sm">
					<thead>
						<tr className="bg-slate-100 text-slate-800">
							<th className="sticky top-0 z-20 min-w-24 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold">
								Zespół
							</th>
							{summaryPivotColumns.map((column) => (
								<th
									key={column.key}
									className="sticky top-0 z-20 min-w-24 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold"
								>
									{column.label}
								</th>
							))}
						</tr>
					</thead>

					<tbody>
						{displaySummaryPivotRows.map((row, index) => (
							<tr
								key={`${row.zespol}-${index}`}
								className={`border-slate-200 border-b last:border-b-0 ${
									row.zespol === "Departament" ? "bg-slate-50" : "bg-white"
								}`}
							>
							<td className="min-w-24 px-3 py-2.5 text-slate-900">{row.zespol}</td>
							{summaryPivotColumns.map((column) => (
								<td
									key={`${row.zespol}-${index}-${column.key}`}
									className="min-w-24 px-3 py-2.5 text-slate-900"
								>
									{(() => {
										const formattedValue = formatSummaryCellValue(
											row.values[column.key] ?? null,
										);
										if (!isManagerView && row.zespol === "Mój czas") {
											return renderInspectorSplitValue(String(formattedValue));
										}

										return formattedValue;
									})()}
								</td>
							))}
							</tr>
						))}

						{!isLoading && (displaySummaryPivotRows.length === 0 || summaryPivotColumns.length === 0) ? (
							<tr>
								<td colSpan={Math.max(2, summaryPivotColumns.length + 1)} className="px-3 py-6 text-center text-slate-500 text-sm">
									Brak danych do agregacji.
								</td>
							</tr>
						) : null}

						{isLoading ? (
							<tr>
								<td colSpan={Math.max(2, summaryPivotColumns.length + 1)} className="px-3 py-6 text-center text-slate-500 text-sm">
									Ładowanie danych raportu...
								</td>
							</tr>
						) : null}
					</tbody>
				</table>
				</div>
			</div>

			<div className="pt-2 space-y-2">
				<div className="px-1">
					<h3 className="font-semibold text-[#dce9fa] text-sm">{yearlyCountSectionTitle}</h3>
				</div>
				<div className="relative subtle-horizontal-scroll table-scroll-gutter-right w-full max-w-full overflow-x-auto overflow-y-hidden rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
					{isLoading ? <TableLoadingOverlay /> : null}
					<table className="w-full min-w-max border-collapse text-slate-900 text-sm">
						<thead>
							<tr className="bg-slate-100 text-slate-800">
								<th className="sticky top-0 z-20 min-w-32 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold">
									Zespół
								</th>
								{resolvedYearCountColumns.map((year) => (
									<th
										key={`count-${year}`}
										className="sticky top-0 z-20 min-w-24 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold"
									>
										{year}
									</th>
								))}
							</tr>
						</thead>

						<tbody>
							{orderedYearCountRows.map((row, index) => (
								<tr
									key={`year-count-${row.label}-${index}`}
									className="border-slate-200 border-b bg-white last:border-b-0"
								>
									<td className="min-w-32 px-3 py-2.5 text-slate-900">{row.label}</td>
									{resolvedYearCountColumns.map((year) => (
										<td
											key={`year-count-${row.label}-${year}`}
											className="min-w-24 px-3 py-2.5 text-slate-900"
										>
											{(() => {
												const formattedValue = formatCountCellValue(
													row.values[year] ?? null,
												);
												if (!isManagerView && row.label === "Moja liczba") {
													return renderInspectorSplitValue(String(formattedValue));
												}

												return formattedValue;
											})()}
										</td>
									))}
								</tr>
							))}

							{!isLoading && !hasYearCountData ? (
								<tr>
									<td colSpan={Math.max(2, resolvedYearCountColumns.length + 1)} className="px-3 py-6 text-center text-slate-500 text-sm">
										Brak danych liczności wg roku.
									</td>
								</tr>
							) : null}

							{isLoading ? (
								<tr>
									<td colSpan={Math.max(2, resolvedYearCountColumns.length + 1)} className="px-3 py-6 text-center text-slate-500 text-sm">
										Ładowanie danych raportu...
									</td>
								</tr>
							) : null}
						</tbody>
					</table>
				</div>
			</div>

			<div className="pt-2 space-y-2">
				<div className="px-1">
					<h3 className="font-semibold text-[#dce9fa] text-sm">{allYearsSectionTitle}</h3>
				</div>
				<div className="relative subtle-horizontal-scroll table-scroll-gutter-right w-full max-w-full overflow-x-auto overflow-y-hidden rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
					{isLoading ? <TableLoadingOverlay /> : null}
					<table className="w-full min-w-max border-collapse text-slate-900 text-sm">
						<thead>
							<tr className="bg-slate-100 text-slate-800">
								{resolvedOverallColumns.map((column) => (
									<th
										key={column.key}
										className="sticky top-0 z-20 min-w-24 whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold"
									>
										{column.label}
									</th>
								))}
							</tr>
						</thead>

						<tbody>
							{displayOverallRows.map((row, index) => {
								const teamValue = String(row.zespol ?? "");
								const rowClassName =
									teamValue === "Departament"
										? "border-slate-200 border-b bg-slate-50 last:border-b-0"
										: "border-slate-200 border-b bg-white last:border-b-0";

								return (
									<tr key={`overall-${index}`} className={rowClassName}>
										{resolvedOverallColumns.map((column) => (
											<td key={`overall-${index}-${column.key}`} className="min-w-24 px-3 py-2.5 text-slate-900">
												{(() => {
													const isCountColumn = column.key === "count";
													const formattedValue = isCountColumn
														? formatCountCellValue(row[column.key] ?? null)
														: formatSummaryCellValue(row[column.key] ?? null);

													if (!isManagerView && teamValue === "Mój czas") {
														return renderInspectorSplitValue(String(formattedValue));
													}

													return formattedValue;
												})()}
											</td>
										))}
									</tr>
								);
							})}

							{!isLoading && (displayOverallRows.length === 0 || resolvedOverallColumns.length === 0) ? (
								<tr>
									<td colSpan={Math.max(1, resolvedOverallColumns.length)} className="px-3 py-6 text-center text-slate-500 text-sm">
										Brak danych do zestawienia ogólnego.
									</td>
								</tr>
							) : null}

							{isLoading ? (
								<tr>
									<td colSpan={Math.max(1, resolvedOverallColumns.length)} className="px-3 py-6 text-center text-slate-500 text-sm">
										Ładowanie danych raportu...
									</td>
								</tr>
							) : null}
						</tbody>
					</table>
				</div>
			</div>
					</div>
				</div>
			) : null}

			{activeRibbonTab === "visualization" ? (
				<div className="flex min-h-0 flex-1 flex-col gap-2">
					<div className="relative flex min-h-[30rem] flex-1 flex-col rounded-xl border border-[#becadd] bg-[#f8fbff] p-3 shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
						{isLoading ? <TableLoadingOverlay /> : null}
					<div className="mb-3 flex flex-wrap items-center justify-between gap-2">
						<h3 className="font-semibold text-[#133259] text-sm">
							{yearlyTimeSectionTitle}
						</h3>
						<div className="flex flex-wrap items-center gap-3 text-[#33577f] text-xs">
							<div className="mr-1 inline-flex items-center gap-3 rounded-md bg-[#eef4fc] px-2 py-1 text-[#294c76]">
								{!isManagerView ? (
									<span className="inline-flex items-center gap-1">
										<svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
											<path d="M5 1 L1.5 8 H8.5 Z" fill="#255087" />
										</svg>
										<span>{metricLegendLabel}</span>
									</span>
								) : null}
								<span className="inline-flex items-center gap-1">
									<svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
										<rect x="1.5" y="1.5" width="7" height="7" fill="#dc2626" />
									</svg>
									<span>{metricLegendTitleLabel} departamentu</span>
								</span>
								<span className="inline-flex items-center gap-1">
									<svg width="24" height="10" viewBox="0 0 24 10" aria-hidden="true">
										<line x1="1" y1="5" x2="7" y2="5" stroke="#ea580c" strokeWidth="2" strokeLinecap="round" />
										<line x1="17" y1="5" x2="23" y2="5" stroke="#ea580c" strokeWidth="2" strokeLinecap="round" />
										<line x1="9" y1="2" x2="15" y2="8" stroke="#dc2626" strokeWidth="1.8" strokeLinecap="round" />
										<line x1="9" y1="8" x2="15" y2="2" stroke="#dc2626" strokeWidth="1.8" strokeLinecap="round" />
									</svg>
									<span>Min/max departamentu</span>
								</span>
							</div>
							{isManagerView ? (
								<>
									<label className="inline-flex cursor-pointer items-center gap-1.5">
										<input
											type="checkbox"
											checked={showHistogram}
											onChange={(event) => setShowHistogram(event.target.checked)}
											className="h-3.5 w-3.5"
										/>
										<span>Dodaj histogram</span>
									</label>
									<label className="inline-flex cursor-pointer items-center gap-1.5">
										<input
											type="checkbox"
											checked={showScatterPoints}
											onChange={(event) => setShowScatterPoints(event.target.checked)}
											className="h-3.5 w-3.5"
										/>
										<span>Dodaj punkty</span>
									</label>
								</>
							) : null}
						</div>
					</div>

					{scatterRowsWithDisplayNames.length > 0 ? (
						<div
							className={`min-h-0 flex-1 w-full ${
								shouldEnableChartScroll
									? "subtle-horizontal-scroll overflow-x-auto overflow-y-hidden"
									: "overflow-hidden"
							}`}
						>
							<div
								className="relative h-full"
								onClick={handleChartBackgroundClick}
								style={
									shouldEnableChartScroll
										? { minWidth: `${chartScrollableWidthPx}px` }
										: undefined
								}
							>
							<ResponsiveContainer width="100%" height="100%">
								<ComposedChart
									data={chartTrendData}
									margin={{ top: 8, right: 12, left: 8, bottom: 28 }}
								>
									<CartesianGrid stroke="#d5deea" strokeDasharray="3 3" />
									{showHistogram
										? yearRangeAreas.map((area) => (
											<ReferenceArea
												key={`shell-visualization-${area.year}`}
												x1={area.x - YEAR_BOX_HALF_WIDTH}
												x2={area.x + YEAR_BOX_HALF_WIDTH}
												y1={area.y1}
												y2={area.y2}
												fill="#8dbaf5"
												fillOpacity={0.24}
												stroke="#3f6ea8"
												strokeOpacity={0.75}
											/>
										))
										: null}
									{showHistogram
										? histogramAreas.map((area) => (
											<ReferenceArea
												key={area.key}
												x1={area.x1}
												x2={area.x2}
												y1={area.y1}
												y2={area.y2}
												fill="#3f7cc5"
												fillOpacity={area.opacity}
												stroke="#2f5f95"
												strokeOpacity={0.22}
											/>
										))
										: null}
									<XAxis
										type="number"
										dataKey="x"
										allowDecimals={false}
										tick={{ fill: "#27486d", fontSize: 12 }}
										ticks={yearBuckets.map((_, index) => index)}
										tickFormatter={(value) => String(yearBuckets[value] ?? "")}
										domain={xAxisDomain}
										label={{ value: "Rok", position: "bottom", offset: 8, fill: "#27486d" }}
									/>
									<YAxis
										type="number"
										allowDecimals={false}
										tick={{ fill: "#27486d", fontSize: 12 }}
										domain={yAxisDomain}
										label={{ value: "Czas (dni)", angle: -90, position: "insideLeft", fill: "#27486d" }}
									/>
										<Line
											type="monotone"
											dataKey="departmentTrend"
											stroke={isManagerView ? "#3f6ea8" : "transparent"}
											strokeDasharray="5 5"
											strokeWidth={isManagerView ? 2 : 0}
											dot={renderDepartmentTrendDot}
											connectNulls={false}
											isAnimationActive={false}
										/>
										<Scatter
											data={departmentRangePoints}
											dataKey="value"
											shape={renderDepartmentRangeDot}
										/>
									<Line
										type="monotone"
										dataKey="trend"
										stroke={isManagerView ? "#255087" : "transparent"}
										strokeWidth={isManagerView ? 3 : 0}
										dot={renderTrendDot}
										connectNulls={false}
										isAnimationActive={false}
									/>
									{showScatterPoints ? (
										<Scatter
											data={chartPointsData}
											dataKey="time"
											fill="#5d8fc9"
												shape={renderScatterPoint}
										/>
									) : null}
								</ComposedChart>
							</ResponsiveContainer>
							{chartClickTooltip ? (
								<div
									className="pointer-events-auto absolute z-20 max-w-72 rounded-xl border border-[#b8cbe3] bg-gradient-to-b from-white to-[#f5f9ff] px-3 py-2 text-[#1d3557] text-[13px] leading-5 shadow-[0_14px_30px_rgba(15,35,70,0.18)] before:absolute before:top-3 before:-left-1.5 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-l before:border-b before:bg-white before:content-['']"
									style={{
										left: `${chartClickTooltip.x + 10}px`,
										top: `${Math.max(8, chartClickTooltip.y - 12)}px`,
									}}
									onClick={(event) => event.stopPropagation()}
								>
									{chartClickTooltip.kind === "point" ? (
										<>
											<p><strong>Nazwa podmiotu:</strong> {chartClickTooltip.data.nazwaPodmiotu}</p>
											<p>
												<strong>Kontrola:</strong>{" "}
												{(() => {
													const inspectionCode = String(chartClickTooltip.data.kontrola ?? "").trim();
													if (!inspectionCode || inspectionCode === "-") {
														return chartClickTooltip.data.kontrola;
													}

													return (
														<button
															type="button"
															onClick={(event) => {
																event.stopPropagation();
																openInspectionFromDashboard(inspectionCode);
															}}
															className="cursor-pointer border-0 bg-transparent p-0 text-[#1459c5] underline underline-offset-2 hover:text-[#0f4396]"
														>
															{inspectionCode}
														</button>
													);
												})()}
											</p>
											<p><strong>Osoba kierująca:</strong> {chartClickTooltip.data.osobaKierujaca}</p>
											<p><strong>Zespół:</strong> {chartClickTooltip.data.zespol}</p>
											<p><strong>Czas:</strong> {chartClickTooltip.data.time}</p>
										</>
									) : chartClickTooltip.kind === "trend" ? (
										<>
											<p><strong>Rok:</strong> {chartClickTooltip.year}</p>
											<p>
												<strong>{trendMode === "average" ? "Średnia" : "Mediana"}:</strong>{" "}
												{chartClickTooltip.trend === null ? "-" : chartClickTooltip.trend.toFixed(1)}
											</p>
										</>
									) : (
										<>
											<p><strong>Rok:</strong> {chartClickTooltip.year}</p>
											<p>
												<strong>{chartClickTooltip.label}:</strong>{" "}
												{chartClickTooltip.value === null ? "-" : chartClickTooltip.value.toFixed(1)}
											</p>
										</>
									)}
								</div>
							) : null}
							</div>
						</div>
					) : (
						<p className="py-8 text-center text-[#4b6484] text-sm">
							Brak danych liczbowych czasu do wyświetlenia wykresu.
						</p>
					)}
					</div>
				</div>
			) : null}

		</section>
	);
}

type SingleReportPanelProps = {
	operatorLogin: string;
};

export function ProtocolTimePanel({ operatorLogin }: SingleReportPanelProps) {
	return (
		<TimeReportPanel
			operatorLogin={operatorLogin}
			title="Czas protokołu"
			inspectionType="K"
		/>
	);
}

export function StatementTimePanel({ operatorLogin }: SingleReportPanelProps) {
	return (
		<TimeReportPanel
			operatorLogin={operatorLogin}
			title="Czas sprawozdania"
			inspectionType="W"
		/>
	);
}
