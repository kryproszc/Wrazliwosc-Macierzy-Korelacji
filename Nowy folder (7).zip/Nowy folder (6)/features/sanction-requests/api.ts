import type {
	SanctionRequestFilters,
	SanctionRequestListResponse,
	SanctionRequestRead,
	SanctionRequestWrite,
} from "@/features/sanction-requests/types";

export type SanctionRequestLockConflict = {
	module: string;
	recordId: string;
	ownerUserId: string;
	ownerLogin: string;
	ownerDisplayName: string;
	acquiredAt: string;
	expiresAt: string;
};

type ApiResult<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
			errorCode?: string;
			lockConflict?: SanctionRequestLockConflict;
			lockErrorCode?: string;
			lockReason?: string;
			currentUpdatedAt?: string;
	  };

function getErrorMessageByStatus(status: number) {
	if (status === 400) return "Błędne dane wejściowe.";
	if (status === 401) return "Brak autoryzacji operatora.";
	if (status === 403) return "Brak uprawnień do operacji.";
	if (status === 404) return "Nie znaleziono zasobu.";
	if (status === 409)
		return "Dane zostały zmienione przez innego użytkownika. Odśwież widok i spróbuj ponownie.";
	if (status === 423) return "Błąd blokady rekordu.";
	if (status === 422) return "Nieprawidłowy format danych.";
	return `Błąd API (${status}).`;
}

function toStringValue(value: unknown) {
	return typeof value === "string" ? value.trim() : "";
}

function toStringList(value: unknown) {
	if (!Array.isArray(value)) {
		return [] as string[];
	}

	return value
		.map((entry) => toStringValue(entry))
		.filter(Boolean);
}

function toNullableNumber(value: unknown) {
	if (typeof value === "number" && Number.isFinite(value)) {
		return value;
	}

	if (typeof value === "string" && value.trim()) {
		const parsed = Number(value.trim());
		return Number.isFinite(parsed) ? parsed : null;
	}

	return null;
}

function toNullablePositiveNumber(value: unknown) {
	const parsed = toNullableNumber(value);
	if (typeof parsed !== "number" || !Number.isFinite(parsed) || parsed <= 0) {
		return null;
	}

	return parsed;
}

function toPositiveNumberList(value: unknown) {
	if (!Array.isArray(value)) {
		return [] as number[];
	}

	return value
		.map((entry) => toNullablePositiveNumber(entry))
		.filter((entry): entry is number => typeof entry === "number");
}

function readErrorCode(responsePayload: unknown) {
	if (!responsePayload || typeof responsePayload !== "object") {
		return undefined;
	}

	const source = responsePayload as Record<string, unknown>;
	const topLevelCode = toStringValue(source.code);
	if (topLevelCode) {
		return topLevelCode;
	}

	const detail = source.detail;
	if (detail && typeof detail === "object" && !Array.isArray(detail)) {
		const detailCode = toStringValue((detail as Record<string, unknown>).code);
		return detailCode || undefined;
	}

	return undefined;
}

function readErrorMessage(responsePayload: unknown) {
	if (!responsePayload || typeof responsePayload !== "object") {
		return "";
	}

	const source = responsePayload as Record<string, unknown>;
	const detail = source.detail ?? source.message;

	if (typeof detail === "string") {
		return detail;
	}

	if (detail && typeof detail === "object" && !Array.isArray(detail)) {
		const detailMessage = toStringValue(
			(detail as Record<string, unknown>).message,
		);
		if (detailMessage) {
			return detailMessage;
		}
	}

	return "";
}

function normalizeSanctionRequestRead(payload: unknown): SanctionRequestRead {
	const source = payload && typeof payload === "object"
		? (payload as Record<string, unknown>)
		: {};

	const nazwaPodmiotuObjetegoInspekcjaSkrocona = toStringValue(
		source.nazwaPodmiotuObjetegoInspekcjaSkrocona ??
			source.nazwaPodmiotuObjetegoInspekcjaSkrot,
	);
	const nazwaPodmiotuObjetegoSankcjaListSkrocona = toStringList(
		source.nazwaPodmiotuObjetegoSankcjaListSkrocona ??
			source.nazwaPodmiotuObjetegoSankcjaListSkrot,
	);
	const wniosekDoSkrocona = toStringValue(
		source.wniosekDoSkrocona ?? source.wniosekDoSkrot,
	);
	const sankcjaListSkrocona = toStringList(
		source.sankcjaListSkrocona ?? source.sankcjaListSkrot,
	);
	const podstawaPrawnaSankcjiListSkrocona = toStringList(
		source.podstawaPrawnaSankcjiListSkrocona ??
			source.podstawaPrawnaSankcjiListSkrot,
	);
	const naruszeniaSkutkujaceSankcjaListSkrocona = toStringList(
		source.naruszeniaSkutkujaceSankcjaListSkrocona ??
			source.naruszeniaSkutkujaceSankcjaListSkrot,
	);
	const czyMamyInformacjeOWszczeciuPostepowaniaSkrocona = toStringValue(
		source.czyMamyInformacjeOWszczeciuPostepowaniaSkrocona ??
			source.czyMamyInformacjeOWszczeciuPostepowaniaSkrot,
	);
	const rozstrzygniecieSkrocona = toStringValue(
		source.rozstrzygniecieSkrocona ?? source.rozstrzygniecieSkrot,
	);

	return {
		id: toNullableNumber(source.id) ?? 0,
		lp: toNullableNumber(source.lp) ?? 0,
		kodSankcji: toStringValue(source.kodSankcji) || null,
		canEdit: source.canEdit === true,
		inspectionId: toNullableNumber(source.inspectionId),
		inspectionLp: toNullableNumber(source.inspectionLp),
		inspectionKod: toStringValue(source.inspectionKod) || null,
		kodInspekcji: toStringValue(source.kodInspekcji) || null,
		nazwaPodmiotuObjetegoInspekcjaId: toNullablePositiveNumber(
			source.nazwaPodmiotuObjetegoInspekcjaId,
		),
		nazwaPodmiotuObjetegoInspekcja:
			toStringValue(source.nazwaPodmiotuObjetegoInspekcja) || null,
		nazwaPodmiotuObjetegoInspekcjaSkrocona:
			nazwaPodmiotuObjetegoInspekcjaSkrocona || null,
		nazwaPodmiotuObjetegoSankcjaIds: toPositiveNumberList(
			source.nazwaPodmiotuObjetegoSankcjaIds,
		),
		nazwaPodmiotuObjetegoSankcjaList: toStringList(
			source.nazwaPodmiotuObjetegoSankcjaList,
		),
		nazwaPodmiotuObjetegoSankcjaListSkrocona:
			nazwaPodmiotuObjetegoSankcjaListSkrocona,
		dataWniosku: toStringValue(source.dataWniosku) || null,
		wniosekDoId: toNullablePositiveNumber(source.wniosekDoId),
		wniosekDo: toStringValue(source.wniosekDo) || null,
		wniosekDoSkrocona: wniosekDoSkrocona || null,
		sankcjaIds: toPositiveNumberList(source.sankcjaIds),
		sankcjaList: toStringList(source.sankcjaList),
		sankcjaListSkrocona,
		podstawaPrawnaSankcjiIds: toPositiveNumberList(
			source.podstawaPrawnaSankcjiIds,
		),
		podstawaPrawnaSankcjiList: toStringList(source.podstawaPrawnaSankcjiList),
		podstawaPrawnaSankcjiListSkrocona,
		naruszeniaSkutkujaceSankcjaIds: toPositiveNumberList(
			source.naruszeniaSkutkujaceSankcjaIds,
		),
		naruszeniaSkutkujaceSankcjaList: toStringList(
			source.naruszeniaSkutkujaceSankcjaList,
		),
		naruszeniaSkutkujaceSankcjaListSkrocona,
		czyMamyInformacjeOWszczeciuPostepowaniaId: toNullablePositiveNumber(
			source.czyMamyInformacjeOWszczeciuPostepowaniaId,
		),
		czyMamyInformacjeOWszczeciuPostepowania:
			toStringValue(source.czyMamyInformacjeOWszczeciuPostepowania) || null,
		czyMamyInformacjeOWszczeciuPostepowaniaSkrocona:
			czyMamyInformacjeOWszczeciuPostepowaniaSkrocona || null,
		rozstrzygniecieId: toNullablePositiveNumber(source.rozstrzygniecieId),
		rozstrzygniecie: toStringValue(source.rozstrzygniecie) || null,
		rozstrzygniecieSkrocona: rozstrzygniecieSkrocona || null,
		komentarz: toStringValue(source.komentarz) || null,
		createdByUserId: toNullablePositiveNumber(source.createdByUserId),
		createdByLogin: toStringValue(source.createdByLogin) || null,
		createdByDisplayName: toStringValue(source.createdByDisplayName) || null,
		utworzonoO: toStringValue(source.utworzonoO) || null,
		zaktualizowanoO: toStringValue(source.zaktualizowanoO) || null,
	};
}

function parseLockConflict(payload: unknown): SanctionRequestLockConflict | undefined {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	if (toStringValue(source.code) !== "RECORD_LOCKED") {
		return undefined;
	}

	return {
		module: toStringValue(source.module),
		recordId: toStringValue(source.recordId),
		ownerUserId: toStringValue(source.ownerUserId),
		ownerLogin: toStringValue(source.ownerLogin),
		ownerDisplayName: toStringValue(source.ownerDisplayName),
		acquiredAt: toStringValue(source.acquiredAt),
		expiresAt: toStringValue(source.expiresAt),
	};
}

function parseCurrentUpdatedAt(payload: unknown) {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	const value = source.currentUpdatedAt ?? source.updatedAt;
	const parsed = toStringValue(value);
	return parsed || undefined;
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
		};
		const detail = payload.detail ?? payload.message;

		if (typeof detail === "string") {
			return detail;
		}

		if (Array.isArray(detail)) {
			return detail
				.map((item) => {
					if (typeof item === "string") return item;
					if (item && typeof item === "object") {
						const maybeMsg = (item as { msg?: unknown }).msg;
						return typeof maybeMsg === "string"
							? maybeMsg
							: JSON.stringify(item);
					}
					return "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

export async function fetchSanctionRequests(
	operatorLogin: string,
	filters: SanctionRequestFilters,
): Promise<ApiResult<SanctionRequestListResponse>> {
	try {
		const query = new URLSearchParams();

		if (
			typeof filters.inspectionId === "number" &&
			Number.isFinite(filters.inspectionId)
		) {
			query.set("inspectionId", String(filters.inspectionId));
		}

		if (filters.sortBy) {
			query.set("sortBy", filters.sortBy);
		}

		if (filters.sortOrder) {
			query.set("sortOrder", filters.sortOrder);
		}

		const querySuffix = query.toString() ? `?${query.toString()}` : "";
		const response = await fetch(`/api/sanction-requests${querySuffix}`, {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (!response.ok) {
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
			};
		}

		const payload = (await response.json()) as unknown;
		if (Array.isArray(payload)) {
			return {
				ok: true,
				data: {
					items: payload.map((item) => normalizeSanctionRequestRead(item)),
					total: payload.length,
				},
			};
		}

		const data = (payload ?? {}) as Partial<SanctionRequestListResponse>;
		return {
			ok: true,
			data: {
				items: Array.isArray(data.items)
					? data.items.map((item) => normalizeSanctionRequestRead(item))
					: [],
				total: typeof data.total === "number" ? data.total : 0,
			},
		};
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function createSanctionRequest(
	operatorLogin: string,
	payload: SanctionRequestWrite,
): Promise<ApiResult<SanctionRequestRead>> {
	try {
		const response = await fetch("/api/sanction-requests", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(payload),
		});

		if (!response.ok) {
			const contentType = response.headers.get("content-type") ?? "";
			const responsePayload = contentType.includes("application/json")
				? ((await response.json()) as unknown)
				: null;
			const detail = readErrorMessage(responsePayload);
			const errorCode = readErrorCode(responsePayload);
			const isInspectionStatusBlocked =
				response.status === 409 && errorCode === "INSPECTION_STATUS_BLOCKS_OPERATION";
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: isInspectionStatusBlocked
					? (detail || "Nie można zapisać rekordu dla inspekcji zamkniętej.")
					: detail
						? `${base} ${detail}`
						: base,
				status: response.status,
				errorCode,
			};
		}

		return {
			ok: true,
			data: normalizeSanctionRequestRead(await response.json()),
		};
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function updateSanctionRequest(
	operatorLogin: string,
	id: number,
	payload: SanctionRequestWrite,
	options?: {
		expectedUpdatedAt?: string | null;
		lockToken?: string | null;
	},
): Promise<ApiResult<SanctionRequestRead>> {
	try {
		const requestPayload: Record<string, unknown> = {
			...payload,
		};

		if (typeof options?.expectedUpdatedAt === "string" && options.expectedUpdatedAt.trim()) {
			requestPayload.expectedUpdatedAt = options.expectedUpdatedAt.trim();
		}

		if (typeof options?.lockToken === "string" && options.lockToken.trim()) {
			requestPayload.lockToken = options.lockToken.trim();
		}

		const response = await fetch(`/api/sanction-requests/${id}`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(requestPayload),
		});

		if (!response.ok) {
			const contentType = response.headers.get("content-type") ?? "";
			const responsePayload = contentType.includes("application/json")
				? ((await response.json()) as unknown)
				: null;
			const detail = readErrorMessage(responsePayload);
			const base = getErrorMessageByStatus(response.status);
			const lockConflict =
				response.status === 423 ? parseLockConflict(responsePayload) : undefined;
			const lockErrorCode =
				response.status === 423 && responsePayload && typeof responsePayload === "object"
					? toStringValue((responsePayload as Record<string, unknown>).code) || undefined
					: undefined;
			const lockReason =
				response.status === 423 && responsePayload && typeof responsePayload === "object"
					? toStringValue((responsePayload as Record<string, unknown>).reason) || undefined
					: undefined;
			const errorCode = readErrorCode(responsePayload);
			const isInspectionStatusBlocked =
				response.status === 409 && errorCode === "INSPECTION_STATUS_BLOCKS_OPERATION";
			const currentUpdatedAt =
				response.status === 409 && !isInspectionStatusBlocked
					? parseCurrentUpdatedAt(responsePayload)
					: undefined;
			const lockMessage =
				lockErrorCode === "RECORD_LOCKED"
					? "Nie możesz teraz edytować tego wpisu, ponieważ jest edytowany przez innego użytkownika."
					: lockErrorCode === "LOCK_REQUIRED" || lockReason === "lock_required"
						? "Do zapisu wymagana jest aktywna blokada rekordu. Odśwież dane i otwórz formularz ponownie."
						: lockErrorCode === "LOCK_TOKEN_INVALID" || lockReason === "lock_token_invalid"
							? "Blokada edycji wygasła lub jest nieprawidłowa. Odśwież dane i otwórz formularz ponownie."
							: base;
			return {
				ok: false,
				error:
					isInspectionStatusBlocked
						? (detail || "Nie można zapisać rekordu dla inspekcji zamkniętej.")
						: response.status === 423
						? detail
							? `${lockMessage} ${detail}`
							: lockMessage
						: detail
							? `${base} ${detail}`
							: base,
				status: response.status,
				errorCode,
				lockConflict,
				lockErrorCode,
				lockReason,
				currentUpdatedAt,
			};
		}

		return {
			ok: true,
			data: normalizeSanctionRequestRead(await response.json()),
		};
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function deleteSanctionRequest(
	operatorLogin: string,
	id: number,
): Promise<ApiResult<null>> {
	try {
		let response = await fetch(`/api/risk-exposure/${id}`, {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
		});

		if (response.status === 404) {
			response = await fetch(`/api/sanction-requests/${id}`, {
				method: "DELETE",
				headers: {
					"Content-Type": "application/json",
					"X-Operator-Login": operatorLogin,
				},
			});
		}

		if (!response.ok) {
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
			};
		}

		return { ok: true, data: null };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}
