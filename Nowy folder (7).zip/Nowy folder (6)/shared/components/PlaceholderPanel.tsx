type PlaceholderPanelProps = {
	title?: string;
	subtitle?: string;
};

export function PlaceholderPanel({
	title = "Panel w przygotowaniu",
	subtitle = "Ta sekcja będzie dostępna w kolejnej iteracji.",
}: PlaceholderPanelProps) {
	return (
		<section className="min-h-45 rounded-2xl border border-slate-700/70 bg-[#101f39] p-6">
			<h2 className="font-semibold text-lg text-slate-100">{title}</h2>
			<p className="mt-1 text-slate-300/85 text-sm">{subtitle}</p>
		</section>
	);
}
