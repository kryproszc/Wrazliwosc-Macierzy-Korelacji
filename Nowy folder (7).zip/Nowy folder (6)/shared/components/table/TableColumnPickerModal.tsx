import { X } from "lucide-react";
import type { ReactNode } from "react";

type TableLayoutOption<TLayoutId extends string> = {
	id: TLayoutId;
	label: string;
	description?: string;
};

type TableColumnDefinition<TColumnKey extends string> = {
	key: TColumnKey;
	label: string;
};

type TableColumnModeOption = {
	value: string;
	label: string;
};

type TableColumnPickerModalProps<
	TColumnKey extends string,
	TLayoutId extends string,
> = {
	isOpen: boolean;
	columns: TableColumnDefinition<TColumnKey>[];
	hiddenColumns: TColumnKey[];
	visibleColumnsCount: number;
	onClose: () => void;
	onChangeColumnVisibility: (columnKey: TColumnKey, isVisible: boolean) => void;
	onChangeColumnDisplayMode?: (columnKey: TColumnKey, value: string) => void;
	onShowAllColumns: () => void;
	onHideAllColumns?: () => void;
	onResetSelection?: () => void;
	onApply: () => void;
	columnDisplayModeOptions?: Partial<
		Record<TColumnKey, TableColumnModeOption[]>
	>;
	columnDisplayModeValues?: Partial<Record<TColumnKey, string>>;
	layoutOptions?: TableLayoutOption<TLayoutId>[];
	selectedLayoutId?: TLayoutId;
	onSelectLayout?: (layoutId: TLayoutId) => void;
	title?: string;
	description?: string;
	headerControls?: ReactNode;
};

export function TableColumnPickerModal<
	TColumnKey extends string,
	TLayoutId extends string,
>({
	isOpen,
	columns,
	hiddenColumns,
	visibleColumnsCount,
	onClose,
	onChangeColumnVisibility,
	onChangeColumnDisplayMode,
	onShowAllColumns,
	onHideAllColumns,
	onResetSelection,
	onApply,
	columnDisplayModeOptions,
	columnDisplayModeValues,
	layoutOptions,
	selectedLayoutId,
	onSelectLayout,
	title = "Widok tabeli",
	description = "",
	headerControls,
}: TableColumnPickerModalProps<TColumnKey, TLayoutId>) {
	if (!isOpen) {
		return null;
	}

	const hasLayouts = Boolean(
		layoutOptions &&
			layoutOptions.length > 0 &&
			selectedLayoutId &&
			onSelectLayout,
	);

	return (
		<div className="fixed inset-0 z-40 flex items-center justify-center p-4">
			<button
				type="button"
				aria-label="Zamknij okno wyboru kolumn"
				className="absolute inset-0 bg-slate-950/65"
				onClick={onClose}
			/>

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Wybór kolumn tabeli"
				className="relative z-10 flex w-[min(97vw,1500px)] max-w-none flex-col overflow-hidden rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">{title}</h3>
						{description ? (
							<p className="mt-1 text-slate-600 text-sm">{description}</p>
						) : null}
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				{headerControls ? (
					<div className="mb-4 border-slate-200 border-b pb-3">{headerControls}</div>
				) : null}

				<div className="min-h-0 flex-1 pr-1">
					{hasLayouts ? (
						<div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
							<p className="mb-2 font-semibold text-slate-700 text-sm">Układ</p>
							<div className="grid gap-2 sm:grid-cols-3">
								{layoutOptions?.map((view) => {
									const isActive = selectedLayoutId === view.id;

									return (
										<button
											key={view.id}
											type="button"
											onClick={() => onSelectLayout?.(view.id)}
											className={`rounded-lg border px-3 py-2 text-left transition-colors ${
												isActive
													? "border-blue-300 bg-blue-50 text-slate-900"
													: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
											}`}
										>
											<p className="font-semibold text-sm">{view.label}</p>
											{view.description ? (
												<p className="mt-1 text-slate-500 text-xs">{view.description}</p>
											) : null}
										</button>
									);
								})}
							</div>
						</div>
					) : null}

					<p className="mb-2 font-semibold text-slate-700 text-sm">Kolumny</p>
					<div className="subtle-vertical-scroll">
						<div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
						{columns.map((column) => {
							const isVisible = !hiddenColumns.includes(column.key);
							const isOnlyVisibleColumn =
								isVisible && visibleColumnsCount <= 1;
							const modeOptions = columnDisplayModeOptions?.[column.key] ?? [];
							const hasModeSelector =
								Boolean(onChangeColumnDisplayMode) && modeOptions.length > 0;
							const selectedMode =
								columnDisplayModeValues?.[column.key] ?? modeOptions[0]?.value ?? "";

							return (
								<div
									key={column.key}
									className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-800 text-sm"
								>
									<div className="flex items-start gap-2">
										<label className="flex min-w-0 flex-1 cursor-pointer items-start gap-2">
											<input
												type="checkbox"
												checked={isVisible}
												disabled={isOnlyVisibleColumn}
												onChange={(event) =>
													onChangeColumnVisibility(column.key, event.target.checked)
												}
												className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600"
											/>
											<span className="min-w-0 whitespace-pre-line break-words leading-snug">
												{column.label}
											</span>
										</label>

										{hasModeSelector ? (
											<select
												value={selectedMode}
												onChange={(event) =>
													onChangeColumnDisplayMode?.(
														column.key,
														event.target.value,
													)
												}
												className="w-36 shrink-0 rounded-md border border-slate-300 bg-white px-2 py-1.5 text-slate-700 text-xs outline-none transition-colors focus:border-blue-400"
											>
												{modeOptions.map((option) => (
													<option key={option.value} value={option.value}>
														{option.label}
													</option>
												))}
											</select>
										) : null}
									</div>
								</div>
							);
						})}
						</div>
					</div>
				</div>

				<div className="mt-4 flex flex-wrap justify-end gap-2 border-slate-200 border-t bg-white pt-3">
					{onResetSelection ? (
						<button
							type="button"
							onClick={onResetSelection}
							className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
						>
							Reset zaznaczeń
						</button>
					) : null}
					{onHideAllColumns ? (
						<button
							type="button"
							onClick={onHideAllColumns}
							className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
						>
							Odznacz wszystkie
						</button>
					) : null}
					<button
						type="button"
						onClick={onShowAllColumns}
						className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Zaznacz wszystkie
					</button>

					<button
						type="button"
						onClick={onApply}
						className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99]"
					>
						Pokaż
					</button>
				</div>
			</div>
		</div>
	);
}
