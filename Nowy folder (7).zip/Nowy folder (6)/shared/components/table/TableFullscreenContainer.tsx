"use client";

import type { MouseEventHandler, ReactNode } from "react";
import { createPortal } from "react-dom";

type TableFullscreenContainerProps = {
	isFullscreen: boolean;
	onClose: () => void;
	showCloseBar?: boolean;
	children: ReactNode;
	className: string;
	onClick?: MouseEventHandler<HTMLElement>;
};

export function TableFullscreenContainer({
	isFullscreen,
	onClose,
	showCloseBar = true,
	children,
	className,
	onClick,
}: TableFullscreenContainerProps) {
	const section = (
		<section
			className={`${className} ${
				isFullscreen
					? "!fixed !inset-0 !z-[999] !h-dvh !w-screen !max-w-none !px-2 !pt-12 !pb-2 sm:!px-3 sm:!pt-12 sm:!pb-3"
					: ""
			}`}
			onClick={onClick}
		>
			{isFullscreen && showCloseBar ? (
				<div className="pointer-events-none absolute top-3 right-3 z-20">
					<button
						type="button"
						onClick={onClose}
						className="pointer-events-auto inline-flex h-7 items-center rounded-md border border-slate-500/80 bg-[#1b2f50]/95 px-2 font-semibold text-slate-100 text-xs shadow-[0_4px_12px_rgba(2,8,23,0.35)] transition-colors hover:bg-[#294673]"
					>
						Zamknij pełny ekran
					</button>
				</div>
			) : null}
			{children}
		</section>
	);

	if (isFullscreen && typeof document !== "undefined") {
		return createPortal(section, document.body);
	}

	return section;
}
