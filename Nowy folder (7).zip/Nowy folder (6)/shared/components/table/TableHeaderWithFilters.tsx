import { ChevronDown, Info } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import type { TableSortDirection } from "@/shared/types/table";

type TableHeaderColumn<TColumnKey extends string> = {
	key: TColumnKey;
	label: string;
	tooltip?: string;
};

type TableHeaderWithFiltersProps<TColumnKey extends string> = {
	visibleColumns: TableHeaderColumn<TColumnKey>[];
	sortColumnKey: TColumnKey | null;
	sortDirection: TableSortDirection | null;
	advancedFilters: Partial<Record<TColumnKey, string[]>>;
	columnFilters: Partial<Record<TColumnKey, string>>;
	onSortByColumn: (columnKey: TColumnKey) => void;
	onOpenAdvancedFilter: (columnKey: TColumnKey, triggerElement: HTMLElement) => void;
	onFilterChange: (columnKey: TColumnKey, value: string) => void;
	columnWidths?: Partial<Record<TColumnKey, number>>;
	columnMinWidths?: Partial<Record<TColumnKey, number>>;
	onResizeColumn?: (columnKey: TColumnKey, width: number) => void;
	minColumnWidth?: number;
	compact?: boolean;
	wrapHeaderLabels?: boolean;
	controlsInFilterRow?: boolean;
	showInfoIcon?: boolean;
	infoIconSize?: number;
	truncateWrappedHeaderLabels?: boolean;
};

export function TableHeaderWithFilters<TColumnKey extends string>({
	visibleColumns,
	sortColumnKey,
	sortDirection,
	advancedFilters,
	columnFilters,
	onSortByColumn,
	onOpenAdvancedFilter,
	onFilterChange,
	columnWidths,
	columnMinWidths,
	onResizeColumn,
	minColumnWidth = 110,
	compact = false,
	wrapHeaderLabels = false,
	controlsInFilterRow = false,
	showInfoIcon = true,
	infoIconSize,
	truncateWrappedHeaderLabels = true,
}: TableHeaderWithFiltersProps<TColumnKey>) {
	const resizeCleanupRef = useRef<(() => void) | null>(null);
	const headerRowRef = useRef<HTMLTableRowElement | null>(null);
	const [headerRowHeight, setHeaderRowHeight] = useState(compact ? 34 : 44);

	useEffect(() => {
		const headerRowElement = headerRowRef.current;
		if (!headerRowElement) {
			return;
		}

		const updateHeaderHeight = () => {
			const measuredHeight = Math.ceil(
				headerRowElement.getBoundingClientRect().height,
			);
			setHeaderRowHeight((prev) =>
				measuredHeight > 0 && measuredHeight !== prev ? measuredHeight : prev,
			);
		};

		updateHeaderHeight();

		if (typeof ResizeObserver !== "undefined") {
			const observer = new ResizeObserver(updateHeaderHeight);
			observer.observe(headerRowElement);
			return () => observer.disconnect();
		}

		window.addEventListener("resize", updateHeaderHeight);
		return () => {
			window.removeEventListener("resize", updateHeaderHeight);
		};
	}, [compact, visibleColumns.length, wrapHeaderLabels, truncateWrappedHeaderLabels]);

	const startColumnResize = (
		event: React.MouseEvent<HTMLDivElement>,
		columnKey: TColumnKey,
		startWidth: number,
	) => {
		if (!onResizeColumn) {
			return;
		}

		const effectiveMinWidth = Math.max(
			minColumnWidth,
			columnMinWidths?.[columnKey] ?? minColumnWidth,
		);

		event.preventDefault();
		event.stopPropagation();

		const initialX = event.clientX;
		const baseWidth = Number.isFinite(startWidth) && startWidth > 0
			? startWidth
			: effectiveMinWidth;

		const handleMouseMove = (moveEvent: MouseEvent) => {
			const deltaX = moveEvent.clientX - initialX;
			const nextWidth = Math.max(effectiveMinWidth, Math.round(baseWidth + deltaX));
			onResizeColumn(columnKey, nextWidth);
		};

		const cleanup = () => {
			document.removeEventListener("mousemove", handleMouseMove);
			document.removeEventListener("mouseup", cleanup);
			resizeCleanupRef.current = null;
		};

		resizeCleanupRef.current?.();
		resizeCleanupRef.current = cleanup;
		document.addEventListener("mousemove", handleMouseMove);
		document.addEventListener("mouseup", cleanup);
	};

	return (
		<thead>
			<tr ref={headerRowRef} className="bg-slate-100 text-slate-800">
				{visibleColumns.map((column) => {
					const columnWidth = columnWidths?.[column.key];
					const sortIndicator =
						sortColumnKey === column.key
							? sortDirection === "asc"
								? "▲"
								: sortDirection === "desc"
									? "▼"
									: "↕"
							: "↕";

					return (
					<th
						key={column.key}
						className={`sticky top-0 z-30 border-slate-300 border-b bg-slate-100 text-left font-semibold hover:z-40 focus-within:z-40 ${
							wrapHeaderLabels ? "" : "whitespace-nowrap"
						} ${
							compact ? "px-2 py-1.5 text-xs" : "px-3 py-2"
						}`}
						style={
							columnWidth
								? { width: columnWidth, minWidth: columnWidth, maxWidth: columnWidth }
								: undefined
						}
					>
						<div
							className={`group relative flex w-full gap-1.5 pr-8 ${
								wrapHeaderLabels ? "items-start" : "items-center"
							}`}
						>
							<div
								className={`inline-flex min-w-0 gap-1.5 rounded-sm px-0.5 py-0.5 text-left ${
									wrapHeaderLabels ? "items-start" : "items-center"
								}`}
							>
								{showInfoIcon && column.tooltip ? (
									<Info
										size={infoIconSize ?? (compact ? 12 : 13)}
										className="mt-0.5 shrink-0 text-[#5d7fa8] transition-colors duration-150 group-hover:text-[#1f4f8f] group-focus-within:text-[#1f4f8f]"
										aria-hidden="true"
									/>
								) : null}
								<span
									className={
										wrapHeaderLabels
											? truncateWrappedHeaderLabels
												? "min-w-0 overflow-hidden whitespace-pre-line break-words text-sm leading-4 [display:-webkit-box] [-webkit-box-orient:vertical] [-webkit-line-clamp:2]"
												: "min-w-0 whitespace-pre-line break-words text-sm leading-4"
											: "truncate"
									}
								>
									{column.label}
								</span>
								{controlsInFilterRow ? null : (
									<span className="text-[10px] text-slate-500 leading-none">
										{sortIndicator}
									</span>
								)}
							</div>

							{controlsInFilterRow ? (
								<button
									type="button"
									onClick={() => onSortByColumn(column.key)}
									className="absolute top-1/2 right-0 inline-flex h-6 w-5 -translate-y-1/2 items-center justify-center rounded text-sm text-slate-500 leading-none transition-colors hover:text-slate-700"
									aria-label={`Sortuj kolumnę ${column.label}`}
								>
									{sortIndicator}
								</button>
							) : null}

							{column.tooltip ? (
								<div className="pointer-events-none absolute top-full left-0 z-50 mt-2 w-[min(22rem,90vw)] translate-y-1 whitespace-pre-line rounded-xl border border-[#b8cbe3] bg-gradient-to-b from-white to-[#f5f9ff] px-3 py-2 text-[#1d3557] text-[13px] leading-5 opacity-0 shadow-[0_14px_30px_rgba(15,35,70,0.18)] transition-all duration-150 before:absolute before:-top-1.5 before:left-4 before:h-3 before:w-3 before:rotate-45 before:border-[#b8cbe3] before:border-l before:border-t before:bg-white before:content-[''] group-hover:pointer-events-auto group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:pointer-events-auto group-focus-within:translate-y-0 group-focus-within:opacity-100">
									{column.tooltip}
								</div>
							) : null}

							{controlsInFilterRow ? null : (
								<button
									type="button"
									onClick={(event) => {
										event.stopPropagation();
										onOpenAdvancedFilter(column.key, event.currentTarget);
									}}
									aria-label={
										column.tooltip
											? `Filtruj kolumnę ${column.label}. ${column.tooltip}`
											: `Filtruj kolumnę ${column.label}`
									}
									className={`absolute top-1/2 right-0 inline-flex h-6 w-5 -translate-y-1/2 items-center justify-center rounded border transition-colors ${
										(advancedFilters[column.key] ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									<ChevronDown size={compact ? 11 : 12} />
								</button>
							)}

						</div>

						{onResizeColumn ? (
							<div
								role="separator"
								aria-orientation="vertical"
								onMouseDown={(event) =>
									startColumnResize(
										event,
										column.key,
										columnWidth ??
											event.currentTarget.parentElement?.getBoundingClientRect().width ??
											minColumnWidth,
									)
								}
								className="absolute top-0 -right-px z-20 h-full w-2 cursor-col-resize before:absolute before:top-0 before:left-1/2 before:h-full before:w-px before:-translate-x-1/2 before:bg-slate-300 before:content-[''] hover:before:bg-blue-500"
								title="Przeciągnij, aby zmienić szerokość kolumny"
							/>
						) : null}
					</th>
					);
				})}
			</tr>

			<tr className="bg-white text-slate-700">
				{visibleColumns.map((column) => {
					const columnWidth = columnWidths?.[column.key];
					const sortIndicator =
						sortColumnKey === column.key
							? sortDirection === "asc"
								? "▲"
								: sortDirection === "desc"
									? "▼"
									: "↕"
							: "↕";

					return (
					<th
						key={`${column.key}-filter`}
						className={`sticky z-20 overflow-hidden border-slate-200 border-b bg-white ${
							compact ? "px-1.5 py-1.5" : "px-2 py-2"
						}`}
						style={
							columnWidth
								? {
										top: headerRowHeight,
										width: columnWidth,
										minWidth: columnWidth,
										maxWidth: columnWidth,
								  }
								: { top: headerRowHeight }
						}
					>
						{controlsInFilterRow ? (
							<div className="flex items-center gap-1">
								<input
									type="text"
									value={columnFilters[column.key] ?? ""}
									onChange={(event) =>
										onFilterChange(column.key, event.target.value)
									}
									placeholder="Filtruj..."
									className={`min-w-0 flex-1 rounded-md border border-slate-300 bg-white text-slate-800 outline-none transition-colors focus:border-blue-400 ${
										compact ? "px-1.5 py-0.5 text-[11px]" : "px-2 py-1 text-xs"
									}`}
								/>
								<button
									type="button"
									onClick={(event) => {
										event.stopPropagation();
										onOpenAdvancedFilter(column.key, event.currentTarget);
									}}
									aria-label={
										column.tooltip
											? `Filtruj kolumnę ${column.label}. ${column.tooltip}`
											: `Filtruj kolumnę ${column.label}`
									}
									className={`inline-flex h-6 w-5 items-center justify-center rounded border transition-colors ${
										(advancedFilters[column.key] ?? []).length > 0
											? "border-blue-400 bg-blue-50 text-blue-700"
											: "border-slate-300 bg-white text-slate-600 hover:bg-slate-100"
									}`}
								>
									<ChevronDown size={compact ? 11 : 12} />
								</button>
							</div>
						) : (
							<input
								type="text"
								value={columnFilters[column.key] ?? ""}
								onChange={(event) =>
									onFilterChange(column.key, event.target.value)
								}
								placeholder="Filtruj..."
								className={`w-full rounded-md border border-slate-300 bg-white text-slate-800 outline-none transition-colors focus:border-blue-400 ${
									compact ? "px-1.5 py-0.5 text-[11px]" : "px-2 py-1 text-xs"
								}`}
							/>
						)}
					</th>
					);
				})}
			</tr>
		</thead>
	);
}
