import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";

type TablePaginationProps = {
	currentPage: number;
	totalPages: number;
	paginationItems: Array<number | "ellipsis">;
	totalItems: number;
	pageSize: number;
	onPageChange: (nextPage: number) => void;
	showResultSummary?: boolean;
	showPageSummary?: boolean;
	pageSizeOptions?: number[];
	onPageSizeChange?: (nextPageSize: number) => void;
	showClearFiltersButton?: boolean;
	onClearFilters?: () => void;
	clearFiltersLabel?: string;
	showWhenSinglePage?: boolean;
	showTotalRowsLabel?: boolean;
	totalRowsLabel?: string;
};

export function TablePagination({
	currentPage,
	totalPages,
	paginationItems,
	totalItems,
	pageSize,
	onPageChange,
	showResultSummary = false,
	showPageSummary = false,
	pageSizeOptions,
	onPageSizeChange,
	showClearFiltersButton = false,
	onClearFilters,
	clearFiltersLabel = "Wyczyść filtry",
	showWhenSinglePage = false,
	showTotalRowsLabel = false,
	totalRowsLabel = "Liczba wierszy:",
}: TablePaginationProps) {
	if (totalPages <= 1 && !showWhenSinglePage) {
		return null;
	}

	const firstItemIndex = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
	const lastItemIndex = Math.min(currentPage * pageSize, totalItems);

	return (
		<div className="w-full max-w-full px-4 py-1">
			<div className="grid grid-cols-1 gap-1 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
				<div className="text-center text-slate-600 text-xs lg:text-left">
					{showResultSummary ? `Wyniki ${firstItemIndex}-${lastItemIndex} z ${totalItems}` : null}
				</div>

				<nav
					className="flex w-full justify-center overflow-x-auto"
					aria-label="Nawigacja stronicowania tabeli"
				>
					<div className="flex min-w-max items-center gap-1 pb-0.5">
						<button
							type="button"
							disabled={currentPage <= 1}
							onClick={() => onPageChange(1)}
							className="hidden h-8 min-w-8 items-center justify-center rounded-md border border-slate-300 bg-white px-1.5 font-medium text-slate-700 text-xs transition-colors disabled:cursor-not-allowed disabled:opacity-45 hover:bg-slate-100 sm:inline-flex"
							aria-label="Pierwsza strona"
						>
							<ChevronsLeft size={13} />
						</button>

						<button
							type="button"
							disabled={currentPage <= 1}
							onClick={() => onPageChange(currentPage - 1)}
							className="inline-flex h-8 min-w-8 items-center justify-center rounded-md border border-slate-300 bg-white px-1.5 font-medium text-slate-700 text-xs transition-colors disabled:cursor-not-allowed disabled:opacity-45 hover:bg-slate-100"
							aria-label="Poprzednia strona"
						>
							<ChevronLeft size={13} />
						</button>

						{paginationItems.map((item, index) =>
							item === "ellipsis" ? (
								<span
									key={`ellipsis-${index}`}
									className="inline-flex h-8 min-w-6 items-center justify-center px-1 text-slate-500 text-xs"
								>
									...
								</span>
							) : (
								<button
									type="button"
									key={`page-${item}`}
									onClick={() => onPageChange(item)}
									aria-current={currentPage === item ? "page" : undefined}
									aria-label={`Przejdz do strony ${item}`}
									className={`inline-flex h-8 min-w-8 items-center justify-center rounded-full border px-2 font-medium text-xs transition-colors ${
										currentPage === item
											? "border-[#2b5d9a] bg-[#2b5d9a] text-white shadow-[0_3px_8px_rgba(43,93,154,0.24)]"
											: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
									}`}
								>
									{item}
								</button>
							),
						)}

						<button
							type="button"
							disabled={currentPage >= totalPages}
							onClick={() => onPageChange(currentPage + 1)}
							className="inline-flex h-8 min-w-8 items-center justify-center rounded-md border border-slate-300 bg-white px-1.5 font-medium text-slate-700 text-xs transition-colors disabled:cursor-not-allowed disabled:opacity-45 hover:bg-slate-100"
							aria-label="Nastepna strona"
						>
							<ChevronRight size={13} />
						</button>

						<button
							type="button"
							disabled={currentPage >= totalPages}
							onClick={() => onPageChange(totalPages)}
							className="hidden h-8 min-w-8 items-center justify-center rounded-md border border-slate-300 bg-white px-1.5 font-medium text-slate-700 text-xs transition-colors disabled:cursor-not-allowed disabled:opacity-45 hover:bg-slate-100 sm:inline-flex"
							aria-label="Ostatnia strona"
						>
							<ChevronsRight size={13} />
						</button>
					</div>
				</nav>

				<div className="flex items-center justify-center gap-2 pr-1 text-center text-slate-600 text-xs lg:-mr-2 lg:justify-end lg:text-right">
					{showPageSummary ? `Strona ${currentPage}/${totalPages} • po ${pageSize}` : null}
					{showTotalRowsLabel ? (
						<span className="inline-flex items-center gap-1.5 text-slate-600 text-xs">
							<span>{totalRowsLabel}</span>
							<strong className="font-semibold text-slate-700">{totalItems}</strong>
						</span>
					) : null}
					{showTotalRowsLabel && Array.isArray(pageSizeOptions) && pageSizeOptions.length > 0 && onPageSizeChange ? (
						<span
							aria-hidden="true"
							className="mx-1 hidden h-5 w-px bg-slate-300 lg:inline-block"
						/>
					) : null}
					{showClearFiltersButton && onClearFilters ? (
						<button
							type="button"
							onClick={onClearFilters}
							className="inline-flex h-8 items-center rounded-md border border-slate-300 bg-white px-2 font-medium text-slate-700 text-xs transition-colors hover:bg-slate-100"
						>
							{clearFiltersLabel}
						</button>
					) : null}
					{Array.isArray(pageSizeOptions) && pageSizeOptions.length > 0 && onPageSizeChange ? (
						<label className="ml-1 flex items-center gap-1.5 text-slate-600 text-xs">
							<span>Na stronie:</span>
							<select
								value={pageSize}
								onChange={(event) => onPageSizeChange(Number(event.target.value))}
								className="h-8 rounded-md border border-slate-300 bg-white px-2 text-slate-700 text-xs"
							>
								{pageSizeOptions.map((option) => (
									<option key={option} value={option}>
										{option}
									</option>
								))}
							</select>
						</label>
					) : null}
				</div>
			</div>
		</div>
	);
}
