import type { ReactNode } from "react";

type TableSurfaceProps = {
	isLoading?: boolean;
	loadingMessage?: string;
	errorMessage?: string | null;
	footer?: ReactNode;
	containerClassName?: string;
	scrollAreaClassName?: string;
	children: ReactNode;
};

export function TableSurface({
	isLoading = false,
	loadingMessage = "Ładowanie danych...",
	errorMessage = null,
	footer = null,
	containerClassName = "",
	scrollAreaClassName = "h-[calc(96vh-10rem)] min-h-96",
	children,
}: TableSurfaceProps) {
	return (
		<div
			className={`w-full max-w-full overflow-hidden rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)] ${containerClassName}`}
		>
			{errorMessage ? (
				<p className="border-rose-200 border-b bg-rose-50 px-3 py-2 font-medium text-rose-700 text-sm">
					{errorMessage}
				</p>
			) : null}

			<div
				className={`subtle-horizontal-scroll subtle-vertical-scroll table-scroll-gutter-right w-full max-w-full overflow-x-auto overflow-y-auto ${scrollAreaClassName}`}
			>
				{isLoading ? (
					<div className="flex h-full min-h-[14rem] items-center justify-center bg-linear-to-b from-slate-50 to-white">
						<div className="flex flex-col items-center gap-2 text-slate-600">
							<div
								className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-[#2b5d9a]"
								aria-hidden="true"
							/>
							<p className="font-medium text-sm">{loadingMessage}</p>
						</div>
					</div>
				) : (
					children
				)}
			</div>

			{footer ? (
				<div className="border-slate-200 border-t bg-gradient-to-b from-slate-50 to-white">
					{footer}
				</div>
			) : null}
		</div>
	);
}
