import { useCallback, useEffect, useRef, useState } from "react";

type UseInactivityTimeoutParams = {
	enabled: boolean;
	inactivityMs: number;
	warningMs: number;
	onTimeout: () => void;
};

export function useInactivityTimeout({
	enabled,
	inactivityMs,
	warningMs,
	onTimeout,
}: UseInactivityTimeoutParams) {
	const [isWarning, setIsWarning] = useState(false);
	const [secondsRemaining, setSecondsRemaining] = useState(0);

	const isWarningRef = useRef(false);
	const inactivityTimerRef = useRef<number | null>(null);
	const countdownIntervalRef = useRef<number | null>(null);
	const lastActivityAtRef = useRef<number>(Date.now());
	const warningStartedAtRef = useRef<number | null>(null);
	const didTimeoutRef = useRef(false);
	const onTimeoutRef = useRef(onTimeout);
	const enabledRef = useRef(enabled);

	useEffect(() => {
		onTimeoutRef.current = onTimeout;
	}, [onTimeout]);

	useEffect(() => {
		enabledRef.current = enabled;
	}, [enabled]);

	const clearTimers = useCallback(() => {
		if (inactivityTimerRef.current !== null) {
			window.clearTimeout(inactivityTimerRef.current);
			inactivityTimerRef.current = null;
		}
		if (countdownIntervalRef.current !== null) {
			window.clearInterval(countdownIntervalRef.current);
			countdownIntervalRef.current = null;
		}
	}, []);

	const runTimeout = useCallback(() => {
		if (didTimeoutRef.current) return;
		didTimeoutRef.current = true;
		clearTimers();
		isWarningRef.current = false;
		warningStartedAtRef.current = null;
		setIsWarning(false);
		setSecondsRemaining(0);
		onTimeoutRef.current();
	}, [clearTimers]);

	const updateCountdownFromNow = useCallback(() => {
		const warningStartedAt = warningStartedAtRef.current;
		if (!warningStartedAt) return;

		const elapsedWarningMs = Date.now() - warningStartedAt;
		const remainingMs = Math.max(0, warningMs - elapsedWarningMs);
		const nextSeconds = Math.ceil(remainingMs / 1000);
		setSecondsRemaining(nextSeconds);

		if (remainingMs <= 0) {
			runTimeout();
		}
	}, [runTimeout, warningMs]);

	const startCountdown = useCallback((elapsedWarningMs = 0) => {
		clearTimers();
		isWarningRef.current = true;
		setIsWarning(true);
		warningStartedAtRef.current = Date.now() - elapsedWarningMs;
		updateCountdownFromNow();

		countdownIntervalRef.current = window.setInterval(() => {
			updateCountdownFromNow();
		}, 1000);
	}, [clearTimers, updateCountdownFromNow]);

	const scheduleInactivityPhase = useCallback((delayMs: number) => {
		if (!enabledRef.current) return;

		inactivityTimerRef.current = window.setTimeout(() => {
			inactivityTimerRef.current = null;
			startCountdown(0);
		}, Math.max(0, delayMs));
	}, [startCountdown]);

	const evaluateTimeProgress = useCallback(() => {
		if (!enabledRef.current || didTimeoutRef.current) return;

		const elapsedSinceActivityMs = Date.now() - lastActivityAtRef.current;
		if (elapsedSinceActivityMs < inactivityMs) {
			if (isWarningRef.current) {
				isWarningRef.current = false;
				warningStartedAtRef.current = null;
				setIsWarning(false);
				setSecondsRemaining(0);
			}
			clearTimers();
			scheduleInactivityPhase(inactivityMs - elapsedSinceActivityMs);
			return;
		}

		const elapsedWarningMs = elapsedSinceActivityMs - inactivityMs;
		if (elapsedWarningMs >= warningMs) {
			runTimeout();
			return;
		}

		startCountdown(elapsedWarningMs);
	}, [clearTimers, inactivityMs, runTimeout, scheduleInactivityPhase, startCountdown, warningMs]);

	const resetTimer = useCallback(() => {
		didTimeoutRef.current = false;
		lastActivityAtRef.current = Date.now();
		warningStartedAtRef.current = null;
		clearTimers();
		isWarningRef.current = false;
		setIsWarning(false);
		setSecondsRemaining(0);

		if (!enabledRef.current) return;

		scheduleInactivityPhase(inactivityMs);
	}, [clearTimers, inactivityMs, scheduleInactivityPhase]);

	useEffect(() => {
		if (!enabled) {
			didTimeoutRef.current = false;
			warningStartedAtRef.current = null;
			clearTimers();
			isWarningRef.current = false;
			setIsWarning(false);
			setSecondsRemaining(0);
			return;
		}

		const handleActivity = () => {
			resetTimer();
		};

		const handleVisibilityOrFocus = () => {
			evaluateTimeProgress();
		};

		document.addEventListener("keydown", handleActivity);
		document.addEventListener("mousedown", handleActivity);
		document.addEventListener("scroll", handleActivity, true);
		document.addEventListener("visibilitychange", handleVisibilityOrFocus);
		window.addEventListener("focus", handleVisibilityOrFocus);
		window.addEventListener("pageshow", handleVisibilityOrFocus);

		resetTimer();

		return () => {
			document.removeEventListener("keydown", handleActivity);
			document.removeEventListener("mousedown", handleActivity);
			document.removeEventListener("scroll", handleActivity, true);
			document.removeEventListener("visibilitychange", handleVisibilityOrFocus);
			window.removeEventListener("focus", handleVisibilityOrFocus);
			window.removeEventListener("pageshow", handleVisibilityOrFocus);
			clearTimers();
		};
	}, [enabled, resetTimer, clearTimers, evaluateTimeProgress]);

	return {
		isWarning,
		secondsRemaining,
		resetTimer,
	};
}
