import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
	acquireRecordLock,
	heartbeatRecordLock,
	releaseRecordLock,
	type RecordLockDetails,
} from "@/shared/api/record-lock";

type RecordLockStatus =
	| "idle"
	| "acquiring"
	| "locked"
	| "blocked"
	| "lost"
	| "expired"
	| "error";

type UseRecordLockParams = {
	enabled: boolean;
	module: string;
	recordId: string | number | null;
	alternateRecordIds?: Array<string | number | null>;
	operatorLogin: string;
	heartbeatIntervalMs?: number;
};

function normalizeRecordId(recordId: string | number | null) {
	if (typeof recordId === "number" && Number.isFinite(recordId) && recordId > 0) {
		return String(recordId);
	}

	if (typeof recordId === "string") {
		const trimmed = recordId.trim();
		return trimmed || "";
	}

	return "";
}

const MAX_ACQUIRE_RETRIES = 2;
const ACQUIRE_RETRY_DELAY_MS = 2_000;
const HEARTBEAT_RETRY_INTERVAL_MS = 5_000;
const HEARTBEAT_MAX_RETRIES = 10;

function sleep(ms: number) {
	return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

export function useRecordLock({
	enabled,
	module,
	recordId,
	alternateRecordIds = [],
	operatorLogin,
	heartbeatIntervalMs = 20_000,
}: UseRecordLockParams) {
	const resolvedRecordId = normalizeRecordId(recordId);
	// Stabilize alternateRecordIds using a primitive key to avoid infinite
	// re-render when callers pass a new [] literal on every render.
	const altIdsKey = alternateRecordIds.map(normalizeRecordId).filter(Boolean).join("|");
	const acquireRecordIdCandidates = useMemo(() => {
		const altIds = altIdsKey ? altIdsKey.split("|") : [];
		const candidates = [resolvedRecordId, ...altIds]
			.map((value) => value.trim())
			.filter(Boolean);

		return Array.from(new Set(candidates));
	// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [resolvedRecordId, altIdsKey]);
	const [status, setStatus] = useState<RecordLockStatus>("idle");
	const [error, setError] = useState<string | null>(null);
	const [lockDetails, setLockDetails] = useState<RecordLockDetails | null>(null);
	const [lockToken, setLockToken] = useState<string | null>(null);
	const [effectiveRecordId, setEffectiveRecordId] = useState<string>(
		resolvedRecordId,
	);
	const effectiveRecordIdRef = useRef<string>(resolvedRecordId);
	const lockTokenRef = useRef<string | null>(null);
	const heartbeatIntervalRef = useRef<number | null>(null);
	const heartbeatRetryIntervalRef = useRef<number | null>(null);
	const heartbeatRetryCountRef = useRef(0);
	const releaseInFlightRef = useRef(false);
	const acquireAbortedRef = useRef(false);

	useEffect(() => {
		lockTokenRef.current = lockToken;
	}, [lockToken]);

	useEffect(() => {
		effectiveRecordIdRef.current = effectiveRecordId;
	}, [effectiveRecordId]);

	useEffect(() => {
		if (!lockTokenRef.current) {
			setEffectiveRecordId(resolvedRecordId);
		}
	}, [resolvedRecordId]);

	const stopHeartbeat = useCallback(() => {
		if (heartbeatIntervalRef.current !== null) {
			window.clearInterval(heartbeatIntervalRef.current);
			heartbeatIntervalRef.current = null;
		}
	}, []);

	const stopHeartbeatRetry = useCallback(() => {
		if (heartbeatRetryIntervalRef.current !== null) {
			window.clearInterval(heartbeatRetryIntervalRef.current);
			heartbeatRetryIntervalRef.current = null;
		}
		heartbeatRetryCountRef.current = 0;
	}, []);

	useEffect(() => {
		const handleUnload = () => {
			const token = lockTokenRef.current;
			const recId = effectiveRecordIdRef.current;
			if (!token || !recId) return;
			const endpoint = `/api/locks/${encodeURIComponent(module)}/${encodeURIComponent(recId)}/release`;
			const blob = new Blob([JSON.stringify({ lockToken: token, operatorLogin: operatorLogin })], {
				type: "application/json",
			});
			navigator.sendBeacon(endpoint, blob);
		};
		window.addEventListener("beforeunload", handleUnload);
		return () => window.removeEventListener("beforeunload", handleUnload);
	}, [module]);

	const release = useCallback(async (providedToken?: string) => {
		const token = providedToken ?? lockTokenRef.current;
		const targetRecordId = effectiveRecordIdRef.current;
		if (!targetRecordId || !token || releaseInFlightRef.current) {
			return;
		}

		releaseInFlightRef.current = true;
		try {
			await releaseRecordLock({
				module,
				recordId: targetRecordId,
				operatorLogin,
				lockToken: token,
			});
		} finally {
			releaseInFlightRef.current = false;
			lockTokenRef.current = null;
			effectiveRecordIdRef.current = resolvedRecordId;
			setEffectiveRecordId(resolvedRecordId);
			setLockToken(null);
			setLockDetails(null);
			setStatus("idle");
			setError(null);
		}
	}, [module, operatorLogin, resolvedRecordId]);

	const acquire = useCallback(async () => {
		if (!enabled || acquireRecordIdCandidates.length === 0) {
			setStatus("idle");
			setError(null);
			setLockDetails(null);
			setLockToken(null);
			return;
		}

		acquireAbortedRef.current = false;
		setStatus("acquiring");
		setError(null);

		let lastNetworkError: string | null = null;

		for (let attempt = 0; attempt <= MAX_ACQUIRE_RETRIES; attempt++) {
			if (attempt > 0) {
				await sleep(ACQUIRE_RETRY_DELAY_MS);
				if (acquireAbortedRef.current) return;
			}

			try {
				for (const candidateRecordId of acquireRecordIdCandidates) {
					const result = await acquireRecordLock({
						module,
						recordId: candidateRecordId,
						operatorLogin,
					});

					if (acquireAbortedRef.current) return;

					if (!result.ok) {
						if (result.status === 404) {
							continue;
						}

						if (result.status === 423) {
							if (result.errorCode === "RECORD_LOCKED") {
								setStatus("blocked");
								setLockDetails(result.lockDetails);
								setError(result.error);
								setLockToken(null);
								return;
							}

							setStatus("error");
							setLockDetails(result.lockDetails);
							setError(result.error);
							setLockToken(null);
							return;
						}

						// Other API error — don't retry
						setStatus("error");
						setLockDetails(result.lockDetails);
						setError(result.error);
						setLockToken(null);
						return;
					}

					setEffectiveRecordId(candidateRecordId);
					setStatus("locked");
					setLockDetails(result.data);
					setLockToken(result.data.lockToken);
					setError(null);
					return;
				}

				// All candidates returned 404 — record not found, no point retrying
				setStatus("error");
				setLockDetails(null);
				setLockToken(null);
				setError("Rekord nie istnieje.");
				return;
			} catch {
				// Network error — retry
				lastNetworkError = "Nie udało się założyć blokady rekordu. Sprawdź połączenie z siecią.";
			}
		}

		// All retries exhausted after network errors
		setStatus("error");
		setError(lastNetworkError ?? "Nie udało się założyć blokady rekordu.");
		setLockDetails(null);
		setLockToken(null);
	}, [acquireRecordIdCandidates, enabled, module, operatorLogin]);

	useEffect(() => {
		if (!enabled || !resolvedRecordId) {
			acquireAbortedRef.current = true;
			stopHeartbeat();
			stopHeartbeatRetry();
			if (lockTokenRef.current) {
				void release(lockTokenRef.current);
			}
			return;
		}

		void acquire();
		return () => {
			acquireAbortedRef.current = true;
			stopHeartbeat();
			stopHeartbeatRetry();
			if (lockTokenRef.current) {
				void release(lockTokenRef.current);
			}
		};
	}, [acquire, enabled, release, resolvedRecordId, stopHeartbeat, stopHeartbeatRetry]);

	useEffect(() => {
		if (!enabled || !effectiveRecordId || !lockToken || status !== "locked") {
			stopHeartbeat();
			return;
		}

		const runHeartbeat = async () => {
			let result;
			try {
				result = await heartbeatRecordLock({
					module,
					recordId: effectiveRecordId,
					operatorLogin,
					lockToken,
				});
			} catch {
				// Network error — enter "lost" state and start retry loop
				stopHeartbeat();
				heartbeatRetryCountRef.current = 0;
				setStatus("lost");
				setError("Utracono połączenie z serwerem — trwa próba odnowienia blokady...");
				return;
			}

			if (!result.ok) {
				if (result.status === 423) {
					if (result.errorCode === "RECORD_LOCKED") {
						setStatus("blocked");
						setError(result.error);
						setLockDetails(result.lockDetails);
						setLockToken(null);
						stopHeartbeat();
						return;
					}

					setStatus("error");
					setError(result.error);
					setLockDetails(result.lockDetails);
					setLockToken(null);
					stopHeartbeat();
					return;
				}

				// Non-423 API error — also enter "lost" to retry
				stopHeartbeat();
				heartbeatRetryCountRef.current = 0;
				setStatus("lost");
				setError("Utracono połączenie z serwerem — trwa próba odnowienia blokady...");
				return;
			}

			setLockDetails(result.data);
		};

		heartbeatIntervalRef.current = window.setInterval(() => {
			void runHeartbeat();
		}, heartbeatIntervalMs);

		return () => {
			stopHeartbeat();
		};
	}, [effectiveRecordId, enabled, heartbeatIntervalMs, lockToken, module, operatorLogin, status, stopHeartbeat]);

	// Retry heartbeat when connection is lost
	useEffect(() => {
		if (status !== "lost" || !effectiveRecordId || !lockToken) {
			stopHeartbeatRetry();
			return;
		}

		const runRetry = async () => {
			if (heartbeatRetryCountRef.current >= HEARTBEAT_MAX_RETRIES) {
				stopHeartbeatRetry();
				setStatus("expired");
				setError(
					"Czas edycji wygasł — połączenie zostało przerwane zbyt długo. Zamknij formularz i otwórz ponownie.",
				);
				setLockToken(null);
				return;
			}

			heartbeatRetryCountRef.current += 1;

			let result;
			try {
				result = await heartbeatRecordLock({
					module,
					recordId: effectiveRecordId,
					operatorLogin,
					lockToken,
				});
			} catch {
				// Still no connection, retry on next interval
				return;
			}

			if (!result.ok) {
				if (result.status === 423 && result.errorCode === "RECORD_LOCKED") {
					stopHeartbeatRetry();
					setStatus("blocked");
					setError(result.error);
					setLockDetails(result.lockDetails);
					setLockToken(null);
					return;
				}
				// Other error — keep retrying until max
				return;
			}

			// Connection restored!
			stopHeartbeatRetry();
			setStatus("locked");
			setLockDetails(result.data);
			setError(null);
		};

		heartbeatRetryIntervalRef.current = window.setInterval(() => {
			void runRetry();
		}, HEARTBEAT_RETRY_INTERVAL_MS);

		return () => {
			stopHeartbeatRetry();
		};
	}, [effectiveRecordId, lockToken, module, operatorLogin, status, stopHeartbeatRetry]);

	const owner = lockDetails?.owner ?? null;

	const ownerLabel = useMemo(() => {
		if (!owner) {
			return "";
		}

		const name = owner.displayName || "Nieznany użytkownik";
		const login = owner.login ? ` (${owner.login})` : "";
		return `${name}${login}`;
	}, [owner]);

	const retryAcquire = useCallback(() => {
		if (status !== "error") return;
		void acquire();
	}, [acquire, status]);

	return {
		status,
		error,
		lockDetails,
		lockToken,
		owner,
		ownerLabel,
		acquire,
		release,
		retryAcquire,
		isLocked: status === "locked",
		isBlocked: status === "blocked",
		isAcquireFailed: status === "error",
		isConnectionLost: status === "lost",
		isExpired: status === "expired",
	};
}
