import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
	createAdvancedDateRangeFilterToken,
	getAdvancedDateRangeFromSelectedValues,
	hasActiveTableFilters,
	isAdvancedDateRangeFilterToken,
	matchesAdvancedFilterCellValue,
	splitAdvancedFilterCellValue,
} from "@/shared/utils/table-filters";
import type {
	TableAdvancedFilters,
	TableColumnFilters,
	TableSortDirection,
} from "@/shared/types/table";

type UseTableStateOptions<TRow, TColumnKey extends string> = {
	rows: TRow[];
	allColumnKeys: TColumnKey[];
	initialAdvancedFilterColumnKey: TColumnKey;
	initialSortColumnKey?: TColumnKey | null;
	initialSortDirection?: TableSortDirection | null;
	paginationResetMode?: "start" | "end";
	initialPageMode?: "start" | "end";
	getCellValue: (row: TRow, columnKey: TColumnKey) => string;
	advancedFilterValueSplitter?: (
		rawValue: string,
		columnKey: TColumnKey,
		row: TRow,
	) => string[];
	advancedFilterMatcher?: (
		rawValue: string,
		selectedValues: string[],
		columnKey: TColumnKey,
		row: TRow,
	) => boolean;
	pageSize?: number;
	alignToEndPageSize?: boolean;
	hiddenColumnsStorageKey?: string;
	hiddenColumnsStorageArea?: "localStorage" | "sessionStorage";
	sortComparators?: Partial<
		Record<TColumnKey, (leftRow: TRow, rightRow: TRow) => number>
	>;
};

const DEFAULT_TABLE_PAGE_SIZE = 25;

function readPersistedCurrentPage(
	hiddenColumnsStorageKey: string | undefined,
	hiddenColumnsStorageArea: "localStorage" | "sessionStorage",
) {
	if (typeof window === "undefined" || !hiddenColumnsStorageKey) {
		return null;
	}

	const storage =
		hiddenColumnsStorageArea === "localStorage"
			? window.localStorage
			: window.sessionStorage;
	const raw = storage.getItem(hiddenColumnsStorageKey);
	if (!raw) {
		return null;
	}

	try {
		const parsed = JSON.parse(raw) as unknown;
		if (
			parsed &&
			typeof parsed === "object" &&
			!Array.isArray(parsed) &&
			typeof (parsed as { currentPage?: unknown }).currentPage === "number" &&
			Number.isFinite((parsed as { currentPage?: number }).currentPage)
		) {
			return Math.max(
				1,
				Math.trunc((parsed as { currentPage: number }).currentPage),
			);
		}
	} catch {
		// Ignore invalid persisted state.
	}

	return null;
}

type PaginationItem = number | "ellipsis";

function createRange(start: number, end: number) {
	const length = end - start + 1;
	return Array.from({ length }, (_, index) => index + start);
}

function buildPaginationItems(
	currentPage: number,
	totalPages: number,
	siblingCount = 1,
): PaginationItem[] {
	const totalPageNumbers = siblingCount + 5;

	if (totalPageNumbers >= totalPages) {
		return createRange(1, totalPages);
	}

	const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
	const rightSiblingIndex = Math.min(currentPage + siblingCount, totalPages);

	const shouldShowLeftDots = leftSiblingIndex > 2;
	const shouldShowRightDots = rightSiblingIndex < totalPages - 2;

	if (!shouldShowLeftDots && shouldShowRightDots) {
		const leftItemCount = 3 + 2 * siblingCount;
		const leftRange = createRange(1, leftItemCount);
		return [...leftRange, "ellipsis", totalPages];
	}

	if (shouldShowLeftDots && !shouldShowRightDots) {
		const rightItemCount = 3 + 2 * siblingCount;
		const rightRange = createRange(totalPages - rightItemCount + 1, totalPages);
		return [1, "ellipsis", ...rightRange];
	}

	if (shouldShowLeftDots && shouldShowRightDots) {
		const middleRange = createRange(leftSiblingIndex, rightSiblingIndex);
		return [1, "ellipsis", ...middleRange, "ellipsis", totalPages];
	}

	return createRange(1, totalPages);
}

function getFirstPageSize(totalItems: number, pageSize: number) {
	if (totalItems <= 0 || pageSize <= 0) {
		return 0;
	}

	const remainder = totalItems % pageSize;
	return remainder === 0 ? pageSize : remainder;
}

export function useTableState<TRow, TColumnKey extends string>({
	rows,
	allColumnKeys,
	initialAdvancedFilterColumnKey,
	initialSortColumnKey = null,
	initialSortDirection = null,
	paginationResetMode = "end",
	initialPageMode = "end",
	getCellValue,
	advancedFilterValueSplitter,
	advancedFilterMatcher,
	pageSize = DEFAULT_TABLE_PAGE_SIZE,
	alignToEndPageSize = false,
	hiddenColumnsStorageKey,
	hiddenColumnsStorageArea = "sessionStorage",
	sortComparators,
}: UseTableStateOptions<TRow, TColumnKey>) {
	const [sortColumnKey, setSortColumnKey] = useState<TColumnKey | null>(
		initialSortColumnKey,
	);
	const [sortDirection, setSortDirection] = useState<TableSortDirection | null>(
		initialSortDirection,
	);
	const [columnFilters, setColumnFilters] =
		useState<TableColumnFilters<TColumnKey>>({});
	const [advancedFilters, setAdvancedFilters] =
		useState<TableAdvancedFilters<TColumnKey>>({});
	const [isAdvancedFilterModalOpen, setIsAdvancedFilterModalOpen] =
		useState(false);
	const [advancedFilterColumnKey, setAdvancedFilterColumnKey] =
		useState<TColumnKey>(initialAdvancedFilterColumnKey);
	const [advancedFilterSearch, setAdvancedFilterSearch] = useState("");
	const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
	const [hiddenColumns, setHiddenColumns] = useState<TColumnKey[]>([]);
	const [draftHiddenColumns, setDraftHiddenColumns] = useState<TColumnKey[]>([]);
	const [areHiddenColumnsHydrated, setAreHiddenColumnsHydrated] = useState(
		() => !hiddenColumnsStorageKey,
	);
	const [currentPage, setCurrentPage] = useState(
		() =>
			readPersistedCurrentPage(
				hiddenColumnsStorageKey,
				hiddenColumnsStorageArea,
			) ?? 1,
	);
	const [hasPersistedCurrentPage] = useState(
		() =>
			readPersistedCurrentPage(
				hiddenColumnsStorageKey,
				hiddenColumnsStorageArea,
			) !== null,
	);
	const [hasReceivedNonEmptyRows, setHasReceivedNonEmptyRows] = useState(false);
	const previousPaginationControlKeyRef = useRef<string | null>(null);

	useEffect(() => {
		if (rows.length > 0) {
			setHasReceivedNonEmptyRows(true);
		}
	}, [rows.length]);

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		if (!hiddenColumnsStorageKey) {
			setAreHiddenColumnsHydrated(true);
			return;
		}

		const storage =
			hiddenColumnsStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;
		const raw = storage.getItem(hiddenColumnsStorageKey);

		if (!raw) {
			setAreHiddenColumnsHydrated(true);
			return;
		}

		try {
			const parsed = JSON.parse(raw) as unknown;
			const normalizeColumns = (value: unknown) =>
				Array.isArray(value)
					? value.filter(
						(valueItem): valueItem is TColumnKey =>
							typeof valueItem === "string" &&
							allColumnKeys.includes(valueItem as TColumnKey),
					  )
					: [];
			const parsedColumns = Array.isArray(parsed)
				? normalizeColumns(parsed)
				: parsed && typeof parsed === "object" && !Array.isArray(parsed)
					? normalizeColumns((parsed as { hiddenColumns?: unknown }).hiddenColumns)
					: [];
			const parsedCurrentPage =
				parsed &&
				typeof parsed === "object" &&
				!Array.isArray(parsed) &&
				typeof (parsed as { currentPage?: unknown }).currentPage === "number" &&
				Number.isFinite((parsed as { currentPage?: number }).currentPage)
					? Math.max(
						1,
						Math.trunc((parsed as { currentPage: number }).currentPage),
					  )
					: null;

			setHiddenColumns(parsedColumns);
			setDraftHiddenColumns(parsedColumns);
			if (parsedCurrentPage !== null) {
				setCurrentPage(parsedCurrentPage);
			}
		} catch {
			setHiddenColumns([]);
			setDraftHiddenColumns([]);
		}

		setAreHiddenColumnsHydrated(true);
	}, [allColumnKeys, hiddenColumnsStorageArea, hiddenColumnsStorageKey]);

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		if (!hiddenColumnsStorageKey || !areHiddenColumnsHydrated) {
			return;
		}

		const storage =
			hiddenColumnsStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;

		let persistedPageSize: number | null = null;
		try {
			const raw = storage.getItem(hiddenColumnsStorageKey);
			if (raw) {
				const parsed = JSON.parse(raw) as unknown;
				if (
					parsed &&
					typeof parsed === "object" &&
					!Array.isArray(parsed) &&
					typeof (parsed as { pageSize?: unknown }).pageSize === "number" &&
					Number.isFinite((parsed as { pageSize?: number }).pageSize)
				) {
					persistedPageSize = Math.max(
						1,
						Math.trunc((parsed as { pageSize: number }).pageSize),
					);
				}
			}
		} catch {
			persistedPageSize = null;
		}

		storage.setItem(
			hiddenColumnsStorageKey,
			JSON.stringify({
				hiddenColumns,
				currentPage,
				...(persistedPageSize !== null ? { pageSize: persistedPageSize } : {}),
			}),
		);
	}, [
		areHiddenColumnsHydrated,
		currentPage,
		hiddenColumns,
		hiddenColumnsStorageArea,
		hiddenColumnsStorageKey,
	]);

	const hasActiveFilters = useMemo(
		() => hasActiveTableFilters(columnFilters, advancedFilters),
		[advancedFilters, columnFilters],
	);

	const canClearFilters = hasActiveFilters;

	const visibleColumns = useMemo(
		() => allColumnKeys.filter((columnKey) => !hiddenColumns.includes(columnKey)),
		[allColumnKeys, hiddenColumns],
	);

	const draftVisibleColumns = useMemo(
		() =>
			allColumnKeys.filter((columnKey) => !draftHiddenColumns.includes(columnKey)),
		[allColumnKeys, draftHiddenColumns],
	);

	const advancedFilterValuesByColumn = useMemo(() => {
		const map: TableAdvancedFilters<TColumnKey> = {};

		allColumnKeys.forEach((columnKey) => {
			const uniqueValues = Array.from(
				new Set(
					rows.flatMap((row) =>
						(advancedFilterValueSplitter
							? advancedFilterValueSplitter(
									getCellValue(row, columnKey),
									columnKey,
									row,
							  )
							: splitAdvancedFilterCellValue(getCellValue(row, columnKey))),
					),
				),
			).sort((left, right) =>
				left.localeCompare(right, "pl", {
					sensitivity: "base",
					numeric: true,
				}),
			);

			map[columnKey] = uniqueValues;
		});

		return map;
	}, [allColumnKeys, getCellValue, rows]);

	const selectedAdvancedFilterValues = useMemo(
		() =>
			(advancedFilters[advancedFilterColumnKey] ?? []).filter(
				(value) => !isAdvancedDateRangeFilterToken(value),
			),
		[advancedFilterColumnKey, advancedFilters],
	);

	const selectedAdvancedFilterDateRange = useMemo(
		() =>
			getAdvancedDateRangeFromSelectedValues(
				advancedFilters[advancedFilterColumnKey] ?? [],
			),
		[advancedFilterColumnKey, advancedFilters],
	);

	const visibleAdvancedFilterValues = useMemo(() => {
		const sourceValues = advancedFilterValuesByColumn[advancedFilterColumnKey] ?? [];
		const normalizedSearch = advancedFilterSearch.trim().toLowerCase();

		if (!normalizedSearch) {
			return sourceValues;
		}

		return sourceValues.filter((value) =>
			value.toLowerCase().includes(normalizedSearch),
		);
	}, [advancedFilterColumnKey, advancedFilterSearch, advancedFilterValuesByColumn]);

	const filteredAndSortedRows = useMemo(() => {
		const filteredRows = rows.filter((row) => {
			const advancedFiltersMatch = (Object.keys(advancedFilters) as TColumnKey[]).every(
				(columnKey) => {
					const selectedValues = advancedFilters[columnKey] ?? [];
					return advancedFilterMatcher
						? advancedFilterMatcher(
								getCellValue(row, columnKey),
								selectedValues,
								columnKey,
								row,
						  )
						: matchesAdvancedFilterCellValue(
								getCellValue(row, columnKey),
								selectedValues,
						  );
				},
			);

			if (!advancedFiltersMatch) {
				return false;
			}

			return (Object.keys(columnFilters) as TColumnKey[]).every((columnKey) => {
				const filterValue = (columnFilters[columnKey] ?? "").trim();
				if (!filterValue) {
					return true;
				}

				const cellValue = getCellValue(row, columnKey).toLowerCase();
				return cellValue.includes(filterValue.toLowerCase());
			});
		});

		if (!sortColumnKey || !sortDirection) {
			return filteredRows;
		}

		const directionMultiplier = sortDirection === "asc" ? 1 : -1;
		const customComparator = sortComparators?.[sortColumnKey];

		return [...filteredRows].sort((leftRow, rightRow) => {
			if (customComparator) {
				return customComparator(leftRow, rightRow) * directionMultiplier;
			}

			const leftValue = getCellValue(leftRow, sortColumnKey);
			const rightValue = getCellValue(rightRow, sortColumnKey);
			return (
				leftValue.localeCompare(rightValue, "pl", {
					numeric: true,
					sensitivity: "base",
				}) * directionMultiplier
			);
		});
	}, [
		advancedFilterMatcher,
		advancedFilterValueSplitter,
		advancedFilters,
		columnFilters,
		getCellValue,
		rows,
		sortColumnKey,
		sortComparators,
		sortDirection,
	]);

	const totalPages = useMemo(
		() => Math.max(1, Math.ceil(filteredAndSortedRows.length / pageSize)),
		[filteredAndSortedRows.length, pageSize],
	);

	const firstPageSize = useMemo(
		() =>
			alignToEndPageSize
				? getFirstPageSize(filteredAndSortedRows.length, pageSize)
				: pageSize,
		[alignToEndPageSize, filteredAndSortedRows.length, pageSize],
	);

	const paginationControlKey = useMemo(
		() =>
			JSON.stringify({
				advancedFilters,
				columnFilters,
				hiddenColumns,
				sortColumnKey,
				sortDirection,
			}),
		[advancedFilters, columnFilters, hiddenColumns, sortColumnKey, sortDirection],
	);

	useEffect(() => {
		if (previousPaginationControlKeyRef.current === null) {
			previousPaginationControlKeyRef.current = paginationControlKey;
			return;
		}

		if (previousPaginationControlKeyRef.current !== paginationControlKey) {
			setCurrentPage(paginationResetMode === "start" ? 1 : totalPages);
			previousPaginationControlKeyRef.current = paginationControlKey;
		}
	}, [paginationControlKey, paginationResetMode, totalPages]);

	useEffect(() => {
		if (!areHiddenColumnsHydrated) {
			return;
		}

		if (!hasPersistedCurrentPage && hasReceivedNonEmptyRows) {
			setCurrentPage(initialPageMode === "start" ? 1 : totalPages);
			return;
		}

		if (!hasReceivedNonEmptyRows && rows.length === 0) {
			return;
		}

		setCurrentPage((previous) => Math.min(Math.max(previous, 1), totalPages));
	}, [
		areHiddenColumnsHydrated,
		initialPageMode,
		hasPersistedCurrentPage,
		hasReceivedNonEmptyRows,
		rows.length,
		totalPages,
	]);

	const paginatedRows = useMemo(() => {
		if (!alignToEndPageSize) {
			const startIndex = (currentPage - 1) * pageSize;
			const endIndex = startIndex + pageSize;
			return filteredAndSortedRows.slice(startIndex, endIndex);
		}

		const startIndex =
			currentPage <= 1
				? 0
				: firstPageSize + (currentPage - 2) * pageSize;
		const endIndex =
			currentPage <= 1 ? firstPageSize : startIndex + pageSize;
		return filteredAndSortedRows.slice(startIndex, endIndex);
	}, [
		alignToEndPageSize,
		currentPage,
		filteredAndSortedRows,
		firstPageSize,
		pageSize,
	]);

	const resolvePageForRowIndex = useCallback(
		(rowIndex: number) => {
			if (!Number.isFinite(rowIndex)) {
				return 1;
			}

			const normalizedRowIndex = Math.max(0, Math.trunc(rowIndex));
			if (!alignToEndPageSize) {
				const page = Math.floor(normalizedRowIndex / pageSize) + 1;
				return Math.min(Math.max(page, 1), totalPages);
			}

			if (normalizedRowIndex < firstPageSize) {
				return 1;
			}

			const page = Math.floor((normalizedRowIndex - firstPageSize) / pageSize) + 2;
			return Math.min(Math.max(page, 1), totalPages);
		},
		[alignToEndPageSize, firstPageSize, pageSize, totalPages],
	);

	const paginationItems = useMemo(
		() => buildPaginationItems(currentPage, totalPages),
		[currentPage, totalPages],
	);

	const handlePageChange = (nextPage: number) => {
		if (!Number.isFinite(nextPage)) {
			return;
		}

		const normalized = Math.trunc(nextPage);
		setCurrentPage(Math.min(Math.max(normalized, 1), totalPages));
	};

	const handleSortByColumn = (columnKey: TColumnKey) => {
		if (sortColumnKey !== columnKey) {
			setSortColumnKey(columnKey);
			setSortDirection("asc");
			return;
		}

		if (sortDirection === "asc") {
			setSortDirection("desc");
			return;
		}

		if (sortDirection === "desc") {
			setSortColumnKey(null);
			setSortDirection(null);
			return;
		}

		setSortDirection("asc");
	};

	const handleFilterChange = (columnKey: TColumnKey, value: string) => {
		setColumnFilters((prev) => ({ ...prev, [columnKey]: value }));
	};

	const clearFilters = () => {
		setColumnFilters({});
		setAdvancedFilters({});
	};

	const toggleAdvancedFilterValue = (value: string) => {
		setAdvancedFilters((prev) => {
			const currentValues = (prev[advancedFilterColumnKey] ?? []).filter(
				(item) => !isAdvancedDateRangeFilterToken(item),
			);
			const nextValues = currentValues.includes(value)
				? currentValues.filter((item) => item !== value)
				: [...currentValues, value];

			return {
				...prev,
				[advancedFilterColumnKey]: nextValues,
			};
		});
	};

	const setAdvancedFilterValuesForColumn = useCallback(
		(columnKey: TColumnKey, values: string[]) => {
			const normalizedValues = Array.from(
				new Set(values.map((value) => value.trim()).filter(Boolean)),
			);

			setAdvancedFilters((prev) => ({
				...prev,
				[columnKey]: normalizedValues,
			}));
		},
		[],
	);

	const toggleAdvancedFilterValueForColumn = useCallback(
		(columnKey: TColumnKey, value: string) => {
			const normalizedValue = value.trim();
			if (!normalizedValue) {
				return;
			}

			setAdvancedFilters((prev) => {
				const currentValues = (prev[columnKey] ?? []).filter(
					(item) => !isAdvancedDateRangeFilterToken(item),
				);
				const nextValues = currentValues.includes(normalizedValue)
					? currentValues.filter((item) => item !== normalizedValue)
					: [...currentValues, normalizedValue];

				return {
					...prev,
					[columnKey]: nextValues,
				};
			});
		},
		[],
	);

	const selectAllVisibleAdvancedFilterValues = () => {
		setAdvancedFilters((prev) => {
			const currentValues = new Set(
				(prev[advancedFilterColumnKey] ?? []).filter(
					(value) => !isAdvancedDateRangeFilterToken(value),
				),
			);
			visibleAdvancedFilterValues.forEach((value) => currentValues.add(value));

			return {
				...prev,
				[advancedFilterColumnKey]: Array.from(currentValues),
			};
		});
	};

	const clearAdvancedFilterForSelectedColumn = () => {
		setAdvancedFilters((prev) => ({
			...prev,
			[advancedFilterColumnKey]: [],
		}));
	};

	const setAdvancedFilterDateRange = (range: { from: string; to: string }) => {
		setAdvancedFilters((prev) => {
			const token = createAdvancedDateRangeFilterToken(range);

			return {
				...prev,
				[advancedFilterColumnKey]: token ? [token] : [],
			};
		});
	};

	const handleDraftColumnVisibilityChange = (
		columnKey: TColumnKey,
		isVisible: boolean,
	) => {
		if (!isVisible && draftVisibleColumns.length <= 1) {
			return;
		}

		if (isVisible) {
			setDraftHiddenColumns((prev) => prev.filter((key) => key !== columnKey));
			return;
		}

		setDraftHiddenColumns((prev) => {
			if (prev.includes(columnKey)) {
				return prev;
			}

			return [...prev, columnKey];
		});
	};

	const handleDraftSelectAllColumns = () => {
		setDraftHiddenColumns([]);
	};

	const handleDraftDeselectAllColumns = () => {
		setDraftHiddenColumns([...allColumnKeys]);
	};

	const handleOpenViewModal = () => {
		setDraftHiddenColumns(hiddenColumns);
		setIsColumnPickerOpen(true);
	};

	const handleApplyViewChanges = () => {
		setHiddenColumns(
			draftHiddenColumns.filter((columnKey) => allColumnKeys.includes(columnKey)),
		);
		setIsColumnPickerOpen(false);
	};

	return {
		advancedFilterColumnKey,
		advancedFilterSearch,
		advancedFilters,
		canClearFilters,
		clearAdvancedFilterForSelectedColumn,
		clearFilters,
		columnFilters,
		draftHiddenColumns,
		draftVisibleColumns,
		filteredAndSortedRows,
		paginatedRows,
		currentPage,
		totalPages,
		pageSize,
		paginationItems,
		resolvePageForRowIndex,
		handlePageChange,
		handleApplyViewChanges,
		handleDraftColumnVisibilityChange,
		handleDraftDeselectAllColumns,
		handleDraftSelectAllColumns,
		handleFilterChange,
		handleOpenViewModal,
		handleSortByColumn,
		hiddenColumns,
		isAdvancedFilterModalOpen,
		isColumnPickerOpen,
		selectedAdvancedFilterDateRange,
		selectedAdvancedFilterValues,
		selectAllVisibleAdvancedFilterValues,
		setAdvancedFilterDateRange,
		setAdvancedFilterColumnKey,
		setAdvancedFilterSearch,
		setDraftHiddenColumns,
		setIsAdvancedFilterModalOpen,
		setIsColumnPickerOpen,
		sortColumnKey,
		sortDirection,
		toggleAdvancedFilterValue,
		toggleAdvancedFilterValueForColumn,
		setAdvancedFilterValuesForColumn,
		visibleAdvancedFilterValues,
		visibleColumns,
	};
}
