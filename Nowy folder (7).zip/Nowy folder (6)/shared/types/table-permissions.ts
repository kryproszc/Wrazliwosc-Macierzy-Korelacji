import type { AuthRole } from "@/app/_components/home-tabs/types";

import type { TableCapabilities } from "@/shared/types/table";

export function resolveDefaultTableCapabilities(authRole: AuthRole): TableCapabilities {
	const canManage = authRole !== "external_user";
	const isDirector = authRole === "director";

	return {
		canView: true,
		canFilter: true,
		canExport: true,
		canCreate: canManage,
		canEdit: canManage,
		canDelete: isDirector,
	};
}
