export type TableSortDirection = "asc" | "desc";

export type TableSortState<TColumnKey extends string> = {
	columnKey: TColumnKey | null;
	direction: TableSortDirection | null;
};

export type TableColumnFilters<TColumnKey extends string> = Partial<
	Record<TColumnKey, string>
>;

export type TableAdvancedFilters<TColumnKey extends string> = Partial<
	Record<TColumnKey, string[]>
>;

export type TableColumnDefinition<TColumnKey extends string> = {
	key: TColumnKey;
	label: string;
	tooltip?: string;
};

export type TableCapabilities = {
	canView: boolean;
	canFilter: boolean;
	canExport: boolean;
	canCreate: boolean;
	canEdit: boolean;
	canDelete: boolean;
};

export type TableRowPermissionResolver<TRow> = {
	canEditRow?: (row: TRow) => boolean;
	canDeleteRow?: (row: TRow) => boolean;
};

export type TableActionConfig<TActionId extends string> = {
	id: TActionId;
	label: string;
	isVisible?: boolean;
	isDisabled?: boolean;
};
