import type { Workbook } from "exceljs";

type ExcelJSLikeModule = {
	Workbook?: new () => Workbook;
	default?: {
		Workbook?: new () => Workbook;
	};
};

type ExcelJSResolvedModule = {
	Workbook: new () => Workbook;
};

type SaveAsFunction = (data: Blob, fileName?: string) => void;

type FileSaverLikeModule = {
	saveAs?: SaveAsFunction;
	default?: SaveAsFunction | { saveAs?: SaveAsFunction };
};

type SaveFilePickerWindow = Window & {
	showSaveFilePicker?: (options?: {
		suggestedName?: string;
		types?: Array<{
			description?: string;
			accept: Record<string, string[]>;
		}>;
	}) => Promise<{
		createWritable: () => Promise<{
			write: (data: Blob) => Promise<void>;
			close: () => Promise<void>;
		}>;
	}>;
};

function resolveExcelJSModule(moduleValue: unknown): ExcelJSResolvedModule {
	const module = moduleValue as ExcelJSLikeModule;
	const candidate = module.default ?? module;

	if (typeof candidate.Workbook !== "function") {
		throw new Error("Nieprawidlowy modul exceljs: brak konstruktora Workbook.");
	}

	return {
		Workbook: candidate.Workbook,
	};
}

function resolveFileSaverSaveAs(moduleValue: unknown): SaveAsFunction {
	const module = moduleValue as FileSaverLikeModule;

	if (typeof module.saveAs === "function") {
		return module.saveAs;
	}

	if (typeof module.default === "function") {
		return module.default;
	}

	if (
		typeof module.default === "object" &&
		module.default !== null &&
		typeof module.default.saveAs === "function"
	) {
		return module.default.saveAs;
	}

	throw new Error("Nieprawidlowy modul file-saver: brak funkcji saveAs.");
}

export async function createStyledExportWorkbook(creator: string) {
	const excelJSImport = await import("exceljs");
	const ExcelJS = resolveExcelJSModule(excelJSImport);
	const workbook = new ExcelJS.Workbook();
	workbook.creator = creator;
	workbook.created = new Date();
	return workbook;
}

export function addWorksheetWithStyles(
	workbook: Workbook,
	title: string,
	headers: string[],
	rows: string[][],
) {
	const worksheet = workbook.addWorksheet(title, {
		views: [{ state: "frozen", ySplit: 1 }],
	});

	worksheet.addRow(headers);
	rows.forEach((row) => worksheet.addRow(row));

	const maxColumnLengths = headers.map((header, index) => {
		const valuesLength = rows.reduce((maxLength, row) => {
			const value = row[index] ?? "";
			return Math.max(maxLength, value.length);
		}, 0);

		return Math.min(50, Math.max(14, Math.max(header.length, valuesLength) + 2));
	});

	worksheet.columns = headers.map((_, index) => ({
		width: maxColumnLengths[index],
	}));

	const headerRow = worksheet.getRow(1);
	headerRow.font = { bold: true, color: { argb: "FF1E293B" } };
	headerRow.alignment = { vertical: "middle", horizontal: "left" };
	headerRow.fill = {
		type: "pattern",
		pattern: "solid",
		fgColor: { argb: "FFE2E8F0" },
	};

	worksheet.eachRow((row, rowNumber) => {
		row.eachCell((cell) => {
			cell.border = {
				top: { style: "thin", color: { argb: "FFCBD5E1" } },
				left: { style: "thin", color: { argb: "FFCBD5E1" } },
				bottom: { style: "thin", color: { argb: "FFCBD5E1" } },
				right: { style: "thin", color: { argb: "FFCBD5E1" } },
			};

			if (rowNumber > 1) {
				cell.alignment = {
					vertical: "top",
					horizontal: "left",
					wrapText: true,
				};
			}
		});
	});

	if (headers.length > 0) {
		worksheet.autoFilter = {
			from: { row: 1, column: 1 },
			to: { row: 1, column: headers.length },
		};
	}
}

export async function saveWorkbookAsXlsx(workbook: Workbook, fileName: string) {
	const fileSaverModule = await import("file-saver");
	const saveAs = resolveFileSaverSaveAs(fileSaverModule);
	const buffer = await workbook.xlsx.writeBuffer();
	const blob = new Blob([buffer], {
		type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	});

	const windowWithPicker = window as SaveFilePickerWindow;
	if (windowWithPicker.showSaveFilePicker && window.isSecureContext) {
		const fileHandle = await windowWithPicker.showSaveFilePicker({
			suggestedName: fileName,
			types: [
				{
					description: "Plik Excel",
					accept: {
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
							".xlsx",
						],
					},
				},
			],
		});

		const writable = await fileHandle.createWritable();
		await writable.write(blob);
		await writable.close();
		return;
	}

	saveAs(blob, fileName);
}