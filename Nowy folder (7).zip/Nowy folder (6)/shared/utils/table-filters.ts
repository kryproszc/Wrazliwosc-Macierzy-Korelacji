export function hasActiveTableFilters<TColumnKey extends string>(
	columnFilters: Partial<Record<TColumnKey, string>>,
	advancedFilters: Partial<Record<TColumnKey, string[]>>,
) {
	return (
		Object.values(columnFilters).some(
			(value) => typeof value === "string" && value.trim().length > 0,
		) ||
		Object.values(advancedFilters).some(
			(values) => Array.isArray(values) && values.length > 0,
		)
	);
}

export function splitAdvancedFilterCellValue(rawValue: string) {
	const normalizedValue = rawValue.trim();
	if (!normalizedValue) {
		return ["(puste)"];
	}

	const tokens = normalizedValue
		.split(/[;,\n]/)
		.map((item) => item.trim())
		.filter(Boolean);

	if (tokens.length === 0) {
		return ["(puste)"];
	}

	return Array.from(new Set(tokens));
}

const ADVANCED_DATE_RANGE_FILTER_PREFIX = "__date_range__:";

export type AdvancedDateRange = {
	from: string;
	to: string;
};

function parseIsoDateToken(value: string) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
		return null;
	}

	const [yearText, monthText, dayText] = value.split("-");
	const year = Number(yearText);
	const month = Number(monthText);
	const day = Number(dayText);

	if (
		!Number.isInteger(year) ||
		!Number.isInteger(month) ||
		!Number.isInteger(day) ||
		month < 1 ||
		month > 12 ||
		day < 1 ||
		day > 31
	) {
		return null;
	}

	const date = new Date(year, month - 1, day);
	if (
		date.getFullYear() !== year ||
		date.getMonth() !== month - 1 ||
		date.getDate() !== day
	) {
		return null;
	}

	return value;
}

function normalizeAdvancedDateRange(range: AdvancedDateRange) {
	const from = parseIsoDateToken(range.from.trim());
	const to = parseIsoDateToken(range.to.trim());

	if (!from && !to) {
		return null;
	}

	if (!from) {
		return { from: "", to: to ?? "" };
	}

	if (!to) {
		return { from, to: "" };
	}

	if (from <= to) {
		return { from, to };
	}

	return { from: to, to: from };
}

export function isAdvancedDateRangeFilterToken(value: string) {
	return value.startsWith(ADVANCED_DATE_RANGE_FILTER_PREFIX);
}

export function getAdvancedDateRangeFromSelectedValues(selectedValues: string[]) {
	const rangeToken = selectedValues.find(isAdvancedDateRangeFilterToken);
	if (!rangeToken) {
		return null;
	}

	const payload = rangeToken.slice(ADVANCED_DATE_RANGE_FILTER_PREFIX.length);
	const [rawFrom = "", rawTo = ""] = payload.split("|");
	return normalizeAdvancedDateRange({ from: rawFrom, to: rawTo });
}

export function createAdvancedDateRangeFilterToken(range: AdvancedDateRange) {
	const normalizedRange = normalizeAdvancedDateRange(range);
	if (!normalizedRange) {
		return null;
	}

	return `${ADVANCED_DATE_RANGE_FILTER_PREFIX}${normalizedRange.from}|${normalizedRange.to}`;
}

function tokenMatchesAdvancedDateRange(token: string, range: AdvancedDateRange) {
	const normalizedToken = parseIsoDateToken(token);
	if (!normalizedToken) {
		return false;
	}

	if (range.from && normalizedToken < range.from) {
		return false;
	}

	if (range.to && normalizedToken > range.to) {
		return false;
	}

	return true;
}

export function matchesAdvancedFilterCellValue(
	rawValue: string,
	selectedValues: string[],
) {
	if (selectedValues.length === 0) {
		return true;
	}

	const selectedDateRange = getAdvancedDateRangeFromSelectedValues(selectedValues);
	const selectedDiscreteValues = selectedValues.filter(
		(value) => !isAdvancedDateRangeFilterToken(value),
	);

	const cellTokens = splitAdvancedFilterCellValue(rawValue);
	const hasDiscreteMatch =
		selectedDiscreteValues.length === 0 ||
		cellTokens.some((token) => selectedDiscreteValues.includes(token));

	if (!hasDiscreteMatch) {
		return false;
	}

	if (!selectedDateRange) {
		return true;
	}

	return cellTokens.some((token) =>
		tokenMatchesAdvancedDateRange(token, selectedDateRange),
	);
}
