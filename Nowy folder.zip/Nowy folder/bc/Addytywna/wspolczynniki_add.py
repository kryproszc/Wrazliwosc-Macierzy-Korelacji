from fastapi import APIRouter
import numpy as np
import sys
import os
import pandas as pd
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import AddTriangleRequest, AddCLRequest, AddTriangleRequestIncurred, AddCLRequestIncurred
from calculation_method import TriangleCalculator

router = APIRouter()


@router.post("/calc/add/train_devide_add")
async def calc_add_train_devide(payload: AddTriangleRequest):
    result = TriangleCalculator.calculate_train_devide(
        add_data_det=payload.add_data_det,
        ekspozycja=payload.ekspozycja
    )

    train_devide_serializable = [
        [None if (isinstance(v, float) and (np.isnan(v) or np.isinf(v))) else v
         for v in row]
        for row in result["train_devide"]
    ]

    return {
        "message": "Wyliczono train_devide",
        "train_devide": train_devide_serializable,
        "ekspozycja": result["ekspozycja"]
    }


@router.post("/calc/add/train_devide_add_incurred")
async def calc_add_train_devide_incurred(payload: AddTriangleRequestIncurred):
    result = TriangleCalculator.calculate_train_devide(
        add_data_det=payload.add_data_incurred,
        ekspozycja=payload.ekspozycja
    )

    train_devide_serializable = [
        [None if (isinstance(v, float) and (np.isnan(v) or np.isinf(v))) else v
         for v in row]
        for row in result["train_devide"]
    ]

    return {
        "message": "Wyliczono train_devide incurred",
        "train_devide": train_devide_serializable,
        "ekspozycja": result["ekspozycja"]
    }


@router.post("/calc/add/wspolczynniki_add")
async def calc_add_cl(payload: AddCLRequest):
    add_data = payload.add_data_det
    weights = payload.weights
    ekspozycja = payload.ekspozycja

    print(pd.DataFrame(weights))
    data = {}
    headers = np.arange(len(add_data[0]))
    for i, col in enumerate(headers):
        data[col] = []
        for row in add_data:
            value = row[i]
            try:
                num_value = float(value)
            except (ValueError, TypeError):
                num_value = None
            data[col].append(num_value)

    result = TriangleCalculator.calculate_train_devide(
        add_data_det=payload.add_data_det,
        ekspozycja=payload.ekspozycja 
    )
    train_devide_only = result["train_devide"]
    LR_j = TriangleCalculator.wspolczynnik_LR(
        train_devide_only, weights, ekspozycja 
    )
    sigma_j = TriangleCalculator.sigma_LR(
        data_LR=train_devide_only,
        w=weights,
        exposure=ekspozycja,
        wsp_LR=LR_j
    )
    sd_j = TriangleCalculator.wspolczynnik_sd(
        wsp_sigma=sigma_j,
        w=weights,
        exposure=ekspozycja
    )
    sigma_j_kwadrat = [x for x in sigma_j]
    sd_j_kwadrat = [x**2 for x in sd_j]
    return {
        "message": "Odebrano dane ADD i zastosowano wagi",
        "train_devide": train_devide_only,
        "LR_j": list(LR_j),
        "sigma_j": list(sigma_j_kwadrat),
        "sd_j": list(sd_j_kwadrat),
    }


@router.post("/calc/add/wspolczynniki_add_incurred")
async def calc_add_cl_incurred(payload: AddCLRequestIncurred):
    add_data = payload.add_data_incurred
    weights = payload.weights
    ekspozycja = payload.ekspozycja

    print(pd.DataFrame(weights))
    data = {}
    headers = np.arange(len(add_data[0]))
    for i, col in enumerate(headers):
        data[col] = []
        for row in add_data:
            value = row[i]
            try:
                num_value = float(value)
            except (ValueError, TypeError):
                num_value = None
            data[col].append(num_value)

    result = TriangleCalculator.calculate_train_devide(
        add_data_det=payload.add_data_incurred,
        ekspozycja=payload.ekspozycja
    )
    train_devide_only = result["train_devide"]
    LR_j = TriangleCalculator.wspolczynnik_LR(
        train_devide_only, weights, ekspozycja
    )
    sigma_j = TriangleCalculator.sigma_LR(
        data_LR=train_devide_only,
        w=weights,
        exposure=ekspozycja,
        wsp_LR=LR_j
    )
    sd_j = TriangleCalculator.wspolczynnik_sd(
        wsp_sigma=sigma_j,
        w=weights,
        exposure=ekspozycja
    )
    sigma_j_kwadrat = [x for x in sigma_j]
    sd_j_kwadrat = [x**2 for x in sd_j]
    return {
        "message": "Odebrano dane ADD incurred i zastosowano wagi",
        "train_devide": train_devide_only,
        "LR_j": list(LR_j),
        "sigma_j": list(sigma_j_kwadrat),
        "sd_j": list(sd_j_kwadrat),
    }