from fastapi import APIRouter
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import ExecuteCalculationsRequestLR
from add_simulator import YearHorizontLR2

router = APIRouter()
yh_lr = YearHorizontLR2()


@router.post("/calc_lr/execute_calculations")
async def execute_calculations_lr(request: ExecuteCalculationsRequestLR):
    """
    Endpoint do obliczania wyników dla metody Loss Ratio (LR).
    Zwraca pełne wektory: last_col, cum_trian, ult_net_disc (bez sumy).
    """
    data = np.array(request.paid_triangle, dtype=float)
    ekspozycja = np.array(request.ekspozycja, dtype=float)
    lr_j = np.array(request.selected_value_lr, dtype=float)

    mm = data.shape[0]

    # -------- discount_rates -> lista wartości
    discount_values = []
    if request.discount_rates:
        first_key = next(iter(request.discount_rates), None)
        if first_key is not None and request.discount_rates.get(first_key):
            discount_values = [
                v
                for k, v in request.discount_rates[first_key].items()
                if k != "0" and v is not None
            ]

    # -------- netto_brutto -> lista wartości
    netto_brutto_values = []
    if request.netto_brutto:
        first_key = next(iter(request.netto_brutto), None)
        if first_key is not None and request.netto_brutto.get(first_key):
            netto_brutto_values = [
                v
                for k, v in request.netto_brutto[first_key].items()
                if k != "0" and v is not None
            ]

    # -------- discount_factors (jeśli brak -> jedynki)
    if discount_values:
        discount_factors = np.asarray(discount_values, dtype=float)
    else:
        discount_factors = np.ones(max(1, len(lr_j)), dtype=float)

    # -------- net_to_gross (jeśli brak -> jedynki, dopasuj do mm)
    if netto_brutto_values:
        net_to_gross = np.asarray(netto_brutto_values, dtype=float)
        if len(net_to_gross) < mm:
            net_to_gross = np.pad(net_to_gross, (0, mm - len(net_to_gross)), constant_values=1.0)
        elif len(net_to_gross) > mm:
            net_to_gross = net_to_gross[:mm]
    else:
        net_to_gross = np.ones(mm, dtype=float)
    
    # -------- printy przed obliczeniami
    print(f"lr_j (LR_j): {lr_j}")
    print(f"ekspozycja (exposure): {ekspozycja}")
    print(f"discount_factors: {discount_factors}")
    print(f"net_to_gross: {net_to_gross}")
    print(f"k_forward: {len(lr_j)}")
    
    # -------- obliczenia
    ult_det = yh_lr.triangle_forward_lr_np_disc(
        tri_in=data,
        LR_j=lr_j[1:],
        exposure=ekspozycja,
        discount_factors=discount_factors,
        net_to_gross=net_to_gross,
        k_forward=len(lr_j[1:]),
    )

    # -------- JSON-friendly (bez numpy/np.float64)
    last_col = [float(x) for x in np.asarray(ult_det["last_col"], dtype=float).tolist()]
    cum_trian = [float(x) for x in np.asarray(ult_det["cum_trian"], dtype=float).tolist()]
    ult_net_disc = [float(x) for x in np.asarray(ult_det["ult_net_disc"], dtype=float).tolist()]

    # -------- Sumy do simulation_results (kompatybilność z AddytywnaStoch)
    simulation_results = {
        "last_col": [float(np.sum(last_col))],
        "cum_trian": [float(np.sum(cum_trian))],
        "ult_net_disc": [float(np.sum(ult_net_disc))]
    }

    return {
        "status": "ok",
        "vectors": {
            "last_col": last_col,
            "cum_trian": cum_trian,
            "ult_net_disc": ult_net_disc,
        },
        "simulation_results": simulation_results,
    }

    """
    Endpoint do obliczania wyników dla metody Loss Ratio (LR).
    Używa funkcji triangle_forward_lr_np_disc z add_simulator.py
    """
    # Dane z frontu bez żadnego sprawdzania
    user_id = request.user_id
    data = np.array(request.paid_triangle, dtype=float)
    ekspozycja = np.array(request.ekspozycja, dtype=float)
    lr_j = np.array(request.selected_value_lr, dtype=float)
    
    # Pobieranie discount rates
    discount_values = []
    if request.discount_rates and len(request.discount_rates) > 0:
        first_key = next(iter(request.discount_rates))
        discount_values = [
            v for k, v in request.discount_rates[first_key].items()
            if k != "0" and v is not None
        ]
    
    # Pobieranie netto/brutto ratios
    netto_brutto_values = []
    if request.netto_brutto and len(request.netto_brutto) > 0:
        first_key = next(iter(request.netto_brutto))
        netto_brutto_values = [
            v for k, v in request.netto_brutto[first_key].items()
            if k != "0" and v is not None
        ]
    
    # Konwersja na numpy arrays z odpowiednimi rozmiarami
    mm = data.shape[0]  # liczba wierszy w trójkącie
    
    # Discount factors - jeśli nie podano, używamy samych jedynek
    if discount_values:
        discount_factors = np.array(discount_values, dtype=float)
    else:
        discount_factors = np.ones(len(lr_j), dtype=float)
    
    # Net to gross ratios - jeśli nie podano, używamy samych jedynek
    if netto_brutto_values:
        net_to_gross = np.array(netto_brutto_values, dtype=float)
        # Dopasowanie długości do liczby wierszy
        if len(net_to_gross) < mm:
            net_to_gross = np.pad(net_to_gross, (0, mm - len(net_to_gross)), constant_values=1.0)
        elif len(net_to_gross) > mm:
            net_to_gross = net_to_gross[:mm]
    else:
        net_to_gross = np.ones(mm, dtype=float)
    
    # Ustawienie precyzji numpy
    np.set_printoptions(precision=20, suppress=False)

    # Wywołanie funkcji triangle_forward_lr_np_disc
    # Funkcja zwraca [ult_gross, total_disc, ult_net_disc]
    ult_det = yh_lr.triangle_forward_lr_np_disc(
        data,
        lr_j,
        ekspozycja,
        discount_factors=discount_factors,
        net_to_gross=net_to_gross,
        k_forward=len(lr_j)
    )

    return {
        "status": "ok",
        "vectors": {
            "last_col": [float(ult_det[0])],
            "cum_trian": [float(ult_det[1])],
            "ult_net_disc": [float(ult_det[2])],
        },
    }