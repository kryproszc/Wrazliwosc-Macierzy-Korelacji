from fastapi import APIRouter
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import ExecuteCalculationsRequest, ExecuteCalculationsRequestIncurred
from cl_simulator import YearHorizont2
from calculation_method import TriangleCalculator
router = APIRouter()
yh2 = YearHorizont2()

from calculation_method import TriangleCalculator


@router.post("/calc/execute_calculations")
async def execute_calculations(request: ExecuteCalculationsRequest):
    # Dane z frontu bez żadnego sprawdzania
    user_id = request.user_id
    data = np.array(request.paid_triangle, dtype=float)
    f = np.array(request.selected_value_cl, dtype=float)
    discount_values = [
        v for k, v in request.discount_rates[next(iter(request.discount_rates))].items()
        if k != "0"
    ]
    netto_brutto_values = [
        v for k, v in request.netto_brutto[next(iter(request.netto_brutto))].items()
        if k != "0"
    ]
    np.set_printoptions(precision=20, suppress=False)
    discount_factors = np.array(discount_values, dtype=float)
    net_to_gross = np.array(netto_brutto_values, dtype=float)
    ult_det = yh2.triangle_forward_np(
        data,
        f,
        k_forward_start=0,
        discount_factors=discount_factors,
        net_to_gross=net_to_gross,
    )

    return {
        "status": "ok",
        "vectors": {
            "last_col": np.array(ult_det["last_col"]).tolist(),
            "cum_trian": np.array(ult_det["cum_trian"]).tolist(),
            "ult_net_disc": np.array(ult_det["ult_net_disc"]).tolist(),
        },
    }


@router.post("/calc/execute_calculations_incurred")
async def execute_calculations_incurred(request: ExecuteCalculationsRequestIncurred):
    # Dane z frontu - obliczenia dla incurred
    user_id = request.user_id
    
    # Bezpieczne konwertowanie macierzy z obsługą null wartości
    def safe_convert_matrix_to_numpy(matrix):
        # Konwertuj na numpy array, zastąp null/None wartościami NaN
        result = []
        for row in matrix:
            safe_row = []
            for val in row:
                if val is None:
                    safe_row.append(np.nan)
                else:
                    safe_row.append(float(val))
            result.append(safe_row)
        return np.array(result, dtype=float)
    
 
    # Konwersja danych
    incurred_triangle = safe_convert_matrix_to_numpy(request.incurred_triangle)
    paid_triangle = safe_convert_matrix_to_numpy(request.paid_triangle)
    
    # Ustaw f na podstawie selected_values_dev_j (jeśli niepuste) lub dev_j_current
    if hasattr(request, 'selected_values_dev_j') and request.selected_values_dev_j:
        f = np.array(request.selected_values_dev_j, dtype=float)
    else:
        f = np.array(request.dev_j_current, dtype=float)
    
    # Ustaw rj na podstawie selected_values_rj_paid_to_incurred (jeśli niepuste) lub rj_paid_to_incurred_current
    if request.selected_values_rj_paid_to_incurred:
        rj = np.array(request.selected_values_rj_paid_to_incurred, dtype=float)
    else:
        rj = np.array(request.rj_paid_to_incurred_current, dtype=float)
    
    # Obsługa discount_rates - jeśli puste to wektor jedynek
    if not request.discount_rates or not any(request.discount_rates.values()):
        discount_factors = np.ones(len(f), dtype=float)
    else:
        discount_values = [
            v for k, v in request.discount_rates[next(iter(request.discount_rates))].items()
            if k != "0" and v is not None
        ]
        if not discount_values:
            discount_factors = np.ones(len(f), dtype=float)
        else:
            discount_factors = np.array(discount_values, dtype=float)
    
    # Obsługa netto_brutto - jeśli puste to wektor jedynek
    if not request.netto_brutto or not any(request.netto_brutto.values()):
        net_to_gross = np.ones(paid_triangle.shape[0], dtype=float)
    else:
        netto_brutto_values = [
            v for k, v in request.netto_brutto[next(iter(request.netto_brutto))].items()
            if k != "0" and v is not None
        ]
        if not netto_brutto_values:
            net_to_gross = np.ones(paid_triangle.shape[0], dtype=float)
        else:
            net_to_gross = np.array(netto_brutto_values, dtype=float)
    
    # Wywołanie funkcji obliczeń
    ult_det = TriangleCalculator.triangle_forward_np_p_i(
        triangle_data=incurred_triangle,
        triangle_paid_infl=paid_triangle,
        f=f,
        rj=rj,
        discount_factors=discount_factors,
        net_to_gross=net_to_gross
    )
    
    return {
        "status": "ok",
        "vectors": {
            "last_col_incurred": np.array(ult_det["last_col"]).tolist(),
            "cum_trian_incurred": np.array(ult_det["cum_trian"]).tolist(),
            "ult_net_disc_incurred": np.array(ult_det["ult_net_disc"]).tolist(),
        },
    }