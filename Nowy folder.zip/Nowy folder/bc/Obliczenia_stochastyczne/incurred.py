from fastapi import APIRouter
import numpy as np

from clinc_simulator import ClincSimulator
from add_simulator import YearHorizontLR2
from .models import (
	SimulationClIncurredRequest,
	SimulationLrIncurredRequest,
	SimulationClIncurredResult,
	StatisticClIncurredRequest,
)


router = APIRouter()
clinc_simulator = ClincSimulator()
lr_incurred_simulator = YearHorizontLR2()


@router.post("/calc/incurred/simulation")
async def simulation_cl_incurred(request: SimulationClIncurredRequest):
	user_id = request.user_id_incurred
	dev_inc = np.array(request.selected_value_cl_incurred, dtype=np.float64)
	sigma_inc = np.array(request.selected_value_sigma_incurred, dtype=np.float64)
	sd_inc = np.array(request.selected_value_sd_incurred, dtype=np.float64)
	rj = np.array(request.selected_values_rj_paid_to_incurred, dtype=np.float64)
	varj = np.array(request.selected_values_varj_paid_to_incurred, dtype=np.float64)
	r_i_j = np.array(request.train_paidtoincurred, dtype=np.float64)

	lambda_cor = np.array([request.lambda_value], dtype=np.float64)
	traingle_paid_inf = np.array(request.paid_triangle_incurred, dtype=np.float64)
	traingle_incurred_inf = np.array(request.incurred_triangle_incurred, dtype=np.float64)
	data_wagi_cl = np.array(request.weights_incurred, dtype=np.float64)
	data_wagi_pi = np.array(request.weights_rj_incurred, dtype=np.float64)

	wykluczenia = np.array([i + 1 for i in request.selected_dev_j_indexes_incurred], dtype=np.int32)
	Poz_CL = request.left_count_cl_incurred
	dop_ogo_p_i = False
	il_ogon = request.tail_count_cl_incurred
	wykluczenia_p_i = np.array([i + 1 for i in request.selected_rj_paid_to_incurred_indexes_incurred], dtype=np.int32)
	Poz_CL_p_i = request.tail_count_rj_paid_to_incurred

	if request.discount_rates_incurred and len(request.discount_rates_incurred) > 0:
		first_inner = next(iter(request.discount_rates_incurred.values()))
		discount_rates = np.array(list(first_inner.values()), dtype=float)
	else:
		discount_rates = np.array([], dtype=float)

	if request.netto_brutto_incurred and len(request.netto_brutto_incurred) > 0:
		first_inner = next(iter(request.netto_brutto_incurred.values()))
		netto_brutto = np.array(list(first_inner.values()), dtype=float)
	else:
		netto_brutto = np.array([], dtype=float)

	sim_total = request.ilosc_symulacji_incurred
	batch_sim = request.ziarno_incurred
	main_seed = 202260011

	# Parametry hybrydowe (ADD/LR) - domyślnie wyłączone dla ścieżki CL.
	sigma_inc_LR = np.empty(0, dtype=np.float64)
	dev_inc_LR = np.empty(0, dtype=np.float64)
	sd_inc_LR = np.empty(0, dtype=np.float64)
	e_values = np.empty(0, dtype=np.float64)
	wagi_trimmed_LR = np.empty((0, 0), dtype=np.float64)
	ilosc_dop_wsp_LR = np.empty(0, dtype=np.int32)
	Poz_LR = 0
	il_ogon_LR = 0
	k_zmiana = 0

	sim_results = clinc_simulator.run_simulation_clinc(
		dev_inc=dev_inc,
		sigma_inc=sigma_inc,
		sd_inc=sd_inc,
		rj=rj,
		varj=varj,
		r_i_j=r_i_j,
		lambda_cor=lambda_cor,
		data_paid_np=traingle_paid_inf,
		data_inc_np=traingle_incurred_inf,
		weights_np=data_wagi_cl,
		wykluczenia=wykluczenia,
		Poz_CL=Poz_CL,
		data_wagi_pi=data_wagi_pi,
		wykluczenia_p_i=wykluczenia_p_i,
		Poz_CL_p_i=Poz_CL_p_i,
		dop_ogo_p_i=dop_ogo_p_i,
		il_ogon=il_ogon,
		discount_factors=discount_rates,
		net_to_gross=netto_brutto,
		sigma_inc_LR=sigma_inc_LR,
		dev_inc_LR=dev_inc_LR,
		sd_inc_LR=sd_inc_LR,
		e_values=e_values,
		wagi_trimmed_LR=wagi_trimmed_LR,
		ilosc_dop_wsp_LR=ilosc_dop_wsp_LR,
		Poz_LR=Poz_LR,
		il_ogon_LR=il_ogon_LR,
		k_zmiana=k_zmiana,
		sim_total=sim_total,
		batch_sim=batch_sim,
		main_seed=main_seed,
	)

	SimulationClIncurredResult(user_id, sim_results)

	return {"status": "ok"}


@router.post("/calc/incurred/simulationaddytywna")
async def simulation_lr_incurred(request: SimulationLrIncurredRequest):
	user_id = request.user_id or "default_user"

	data_paid_np = np.array(request.data_paid_np, dtype=np.float64)
	data_inc_np = np.array(request.data_inc_np, dtype=np.float64)

	Lr_inc = np.array(request.Lr_inc, dtype=np.float64)
	sigma_inc = np.array(request.sigma_inc, dtype=np.float64)
	sd_inc = np.array(request.sd_inc, dtype=np.float64)

	rj = np.array(request.rj, dtype=np.float64)
	varj = np.array(request.varj, dtype=np.float64)
	r_i_j = np.array(request.r_i_j, dtype=np.float64)

	weights_np = np.array(request.weights_np, dtype=np.float64)
	data_wagi_pi = np.array(request.data_wagi_pi, dtype=np.float64)

	e_values = np.array(request.e_values or [], dtype=np.float64)
	lambda_cor = np.atleast_1d(
		np.array(
			request.lambda_cor if request.lambda_cor is not None else ([request.lambda_value] if request.lambda_value is not None else [0.0]),
			dtype=np.float64,
		)
	)
	if len(request.discount_factors) == 0:
		discount_factors = np.ones(len(Lr_inc), dtype=np.float64)
	else:
		discount_factors = np.array(request.discount_factors, dtype=np.float64)

	if len(request.net_to_gross) == 0:
		net_to_gross = np.ones(len(Lr_inc), dtype=np.float64)
	else:
		net_to_gross = np.array(request.net_to_gross, dtype=np.float64)

	wykluczenia = np.array(request.wykluczenia or [i + 1 for i in range(len(Lr_inc))], dtype=np.int32)
	wykluczenia_p_i = np.array(request.wykluczenia_p_i or [i + 1 for i in range(len(rj))], dtype=np.int32)

	Poz_LR = request.Poz_LR[0] if isinstance(request.Poz_LR, list) else request.Poz_LR
	Poz_LR_p_i = request.Poz_LR_p_i[0] if isinstance(request.Poz_LR_p_i, list) else request.Poz_LR_p_i

	sim_results = lr_incurred_simulator.run_simulation_lr_incurred(
		Lr_inc=Lr_inc[1:],
		sigma_inc=sigma_inc[1:],
		sd_inc=sd_inc[1:],
		e_values=e_values,
		rj=rj,
		varj=varj,
		r_i_j=r_i_j,
		lambda_cor=lambda_cor,
		data_paid_np=data_paid_np,
		data_inc_np=data_inc_np,
		weights_np=weights_np,
		wykluczenia=wykluczenia,
		Poz_LR=int(Poz_LR),
		data_wagi_pi=data_wagi_pi,
		wykluczenia_p_i=wykluczenia_p_i,
		Poz_LR_p_i=int(Poz_LR_p_i),
		dop_ogo_p_i=request.dop_ogo_p_i,
		il_ogon=request.il_ogon,
		discount_factors=discount_factors,
		net_to_gross=net_to_gross,
		sim_total=request.sim_total,
		batch_sim=request.batch_sim,
		main_seed=request.main_seed,
	)
	SimulationClIncurredResult(user_id, sim_results)

	return {"status": "ok"}


@router.post("/calc/incurred/statistic")
async def statistic_cl_incurred(request: StatisticClIncurredRequest):
	payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
	user_id = payload["user_id"]
	skalowanie1 = payload["skalowanie"]
	skalowanie2 = payload["skalowanie2"]
	result_obj = SimulationClIncurredResult.get_for_user(user_id)

	if result_obj is None or result_obj.data is None:
		return {
			"status": "error",
			"message": "Brak wyników symulacji dla user_id.",
			"user_id": user_id,
			"stats": [],
		}

	data_deterministic = payload.get("deterministic_results")
	keys = ["last_col", "cum_trian", "ult_net_disc"]
	data_deterministic_sum = [sum(data_deterministic[k]) for k in keys] if data_deterministic is not None else [0.0, 0.0, 0.0]
	print(data_deterministic_sum)
	modified_data = result_obj.data.copy()
	for i in range(min(len(data_deterministic_sum), modified_data.shape[1])):
		if i == 0:
			modified_data[:, i] = skalowanie1 * (modified_data[:, i] - data_deterministic_sum[i])
		else:
			modified_data[:, i] = skalowanie1 * skalowanie2 * (modified_data[:, i] - data_deterministic_sum[i])

	kwantyle = payload["kwantyle"]
	stats = []
	for i in range(modified_data.shape[1]):
		col = modified_data[:, i]
		if not np.isnan(col).any():
			mean = np.mean(col)
			std = np.std(col)
			quantiles = np.quantile(col, kwantyle)
			stats.append(
				{
					"column": i,
					"mean": float(mean),
					"quantiles": [float(q) for q in quantiles],
					"std": float(std),
					"SCR": float(np.quantile(col, 0.995)) - float(mean),
				}
			)

	return {
		"status": "ok",
		"message": "Dane statystyk incurred odebrane pomyślnie.",
		"user_id": user_id,
		"stats": stats,
	}
