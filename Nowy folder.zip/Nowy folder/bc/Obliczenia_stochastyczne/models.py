from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional, Union
import numpy as np


class SimulationCalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class SimulationHybridClPaidRequest(BaseModel):
    user_id: str
    paid_triangle: List[List[Optional[float]]]
    cl_indexes: List[int]
    sigma_indexes: List[int]
    left_count_cl: int
    selected_value_cl: List[float]
    selected_value_sigma: List[float]
    combined_sd_summary: List[float]
    calculation_options: SimulationCalculationOptions
    discount_rates: Dict[str, Dict[str, Optional[float]]]
    netto_brutto: Dict[str, Dict[str, Optional[float]]]
    weights: List[List[int]]
    ilosc_symulacji: int = 1000
    ziarno: int = 1111
    podzial_ziarna: int = 1000
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    tail_count_cl: Optional[int] = None


class SimulationHybridAddPaidRequest(BaseModel):
    user_id: str
    paid_triangle: List[List[Optional[float]]]
    lr_indexes: List[int]
    sigma_indexes: List[int]
    left_count_lr: int
    selected_value_lr: List[float]
    selected_value_sigma: List[float]
    combined_sd_summary: List[float]
    calculation_options: SimulationCalculationOptions
    discount_rates: Dict[str, Dict[str, Optional[float]]]
    netto_brutto: Dict[str, Dict[str, Optional[float]]]
    weights: List[List[int]]
    ilosc_symulacji: int = 1000
    ziarno: int = 1111
    podzial_ziarna: int = 1000
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    tail_count_lr: Optional[int] = None
    e_values: List[float]


class SimulationHybridAddClPaidRequest(BaseModel):
    user_id: str
    paid_triangle: List[List[Optional[float]]]
    calculation_options: SimulationCalculationOptions

    cl_indexes: List[int]
    sigma_indexes: List[int]
    left_count_cl: int
    selected_value_cl: List[float]
    selected_value_sigma: List[float]
    combined_sd_summary: List[float]
    tail_count_cl: Optional[int] = None
    weights: List[List[int]]

    lr_indexes: List[int]
    left_count_lr: int
    selected_value_lr: List[float]
    selected_value_sigma_add: List[float]
    combined_sd_summary_add: List[float]
    tail_count_lr: Optional[int] = None
    weights_add: List[List[int]]
    e_values: List[float]

    discount_rates: Dict[str, Dict[str, Optional[float]]]
    netto_brutto: Dict[str, Dict[str, Optional[float]]]

    ilosc_symulacji: int = 1000
    ziarno: int = 1111
    podzial_ziarna: int = 1000
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    kwantyle: Optional[List[float]] = None

    k_chage_sim_paid: Optional[float] = None
 

    multiplikatywna_payload: Optional[Dict[str, Any]] = None
    addytywna_payload: Optional[Dict[str, Any]] = None


class SimulationClIncurredRequest(BaseModel):
    user_id_incurred: str

    last_col_incurred: List[float]
    cum_trian_incurred: List[float]
    ult_net_disc_incurred: List[float]

    ilosc_symulacji_incurred: int
    ziarno_incurred: int
    skalowanie_incurred: float
    skalowanie2_incurred: float
    kwantyle_incurred: List[float]

    paid_triangle_incurred: List[List[Optional[float]]]
    incurred_triangle_incurred: List[List[Optional[float]]]
    train_paidtoincurred: List[List[Optional[float]]]
    res_i_j_paid_to_incurred: List[List[Optional[float]]]

    weights_incurred: List[List[int]]
    weights_rj_incurred: List[List[int]]

    calculation_options_incurred: Dict[str, bool]
    combined_sd_summary_incurred: List[float]

    selected_dev_j_indexes_incurred: List[int]
    selected_sigma_indexes_incurred: List[int]
    sigma_indexes_incurred: List[int]
    left_count_cl_incurred: int

    selected_value_cl_incurred: List[float]
    selected_value_sigma_incurred: List[float]
    selected_value_sd_incurred: List[float]
    selected_values_rj_paid_to_incurred: List[float]
    selected_values_varj_paid_to_incurred: List[float]
    selected_varj_paid_to_incurred_indexes_incurred: List[int]
    selected_rj_paid_to_incurred_indexes_incurred: List[int]

    sigma_incurred: List[float]
    sd_incurred: List[float]

    tail_count_cl_incurred: int
    tail_count_rj_paid_to_incurred: int
    tail_count_varj_paid_to_incurred_incurred: int

    discount_rates_incurred: Dict[str, Dict[str, Optional[float]]]
    netto_brutto_incurred: Dict[str, Dict[str, Optional[float]]]

    lambda_j_paid_to_incurred: float
    varj_paid_to_incurred_coefficients: List[Optional[float]]
    lambda_value: float = Field(alias="lambda")


class SimulationLrIncurredRequest(BaseModel):
    user_id: Optional[str] = None

    data_paid_np: List[List[Optional[float]]]
    data_inc_np: List[List[Optional[float]]]

    Lr_inc: List[float]
    sigma_inc: List[float]
    sd_inc: List[float]

    rj: List[float]
    varj: List[float]
    r_i_j: List[List[Optional[float]]] = Field(default_factory=list)

    lambda_cor: Optional[Union[List[float], float]] = None
    lambda_value: Optional[float] = Field(default=None, alias="lambda")

    sim_total: int = 1000
    batch_sim: int = 1000
    main_seed: int = 202260011

    discount_factors: Union[List[float], Dict[str, Any]] = Field(default_factory=list)
    net_to_gross: Union[List[float], Dict[str, Any]] = Field(default_factory=list)

    weights_np: List[List[float]]
    data_wagi_pi: List[List[float]]
    e_values: Optional[List[float]] = None

    Poz_LR: Union[int, List[int]]
    Poz_LR_p_i: Union[int, List[int]] = Field(default=0, alias="Poz_pi")

    wykluczenia_p_i: List[int] = Field(default_factory=list)
    wykluczenia: Optional[List[int]] = None
    wykluczenia_pi: Optional[List[int]] = None

    il_ogon: int
    il_ogon_pi: Optional[int] = None
    dop_ogo_p_i: bool = False

class StatisticClIncurredRequest(BaseModel):
    user_id: str
    kwantyle: List[float]
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    deterministic_results: Optional[Dict[str, List[float]]] = None


class SimulationClIncurredResult:
    _storage: Dict[str, "SimulationClIncurredResult"] = {}

    def __init__(self, user_id: str, sim_results: Any):
        self.user_id = user_id
        self.raw_result: Any = sim_results
        self.data: Optional[np.ndarray] = sim_results if isinstance(sim_results, np.ndarray) else None
        self.shape = self.data.shape if self.data is not None else None
        SimulationClIncurredResult._storage[user_id] = self

    @staticmethod
    def get_for_user(user_id: str) -> Optional["SimulationClIncurredResult"]:
        return SimulationClIncurredResult._storage.get(user_id)
