import threading

from fastapi import APIRouter, Request
import numpy as np

from add_simulator import YearHorizontLR2
from cl_simulator import YearHorizont2
from cladd_hybrid import CLADDHybrid
from .models import (
    SimulationHybridAddClPaidRequest,
    SimulationHybridAddPaidRequest,
    SimulationHybridClPaidRequest,
)


router = APIRouter()
yh2 = YearHorizont2()
yh_lr = YearHorizontLR2()
yh3 = CLADDHybrid()


class HybridSimulationClPaidResult:
    _results = {}
    _lock = threading.Lock()

    def __init__(self, user_id, data):
        self.user_id = user_id
        self.data = data
        with HybridSimulationClPaidResult._lock:
            HybridSimulationClPaidResult._results[user_id] = self

    @classmethod
    def get_for_user(cls, user_id):
        with cls._lock:
            return cls._results.get(user_id)


@router.post("/calc/simulationHybClpaid")
async def simulation_hybrid_cl_paid(request: SimulationHybridClPaidRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()

    user_id = payload['user_id']
    ilosc_symulacji = payload['ilosc_symulacji']
    ziarno = payload['ziarno']
    podzial_ziarna = payload['podzial_ziarna']
    left_count_cl = payload['left_count_cl']
    paid_triangle = np.array(payload['paid_triangle'])
    selected_value_cl = np.array(payload['selected_value_cl'])
    selected_value_sigma = np.array(payload['selected_value_sigma'])
    tail_count_cl = payload.get('tail_count_cl')

    if payload.get('discount_rates') and len(payload['discount_rates']) > 0:
        first_inner = next(iter(payload['discount_rates'].values()))
        discount_rates = np.array(list(first_inner.values()), dtype=float)
    else:
        discount_rates = np.array([], dtype=float)

    if payload.get('netto_brutto') and len(payload['netto_brutto']) > 0:
        first_inner = next(iter(payload['netto_brutto'].values()))
        netto_brutto = np.array(list(first_inner.values()), dtype=float)
    else:
        netto_brutto = np.array([], dtype=float)

    weights = np.array(payload['weights'])
    paid_triangle = np.asarray(paid_triangle, dtype=np.float64)
    cl_indexes = np.asarray([x + 1 for x in payload['cl_indexes']], dtype=np.int32)
    print(payload["ilosc_symulacji"], payload["podzial_ziarna"], payload["ziarno"])

    sim_results = yh2.run_simulation_cl(
        data_paid=paid_triangle,
        sigma_j=selected_value_sigma,
        dev=selected_value_cl,
        sd=payload['combined_sd_summary'],
        wagi_trimmed=weights,
        wykluczenia=cl_indexes,
        Poz_CL=left_count_cl,
        il_ogon=tail_count_cl if tail_count_cl is not None else 0,
        discount_factors=discount_rates,
        net_to_gross=netto_brutto,
        latest=1,
        sim_total=ilosc_symulacji,
        batch_sim=podzial_ziarna,
        main_seed=ziarno
    )

    HybridSimulationClPaidResult(user_id, sim_results)

    return {
        "status": "ok",
        "message": "Dane odebrane i wyświetlone w logach backendu jako numpy arrays."
    }


@router.post("/calc/simulationHybAddpaid")
async def simulation_hybrid_add_paid(request: SimulationHybridAddPaidRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
    user_id = payload['user_id']
    ilosc_symulacji = payload['ilosc_symulacji']
    ziarno = payload['ziarno']
    podzial_ziarna = payload['podzial_ziarna']
    left_count_lr = payload['left_count_lr']
    paid_triangle = np.array(payload['paid_triangle'])
    exposure_values = np.array(payload['e_values'])[1:]
    selected_value_lr = np.array(payload['selected_value_lr'])
    selected_value_sigma = np.array(payload['selected_value_sigma'])
    tail_count_lr = payload.get('tail_count_lr')
    if payload.get('discount_rates') and len(payload['discount_rates']) > 0:
        first_inner = next(iter(payload['discount_rates'].values()))
        discount_rates = np.array(list(first_inner.values()), dtype=float)
    else:
        discount_rates = np.array([], dtype=float)

    if payload.get('netto_brutto') and len(payload['netto_brutto']) > 0:
        first_inner = next(iter(payload['netto_brutto'].values()))
        netto_brutto = np.array(list(first_inner.values()), dtype=float)
    else:
        netto_brutto = np.array([], dtype=float)
    combined_sd_length = len(payload['combined_sd_summary'])
    target_length = combined_sd_length + 2
    if len(discount_rates) == 0:
        discount_rates = np.ones(target_length, dtype=float)
    if len(netto_brutto) == 0:
        netto_brutto = np.ones(target_length, dtype=float)
    weights = np.array(payload['weights'])
    paid_triangle = np.asarray(paid_triangle, dtype=np.float64)
    lr_indexes = np.asarray([x + 1 for x in payload['lr_indexes']], dtype=np.int32)
    sim_results = yh_lr.run_simulation_lr(
        data_paid=paid_triangle,
        sigma_j_LR=selected_value_sigma[1:],
        dev_LR=selected_value_lr[1:],
        sd_LR=payload['combined_sd_summary'][1:],
        e_values=exposure_values,
        wagi_trimmed=weights,
        ilosc_dop_wsp_CL=lr_indexes,
        Poz_LR=left_count_lr,
        il_ogon=tail_count_lr if tail_count_lr is not None else 0,
        ultimate_param_resrisk=np.array([]),
        discount_factors=discount_rates,
        net_to_gross=netto_brutto,
        sim_total=ilosc_symulacji,
        batch_sim=podzial_ziarna,
        main_seed=ziarno
    )

    HybridSimulationClPaidResult(user_id, sim_results)

    return {
        "status": "ok",
        "message": "Symulacja Hybrydowa AddPaid została wykonana pomyślnie.",
    }

#@router.post("/calc/simulationHybAddClpaid")
@router.post("/calc/simulationHybAddClpaid")
async def simulation_hybrid_addcl_paid(request: SimulationHybridAddClPaidRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()

    user_id = payload["user_id"]
    data_paid = np.asarray(payload["paid_triangle"], dtype=np.float64)

    sigma_j_cl = np.asarray(payload["selected_value_sigma"], dtype=np.float64)
    dev_cl = np.asarray(payload["selected_value_cl"], dtype=np.float64)
    sd_cl = payload["combined_sd_summary"]
    wagi_cl = np.asarray(payload["weights"], dtype=np.float64)
    wykluczenia_cl = np.asarray([x + 1 for x in payload["cl_indexes"]], dtype=np.int32)
    poz_cl = payload["left_count_cl"]
    il_ogon_cl = payload.get("tail_count_cl") or 0

    sigma_j_lr = np.asarray(payload["selected_value_sigma_add"], dtype=np.float64)[1:]
    dev_lr = np.asarray(payload["selected_value_lr"], dtype=np.float64)[1:]
    sd_lr = payload["combined_sd_summary_add"][1:]
    e_values = np.asarray(payload["e_values"], dtype=np.float64)[1:]
    wagi_lr = np.asarray(payload["weights_add"], dtype=np.float64)
    wykluczenia_lr = np.asarray([x + 1 for x in payload["lr_indexes"]], dtype=np.int32)
    poz_lr = payload["left_count_lr"]
    il_ogon_lr = payload.get("tail_count_lr") or 0
    k_chage_sim_paid = payload.get("k_chage_sim_paid")
    if payload.get("discount_rates") and len(payload["discount_rates"]) > 0:
        first_inner = next(iter(payload["discount_rates"].values()))
        discount_factors = np.array(list(first_inner.values()), dtype=float)
    else:
        discount_factors = np.array([], dtype=float)

    if payload.get("netto_brutto") and len(payload["netto_brutto"]) > 0:
        first_inner = next(iter(payload["netto_brutto"].values()))
        net_to_gross = np.array(list(first_inner.values()), dtype=float)
    else:
        net_to_gross = np.array([], dtype=float)



    sim_results = yh3.run_simulation_addcl(
        data_paid=data_paid,
        sigma_j=sigma_j_cl,
        dev=dev_cl,
        sd=sd_cl,
        wagi_trimmed=wagi_cl,
        wykluczenia=wykluczenia_cl,
        Poz_CL=poz_cl,
        il_ogon_CL=il_ogon_cl,
        sigma_j_LR=sigma_j_lr,
        dev_LR=dev_lr,
        sd_LR=sd_lr,
        e_values=e_values,
        wagi_trimmed_LR=wagi_lr,
        ilosc_dop_wsp_LR=wykluczenia_lr,
        Poz_LR=poz_lr,
        il_ogon_LR=il_ogon_lr,
        ultimate_param_resrisk=np.array([]),
        sim_total_lr=payload["ilosc_symulacji"],
        batch_sim_lr=payload["podzial_ziarna"],
        main_seed_lr=payload["ziarno"],
        discount_factors_lr=discount_factors,
        net_to_gross_lr=net_to_gross,
        k_zmiana = k_chage_sim_paid if k_chage_sim_paid is not None else -1
    )
    print("tutaj:")
    HybridSimulationClPaidResult(user_id, sim_results)

    return {
        "status": "ok",
        "message": "Symulacja Hybrydowa Add+Cl została wykonana pomyślnie.",
       # "vectors": {
       #     "last_col": sim_results[:, 0].tolist() if sim_results.shape[1] > 0 else [],
       #     "cum_trian": sim_results[:, 1].tolist() if sim_results.shape[1] > 1 else [],
       #     "ult_net_disc": sim_results[:, 2].tolist() if sim_results.shape[1] > 2 else [],
       # },
    }


@router.post("/calc/statisticHybClpaid")
async def hybrid_statistic_cl_paid(request: Request):
    payload = await request.json()
    user_id = payload['user_id']
    skalowanie1 = payload['skalowanie']
    skalowanie2 = payload['skalowanie2']
    result_obj = HybridSimulationClPaidResult.get_for_user(user_id)
    data_deterministic = payload.get('deterministic_results')
    keys = ['last_col', 'cum_trian', 'ult_net_disc']
    data_deterministic_sum = [sum(data_deterministic[k]) for k in keys]
    modified_data = result_obj.data.copy()

    if data_deterministic_sum is not None:
        for i in range(len(data_deterministic_sum)):
            if i == 0:
                modified_data[:, i] = skalowanie1 * (modified_data[:, i] - data_deterministic_sum[i])
            else:
                modified_data[:, i] = skalowanie1 * skalowanie2 * (modified_data[:, i] - data_deterministic_sum[i])

    kwantyle = payload['kwantyle']
    stats = []
    column_names = ["Brutto", "Brutto One dyskontowany", "Netto One dyskontowany"]

    for i in range(modified_data.shape[1]):
        col = modified_data[:, i]
        if not np.isnan(col).any():
            mean = np.mean(col)
            std = np.std(col)
            quantiles = np.quantile(col, kwantyle)
            stats.append({
                "column": column_names[i] if i < len(column_names) else f"Kolumna {i}",
                "mean": float(mean),
                "quantiles": [float(q) for q in quantiles],
                "std": float(std),
                "SCR": float(np.quantile(col, 0.995)) - float(mean)
            })

    return {
        "status": "ok",
        "message": "Dane statystyk odebrane pomyślnie (hybrydowe)",
        "user_id": user_id,
        "stats": stats,
    }
