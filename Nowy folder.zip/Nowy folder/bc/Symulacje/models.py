from pydantic import BaseModel, Field
from typing import List, Union, Optional, Dict, Any
import numpy as np


class SimulationCalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class SimulationClPaidRequest(BaseModel):
    # ZAWSZE wysyłane - podstawowe dane
    user_id: str
    paid_triangle: List[List[Optional[float]]]
    cl_indexes: List[int]             
    sigma_indexes: List[int]          
    left_count_cl: int               
    selected_value_cl: List[float]
    selected_value_sigma: List[float]
    combined_sd_summary: List[float]
    calculation_options: SimulationCalculationOptions  
    discount_rates: Dict[str, Dict[str, Optional[float]]]
    netto_brutto: Dict[str, Dict[str, Optional[float]]] 
    weights: List[List[int]]
    ilosc_symulacji: int = 1000
    ziarno: int = 1111
    podzial_ziarna: int = 1000
    skalowanie: float = 1.0  
    skalowanie2: float = 1.0  # 🆕 OPCJONALNIE DODAJ I TUTAJ
    tail_count_cl: Optional[int] = None



class SimulationClIncurredRequest(BaseModel):
    # Podstawowe dane użytkownika
    user_id_incurred: str
    
    # Wektory obliczeń z Chain Ladder Results
    last_col_incurred: List[float]
    cum_trian_incurred: List[float] 
    ult_net_disc_incurred: List[float]
    
    # Parametry symulacji
    ilosc_symulacji_incurred: int
    ziarno_incurred: int
    skalowanie_incurred: float
    skalowanie2_incurred: float
    kwantyle_incurred: List[float]
    
    # Trójkąty danych  
    paid_triangle_incurred: List[List[Optional[float]]]
    incurred_triangle_incurred: List[List[Optional[float]]]
    train_paidtoincurred: List[List[Optional[float]]]
    res_i_j_paid_to_incurred: List[List[Optional[float]]]
    

    # Wagi
    weights_incurred: List[List[int]]
    weights_rj_incurred: List[List[int]]
    
    # Opcje kalkulacji
    calculation_options_incurred: Dict[str, bool]
    
    # Podsumowania i współczynniki
    combined_sd_summary_incurred: List[float]
    
    # Indeksy i selekcje
    selected_dev_j_indexes_incurred: List[int]
    selected_sigma_indexes_incurred: List[int]
    sigma_indexes_incurred: List[int]
    left_count_cl_incurred: int
    
    # Selected values
    selected_value_cl_incurred: List[float]
    selected_value_sigma_incurred: List[float]
    selected_value_sd_incurred: List[float]
    selected_values_rj_paid_to_incurred: List[float]
    selected_values_varj_paid_to_incurred: List[float]
    selected_varj_paid_to_incurred_indexes_incurred: List[int]
    selected_rj_paid_to_incurred_indexes_incurred: List[int]
    # Dane z obliczeń
    sigma_incurred: List[float]
    sd_incurred: List[float]
    
    # Tail counts
    tail_count_cl_incurred: int
    tail_count_rj_paid_to_incurred: int
    tail_count_varj_paid_to_incurred_incurred: int
    
    # Stawki dyskontowe i netto/brutto
    discount_rates_incurred: Dict[str, Dict[str, Optional[float]]]
    netto_brutto_incurred: Dict[str, Dict[str, Optional[float]]]
    
    # Dane PaidToIncurred
    train_paidtoincurred: List[List[Optional[float]]]  # Może zawierać None
    res_i_j_paid_to_incurred: List[List[Optional[float]]]  # Może zawierać None
    lambda_j_paid_to_incurred: float
    varj_paid_to_incurred_coefficients: List[Optional[float]]  # Może zawierać None
    
    # Lambda jako ostatnie pole (używamy aliasu bo lambda to słowo kluczowe)
    lambda_value: float = Field(alias="lambda")
    


class DeterministicResults(BaseModel):
    cum_trian: List[float]
    last_col: List[float]
    ult_net_disc: List[float]
    userId: str
    calculatedAt: str

class StatisticClPaidRequest(BaseModel):
    user_id: str
    kwantyle: List[float]
    skalowanie: float = 1.0
    skalowanie2: float = 1.0  # 🆕 DODAJ TO POLE
    simulation_results: Optional[Dict[str, List[float]]] = None
    deterministic_results: Optional[DeterministicResults] = None

class StatisticClIncurredRequest(BaseModel):
    user_id: str
    kwantyle: List[float]
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    simulation_results: Optional[Dict[str, List[float]]] = None
    deterministic_results: Optional[DeterministicResults] = None

class SimulationLrPaidRequest(BaseModel):
    # ZAWSZE wysyłane - podstawowe dane dla Loss Ratio
    user_id: str
    paid_triangle: List[List[Optional[float]]]  # Może zawierać null
    e_values: List[float]                   # 🔥 ZMIANA: e_values zamiast exposure_values
    lr_indexes: List[int]                   # Indeksy dla LR (analogia do cl_indexes)
    sigma_indexes: List[int]               
    left_count_lr: int                     # Pozycja LR (analogia do left_count_cl)
    selected_value_lr: List[float]         # Współczynniki LR
    selected_value_sigma: List[float]      
    combined_sd_summary: List[Union[float, str]]  # 🔥 ZMIANA: AddPaid może mieć mixed types
    calculation_options: SimulationCalculationOptions  
    discount_rates: Dict[str, Dict[str, Optional[float]]]  # Może być {}
    netto_brutto: Dict[str, Dict[str, Optional[float]]] 
    weights: List[List[int]]
    ilosc_symulacji: int = 1000           
    ziarno: int = 1111                    
    podzial_ziarna: int = 1000            
    skalowanie: float = 1.0
    skalowanie2: float = 1.0  # 🆕 DODANE: drugie skalowanie
    kwantyle: List[float]                   # 🔥 DODANE: kwantyle z frontend
    tail_count_lr: Optional[int] = None   # Długość ogona dla LR


class StatisticLrPaidRequest(BaseModel):
    user_id: str
    kwantyle: List[float]
    skalowanie: float = 1.0
    skalowanie2: float = 1.0  # 🆕 DODANE: drugie skalowanie
    simulation_results: Optional[Dict[str, List[float]]] = None
    deterministic_results: Optional[DeterministicResults] = None  # 🆕 DODANE: wyniki deterministyczne AddPaid



class AllTestDataRequest(BaseModel):
    """Wszystkie dane z TestTab w jednym requescie"""
    # === WSPÓLNE DANE ===
    user_id: str
    paid_triangle: List[List[Optional[float]]]
    calculation_options: Dict[str, bool]  # Uproszczone
    discount_rates: Dict[str, Dict[str, Optional[float]]]
    netto_brutto: Dict[str, Dict[str, Optional[float]]]
    
    # === CHAIN LADDER DANE ===
    cl_weights: List[List[int]]
    cl_indexes: List[int]
    cl_sigma_indexes: List[int]
    cl_left_count: int
    cl_tail_count: Optional[int] = None
    cl_selected_value_cl: List[float]
    cl_selected_value_sigma: List[float]
    cl_combined_sd_summary: List[float]
    cl_ilosc_symulacji: int = 1000
    cl_ziarno: int = 1111
    cl_podzial_ziarna: int = 1000
    cl_skalowanie: float = 1.0
    cl_kwantyle: List[float]
    
    # === ADDPAID DANE ===
    add_weights: List[List[int]]
    add_lr_indexes: List[int]
    add_sigma_indexes: List[int]
    add_left_count_lr: int
    add_tail_count_lr: Optional[int] = None
    add_selected_value_lr: List[float]
    add_selected_value_sigma: List[float]
    add_combined_sd_summary: List[Union[float, str]]
    add_e_values: List[float]  # exposure values
    add_ilosc_symulacji: int = 1000
    add_ziarno: int = 1111
    add_podzial_ziarna: int = 1000
    add_skalowanie: float = 1.0
    add_skalowanie2: float = 1.0
    add_kwantyle: List[float]
    
    # === WYNIKI (OPCJONALNE) ===
    cl_simulation_results: Optional[Dict[str, List[float]]] = None
    add_simulation_results: Optional[Dict[str, List[float]]] = None
    cl_deterministic_results: Optional[Dict[str, Any]] = None
    add_deterministic_results: Optional[Dict[str, Any]] = None



class SimulationLrPaidResult:
    _storage: Dict[str, "SimulationLrPaidResult"] = {}

    def __init__(self, user_id: str, sim_results: Any):
        self.user_id = user_id
        self.raw_result: Any = sim_results

        if isinstance(sim_results, np.ndarray):
            self.data: np.ndarray = sim_results
            self.shape = sim_results.shape
        else:
            self.data = None
            self.shape = None

        SimulationLrPaidResult._storage[user_id] = self
    
    @classmethod
    def get_for_user(cls, user_id: str) -> Optional["SimulationLrPaidResult"]:
        return cls._storage.get(user_id)  # 🔥 DODANE: brakująca metoda get_for_user

    @staticmethod
    def get_for_user(user_id: str) -> Optional["SimulationLrPaidResult"]:
        return SimulationLrPaidResult._storage.get(user_id)

    @staticmethod
    def delete_for_user(user_id: str) -> None:
        if user_id in SimulationLrPaidResult._storage:
            del SimulationLrPaidResult._storage[user_id]

    @staticmethod
    def clear_all() -> None:
        SimulationLrPaidResult._storage.clear()

    def __repr__(self):
        return f"<SimulationLrPaidResult user_id={self.user_id} shape={self.shape}>"


class SimulationClPaidResult:
    _storage: Dict[str, "SimulationClPaidResult"] = {}

    def __init__(self, user_id: str, sim_results: Any):
        self.user_id = user_id
        self.raw_result: Any = sim_results

        if isinstance(sim_results, np.ndarray):
            self.data: np.ndarray = sim_results
            self.shape = sim_results.shape
        else:
            self.data = None
            self.shape = None

        SimulationClPaidResult._storage[user_id] = self

    @staticmethod
    def get_for_user(user_id: str) -> Optional["SimulationClPaidResult"]:
        return SimulationClPaidResult._storage.get(user_id)

    @staticmethod
    def delete_for_user(user_id: str) -> None:
        if user_id in SimulationClPaidResult._storage:
            del SimulationClPaidResult._storage[user_id]

    @staticmethod
    def clear_all() -> None:
        SimulationClPaidResult._storage.clear()

    def __repr__(self):
        return f"<SimulationClPaidResult user_id={self.user_id} shape={self.shape}>"


class SimulationClIncurredResult:
    _storage: Dict[str, "SimulationClIncurredResult"] = {}

    def __init__(self, user_id: str, sim_results: Any):
        self.user_id = user_id
        self.raw_result: Any = sim_results

        if isinstance(sim_results, np.ndarray):
            self.data: np.ndarray = sim_results
            self.shape = sim_results.shape
        else:
            self.data = None
            self.shape = None

        SimulationClIncurredResult._storage[user_id] = self

    @staticmethod
    def get_for_user(user_id: str) -> Optional["SimulationClIncurredResult"]:
        return SimulationClIncurredResult._storage.get(user_id)

    @staticmethod
    def delete_for_user(user_id: str) -> None:
        if user_id in SimulationClIncurredResult._storage:
            del SimulationClIncurredResult._storage[user_id]

    @staticmethod
    def clear_all() -> None:
        SimulationClIncurredResult._storage.clear()

    def __repr__(self):
        return f"<SimulationClIncurredResult user_id={self.user_id} shape={self.shape}>"


class SimulationClIncurredIndependentRequest(BaseModel):
    user_id_incurred: str
    last_col_incurred: List[float]
    cum_trian_incurred: List[float]
    ult_net_disc_incurred: List[float]

    ilosc_symulacji_incurred: int
    ziarno_incurred: int
    skalowanie_incurred: float
    skalowanie2_incurred: float
    kwantyle_incurred: List[float]

    paid_triangle_incurred: List[List[Optional[float]]]
    incurred_triangle_incurred: List[List[Optional[float]]]
    train_paidtoincurred: List[List[Optional[float]]]
    res_i_j_paid_to_incurred: List[List[Optional[float]]]

    weights_incurred: List[List[int]]
    weights_rj_incurred: List[List[int]]

    calculation_options_incurred: Dict[str, bool]
    combined_sd_summary_incurred: List[float]

    selected_dev_j_indexes_incurred: List[int]
    selected_sigma_indexes_incurred: List[int]
    sigma_indexes_incurred: List[int]
    left_count_cl_incurred: int

    selected_value_cl_incurred: List[float]
    selected_value_sigma_incurred: List[float]
    selected_value_sd_incurred: List[float]
    selected_values_rj_paid_to_incurred: List[float]
    selected_values_varj_paid_to_incurred: List[float]
    selected_varj_paid_to_incurred_indexes_incurred: List[int]
    selected_rj_paid_to_incurred_indexes_incurred: List[int]

    sigma_incurred: List[float]
    sd_incurred: List[float]

    tail_count_cl_incurred: int
    tail_count_rj_paid_to_incurred: int
    tail_count_varj_paid_to_incurred_incurred: int

    discount_rates_incurred: Dict[str, Dict[str, Optional[float]]]
    netto_brutto_incurred: Dict[str, Dict[str, Optional[float]]]

    lambda_j_paid_to_incurred: float
    varj_paid_to_incurred_coefficients: List[Optional[float]]
    lambda_value: float = Field(alias="lambda")


class StatisticClIncurredIndependentRequest(BaseModel):
    user_id: str
    kwantyle: List[float]
    skalowanie: float = 1.0
    skalowanie2: float = 1.0
    simulation_results: Optional[Dict[str, List[float]]] = None
    deterministic_results: Optional[DeterministicResults] = None


class SimulationClIncurredIndependentResult:
    _storage: Dict[str, "SimulationClIncurredIndependentResult"] = {}

    def __init__(self, user_id: str, sim_results: Any):
        self.user_id = user_id
        self.raw_result: Any = sim_results

        if isinstance(sim_results, np.ndarray):
            self.data: np.ndarray = sim_results
            self.shape = sim_results.shape
        else:
            self.data = None
            self.shape = None

        SimulationClIncurredIndependentResult._storage[user_id] = self

    @staticmethod
    def get_for_user(user_id: str) -> Optional["SimulationClIncurredIndependentResult"]:
        return SimulationClIncurredIndependentResult._storage.get(user_id)

    @staticmethod
    def delete_for_user(user_id: str) -> None:
        if user_id in SimulationClIncurredIndependentResult._storage:
            del SimulationClIncurredIndependentResult._storage[user_id]

    @staticmethod
    def clear_all() -> None:
        SimulationClIncurredIndependentResult._storage.clear()

    def __repr__(self):
        return f"<SimulationClIncurredIndependentResult user_id={self.user_id} shape={self.shape}>"