from pydantic import BaseModel
from typing import List, Optional


class InflationRequest(BaseModel):
    user_id: str
    triangle: List[List[Optional[float]]]
    inflationVector: List[Optional[float]]


class InflationResponse(BaseModel):
    success: bool
    adjustedTriangle: List[List[Optional[float]]]
    message: str = ""


class InflationRequestIncurred(BaseModel):
    user_id: str
    triangle_paid: List[List[Optional[float]]]
    triangle_reserved: List[List[Optional[float]]]
    inflationVector: List[Optional[float]]

class InflationRequestExposure(BaseModel):
    user_id: str
    inflationVector: List[Optional[float]]
    exposureVector: List[Optional[float]]