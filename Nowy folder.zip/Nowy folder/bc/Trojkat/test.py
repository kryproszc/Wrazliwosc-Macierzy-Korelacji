import numpy as np

mm = 5
n_dev = 4

paid = np.full((mm, 5), np.nan)

paid[0] = [100, 120, 140, 150, 155]
paid[1, :4] = [110, 130, 145, 150]
paid[2, :3] = [120, 140, 150]
paid[3, :2] = [130, 145]
paid[4, :1] = [140]

e_values = np.ones(mm) * 1000
sto_lr = 0.10

for j in range(n_dev):

    max_ind_row = mm - j

    for i in range(max_ind_row - 1, mm):

        paid[i, j + 1] = (
            e_values[i] * sto_lr
            + paid[i, j]
        )

print(paid)