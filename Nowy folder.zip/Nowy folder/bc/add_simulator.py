from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
from numba import njit


# ---------------------------------------------------------------------------
# Helper functions (Numba-accelerated)
# ---------------------------------------------------------------------------

@njit
def choose_value_list(vec_input, vec_wykluczenia, a, b):
    """
    Wybiera wartości z vec_input wg indeksów w vec_wykluczenia (1-based),
    filtrując do przedziału (a, b). Zwraca (wartosci, indeksy_0based).
    """
    count = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            count += 1

    out_vals = np.empty(count)
    out_inds = np.empty(count, dtype=np.int64)

    pos = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            out_vals[pos] = val
            out_inds[pos] = idx
            pos += 1

    return out_vals, out_inds


@njit(fastmath=False)
def fit_curve_factor_lr(data_input, sd_input, x_k):
    """
    Dopasowanie krzywej: log(y)=a*k+b, gdzie y=data_input.
    Wagi zależą od błędu (sd_input).
    Zwraca (a_coef, b_coef).
    """
    n = len(data_input)
    se2 = sd_input ** 2
    w = np.empty(n)

    for i in range(n):
        denom = data_input[i] ** 2
        w_mian = np.sqrt(np.log(1.0 + se2[i] / denom)) if denom != 0.0 else 0.0
        if w_mian != 0.0:
            w[i] = 1.0 / w_mian
        else:
            w[i] = 0.0

    y = np.empty(n)
    for i in range(n):
        if data_input[i] > 0.0:
            y[i] = np.log(data_input[i])
        else:
            y[i] = 0.0

    A = A_x = A_xx = A_y = A_xy = 0.0
    for i in range(n):
        wi = w[i]
        xi = x_k[i]
        yi = y[i]
        A += wi
        A_x += wi * xi
        A_xx += wi * xi * xi
        A_y += wi * yi
        A_xy += wi * xi * yi

    Delta = A * A_xx - A_x * A_x
    if Delta == 0.0:
        return 0.0, 0.0

    a_coef = (A * A_xy - A_x * A_y) / Delta
    b_coef = (A_xx * A_y - A_x * A_xy) / Delta
    return a_coef, b_coef


@njit
def wspolczynnik_reg_factor_cl(a_coef, b_coef, k_start, k_stop):
    """
    Ogon: exp(a*k+b) dla k=k_start..k_stop (włącznie).
    """
    n = k_stop - k_start + 1
    out = np.empty(n)
    for i in range(n):
        k = k_start + i
        out[i] = np.exp(a_coef * k + b_coef)
    return out


@njit
def fit_curve_factor_P_to_I(data_input, x_k):
    factor_input = np.log(1.0 - data_input)
    w_k_sqr = np.ones(len(data_input))

    A = np.sum(w_k_sqr)
    A_x = np.sum(w_k_sqr * x_k)
    A_xx = np.sum(w_k_sqr * x_k * x_k)
    A_y = np.sum(w_k_sqr * factor_input)
    A_xy = np.sum(w_k_sqr * x_k * factor_input)

    Delta = A * A_xx - A_x * A_x
    if Delta == 0.0:
        return 0.0, 0.0
    a_num = (A * A_xy - A_x * A_y) / Delta
    b_num = (A_xx * A_y - A_x * A_xy) / Delta

    return a_num, b_num


@njit
def wspolczynnik_reg_factor_P_to_I(a, b, k_start, k_stop):
    k_values = np.arange(k_start, k_stop + 1)
    exponent = np.exp(a * k_values + b)
    wartosci_reg = 1.0 - exponent
    return wartosci_reg


@njit
def _build_base_triangle(data_paid, n_dev):
    """
    Buduje bazę trójkąta o wymiarze (mm, n_dev+1) kopiując dane
    i dopełniając NaN.
    """
    mm, n_cols_orig = data_paid.shape
    total_cols = n_dev + 1
    base = np.empty((mm, total_cols), dtype=np.float64)

    for i in range(mm):
        for j in range(total_cols):
            if j < n_cols_orig:
                base[i, j] = data_paid[i, j]
            else:
                base[i, j] = np.nan
    return base


@njit
def triangle_forward_loss_ratio_numba(tri_in, LR_j, exposure, k_forward):
    """
    Projekcja LR: C_{i,j+1} = C_{i,j} + exposure[i] * LR_j[j]
    """
    mm, n_cols_orig = tri_in.shape
    n_cols_out = max(n_cols_orig, len(LR_j) + 1)

    tri = np.empty((mm, n_cols_out), dtype=np.float64)
    tri[:] = np.nan

    for i in range(mm):
        for j in range(n_cols_orig):
            tri[i, j] = tri_in[i, j]

    for j in range(k_forward):
        max_ind_row = 1 if (mm - j) < 1 else (mm - j)
        start_row = max_ind_row - 1
        for i in range(start_row, mm):
            base_val = tri[i, j]
            tri[i, j + 1] = base_val + exposure[i] * LR_j[j]

    return tri


@njit
def sum_reverse_diagonal(data):
    """
    Suma elementów odwrotnej przekątnej (ostatniej pełnej diagonali).
    """
    tot = 0.0
    rows, cols = data.shape
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                tot += v
    return tot


@njit
def vector_reverse_diagonal(data):
    """
    Zwraca wektor elementów odwrotnej przekątnej (ostatniej pełnej diagonali).
    """
    rows, cols = data.shape
    result = []
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                result.append(v)
    return np.array(result)


@njit
def transform_data(data_input, exposure):
    """
    Transformacja do LR-inkrementów:
    col0: C_{i,0} / exposure[i]
    colj: (C_{i,j}-C_{i,j-1}) / exposure[i]
    """
    n, m = data_input.shape
    data_input = data_input[:, :(n + 1)]

    output = np.empty((n, m))

    for i in range(n):
        output[i, 0] = data_input[i, 0] / exposure[i]

    for j in range(1, m):
        for i in range(n):
            if not np.isnan(data_input[i, j]):
                output[i, j] = (data_input[i, j] - data_input[i, j - 1]) / exposure[i]

    return output


@njit
def wspolczynnik_LR(data_LR, w, exposure):
    """
    LR_j = sum_i(lr_ij * w_ij * e_i) / sum_i(w_ij * e_i)
    """
    n, m = data_LR.shape
    wsp_LR = np.empty(m)

    for j in range(m):
        numerator = 0.0
        denominator = 0.0

        for i in range(n):
            lr_ij = data_LR[i, j]
            w_ij = w[i, j]
            e_i = exposure[i]

            if not np.isnan(lr_ij) and not np.isnan(w_ij) and not np.isnan(e_i) and w_ij > 0.0:
                numerator += lr_ij * w_ij * e_i
                denominator += w_ij * e_i

        if denominator == 0.0:
            wsp_LR[j] = 0.0
        else:
            wsp_LR[j] = numerator / denominator

    return wsp_LR


@njit
def sigma_LR(data_LR, w, exposure, wsp_LR):
    """
    Sigma dla LR (wariancja ważona): sum(w*e*(lr-mean)^2)/(sum(w)-1)
    """
    n, m = data_LR.shape
    sigma_j = np.empty(m)
    for j in range(m):
        sum_num = 0.0
        sum_denom = 0.0
        mean_j = wsp_LR[j]
        for i in range(n):
            lr = data_LR[i, j]
            wij = w[i, j]
            ei = exposure[i]
            if not np.isnan(wij) and wij>0.0  :
                sum_num += wij * ei * (lr - mean_j) ** 2
                sum_denom += wij
        if sum_denom > 1.0:
            sigma_j[j] = sum_num / (sum_denom - 1.0)
        else:
            sigma_j[j] = 0.0
    return sigma_j


@njit
def wspolczynnik_sd(wsp_sigma, w, exposure):
    """
    sd_j = sqrt( sigma_j / sum_i(w_ij * e_i) )
    """
    n, m = w.shape
    sd_j = np.empty(m)

    for j in range(m):
        denominator = 0.0
        for i in range(n):
            wij = w[i, j]
            ei = exposure[i]
            if not np.isnan(wij):
                denominator += wij * ei

        if denominator == 0.0 or wsp_sigma[j] == 0.0:
            sd_j[j] = 0.0
        else:
            sd_j[j] = np.sqrt(wsp_sigma[j] / denominator)

    return sd_j


@njit
def triangle_forward_loss_ratio_numba_disc(
    tri_in,
    LR_j,
    exposure,
    discount_factors,
    net_to_gross,
    k_forward,
):

    mm, n_cols_orig = tri_in.shape
    n_cols_out = max(n_cols_orig, len(LR_j) + 1)

    base_col = tri_in[:, 0].copy()

    tri = np.empty((mm, n_cols_out), dtype=np.float64)
    tri[:] = np.nan

    for i in range(mm):
        for j in range(n_cols_orig):
            tri[i, j] = tri_in[i, j]

    for j in range(k_forward):
        max_ind_row = 1 if (mm - j) < 1 else (mm - j)
        start_row = max_ind_row - 1

        for i in range(start_row, mm):
            base_val = tri[i, j]
            tri[i, j + 1] = base_val + exposure[i] * LR_j[j]

    cols_tmp = tri.shape[1]
    tri_proj = np.full((mm, cols_tmp + 1), np.nan)
    tri_proj[:, 0] = base_col
    tri_proj[:, 1:] = tri

    inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
    inc_proj[:, 0] = base_col

    for rr in range(mm - 1, -1, -1):
        offset = mm - 1 - rr
        for cc in range(offset + 1, inc_proj.shape[1]):
            idx = cc - (offset + 1)
            if idx < len(discount_factors) and not np.isnan(inc_proj[rr, cc]):
                inc_proj[rr, cc] /= discount_factors[idx]

    total_disc = np.sum(np.nansum(inc_proj, axis=1))
    ult_gross_disc = np.nansum(inc_proj, axis=1)

    latest = vector_reverse_diagonal(tri_in)
    ult_net_disc = 0.0
    for iii in range(len(latest)):
        ult_net_disc += latest[iii] + (ult_gross_disc[iii] - latest[iii]) * net_to_gross[iii]

    return np.array([np.sum(tri[:, -1]), total_disc, ult_net_disc])


@njit()
def simulate_reserving_batched_numba(data_paid,
                                     sigma_j, dev, sd, e_values, wagi_trimmed,
                                     ilosc_dop_wsp_CL,
                                     Poz_LR,
                                     il_ogon,
                                     ultimate_param_resrisk,discount_factors,net_to_gross,
                                     sim_total=100_000,
                                     batch_sim=10_000,
                                     main_seed=202260011):
    latest = vector_reverse_diagonal(data_paid)
    mm, _   = data_paid.shape
    n_dev   = len(dev)
    base    = _build_base_triangle(data_paid, n_dev)
    results = np.zeros((sim_total, 3))
    n_batches = (sim_total + batch_sim - 1) // batch_sim

    index_el = 0
    for batch_idx in range(n_batches):
        np.random.seed(main_seed + batch_idx)
        start   = batch_idx * batch_sim
        end     = min(start + batch_sim, sim_total)
        cur_bs  = end - start

        mu_part    = np.empty((cur_bs, n_dev), dtype=np.float64)
        sigma_part = np.empty((cur_bs, n_dev), dtype=np.float64)

        for jj in range(n_dev):
            
            mu_part[:, jj] = np.random.normal(dev[jj], sd[jj], cur_bs)
            df = max(1, mm - jj )
            
            chi = np.random.chisquare(df, cur_bs)
            for ss in range(cur_bs):
                sigma_part[ss, jj] = (chi[ss] * sigma_j[jj]) / df

        for s in range(cur_bs):
            paid = base.copy()
            data_paid_to_one = data_paid.copy()

            new_tri = np.concatenate((data_paid_to_one, np.zeros((mm,1))), axis=1)
            empty_column = np.full((wagi_trimmed.shape[0], 1), np.nan)
            wagi_modified_lr = np.hstack((wagi_trimmed, empty_column))

            LR_i_j = transform_data(new_tri, e_values)
            empty_column_lr = np.full((LR_i_j.shape[0], 1), np.nan)
            LR_i_j_stoch = np.hstack((LR_i_j, empty_column_lr))
            for j in range(n_dev):
                max_ind_row = mm - j
                if max_ind_row < 1:
                    max_ind_row = 1
                for i in range(max_ind_row - 1, mm):
                    var_ij = sigma_part[s, j] / e_values[i]
                    dev_con = dev[j]
                    std_con = np.sqrt(var_ij)
                    if mu_part[s, j] > 0.0:
                        lmean  = np.log(mu_part[s, j]**2 /
                                        np.sqrt(mu_part[s, j]**2 + var_ij))
                        lstdev = np.sqrt(np.log(1.0 + var_ij /
                                                (mu_part[s, j]**2)))
                        
                        sto_lr = np.random.lognormal(lmean, lstdev)
                        paid[i, j + 1] = e_values[i] * sto_lr + paid[i, j]
                        if j == mm - i - 1:
                            new_tri[i, j + 1] = e_values[i] * sto_lr + paid[i, j]
                            LR_i_j_stoch[i, j + 1] = sto_lr
                        if i == mm - j - 1 and (j < (mm)):
                            if dev_con - 2 * std_con <= sto_lr <= dev_con + 2 * std_con:
                                wagi_modified_lr[i , j + 1] = 1
                            elif (dev_con - 3 * std_con <= sto_lr <= dev_con - 2 * std_con) or (
                                    dev_con + 2 * std_con <= sto_lr <= dev_con + 3 * std_con):
                                wagi_modified_lr[i, j + 1] = 0.5
                            else:
                                wagi_modified_lr[i , j + 1] = 0

                    else:
                        adj_mu = (mu_part[s, j] +
                                  paid[i, j] / e_values[i])
                        lmean  = np.log(adj_mu**2 /
                                        np.sqrt(adj_mu**2 + var_ij))
                        lstdev = np.sqrt(np.log(1.0 + var_ij / (adj_mu**2)))
                        
                        sto_lr = np.random.lognormal(lmean, lstdev)
                        paid[i, j + 1] = (e_values[i] *
                                          (sto_lr - paid[i, j] / e_values[i]) +
                                          paid[i, j])
                        if j == mm - i - 1:
                            new_tri[i, j + 1] = (e_values[i] *
                                          (sto_lr - paid[i, j] / e_values[i]) +
                                          paid[i, j])
                            LR_i_j_stoch[i, j + 1] = sto_lr
                        if i == mm - j - 1 and (j < (mm)):
                            if dev_con - 2 * std_con <= sto_lr <= dev_con + 2 * std_con:
                                wagi_modified_lr[i , j + 1] = 1
                            elif (dev_con - 3 * std_con <= sto_lr <= dev_con - 2 * std_con) or (
                                    dev_con + 2 * std_con <= sto_lr <= dev_con + 3 * std_con):
                                wagi_modified_lr[i, j + 1] = 0.5
                            else:
                                wagi_modified_lr[i , j + 1] = 0
 
         #   pd.DataFrame(wagi_modified_lr).to_excel("wagi_modified_lr.xlsx")

            new_tri[1:,new_tri.shape[1]-1] = np.nan
            LR_i_j_stoch = transform_data(new_tri, e_values)
            LR_j_wyzn = wspolczynnik_LR(LR_i_j_stoch, wagi_modified_lr, e_values)
            sigma_j_pred = sigma_LR(LR_i_j_stoch, wagi_modified_lr, e_values, LR_j_wyzn)

          #  pd.DataFrame(new_tri).to_excel("new_tri.xlsx")
            sd_j = wspolczynnik_sd(sigma_j_pred, wagi_modified_lr, e_values)
            vector_value, x_k_ind = choose_value_list(LR_j_wyzn, ilosc_dop_wsp_CL, 0, 10)
            sd_input = sd_j[x_k_ind]
            x_k_ind = x_k_ind
            a, b = fit_curve_factor_lr(vector_value, sd_input, x_k_ind)
            total_f_len = len(LR_j_wyzn) + il_ogon + 1
            vec_f = np.empty(total_f_len - 2)
            vec_f[:(Poz_LR - 2)] = LR_j_wyzn[2:(Poz_LR)]
            tail_factors = wspolczynnik_reg_factor_cl(
                float(a), float(b),
                Poz_LR,
                total_f_len - 1,
            )
            vec_f[(Poz_LR - 2):] = tail_factors[:(total_f_len - 2)]
            
            tri_proj_tmp = triangle_forward_loss_ratio_numba(new_tri[:,1:],vec_f,e_values,len(vec_f))
            cols_tmp = tri_proj_tmp.shape[1]
            tri_proj = np.empty((mm, cols_tmp + 1))
            tri_proj[:, 0] = data_paid[:, 0]

            for r in range(mm):
                for c in range(cols_tmp):
                    tri_proj[r, c + 1] = tri_proj_tmp[r, c]
            inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
            inc_disc = np.empty_like(tri_proj)
            inc_disc[:, 0] = tri_proj[:, 0]
            for r in range(mm):
                for c in range(1, tri_proj.shape[1]):
                    inc_disc[r, c] = inc_proj[r, c - 1]

            for rr in range(mm - 1, -1, -1):
                offset = mm - 1 - rr
                for cc in range(offset + 1, tri_proj.shape[1]):
                    idx = cc - (offset + 1)
                    if idx < len(discount_factors):
                        inc_disc[rr, cc] /= discount_factors[idx]

            cum_disc = inc_disc.copy()
            for r in range(mm):
                for c in range(1, tri_proj.shape[1]):
                    cum_disc[r, c] += cum_disc[r, c - 1]

            ult_gross = np.sum(paid[:,-1])

            #ult_gross_disc = np.sum(cum_disc[:, n_cols_target - 1])
            #ult_net_disc = latest + (ult_gross_disc - latest) * net_to_gross[

            ult_gross_disc = cum_disc[:, -1]
           # total_disc = np.sum(np.nansum(inc_proj, axis=1))
           # ult_net_disc = latest + (total_disc - latest) * net_to_gross
            ult_gross_disc_sum = np.sum(ult_gross_disc)
            latest = vector_reverse_diagonal(data_paid)
            ult_net_disc = 0
            for iii in range(len(latest)):
                ult_net_disc += latest[iii] + (ult_gross_disc[iii] - latest[iii]) * net_to_gross[iii]

            results[index_el, 0] = ult_gross
            results[index_el, 1] = ult_gross_disc_sum
            results[index_el, 2] = ult_net_disc
            index_el = index_el+1
    return results


@njit()
def simulate_reserving_incurred_batched_numba(
    Lr_inc,
    sigma_inc,
    sd_inc,
    e_values,
    rj,
    varj,
    r_i_j,
    lambda_cor,
    data_paid_np,
    data_inc_np,
    weights_np,
    wykluczenia,
    Poz_LR,
    data_wagi_pi,
    wykluczenia_p_i,
    Poz_LR_p_i,
    dop_ogo_p_i,
    il_ogon,
    discount_factors,
    net_to_gross,
    sim_total=100_000,
    batch_sim=10_000,
    main_seed=202260011,
):
 
    if len(discount_factors) == 0:
        discount_factors = np.ones(len(Lr_inc) + il_ogon + 2)
    if len(net_to_gross) == 0:
        net_to_gross = np.ones(data_paid_np.shape[0])

    latest = vector_reverse_diagonal(data_paid_np)
    mm, n_cols_orig = data_paid_np.shape
    n_dev = len(Lr_inc)

    max_cols = n_dev + il_ogon + 3
    all_incurred_triangles = np.zeros((sim_total, mm, max_cols))
    all_paid_triangles = np.zeros((sim_total, mm, max_cols))
    r_j_sim = np.zeros((sim_total, n_cols_orig))
    r_j_sim_mean = np.zeros(n_cols_orig)
    results = np.zeros((sim_total, 3))

    n_batches = (sim_total + batch_sim - 1) // batch_sim
    idx_out = 0

    for batch_idx in range(n_batches):
        np.random.seed(main_seed + batch_idx)
        start = batch_idx * batch_sim
        end = min(start + batch_sim, sim_total)
        cur_bs = end - start

        mu_part_inc = np.empty((cur_bs, n_dev))
        sigma_part_inc = np.empty((cur_bs, n_dev))
        normal_shocks = np.random.normal(loc=0.0, scale=1.0, size=(cur_bs, mm, n_dev))

        for jj in range(n_dev):
            mu_part_inc[:, jj] = np.random.normal(loc=Lr_inc[jj], scale=sd_inc[jj], size=cur_bs)
            df = max(1, mm - jj - 2)
            chi = np.random.chisquare(df, size=cur_bs)
            for s in range(cur_bs):
                sigma_part_inc[s, jj] = (chi[s] * sigma_inc[jj]) / df

        for s in range(cur_bs):
            empty_row = np.full((1, weights_np.shape[1]), np.nan)
            wagi_modified_row = np.vstack((weights_np, empty_row))
            empty_column = np.full((wagi_modified_row.shape[0], 1), np.nan)
            wagi_modified = np.hstack((wagi_modified_row, empty_column))

            empty_column_pi = np.full((data_wagi_pi.shape[0], 1), np.nan)
            data_wagi_pi_modified = np.hstack((data_wagi_pi, empty_column_pi))

            m_i_inc = mu_part_inc[s, :]
            sigma_i_inc = sigma_part_inc[s, :]

            n_cols_target = n_dev + 1
            data_paid_copy = _build_base_triangle(data_paid_np, n_dev)
            data_incurred_copy = _build_base_triangle(data_inc_np, n_dev)
            data_incurred_to_paid_copy = _build_base_triangle(data_paid_np, n_dev)

            data_paid_to_one = np.concatenate((data_paid_np.copy(), np.zeros((mm, 1))), axis=1)
            data_incurred_to_one = np.concatenate((data_inc_np.copy(), np.zeros((mm, 1))), axis=1)

            LR_i_j_stoch = transform_data(data_incurred_to_one, e_values)
            empty_column_lr = np.full((LR_i_j_stoch.shape[0], 1), np.nan)
            LR_i_j_stoch = np.hstack((LR_i_j_stoch, empty_column_lr))

            for j in range(n_dev):
                max_row = max(0, mm - j-1)
                for r in range(max_row, mm):
                    base_inc = data_incurred_copy[r, j]
                    base_paid = data_incurred_to_paid_copy[r, j]

                    if e_values[r] <= 0.0:
                        continue

                    var_ij_inc = sigma_i_inc[j] / e_values[r]
                    dev_con = Lr_inc[j]
                    std_con = sd_inc[j]

                    if m_i_inc[j] > 0.0:
                        lmean = np.log(m_i_inc[j] * m_i_inc[j] / np.sqrt(m_i_inc[j] * m_i_inc[j] + var_ij_inc))
                        lstdev = np.sqrt(np.log(1.0 + var_ij_inc / (m_i_inc[j] * m_i_inc[j])))
                        sto_lr = np.random.lognormal(lmean, lstdev)
                        next_inc = base_inc + e_values[r] * sto_lr
                    else:
                        adj_mu = m_i_inc[j] + base_inc / e_values[r]
                        lmean = np.log(adj_mu * adj_mu / np.sqrt(adj_mu * adj_mu + var_ij_inc))
                        lstdev = np.sqrt(np.log(1.0 + var_ij_inc / (adj_mu * adj_mu)))
                        sto_lr = np.random.lognormal(lmean, lstdev)
                        next_inc = e_values[r] * (sto_lr - base_inc / e_values[r]) + base_inc

                    data_incurred_copy[r, j + 1] = next_inc

                    if varj[j] > 0.0:
                        res_before = ((base_paid / base_inc) - rj[j]) / np.sqrt(varj[j] / base_inc)
                    else:
                        res_before = 0.0

                    r_ij_sim = (
                        rj[j + 1]
                        + np.sqrt(varj[j + 1] / next_inc) *
                        (normal_shocks[s, r, j] + res_before * lambda_cor[0])
                        )
                    next_paid = next_inc * r_ij_sim


                    data_incurred_to_paid_copy[r, j + 1] = next_paid

                    if r == mm - j - 1:
                        data_incurred_to_one[r, j + 1] = next_inc
                        data_paid_to_one[r, j + 1] = next_paid
                        data_paid_copy[r, j + 1] = next_paid
                        LR_i_j_stoch[r, j + 1] = sto_lr

                        if j < mm:
                            if dev_con - 2.0 * std_con <= sto_lr <= dev_con + 2.0 * std_con:
                                wagi_modified[r, j + 1] = 1.0
                                data_wagi_pi_modified[r, j + 1] = 1.0
                            elif (
                                (dev_con - 3.0 * std_con <= sto_lr < dev_con - 2.0 * std_con)
                                or
                                (dev_con + 2.0 * std_con < sto_lr <= dev_con + 3.0 * std_con)
                            ):
                                wagi_modified[r, j + 1] = 0.5
                                data_wagi_pi_modified[r, j + 1] = 0.5
                            else:
                                wagi_modified[r, j + 1] = 0.0
                                data_wagi_pi_modified[r, j + 1] = 0.0

            data_incurred_to_one[1:, n_cols_orig] = np.nan
            data_paid_to_one[1:, n_cols_orig] = np.nan

            LR_j_wyzn = wspolczynnik_LR(LR_i_j_stoch, wagi_modified, e_values)
            sigma_j_pred = sigma_LR(LR_i_j_stoch, wagi_modified, e_values, LR_j_wyzn)
            sd_j = wspolczynnik_sd(sigma_j_pred, wagi_modified, e_values)
            vector_value, x_k_ind = choose_value_list(LR_j_wyzn, wykluczenia, 0.0, 10.0)
            sd_input = sd_j[x_k_ind]
            a_coef, b_coef = fit_curve_factor_lr(vector_value, sd_input, x_k_ind)

            total_f_len = len(LR_j_wyzn) + il_ogon + 1
            vec_f = np.empty(total_f_len - 2)
            vec_f[:(Poz_LR - 2)] = LR_j_wyzn[2:(Poz_LR)]
            tail_factors = wspolczynnik_reg_factor_cl(
                float(a_coef), float(b_coef),
                Poz_LR,
                total_f_len - 1,
            )
            vec_f[(Poz_LR - 2):] = tail_factors[:(total_f_len - 2)]

            incurred_one_new = data_incurred_to_one[:, 1:(n_cols_orig + 1)]
            tri_proj_tmp = triangle_forward_loss_ratio_numba(incurred_one_new, vec_f, e_values, len(vec_f))
            actual_cols = tri_proj_tmp.shape[1]
            all_incurred_triangles[idx_out, :, :actual_cols] = tri_proj_tmp

            mm_loc, nn_loc = incurred_one_new.shape
            print(pd.DataFrame(data_wagi_pi_modified))
            for jjj in range(nn_loc):
                licznik = 0.0
                mianownik = 0.0
                for iii in range(mm_loc):
                    if data_wagi_pi_modified[iii, jjj] != 0.0 and not np.isnan(data_wagi_pi_modified[iii, jjj]):
                        licznik += data_wagi_pi_modified[iii, jjj] * data_paid_to_one[iii, jjj]
                        mianownik += data_wagi_pi_modified[iii, jjj] * data_incurred_to_one[iii, jjj]
                if mianownik == 0.0:
                    r_j_sim[idx_out, jjj] = 1.0
                else:
                    r_j_sim[idx_out, jjj] = licznik / mianownik
            print(r_j_sim)
            results[idx_out, 0] = np.sum(data_incurred_to_paid_copy[:, n_cols_target - 1])
            all_paid_triangles[idx_out, :, :data_paid_copy.shape[1]] = data_paid_copy

            idx_out += 1

    for i in range(n_cols_orig):
        suma = 0.0
        for j in range(sim_total):
            suma += r_j_sim[j, i]
        r_j_sim_mean[i] = suma / sim_total

    rj_choose, ind_choose = choose_value_list(r_j_sim_mean, wykluczenia_p_i, 0.0, 1.0)
    a_num, b_num = fit_curve_factor_P_to_I(rj_choose, ind_choose + 1)

    total_f_len = n_cols_orig + il_ogon
    if Poz_LR_p_i - 1 > 0:
        vec_p_i = np.empty(total_f_len - 1)
        vec_p_i[:(Poz_LR_p_i - 2)] = r_j_sim_mean[2:Poz_LR_p_i]
        if dop_ogo_p_i:
            vec_p_i[(Poz_LR_p_i - 2):] = 1.0
        else:
            vec_p_i[(Poz_LR_p_i - 2):] = 1.0
    else:
        vec_p_i = wspolczynnik_reg_factor_P_to_I(float(a_num), float(b_num), 2, total_f_len)

    for sim_idx in range(sim_total):
        trian_sim = all_incurred_triangles[sim_idx, :, :]
        trian_sim_paid_one = all_paid_triangles[sim_idx, :, 1:]

        max_j_col = min(trian_sim_paid_one.shape[1], vec_p_i.shape[0], trian_sim.shape[1])
        for j_col in range(1, max_j_col):
            max_ind_row = max(0, trian_sim_paid_one.shape[0] - j_col)
            for i in range(max_ind_row, trian_sim.shape[0]):
                trian_sim_paid_one[i, j_col] = trian_sim[i, j_col] * vec_p_i[j_col]

        cols_tmp = max_j_col - 1
        if cols_tmp < 1:
            cols_tmp = 1

        tri_proj = np.empty((mm, cols_tmp + 1))
        tri_proj[:, 0] = data_paid_np[:, 0]
        for r in range(mm):
            for c in range(min(cols_tmp, trian_sim_paid_one.shape[1])):
                tri_proj[r, c + 1] = trian_sim_paid_one[r, c]

        inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
        inc_disc = np.empty_like(tri_proj)
        inc_disc[:, 0] = tri_proj[:, 0]
        for r in range(mm):
            for c in range(1, tri_proj.shape[1]):
                inc_disc[r, c] = inc_proj[r, c - 1]

        for rr in range(mm - 1, -1, -1):
            offset = mm - 1 - rr
            for cc in range(offset + 1, tri_proj.shape[1]):
                idx = cc - (offset + 1)
                if idx < len(discount_factors):
                    inc_disc[rr, cc] /= discount_factors[idx]

        cum_disc = inc_disc.copy()
        for r in range(mm):
            for c in range(1, tri_proj.shape[1]):
                cum_disc[r, c] += cum_disc[r, c - 1]

        ult_gross_disc = np.sum(cum_disc[:, -1])
        cum_disc_last = cum_disc[:, -1]
        ult_net_disc = 0.0
        for i_net in range(len(latest)):
            ult_net_disc += cum_disc_last[i_net] * net_to_gross[i_net]

        results[sim_idx, 1] = ult_gross_disc
        results[sim_idx, 2] = ult_net_disc

    return results





# ---------------------------------------------------------------------------
# Excel helper (poza numba)
# ---------------------------------------------------------------------------

def pobierz_wartosci_z_excela(
    plik: str,
    arkusz: str,
    row_start: int,
    row_end: int,
    linia_biznesowa: str,
    wartosci: list,
) -> dict:
    try:
        df = pd.read_excel(plik, sheet_name=arkusz, header=None)

        # ignorujemy pierwszą kolumnę (A)
        df = df.iloc[:, 1:]

        # nagłówki z wiersza powyżej
        naglowki = df.iloc[row_start - 1]
        blok = df.iloc[row_start:row_end].copy()
        blok.columns = naglowki
        blok.reset_index(drop=True, inplace=True)

        param_col = blok.columns[0]

        wynik = {}
        for parametr in wartosci:
            try:
                wartosc = blok.loc[blok[param_col] == parametr, linia_biznesowa].values[0]
                wynik[parametr] = wartosc
            except IndexError:
                wynik[parametr] = None
        return wynik

    except Exception as e:
        raise RuntimeError(f"Błąd przy pobieraniu danych: {e}")


# ---------------------------------------------------------------------------
# Wrapper class (jak u Ciebie: API + wywołania numba)
# ---------------------------------------------------------------------------

class YearHorizontLR2:
    def vector_reverse_diagonal_to_script(self, data: np.ndarray) -> np.ndarray:
        return vector_reverse_diagonal(data)

    def sum_reverse_diagonal_to_script(self, data: np.ndarray) -> float:
        return sum_reverse_diagonal(data)

    def run_simulation_lr(
        self,
        data_paid: np.ndarray,
        sigma_j_LR: np.ndarray,
        dev_LR: np.ndarray,
        sd_LR: np.ndarray,
        e_values: np.ndarray,
        wagi_trimmed: np.ndarray,
        ilosc_dop_wsp_CL: np.ndarray,
        Poz_LR: int,
        il_ogon: int,
        ultimate_param_resrisk: np.ndarray,
        discount_factors: np.ndarray,
        net_to_gross: np.ndarray,
        sim_total: int = 100_000,
        batch_sim: int = 10_000,
        main_seed: int = 202260011,
    ) -> np.ndarray:
        # latest wyliczany w środku numba; tu zostawiamy styl jak u Ciebie (wrapper)
        return simulate_reserving_batched_numba(
            data_paid,
            sigma_j_LR,
            dev_LR,
            sd_LR,
            e_values,
            wagi_trimmed,
            ilosc_dop_wsp_CL,
            Poz_LR,
            il_ogon,
            ultimate_param_resrisk,
            discount_factors,
            net_to_gross,
            sim_total,
            batch_sim,
            main_seed,
        )

    def run_simulation_lr_incurred(
        self,
        Lr_inc: np.ndarray,
        sigma_inc: np.ndarray,
        sd_inc: np.ndarray,
        e_values: np.ndarray,
        rj: np.ndarray,
        varj: np.ndarray,
        r_i_j: np.ndarray,
        lambda_cor: np.ndarray,
        data_paid_np: np.ndarray,
        data_inc_np: np.ndarray,
        weights_np: np.ndarray,
        wykluczenia: np.ndarray,
        Poz_LR: int,
        data_wagi_pi: np.ndarray,
        wykluczenia_p_i: np.ndarray,
        Poz_LR_p_i: int,
        dop_ogo_p_i: bool,
        il_ogon: int,
        discount_factors: np.ndarray,
        net_to_gross: np.ndarray,
        sim_total: int = 100_000,
        batch_sim: int = 10_000,
        main_seed: int = 202260011,
    ) -> np.ndarray:
        return simulate_reserving_incurred_batched_numba(
            Lr_inc,
            sigma_inc,
            sd_inc,
            e_values,
            rj,
            varj,
            r_i_j,
            lambda_cor,
            data_paid_np,
            data_inc_np,
            weights_np,
            wykluczenia,
            Poz_LR,
            data_wagi_pi,
            wykluczenia_p_i,
            Poz_LR_p_i,
            dop_ogo_p_i,
            il_ogon,
            discount_factors,
            net_to_gross,
            sim_total,
            batch_sim,
            main_seed,
        )

    def triangle_forward_lr_np_disc(
        self,
        tri_in: np.ndarray,
        LR_j: np.ndarray,
        exposure: np.ndarray,
        discount_factors: np.ndarray,
        net_to_gross: np.ndarray,
        k_forward: int,
    ) -> dict:
 
        tri_in = tri_in.copy()
        mm, n_cols_orig = tri_in.shape
        n_cols_out = max(n_cols_orig, len(LR_j) + 1)

        latest = self.vector_reverse_diagonal_to_script(tri_in)
        base_col = tri_in[:, 0].copy()

        tri = np.full((mm, n_cols_out), np.nan, dtype=np.float64)
        tri[:, :n_cols_orig] = tri_in

        # forward (Twoja logika additive: base + exposure * LR_j)
        for j in range(k_forward):
            max_ind_row = 1 if (mm - j) < 1 else (mm - j)
            start_row = max_ind_row - 1
            for i in range(start_row, mm):
                base_val = tri[i, j]
                tri[i, j + 1] = base_val + exposure[i] * LR_j[j]

        cols_tmp = tri.shape[1]
        last_col = tri[:, -1].copy()

        tri_proj = np.full((mm, cols_tmp + 1), np.nan)
        tri_proj[:, 0] = base_col
        tri_proj[:, 1:] = tri

        inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
        inc_proj[:, 0] = base_col

        # ---- discount_factors: identycznie jak w triangle_forward_np
        if discount_factors is None or len(discount_factors) == 0:
            discount_factors = np.ones(cols_tmp, dtype=float)
        else:
            discount_factors = np.asarray(discount_factors, dtype=float)

        for rr in range(mm - 1, -1, -1):
            offset = mm - 1 - rr
            for cc in range(offset + 1, inc_proj.shape[1]):
                idx = cc - (offset + 1)
                if idx < len(discount_factors) and not np.isnan(inc_proj[rr, cc]):
                    inc_proj[rr, cc] /= discount_factors[idx]

        # ---- cum_trian: wektor, identycznie jak w triangle_forward_np
        cum_trian = np.nansum(inc_proj, axis=1)

        # ---- net_to_gross: identycznie jak w triangle_forward_np
        if net_to_gross is None or len(net_to_gross) == 0:
            net_to_gross = np.ones_like(latest, dtype=float)
        else:
            net_to_gross = np.asarray(net_to_gross, dtype=float)
            if len(net_to_gross) < len(latest):
                net_to_gross = np.pad(
                    net_to_gross,
                    (0, len(latest) - len(net_to_gross)),
                    constant_values=1.0,
                )
            elif len(net_to_gross) > len(latest):
                net_to_gross = net_to_gross[:len(latest)]
        net_to_gross = net_to_gross[::-1]

        ult_net_disc_vec = [
            latest[i] + (cum_trian[i] - latest[i]) * net_to_gross[i]
            for i in range(len(latest))
        ]

        return {
            "last_col": last_col,
            "cum_trian": cum_trian,
            "ult_net_disc": ult_net_disc_vec,
        }
