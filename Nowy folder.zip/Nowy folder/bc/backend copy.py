from fastapi import FastAPI, File, UploadFile, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Union
from openpyxl import load_workbook
from io import BytesIO
import pandas as pd
import numpy as np
import asyncio
from calculation_method import TriangleCalculator
import time


print("main.py")
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # frontend origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.post("/upload")
async def create_upload_files(file: UploadFile):
    print(file.filename)
    content = await file.read()

    # Wczytaj plik Excela z pamięci
    wb = load_workbook(filename=BytesIO(content))
    ws = wb.active  # pierwszy arkusz

    if ws:
        for row in ws.iter_rows(values_only=True):
            for cell in row:
                if cell:
                    print(cell, end=" ")
            print("")

    return {
        "filename": file.filename,
        "size": len(content),
    }

@app.post("/calc/cl")
async def calc_cl(
    data: List[List[Union[str, int, float, None]]],
    selected: List[List[int]],
):
    print("selected")
    print(pd.DataFrame(selected))
    df = pd.DataFrame(data).iloc[1:, 1:]
    df = df.apply(pd.to_numeric, errors="coerce")

    tri = TriangleCalculator.full_ci_calculation(df)[0]

    safe_tri = tri.replace([np.inf, -np.inf], np.nan).astype(object).where(pd.notnull(tri), None)

    # Buduj macierz tylko do ostatniej wartości w każdym wierszu
    matrix = [[tri.columns.name or "AY"] + list(tri.columns)]
    for idx in tri.index:
        values = list(safe_tri.loc[idx])
        while values and values[-1] is None:
            values.pop()
        row = [idx] + values
        matrix.append(row)

    return {
        "data": matrix
    }

from pydantic import BaseModel
from typing import List, Union

class MatrixRequest(BaseModel):
    user_id: str
    paid_data: List[List[Union[str, int, float, None]]]
    paid_weights: List[List[int]]
    cl_data: List[List[Union[str, int, float, None]]]
    cl_weights: List[List[int]]
    triangle_raw: List[List[Union[str, int, float, None]]]  # ← dane z 1. Trójkąta
    cl_weights_raw: List[List[int]]                          # ← dane z 2. Współczynniki CL

@app.post("/calc/full")
async def calc_full(payload: MatrixRequest):
    # usuń nagłówki i indeksy, konwertuj na float
    df_triangle_raw = pd.DataFrame(payload.triangle_raw).iloc[1:, 1:].astype(float)
    df_cl_weights_raw = pd.DataFrame(payload.cl_weights_raw).astype(float)
    df_cl_data = df_triangle_raw.copy()


    df_np = np.array(df_triangle_raw.values, dtype=float)
    print("df_np")
    print(df_np)
    df_wagi_np = np.array(df_cl_weights_raw.values, dtype=float)
    combined_mask = (~np.isnan(df_np)) & (df_wagi_np == 1)
    mask_np = ~np.isnan(df_np)
    tri0_np = TriangleCalculator.to_incr_np(df_np)
    ctri0_np = TriangleCalculator.to_cum_np(tri0_np)
    a2a_np = TriangleCalculator.get_a2a_factors_np(ctri0_np, mask_np)
    ctri_np = TriangleCalculator.fit_triangle_from_latest_np(df_np, mask_np)
    tri_np = TriangleCalculator.to_incr_np(ctri_np)
    r_adj_np, phi_np = TriangleCalculator.full_ci_calculation_np(df_np, mask_np)
    residuals = r_adj_np[(combined_mask) & (r_adj_np != 0) & ~np.isnan(r_adj_np)].flatten()

    start = time.time()

    sim_results_np = TriangleCalculator.run_simulations_numpy(
        tri_np, residuals, mask_np, phi_np, a2a_np, nbr_samples=10000
    )

    print(f"Średnia suma rezerw: {np.mean(sim_results_np):,.2f}")
    end = time.time()
    print(f"Czas wykonania: {end - start:.2f} sekund")



    return {
        "message": "OK",
        "triangle_shape": df_triangle_raw.shape,
        "cl_weights_shape": df_cl_weights_raw.shape,
        "cl_shape": df_cl_data.shape,
        "paid_shape": [len(payload.paid_data), len(payload.paid_data[0])]
    }



@app.websocket("/ws/progress")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    for i in range(1, 11):
        data = {"progress": i}
        await websocket.send_json(data)
        if i < 10:
            await asyncio.sleep(1)
    await websocket.close()
