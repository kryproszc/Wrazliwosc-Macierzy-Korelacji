from Obliczenia_stochastyczne import hybrid_paid_router as stoch_paid_router
from Obliczenia_stochastyczne import hybrid_incurred_router as stoch_incurred_router
from Obliczenia_deterministyczne import paid_router as det_paid_router
from Obliczenia_deterministyczne import incurred_router as det_incurred_router
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import numpy as np
import pandas as pd

# Import routerów z poszczególnych modułów
from Trojkat.inflacja import router as trojkat_router
from Multiplikatywna.wspolczynniki_cl import router as mult_wspolczynniki_router
from Multiplikatywna.dopasowanie_krzywej_cl import router as mult_krzywe_router
from Multiplikatywna.wyniki import router as mult_wyniki_router
from Addytywna.wspolczynniki_add import router as add_router
from Addytywna.dopasowanie_krzywej_add import router as add_krzywe_router
from Addytywna.wyniki_lr import router as add_wyniki_lr_router
from Symulacje.MultiplikatywneStoch import router as symulacje_router
from Symulacje.AddytywnaStoch import router as symulacje_add_router
from Symulacje.MultiplikatywneStoch import (
    simulation_cl_paid as simulation_cl_paid_handler,
    statistic_cl_paid as statistic_cl_paid_handler,
    run_simulation_addcl as run_simulation_addcl_handler,
)
from Symulacje.models import (
    SimulationClPaidRequest,
    StatisticClPaidRequest,
    AllTestDataRequest,
    SimulationClPaidResult,
)
from calculation_method import TriangleCalculator

# Import pozostałych klas, które są jeszcze potrzebne w głównym pliku
from pydantic import BaseModel
from typing import List, Union, Optional, Dict

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3011",
        "http://127.0.0.1:3011",
    ],
    allow_origin_regex=r"^http://[A-Za-z0-9.-]+:3011$",
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "status": "error",
            "error": "validation_error",
            "detail": exc.errors(),
        },
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "status": "error",
            "error": "http_error",
            "detail": exc.detail,
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "error": "internal_server_error",
            "detail": str(exc),
        },
    )


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "service": "triangle-fastapi",
    }

# Dodanie routerów
app.include_router(trojkat_router, tags=["Trójkąt"])
app.include_router(mult_wspolczynniki_router, tags=["Multiplikatywna - Współczynniki CL"])
app.include_router(mult_krzywe_router, tags=["Multiplikatywna - Dopasowanie krzywej CL"])
app.include_router(mult_wyniki_router, tags=["Multiplikatywna - Wyniki"])
app.include_router(add_router, tags=["Addytywna - Współczynniki"])
app.include_router(add_krzywe_router, tags=["Addytywna - Dopasowanie krzywej LR"])
app.include_router(add_wyniki_lr_router, tags=["Addytywna - Wyniki LR"])
app.include_router(symulacje_router, tags=["Symulacje"])
app.include_router(symulacje_add_router, tags=["Symulacje - Addytywna"])

# Dodanie routera dla deterministycznych obliczeń paid
app.include_router(det_paid_router, tags=["Obliczenia deterministyczne - Paid"])
app.include_router(det_incurred_router, tags=["Obliczenia deterministyczne - Incurred"])
app.include_router(stoch_paid_router, tags=["Obliczenia stochastyczne - Hybrid Paid"])
app.include_router(stoch_incurred_router, tags=["Obliczenia stochastyczne - Incurred"])

# Klasy, które jeszcze nie zostały przeniesione do odpowiednich modułów
class MatrixRequest(BaseModel):
    user_id: str
    paid_data: List[List[Union[str, int, float, None]]]
    paid_weights: List[List[int]]
    cl_data: List[List[Union[str, int, float, None]]]
    cl_weights: List[List[int]]
    triangle_raw: List[List[Union[str, int, float, None]]]
    cl_weights_raw: List[List[int]]
    wagi_mult: Optional[List[List[int]]] = None
    quantiles: Optional[List[float]] = None
    nbr_samples: Optional[int] = 1000


class QuantileRequest(BaseModel):
    user_id: str
    request_id: str
    quantiles: List[float]


class WspolczynnikiMultiplikatywnaStochastycznaRequest(BaseModel):
    user_id: str
    dev: List[float]
    sd: List[float]
    sigma: List[float]
    triangle: List[List[Union[str, int, float, None]]]
    sim_total: Optional[int] = 1000
    batch_sim: Optional[int] = 1000
    main_seed: Optional[int] = 202260011
    ultimate_param_resrisk: Optional[int] = 0


class SaveVectorRequest(BaseModel):
    curve_name: Optional[str] = None
    coeffs: Optional[List[float]] = None
    volume: Optional[int] = None
    values: Optional[List[float]] = None
    final_dev_vector: Optional[List[float]] = None


class SaveVectorPayload(BaseModel):
    paid_data_det: List[List[Optional[float]]]
    coeff_sets: List[SaveVectorRequest]


class SelectedDevJRequest(BaseModel):
    user_id: Optional[str] = None
    selected_dev_j: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_dev_j: List[float]


class SelectedSigmaRequest(BaseModel):
    user_id: Optional[str] = None
    selected_sigma: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma: List[float]


class QuantilesCompatRequest(BaseModel):
    user_id: str
    quantiles: List[float]
    request_id: Optional[str] = None


class PercentileCompatRequest(BaseModel):
    user_id: str
    percentile: float


def _build_stats_from_simulation_data(data: np.ndarray, quantiles: List[float]) -> List[Dict[str, Union[str, float, List[float]]]]:
    stats = []
    column_names = ["Brutto", "Brutto One dyskontowany", "Netto One dyskontowany"]

    for i in range(data.shape[1]):
        col = data[:, i]
        if np.isnan(col).any():
            continue
        mean = np.mean(col)
        std = np.std(col)
        qvals = np.quantile(col, quantiles)
        stats.append({
            "column": column_names[i] if i < len(column_names) else f"Kolumna {i}",
            "mean": float(mean),
            "quantiles": [float(q) for q in qvals],
            "std": float(std),
            "SCR": float(np.quantile(col, 0.995)) - float(mean),
        })

    return stats


@app.post("/calc/full")
async def calc_full(payload: MatrixRequest):
    try:
        df_triangle_raw = pd.DataFrame(payload.triangle_raw).iloc[1:, 1:].astype(float)
        df_cl_weights_raw = pd.DataFrame(payload.cl_weights_raw).astype(float)
        df_cl_data = df_triangle_raw.copy()

        df_np = np.array(df_triangle_raw.values, dtype=float)
        df_wagi_np = np.array(df_cl_weights_raw.values, dtype=float)

        combined_mask = (~np.isnan(df_np)) & (df_wagi_np == 1)
        mask_np = ~np.isnan(df_np)
        tri0_np = TriangleCalculator.to_incr_np(df_np)
        ctri0_np = TriangleCalculator.to_cum_np(tri0_np)
        a2a_np = TriangleCalculator.get_a2a_factors_np(ctri0_np, mask_np)
        ctri_np = TriangleCalculator.fit_triangle_from_latest_np(df_np, mask_np)
        tri_np = TriangleCalculator.to_incr_np(ctri_np)
        r_adj_np, phi_np = TriangleCalculator.full_ci_calculation_np(df_np, mask_np)
        residuals = r_adj_np[(combined_mask) & (r_adj_np != 0) & ~np.isnan(r_adj_np)].flatten()

        TriangleCalculator.run_simulations_numpy(
            tri_np,
            residuals,
            mask_np,
            phi_np,
            a2a_np,
            nbr_samples=10000,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Invalid payload for /calc/full: {exc}")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Calculation failed in /calc/full: {exc}")

    return {
        "status": "ok",
        "message": "Calculation finished",
        "triangle_shape": df_triangle_raw.shape,
        "cl_weights_shape": df_cl_weights_raw.shape,
        "cl_shape": df_cl_data.shape,
        "paid_shape": [len(payload.paid_data), len(payload.paid_data[0])],
    }


@app.post("/calc/quantiles")
async def calc_quantiles(payload: QuantilesCompatRequest):
    result_obj = SimulationClPaidResult.get_for_user(payload.user_id)
    if result_obj is None or result_obj.data is None:
        raise HTTPException(status_code=404, detail="No simulation results found for provided user_id")

    stats = _build_stats_from_simulation_data(result_obj.data, payload.quantiles)
    return {
        "status": "ok",
        "user_id": payload.user_id,
        "stats": stats,
    }


@app.post("/calc/percentile")
async def calc_percentile(payload: PercentileCompatRequest):
    result_obj = SimulationClPaidResult.get_for_user(payload.user_id)
    if result_obj is None or result_obj.data is None:
        raise HTTPException(status_code=404, detail="No simulation results found for provided user_id")

    percentile = payload.percentile
    if percentile > 1.0:
        percentile = percentile / 100.0
    if percentile < 0.0 or percentile > 1.0:
        raise HTTPException(status_code=422, detail="percentile must be in [0,1] or [0,100]")

    stats = _build_stats_from_simulation_data(result_obj.data, [percentile])
    return {
        "status": "ok",
        "user_id": payload.user_id,
        "percentile": percentile,
        "stats": stats,
    }


@app.post("/calc/obliczenia_stoch_multiplikatywna")
async def calc_obliczenia_stoch_multiplikatywna(request: Request):
    payload = await request.json()
    validated = SimulationClPaidRequest.model_validate(payload)
    return await simulation_cl_paid_handler(validated)


@app.post("/calc/quantiles_stoch")
async def calc_quantiles_stoch(request: Request):
    payload = await request.json()
    validated = StatisticClPaidRequest.model_validate(payload)
    return await statistic_cl_paid_handler(validated)


@app.post("/calc/percentile_stoch")
async def calc_percentile_stoch(request: Request):
    payload = await request.json()
    percentile = payload.get("percentile")

    if percentile is None and payload.get("kwantyle"):
        return await statistic_cl_paid_handler(StatisticClPaidRequest.model_validate(payload))

    if percentile is None:
        raise HTTPException(status_code=422, detail="Provide 'percentile' or 'kwantyle' in request body")

    if percentile > 1.0:
        percentile = percentile / 100.0

    payload_copy = dict(payload)
    payload_copy["kwantyle"] = [percentile]
    validated = StatisticClPaidRequest.model_validate(payload_copy)
    return await statistic_cl_paid_handler(validated)


@app.post("/calc/obliczenia_boot_multiplikatywna")
async def calc_obliczenia_boot_multiplikatywna(request: Request):
    payload = await request.json()
    validated = AllTestDataRequest.model_validate(payload)
    return await run_simulation_addcl_handler(validated)
