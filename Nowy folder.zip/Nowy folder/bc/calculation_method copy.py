import pandas as pd
import numpy as np
from numpy.random import gamma


class TriangleCalculator:
    @staticmethod
    def to_cum(tri: pd.DataFrame) -> pd.DataFrame:
        return tri.cumsum(axis=1)

    @staticmethod
    def to_incr(tri: pd.DataFrame) -> pd.DataFrame:
        tri_incr = tri.diff(axis=1)
        tri_incr.iloc[:, 0] = tri.iloc[:, 0]
        return tri_incr

    @staticmethod
    def get_a2a_factors(tri: pd.DataFrame) -> pd.Series:
        all_devps = tri.columns.tolist()
        min_origin, max_origin = tri.index.min(), tri.index.max()
        dps0, dps1 = all_devps[:-1], all_devps[1:]
        a2a_headers = [f"{ii}-{jj}" for ii, jj in zip(dps0, dps1)]
        a2a = []

        for dp1, dp0 in zip(dps1[::-1], dps0[::-1]):
            vals1 = tri.loc[min_origin:(max_origin - dp0), dp1].sum()
            vals0 = tri.loc[min_origin:(max_origin - dp0), dp0].sum()
            a2a.append((vals1 / vals0).item())

        return pd.Series(data=a2a[::-1], index=a2a_headers)

    @staticmethod
    def get_a2u_factors(a2a: pd.Series) -> pd.Series:
        return pd.Series(np.cumprod(a2a[::-1])[::-1], index=a2a.index, name="A2U")

    @staticmethod
    def fit_triangle_from_latest(ctri0: pd.DataFrame, a2a: pd.Series) -> pd.DataFrame:
        nbr_devps = ctri0.shape[1]
        ctri = pd.DataFrame(columns=ctri0.columns, index=ctri0.index, dtype=float)

        for idx, origin in enumerate(ctri0.index):
            latest_devp = nbr_devps - idx
            if latest_devp <= 0 or latest_devp > nbr_devps:
                continue

            ctri.at[origin, latest_devp] = ctri0.at[origin, latest_devp]

            for devp in range(latest_devp - 1, 0, -1):
                ctri.at[origin, devp] = float(ctri.at[origin, devp + 1]) / float(a2a.iloc[devp - 1])

        return ctri

    @staticmethod
    def full_ci_calculation(df: pd.DataFrame) -> pd.DataFrame:

        a2a = TriangleCalculator.get_a2a_factors(df)
       # a2u = TriangleCalculator.get_a2u_factors(a2a)
        ctri = TriangleCalculator.fit_triangle_from_latest(df, a2a)

        tri0 = TriangleCalculator.to_incr(df)
        tri = TriangleCalculator.to_incr(ctri)

        r_us = (tri0 - tri) / tri.abs().map(np.sqrt)

        n = tri0.count().sum().item()
        p = tri0.index.shape[0] + tri0.columns.shape[0] - 1
        DF = n - p

        phi = ((r_us ** 2).sum().sum() / DF).item()
        r_adj = np.sqrt(n / DF) * r_us

        return [r_adj,phi]



    def square_tri(tri: pd.DataFrame, a2a: pd.Series) -> pd.DataFrame:
       
        nbr_devps = tri.shape[1]
        for r_idx in range(1, nbr_devps):
            for c_idx in range(nbr_devps - r_idx, nbr_devps):
                tri.iat[r_idx, c_idx] = tri.iat[r_idx, c_idx - 1]  * a2a.iat[c_idx - 1]
        return tri
    


    def sample_with_process_variance(ctri_ii_sqrd, phi, rng=None):
        nbr_devps = ctri_ii_sqrd.shape[0]
        tri_ii_sqrd = ctri_ii_sqrd.copy()
        if rng is None:
            rng = np.random.default_rng(seed=516)
        for r_idx in range(1, nbr_devps):
            for c_idx in range(nbr_devps - r_idx, nbr_devps):
                m = np.abs(tri_ii_sqrd.iat[r_idx, c_idx].item())
                v = m * phi

                shape = m**2 / v if v != 0 else 1.0
                scale = v / m if m != 0 else 1.0

                tri_ii_sqrd.iat[r_idx, c_idx] = rng.gamma(shape=shape, scale=scale, size=1).item()

        return tri_ii_sqrd
