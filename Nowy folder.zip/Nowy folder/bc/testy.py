from calculation_method import TriangleCalculator
import pandas as pd
import numpy as np
import time

data = {
    1: [5012, 106, 3410, 5655, 1092, 1513, 557, 1351, 3133, 2063],
    2: [8269, 4285, 8992, 11555, 9565, 6445, 4020, 6947, 5395, None],
    3: [10907, 5396, 13873, 15766, 15836, 11702, 10946, 13112, None, None],
    4: [11805, 10666, 16141, 21266, 22169, 12935, 12314, None, None, None],
    5: [13539, 13782, 18735, 23425, 25955, 15852, None, None, None, None],
    6: [16181, 15599, 22214, 26083, 26180, None, None, None, None, None],
    7: [18009, 15496, 22863, 27067, None, None, None, None, None, None],
    8: [18608, 16169, 23466, None, None, None, None, None, None, None],
    9: [18662, 16704, None, None, None, None, None, None, None, None],
    10: [18834, None, None, None, None, None, None, None, None, None]
}
index = [1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990]


df_wagi = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, np.nan, np.nan],
    [1, 1, 1, 1, 1, 1, 1, np.nan, np.nan, np.nan],
    [1, 1, 1, 1, 1, 1, np.nan, np.nan, np.nan, np.nan],
    [1, 1, 1, 1, 1, np.nan, np.nan, np.nan, np.nan, np.nan],
    [1, 1, 1, 1, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [1, 1, 1, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [1, 1, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [1, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
]


import numpy as np

start = time.time()


df_np = np.array(list(data.values()), dtype=float).T  # shape (10, 10)
df_wagi_np = np.array(df_wagi, dtype=float)


combined_mask = (~np.isnan(df_np)) & (df_wagi_np == 1)
mask_np = ~np.isnan(df_np)

tri0_np = TriangleCalculator.to_incr_np(df_np)
ctri0_np = TriangleCalculator.to_cum_np(tri0_np)
a2a_np = TriangleCalculator.get_a2a_factors_np(ctri0_np, combined_mask)
ctri_np = TriangleCalculator.fit_triangle_from_latest_np(df_np, combined_mask)
tri_np = TriangleCalculator.to_incr_np(ctri_np)

r_adj_np, phi_np = TriangleCalculator.full_ci_calculation_np(df_np, combined_mask)

residuals = r_adj_np[(combined_mask) & (r_adj_np != 0) & ~np.isnan(r_adj_np)].flatten()


print("tri_np shape:", tri_np.shape)
print("residuals shape:", residuals.shape)
print("mask_np sum:", np.sum(mask_np))
print("phi_np mean/std:", np.mean(phi_np), np.std(phi_np))
print("a2a_np shape:", a2a_np.shape)


sim_results_np = TriangleCalculator.run_simulations_numpy_nb(
    tri_np, residuals, mask_np, phi_np, a2a_np, nbr_samples=10000
)

print(f"Średnia suma rezerw: {np.mean(sim_results_np):,.2f}")
end = time.time()
print(f"Czas wykonania: {end - start:.2f} sekund")