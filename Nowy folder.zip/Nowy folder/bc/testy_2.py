from calculation_method import TriangleCalculator
import pandas as pd
import numpy as np
import time

data = {
    1: [5012, 106, 3410, 5655, 1092, 1513, 557, 1351, 3133, 2063],
    2: [8269, 4285, 8992, 11555, 9565, 6445, 4020, 6947, 5395, None],
    3: [10907, 5396, 13873, 15766, 15836, 11702, 10946, 13112, None, None],
    4: [11805, 10666, 16141, 21266, 22169, 12935, 12314, None, None, None],
    5: [13539, 13782, 18735, 23425, 25955, 15852, None, None, None, None],
    6: [16181, 15599, 22214, 26083, 26180, None, None, None, None, None],
    7: [18009, 15496, 22863, 27067, None, None, None, None, None, None],
    8: [18608, 16169, 23466, None, None, None, None, None, None, None],
    9: [18662, 16704, None, None, None, None, None, None, None, None],
    10: [18834, None, None, None, None, None, None, None, None, None]
}
index = [1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990]

df_np = np.array(list(data.values()), dtype=float).T  # shape (10, 10)
mask_np = ~np.isnan(df_np)
a2a_np = TriangleCalculator.get_a2a_factors_np(df_np, mask_np)

sigma = list([166.9834704,  33.2945384 , 26.2952997  , 7.8249598,  10.9288176   ,6.3890424,   1.1590623   ,2.8077043   ,0.8033494])
sd = list([1.130203277, 0.135836119, 0.090498216 ,0.025389927, 0.035376679 ,0.022577813 ,0.004881918 ,0.015055851 ,0.005880651])

start = time.time()

results = TriangleCalculator.run_batched_simulation(
    data_paid=df_np,
    sigma_j=sigma,
    dev=a2a_np,
    sd=sd,
    sim_total=10000,
    batch_sim=1000
)


end = time.time()

print(f"\n⏱ Czas wykonania: {end - start:.2f} sekund")

# Wyniki i analiza
results_cale = 1 * (results - 0)
print(f"📊 Median: {np.median(results_cale):,.2f}")
for q in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.995, 0.996, 0.997, 0.998, 0.999]:
    print(f"Quantile {q}: {np.quantile(results_cale, q):,.2f}")
print(f"Mean: {np.mean(results_cale):,.2f}")
print(f"Difference (Quantile - Mean): {np.quantile(results_cale, 0.995) - np.mean(results_cale):,.2f}")

