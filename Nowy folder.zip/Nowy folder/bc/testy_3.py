from calculation_method import TriangleCalculator
import pandas as pd
import numpy as np
import time

data = {
    1: [5012, 106, 3410, 5655, 1092, 1513, 557, 1351, 3133, 2063],
    2: [8269, 4285, 8992, 11555, 9565, 6445, 4020, 6947, 5395, None],
    3: [10907, 5396, 13873, 15766, 15836, 11702, 10946, 13112, None, None],
    4: [11805, 10666, 16141, 21266, 22169, 12935, 12314, None, None, None],
    5: [13539, 13782, 18735, 23425, 25955, 15852, None, None, None, None],
    6: [16181, 15599, 22214, 26083, 26180, None, None, None, None, None],
    7: [18009, 15496, 22863, 27067, None, None, None, None, None, None],
    8: [18608, 16169, 23466, None, None, None, None, None, None, None],
    9: [18662, 16704, None, None, None, None, None, None, None, None],
    10: [18834, None, None, None, None, None, None, None, None, None]
}


wagi = list([
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, None],
    [1, 1, 1, 1, 1, 1, 1, 1, None, None],
    [1, 1, 1, 1, 1, 1, 1, None, None, None],
    [1, 1, 1, 1, 1, 1, None, None, None, None],
    [1, 1, 1, 1, 1, None, None, None, None, None],
    [1, 1, 1, 1, None, None, None, None, None, None],
    [1, 1, 1, 1, None, None, None, None, None, None],
    [1, 1, 1, 1, None, None, None, None, None, None],
    [1, 1, 1, 1, None, None, None, None, None, None]
])

#print(pd.DataFrame(wagi))
#print(pd.DataFrame(data))

#print(pd.DataFrame(TriangleCalculator.elementwise_division(data)))

#print(pd.DataFrame(wagi).iloc[:-1,:])
p_ij = pd.DataFrame(data)
dev_j = TriangleCalculator.Dev_prem(pd.DataFrame(data),pd.DataFrame(wagi).iloc[:-1,:])
l_ij = pd.DataFrame(TriangleCalculator.elementwise_division(data))
w_ij = pd.DataFrame(wagi)


print(dev_j)
print(p_ij)
print(l_ij)
print(w_ij)


def calculate_sigma(p_ij: pd.DataFrame, l_ij: pd.DataFrame, w_ij: pd.DataFrame, dev_j: list[float]) -> list[float]:

    max_col = l_ij.shape[1]
    sigmas = []
    sd = []

    for j in range(0, max_col):  # zaczynamy od j=1, bo potrzebujemy j-1
        numerator = 0.0
        denominator = 0.0
        denominator_sd = 0.0

        for i in range(len(l_ij)):
            try:
                w = w_ij.iloc[i, j]
                p = p_ij.iloc[i, j]
                l = l_ij.iloc[i, j]
                dev = dev_j[j]

                if not np.isnan(w) and not np.isnan(p) and not np.isnan(l):
                    numerator += w * p * (l - dev) ** 2
                    denominator += w
                    denominator_sd+=w * p 
            except IndexError:
                # jeżeli wychodzimy poza zakres tablicy
                continue
            #print(p)
        if denominator > 1:
            sigma = np.sqrt(numerator / (denominator-1))
        else:
            sigma = min(sigmas[j - 1]**4/sigmas[j - 2]**2, min(sigmas[j - 2]**2, sigmas[j - 1]**2) )
        sd.append(sigma/np.sqrt(denominator_sd))
        sigmas.append(sigma)

    return [sigmas,sd]

sigmas = calculate_sigma(p_ij, l_ij, w_ij, dev_j)
print(sigmas[0])
print("------")
print(sigmas[1])
