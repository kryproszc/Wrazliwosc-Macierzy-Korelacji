import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from statsmodels.nonparametric.smoothers_lowess import lowess

# ---- 1. Dane --------------------------------------------------------------
triangle = np.array([
    [5012, 8269, 10907, 11805, 13539, 16181, 18009, 18608, 18662, 18834],
    [ 106, 4285,  5396, 10666, 13782, 15599, 15496, 16169, 16704,     np.nan],
    [3410, 8992, 13873, 16141, 18735, 22214, 22863, 23466,     np.nan, np.nan],
    [5655,11555, 15766, 21266, 23425, 26083, 27067,     np.nan, np.nan, np.nan],
    [1092, 9565, 15836, 22169, 25955, 26180,     np.nan, np.nan, np.nan, np.nan],
    [1513, 6445, 11072, 12935, 15852,     np.nan,     np.nan, np.nan, np.nan, np.nan],
    [ 557, 4020, 10946, 12314,     np.nan,     np.nan,     np.nan, np.nan, np.nan, np.nan],
    [1351, 6947, 13112,     np.nan,     np.nan,     np.nan,     np.nan, np.nan, np.nan, np.nan],
    [3133, 5395,     np.nan,     np.nan,     np.nan,     np.nan,     np.nan, np.nan, np.nan, np.nan],
    [2063,    np.nan, np.nan,   np.nan,     np.nan,     np.nan,     np.nan, np.nan, np.nan, np.nan],
], dtype=float)

triangle_df = pd.DataFrame(
    triangle,
    index=np.arange(1, triangle.shape[0] + 1),
    columns=np.arange(1, triangle.shape[1] + 1)
)

# ---- 2. Parametry ----------------------------------------------------------
alpha  = 1
delta  = 2 - alpha                              # =1

fitted_values   = []
origin_periods  = []
dev_periods     = []
actual_vals     = []
std_residuals   = []

# ---- 3. Pętla po parach kolumn --------------------------------------------
for j in range(triangle_df.shape[1] - 1):       # kolumny 1–9 (0‑indeks)
    x_col = triangle_df.iloc[:, j]
    y_col = triangle_df.iloc[:, j + 1]

    valid = ~(x_col.isna() | y_col.isna())
    x     = x_col[valid].to_numpy(dtype=float).reshape(-1, 1)
    y     = y_col[valid].to_numpy(dtype=float)
    w     = 1 / np.power(x.flatten(), delta)     # w = 1/x^delta

    lr = LinearRegression(fit_intercept=False)
    lr.fit(x, y, sample_weight=w)

    y_hat     = lr.predict(x)
    residuals = y - y_hat

    rss_w = np.sum(w * residuals**2)
    n     = len(y)
    if n > 1:
        sigma = np.sqrt(rss_w / (n - 1))
        S = np.sum(w * (x.flatten()**2))
        h = w * (x.flatten()**2) / S
        stud_resid = residuals * np.sqrt(w) / (sigma * np.sqrt(1 - h))
    else:
        stud_resid = np.full_like(y, np.nan)

    fitted_values.extend(y_hat)
    origin_periods.extend(x_col.index[valid])        # 1…10
    dev_periods.extend([j + 1] * n)                  # 1‑based
    actual_vals.extend(y)
    std_residuals.extend(stud_resid)

# ---- 4. Ramka wynikowa -----------------------------------------------------
residuals_raw = np.array(actual_vals) - np.array(fitted_values)

obs_vs_fitted = pd.DataFrame({
    "origin.period"      : origin_periods,
    "dev.period"         : np.array(dev_periods),
    "cal.period"         : np.array(origin_periods) + np.array(dev_periods) - 1,
    "residuals"          : residuals_raw,
    "standard.residuals" : std_residuals,
    "fitted.value"       : fitted_values
}).dropna().reset_index(drop=True)

print("\n==== OBS_VS_FITTED ====\n")
print(obs_vs_fitted)

# ---- 5. LOWESS -------------------------------------------------------------
sm_fit    = lowess(obs_vs_fitted["standard.residuals"],
                   obs_vs_fitted["fitted.value"],
                   frac=2/3, return_sorted=True)
sm_origin = lowess(obs_vs_fitted["standard.residuals"],
                   obs_vs_fitted["origin.period"],
                   frac=2/3, return_sorted=True)
sm_cal    = lowess(obs_vs_fitted["standard.residuals"],
                   obs_vs_fitted["cal.period"],
                   frac=2/3, return_sorted=True)
sm_dev    = lowess(obs_vs_fitted["standard.residuals"],
                   obs_vs_fitted["dev.period"],
                   frac=2/3, return_sorted=True)

lowess_results = {
    "fitted.value" : pd.DataFrame(sm_fit,    columns=["x", "lowess"]),
    "origin.period": pd.DataFrame(sm_origin, columns=["x", "lowess"]),
    "cal.period"   : pd.DataFrame(sm_cal,    columns=["x", "lowess"]),
    "dev.period"   : pd.DataFrame(sm_dev,    columns=["x", "lowess"])
}

print("\n==== LOWESS RESULTS ====\n")
for name, df in lowess_results.items():
    print(f"\n-- {name} --\n")
    print(df)
