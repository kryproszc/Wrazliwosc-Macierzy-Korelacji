import numpy as np


def make_cumulative(triangle):
    triangle = triangle.copy()
    for i in range(1, triangle.shape[1]):
        triangle[:, i, :] += triangle[:, i - 1, :]
    return triangle


def get_incremental(triangle):
    triangle = triangle.copy()
    triangle[:, 1:, :] -= triangle[:, :-1, :]
    return triangle


def get_indiv_dfs(triangle):
    dfs = triangle[:, 1:, :] / triangle[:, :-1, :]
    dfs = np.concatenate([dfs, np.full((triangle.shape[0], 1, triangle.shape[2]), np.nan)], axis=1)
    return dfs


def get_av_dfs(dfs, weights):
    include = ~np.isnan(dfs) & ~np.isnan(weights)
    dfs_filled = np.nan_to_num(dfs)
    weights_filled = np.nan_to_num(weights)

    num = np.sum(dfs_filled * weights_filled * include, axis=0)
    denom = np.sum(weights_filled * include, axis=0)

    av_dfs = np.where(denom != 0, num / denom, 1.0)
    av_dfs = np.expand_dims(av_dfs, axis=0)
    return av_dfs


def get_ult_dfs(av_dfs):
    ult_dfs = av_dfs.copy()
    for i in reversed(range(av_dfs.shape[1] - 1)):
        ult_dfs[:, i, :] *= ult_dfs[:, i + 1, :]
    return ult_dfs


def get_ultimates(latest, ult_dfs):
    ult_dfs_reversed = ult_dfs[:, ::-1, :]
    ultimates = latest * ult_dfs_reversed
    return ultimates


def expand_array(x, axis, new_size):
    shape = list(x.shape)
    shape[axis] = new_size
    expanded = np.broadcast_to(x, shape)
    return expanded


def get_expected(ults, ult_dfs):
    ults_expanded = expand_array(ults, 1, ult_dfs.shape[1])
    ult_dfs_expanded = expand_array(ult_dfs, 0, ults.shape[0])
    return ults_expanded * ult_dfs_expanded


def sample_residuals(resids, mask, n_sims, seed=None):
    rng = np.random.default_rng(seed)
    resids_flat = resids.flatten()
    resids_flat = resids_flat[~np.isnan(resids_flat)]

    samples = rng.choice(resids_flat, size=(mask.shape[0], mask.shape[1], n_sims), replace=True)
    samples[~mask] = np.nan
    return samples


def random_claims(exp_clms, resids, n_sims, seed=None):
    mask = ~np.isnan(exp_clms[:, :, 0])
    sampled_resids = sample_residuals(resids, mask, n_sims, seed)
    exp_clms_expanded = np.repeat(exp_clms, n_sims, axis=2)
    return sampled_resids * np.sqrt(np.abs(exp_clms_expanded)) + exp_clms_expanded


def boot_chainladder(triangle_input, R=999, seed=None):
    if isinstance(triangle_input, list):
        triangle_input = np.array(triangle_input, dtype=float)

    triangle = triangle_input.copy()

    if triangle.ndim == 2:
        triangle = triangle[:, :, np.newaxis]

    m, n, _ = triangle.shape

    if m != n:
        raise ValueError("Triangle must be square (m == n)")

    weights = 1 / triangle

    inc_triangle = get_incremental(triangle)
    latest = np.nansum(inc_triangle, axis=1, keepdims=True)

    dfs = get_indiv_dfs(triangle)
    av_dfs = get_av_dfs(dfs, 1 / weights)
    ult_dfs = get_ult_dfs(av_dfs)
    ults = get_ultimates(latest, ult_dfs)

    exp_inc_triangle = get_incremental(get_expected(ults, 1 / ult_dfs))

    origins = np.arange(m - n, m)

    exp_inc_triangle[np.isnan(inc_triangle[origins, :, :])] = np.nan

    inc_triangle = inc_triangle[origins, :, :]

    n_small = n
    inc_triangle = inc_triangle.reshape(n_small, n_small, 1)

    unscaled_residuals = (inc_triangle - exp_inc_triangle) / np.sqrt(np.abs(exp_inc_triangle))

    nobs = 0.5 * n_small * (n_small + 1)
    scale_factor = nobs - 2 * n_small + 1
    scale_phi = np.nansum(unscaled_residuals ** 2) / scale_factor

    adj_resids = unscaled_residuals * np.sqrt(nobs / scale_factor)

    sim_claims = random_claims(exp_inc_triangle, adj_resids, R, seed)

    sim_cum = make_cumulative(sim_claims)

    sim_latest = np.nansum(sim_cum, axis=1, keepdims=True)

    sim_dfs = get_indiv_dfs(sim_cum)
    sim_weights = sim_cum
    sim_av_dfs = get_av_dfs(sim_dfs, sim_weights)
    sim_ult_dfs = get_ult_dfs(sim_av_dfs)
    sim_ults = get_ultimates(sim_latest, sim_ult_dfs)

    sim_exp = get_incremental(get_expected(sim_ults, 1 / sim_ult_dfs))
    sim_exp[~np.isnan(sim_claims)] = np.nan

    rng = np.random.default_rng(seed)

    process_triangle = np.zeros((n_small, n_small, R))

    for r in range(R):
        mask = ~np.isnan(sim_exp[:, :, r])
        shape_param = np.abs(sim_exp[:, :, r][mask]) / scale_phi
        scale_param = scale_phi
        process_triangle[:, :, r][mask] = rng.gamma(shape=shape_param, scale=scale_param)

    ibnr_triangles = make_cumulative(process_triangle)
    ibnr_by_origin = ibnr_triangles[:, -1, :]
    ibnr_totals = np.sum(ibnr_triangles, axis=(0, 1))

    return ibnr_totals


if __name__ == "__main__":
    import pandas as pd

    # Example triangle input
    triangle = [
    [5012, 8269, 10907, 11805, 13539, 16181, 18009, 18608, 18662, 18834],
    [106, 4285, 5396, 10666, 13782, 15599, 15496, 16169, 16704, np.nan],
    [3410, 8992, 13873, 16141, 18735, 22214, 22863, 23466, np.nan, np.nan],
    [5655, 11555, 15766, 21266, 23425, 26083, 27067, np.nan, np.nan, np.nan],
    [1092, 9565, 15836, 22169, 25955, 26180, np.nan, np.nan, np.nan, np.nan],
    [1513, 6445, 11702, 12935, 15852, np.nan, np.nan, np.nan, np.nan, np.nan],
    [557, 4020, 10946, 12314, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [1351, 6947, 13112, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [3133, 5395, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    [2063, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan]
]


    R = 10000

    results = boot_chainladder(triangle, R=R, seed=1234)

    print(f"\nŚrednia rezerw: {np.mean(results):,.2f}")
    print(f"Odchylenie standardowe: {np.std(results):,.2f}")
