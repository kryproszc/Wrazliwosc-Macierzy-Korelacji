# Refaktoryzacja komponentów PaidWyniki i IncurredWyniki

## 🎯 Cele refaktoryzacji

Zrefaktoryzowano komponenty `PaidWyniki.tsx` i `IncurredWyniki.tsx` w celu:

- **Separacji odpowiedzialności** - wydzielenie logiki wielokrotnego użytku do `shared`
- **Reużywalności** - stworzenie komponentów, które można wykorzystać w innych miejscach
- **Lepszej organizacji kodu** - przeniesienie specyficznych funkcjonalności do `features/summary`
- **Łatwiejszego utrzymania** - podział na mniejsze, skoncentrowane komponenty

## 📁 Nowa struktura plików

### Shared Components (wielokrotnego użytku)

```
src/shared/
├── components/
│   └── ComparisonTable.tsx          # ✨ Przeniesiony z _components
├── hooks/
│   ├── useDataOptions.ts            # 🆕 Hook do zarządzania opcjami selecta
│   ├── usePayloadBuilder.ts         # 🆕 Hook do budowania payloadów API
│   └── useExcelExport.ts            # 🆕 Hook do eksportu do Excel
```

### Feature-specific Components

```
src/features/summary/
├── components/
│   ├── DataSelectionPanel.tsx       # 🆕 Panel wyboru danych (reużywalny)
│   ├── PaidResultsPage.tsx          # 🆕 Strona wyników Paid
│   └── IncurredResultsPage.tsx      # 🆕 Strona wyników Incurred
├── hooks/
│   └── useDataSubmission.ts         # 🆕 Hook do wysyłania danych
└── index.ts                         # 🆕 Eksport wszystkich komponentów
```

### Refaktoryzowane pliki

```
src/app/_components/
├── PaidWyniki.tsx                   # ♻️ Teraz tylko wrapper dla PaidResultsPage
└── IncurredWyniki.tsx               # ♻️ Teraz tylko wrapper dla IncurredResultsPage
```

## 🔧 Główne komponenty

### 1. `ComparisonTable` (shared/components)

**Odpowiedzialność:** Wyświetlanie tabeli porównań wyników

- Przeniesiony z `_components` do `shared/components`
- Dodano eksport typów dla lepszej interoperabilności

### 2. `useDataOptions` (shared/hooks)

**Odpowiedzialność:** Zarządzanie opcjami selecta

```typescript
export function useDataOptions({
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
}) {
  // Zwraca allOptions i keyToLabelMap
}
```

### 3. `usePayloadBuilder` (shared/hooks)

**Odpowiedzialność:** Budowanie payloadów dla API

```typescript
export function usePayloadBuilder({
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
}) {
  // Zwraca buildPayload function
}
```

### 4. `useExcelExport` (shared/hooks)

**Odpowiedzialność:** Eksport danych do Excel

```typescript
export function useExcelExport() {
  // Zwraca exportToExcel function
}
```

### 5. `DataSelectionPanel` (features/summary/components)

**Odpowiedzialność:** Panel wyboru danych (lewa kolumna)

- Reużywalny komponent dla Paid i Incurred
- Przyjmuje props dla customizacji

### 6. `useDataSubmission` (features/summary/hooks)

**Odpowiedzialność:** Logika wysyłania danych na backend

```typescript
export function useDataSubmission({
  buildPayload,
  keyToLabelMap,
  getTriangleData,
  addComparisonTable,
  apiEndpoint, // 'paid' lub 'incurred'
}) {
  // Zwraca handleSend function
}
```

## ✨ Główne ulepszenia

### ✅ Przed vs Po

| **Przed**                            | **Po**                          |
| ------------------------------------ | ------------------------------- |
| 2 pliki, każdy ~260 linii            | 8 plików, każdy <100 linii      |
| Duplikacja kodu między Paid/Incurred | Wspólne komponenty w shared     |
| Logika mieszana z UI                 | Wydzielone hooki dla logiki     |
| Trudno testowalne                    | Komponenty łatwe do testowania  |
| Brak reużywalności                   | Komponenty wielokrotnego użytku |

### 🔄 Reużywalność

Komponenty można teraz łatwo wykorzystać w innych miejscach:

```typescript
// Użycie w nowym komponencie
import { DataSelectionPanel, useDataOptions } from '@/features/summary';
import { ComparisonTable, useExcelExport } from '@/shared';

function NewResultsComponent() {
  const { allOptions } = useDataOptions({...});
  const { exportToExcel } = useExcelExport();

  return (
    <DataSelectionPanel
      allOptions={allOptions}
      onExportToExcel={() => exportToExcel(data, 'custom.xlsx')}
      methodType="Custom"
    />
  );
}
```

## 🚀 Korzyści

1. **DRY Principle** - eliminacja duplikacji kodu
2. **Single Responsibility** - każdy hook/komponent ma jedną odpowiedzialność
3. **Testowanie** - łatwiejsze testowanie izolowanych komponentów
4. **Reużywalność** - komponenty można używać w innych funkcjonalnościach
5. **Konsekwencja** - jednolity sposób obsługi wyników Paid/Incurred
6. **Łatwiejsza rozbudowa** - dodanie nowych typów wyników wymaga minimalnych zmian

## 🔄 Jak używać

### Import z features/summary

```typescript
import { PaidResultsPage, IncurredResultsPage } from "@/features/summary";
```

### Import z shared

```typescript
import {
  ComparisonTable,
  useDataOptions,
  usePayloadBuilder,
  useExcelExport,
} from "@/shared";
```

### Tworzenie nowego typu wyników

Aby stworzyć nowy typ wyników (np. "Combined"), wystarczy:

1. Stworzyć nowy komponent używający `DataSelectionPanel`
2. Przekazać odpowiedni `apiEndpoint` do `useDataSubmission`
3. Dostosować `getTriangleData` dla nowego store'a

## 📋 Zachowana kompatybilność

- ✅ Wszystkie istniejące importy działają bez zmian
- ✅ Identyczna funkcjonalność
- ✅ Identyczny interfejs użytkownika
- ✅ Kompatybilność z istniejącymi store'ami
- ✅ Bez zmian w API calls

## 🎨 Możliwe dalsze ulepszenia

1. **Dodanie testów jednostkowych** dla hooków i komponentów
2. **Virtualizacja tabeli** dla bardzo dużych zestawów danych
3. **Lazy loading** komponentów
4. **Internationalization** komunikatów
5. **Custom themes** dla różnych typów wyników
6. **Caching** wyników API w hookach
