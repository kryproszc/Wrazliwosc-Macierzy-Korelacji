'use client';

import { useState } from "react";
import DeterministicMethodsTab from "./DeterministicMethodsTab";
import { ExposureTab } from "./ExposureTab";
import { NetBruttoTab } from "./NetBruttoTab";
import { DiscountRatesTab } from "./DiscountRatesTab";
import { Folder, Calculator, Home, BarChart, Sigma, ChevronDown, ChevronRight, Menu } from "lucide-react";
import { DataTabs } from "./DataTabs";
import { DataTabsIncurred } from "./DataTabsIncurred";

// ✅ importy dla różnych metod symulacji
import { ClSimulationPaid } from "../../features/Parametryzacja/MultPaid/Symulacje/ClSimulationPaid";
import { AddSimulationPaid } from "../../features/Parametryzacja/AddPaid/Symulacje/AddSimulationPaid";
import { ClSimulationIncurred } from "@/features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred";

// ✅ NOWY import (plik Inflacja.tsc w tym samym katalogu co NetBruttoTab)
//    Uwaga: TypeScript rozwiąże rozszerzenie – ścieżka bez .tsc/.tsx
import { InflacjaTab } from "./Inflacja";
import { TestTab } from "../../features/Parametryzacja/Test/TestTab";
import { DeterministicPaidTab } from "../../features/Obliczenia deterministyczne/paid_deterministyczny";
import { DeterministicIncurredTab } from "../../features/Obliczenia deterministyczne/incurred_deterministyczny";
import { StochasticPaidTab } from "../../features/Obliczenia_stochastyczne/paid_stochastyczne";
import { StochasticIncurredTab } from "../../features/Obliczenia_stochastyczne/incurred_stochastyczne";

export function HomeTabs() {
  const [selectedTab, setSelectedTab] =
    useState<"start" | "input" | "deterministic" | "deterministic-calculations" | "stochastic-calculations" | "simulation">("start");

  const [isParametrizationExpanded, setIsParametrizationExpanded] = useState(false);
  const [isDeterministicCalculationsExpanded, setIsDeterministicCalculationsExpanded] = useState(false);
  const [isStochasticCalculationsExpanded, setIsStochasticCalculationsExpanded] = useState(false);
  const [isInputExpanded, setIsInputExpanded] = useState(false);
  const [isSimulationExpanded, setIsSimulationExpanded] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const [selectedMethod, setSelectedMethod] = useState<"paid" | "incurred" | "other1" | "other2" | "other3">("paid");

  // ✅ rozszerzony typ o "incurred"
  const [selectedInputType, setSelectedInputType] =
    useState<"inflacja" | "paid" | "incurred" | "exposure" | "netbrutto" | "discountrates">("paid");

  const [selectedSimMethod, setSelectedSimMethod] =
    useState<"bootstrap" | "addpaid" | "incurred" | "test">("bootstrap");
  const [selectedDeterministicCalculation, setSelectedDeterministicCalculation] =
    useState<"paid" | "incurred">("paid");
  const [selectedStochasticCalculation, setSelectedStochasticCalculation] =
    useState<"paid" | "incurred">("paid");

  const renderContent = () => {
    switch (selectedTab) {
      case "start":
        return <StartPage />;
      case "input":
        // ✅ obsługa nowej zakładki
        if (selectedInputType === "inflacja") return <InflacjaTab />;
        if (selectedInputType === "incurred") return <DataTabsIncurred />;
        if (selectedInputType === "exposure") return <ExposureTab />;
        if (selectedInputType === "netbrutto") return <NetBruttoTab />;
        if (selectedInputType === "discountrates") return <DiscountRatesTab />;
        return <DataTabs />;
      case "deterministic":
        return <DeterministicMethodsTab selectedMethod={selectedMethod} />;
      case "deterministic-calculations":
        if (selectedDeterministicCalculation === "incurred") return <DeterministicIncurredTab />;
        return <DeterministicPaidTab />;
      case "stochastic-calculations":
        if (selectedStochasticCalculation === "incurred") return <StochasticIncurredTab />;
        return <StochasticPaidTab />;
      case "simulation":
        if (selectedSimMethod === "bootstrap") return <ClSimulationPaid />;
        if (selectedSimMethod === "addpaid") return <AddSimulationPaid />;
        if (selectedSimMethod === "incurred") return <ClSimulationIncurred />;
        if (selectedSimMethod === "test") return <TestTab />;
        return <ClSimulationPaid />; // domyślnie ClSimulationPaid
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#162338]">
      {/* Sidebar */}
      <aside
        data-collapsed={isSidebarCollapsed}
        className={`group flex h-screen shrink-0 flex-col overflow-hidden border-r border-slate-600 bg-[#25344c] py-3 text-gray-100 transition-[width] duration-300 ${
          isSidebarCollapsed ? 'w-16 px-2' : 'w-56 px-2'
        }`}
      >
        {/* Logo / nagłówek */}
        <div className="mb-3 flex items-center justify-center gap-2">
          {!isSidebarCollapsed && (
            <h1 className="text-xl font-extrabold tracking-wider text-blue-400">UPZ</h1>
          )}
          <button
            type="button"
            aria-label={isSidebarCollapsed ? 'Rozwiń menu' : 'Zwiń menu'}
            onClick={() => setIsSidebarCollapsed((collapsed) => !collapsed)}
            className="rounded-md p-2 text-slate-300 transition-colors hover:bg-slate-600 hover:text-white"
          >
            <Menu size={20} />
          </button>
        </div>

        <nav className="min-h-0 flex-1 overflow-y-scroll overflow-x-hidden pr-1 [scrollbar-gutter:stable] [scrollbar-width:thin] [scrollbar-color:#94a3b8_transparent] flex flex-col gap-1 [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-400">
          <SidebarItem
            icon={<Home size={20} />}
            label="Start"
            isActive={selectedTab === "start"}
            onClick={() => setSelectedTab("start")}
          />

          {/* Wprowadź dane */}
          <div>
            <SidebarItem
              icon={<Folder size={20} />}
              label="Wprowadź dane"
              isActive={selectedTab === "input"}
              onClick={() => {
                setIsInputExpanded(!isInputExpanded);
                if (!isInputExpanded) setSelectedTab("input");
              }}
              expandIcon={isInputExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              isExpandable
            />

            {isInputExpanded && (
              <div className="ml-6 border-l border-slate-600">
                {/* ✅ NOWA pozycja – przed „Trójkąt paid” */}
                <SidebarSubItem
                  label="Inflacja"
                  isActive={selectedTab === "input" && selectedInputType === "inflacja"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("inflacja"); }}
                />
                <SidebarSubItem
                  label="Trójkąt paid"
                  isActive={selectedTab === "input" && selectedInputType === "paid"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("paid"); }}
                />
                <SidebarSubItem
                  label="Trójkąt incurred"
                  isActive={selectedTab === "input" && selectedInputType === "incurred"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("incurred"); }}
                />
                <SidebarSubItem
                  label="Ekspozycja"
                  isActive={selectedTab === "input" && selectedInputType === "exposure"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("exposure"); }}
                />
                <SidebarSubItem
                  label="Netto/brutto"
                  isActive={selectedTab === "input" && selectedInputType === "netbrutto"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("netbrutto"); }}
                />
                <SidebarSubItem
                  label="Stopy dyskontowe"
                  isActive={selectedTab === "input" && selectedInputType === "discountrates"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("discountrates"); }}
                />
              </div>
            )}
          </div>

          {/* Parametryzacja */}
          <div>
            <SidebarItem
              icon={<Calculator size={20} />}
              label="Parametryzacja"
              isActive={selectedTab === "deterministic"}
              onClick={() => {
                setIsParametrizationExpanded(!isParametrizationExpanded);
                if (!isParametrizationExpanded) setSelectedTab("deterministic");
              }}
              expandIcon={
                isParametrizationExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isParametrizationExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="Multiplikatywna Paid"
                  isActive={selectedTab === "deterministic" && selectedMethod === "paid"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("paid"); }}
                />
                <SidebarSubItem
                  label="Multiplikatywna Incurred"
                  isActive={selectedTab === "deterministic" && selectedMethod === "incurred"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("incurred"); }}
                />
                <SidebarSubItem
                  label="Addytywna Paid"
                  isActive={selectedTab === "deterministic" && selectedMethod === "other1"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("other1"); }}
                />
                <SidebarSubItem
                  label="Addytywna Incurred"
                  isActive={selectedTab === "deterministic" && selectedMethod === "other3"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("other3"); }}
                />
                <SidebarSubItem
                  label="Paid/Incurred"
                  isActive={selectedTab === "deterministic" && selectedMethod === "other2"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("other2"); }}
                />
              </div>
            )}
          </div>

          {/* Obliczenia deterministyczne */}
          <div>
            <SidebarItem
              icon={<Sigma size={20} />}
              label="Obliczenia deterministyczne"
              isActive={selectedTab === "deterministic-calculations"}
              onClick={() => {
                setIsDeterministicCalculationsExpanded(!isDeterministicCalculationsExpanded);
                if (!isDeterministicCalculationsExpanded) setSelectedTab("deterministic-calculations");
              }}
              expandIcon={
                isDeterministicCalculationsExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isDeterministicCalculationsExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="Paid"
                  isActive={selectedTab === "deterministic-calculations" && selectedDeterministicCalculation === "paid"}
                  onClick={() => { setSelectedTab("deterministic-calculations"); setSelectedDeterministicCalculation("paid"); }}
                />
                <SidebarSubItem
                  label="Incurred"
                  isActive={selectedTab === "deterministic-calculations" && selectedDeterministicCalculation === "incurred"}
                  onClick={() => { setSelectedTab("deterministic-calculations"); setSelectedDeterministicCalculation("incurred"); }}
                />
              </div>
            )}
          </div>

          {/* Obliczenia stochastyczne */}
          <div>
            <SidebarItem
              icon={<Sigma size={20} />}
              label="Obliczenia stochastyczne"
              isActive={selectedTab === "stochastic-calculations"}
              onClick={() => {
                setIsStochasticCalculationsExpanded(!isStochasticCalculationsExpanded);
                if (!isStochasticCalculationsExpanded) setSelectedTab("stochastic-calculations");
              }}
              expandIcon={
                isStochasticCalculationsExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isStochasticCalculationsExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="Paid"
                  isActive={selectedTab === "stochastic-calculations" && selectedStochasticCalculation === "paid"}
                  onClick={() => { setSelectedTab("stochastic-calculations"); setSelectedStochasticCalculation("paid"); }}
                />
                <SidebarSubItem
                  label="Incurred"
                  isActive={selectedTab === "stochastic-calculations" && selectedStochasticCalculation === "incurred"}
                  onClick={() => { setSelectedTab("stochastic-calculations"); setSelectedStochasticCalculation("incurred"); }}
                />
              </div>
            )}
          </div>

          {/* Symulacje */}
          <div>
            <SidebarItem
              icon={<BarChart size={20} />}
              label="Symulacje"
              isActive={selectedTab === "simulation"}
              onClick={() => {
                setIsSimulationExpanded(!isSimulationExpanded);
                if (!isSimulationExpanded) setSelectedTab("simulation");
              }}
              expandIcon={
                isSimulationExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isSimulationExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="Chain Ladder Simulation"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "bootstrap"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("bootstrap"); }}
                />
                <SidebarSubItem
                  label="AddPaid Simulation"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "addpaid"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("addpaid"); }}
                />
                <SidebarSubItem
                  label="Chain Ladder Incurred"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "incurred"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("incurred"); }}
                />
                <SidebarSubItem
                  label="Test"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "test"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("test"); }}
                />
              </div>
            )}
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex h-screen min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-[#162338] pb-0 pl-6 pr-8 pt-2">
        <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1 [scrollbar-width:thin] [scrollbar-color:#475569_transparent]">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

function SidebarItem({
  icon,
  label,
  isActive,
  onClick,
  expandIcon,
  isExpandable,
}: {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
  expandIcon?: React.ReactNode;
  isExpandable?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-2 rounded-lg p-2 text-left transition-all group-data-[collapsed=true]:justify-center group-data-[collapsed=true]:px-2
        ${isActive ? "bg-slate-600 text-blue-300 font-semibold shadow-inner" : "hover:bg-slate-600/70 hover:text-blue-200"}`}
    >
      {icon}
      <span className="flex-1 text-sm group-data-[collapsed=true]:hidden">{label}</span>
      {isExpandable && <span className="group-data-[collapsed=true]:hidden">{expandIcon}</span>}
    </button>
  );
}

function SidebarSubItem({
  label,
  isActive,
  onClick,
}: {
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`ml-2 flex w-full items-center gap-2 rounded-lg p-1.5 pl-3 text-left text-xs transition-all group-data-[collapsed=true]:hidden
        ${isActive ? "bg-slate-500 text-blue-100 font-medium" : "hover:bg-slate-500/70 hover:text-blue-100 text-slate-300"}`}
    >
      <span className="w-2 h-2 bg-slate-400 rounded-full"></span>
      <span>{label}</span>
    </button>
  );
}

function StartPage() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-gray-100 animate-fade-in">
      <div className="bg-gradient-to-b from-[#17263d] to-[#2b3a55] p-12 rounded-xl shadow-2xl flex flex-col items-center w-full max-w-4xl">
        <img
          src="/Grafika_powitalna.png"
          alt="Grafika powitalna"
          className="w-full max-w-2xl mb-4 rounded-lg shadow-lg"
        />
        <p className="text-xs text-gray-500 mb-10">
          Źródło:{" "}
          <a
            href="https://www.insurtechexpress.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-gray-400"
          >
            www.insurtechexpress.com
          </a>
        </p>
        <h1 className="text-5xl font-bold mb-6 text-center">Witaj w aplikacji!</h1>
        <p className="text-xl text-gray-400 text-center max-w-2xl">
          Aplikacja do analizy rezerw ubezpieczeniowych metodą Chain-Ladder (Paid).
          Wprowadź dane i przeprowadź analizę współczynników rozwoju.
        </p>
      </div>
    </div>
  );
}
