import React from 'react';
import { Label } from '@/components/ui/label';

export type DataType = 'cumulative' | 'incremental';

interface DataTypeSelectorProps {
  dataType: DataType;
  onDataTypeChange: (type: DataType) => void;
  title?: string;
}

export const DataTypeSelector: React.FC<DataTypeSelectorProps> = ({
  dataType,
  onDataTypeChange,
  title = 'Typ danych',
}) => {
  return (
    <div className="w-full space-y-1.5 p-2.5 border border-slate-500/40 rounded-lg bg-slate-800/20">
      <Label className="text-base leading-tight tracking-tight font-semibold text-slate-100">{title}</Label>
      <div className="flex flex-col gap-1">
        <label className="group flex items-start space-x-3 cursor-pointer p-1.5 rounded-md hover:bg-slate-600/60 transition-colors">
          <input
            type="radio"
            name="dataType"
            value="cumulative"
            checked={dataType === 'cumulative'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="mt-1 h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-slate-100 group-hover:text-white">
              📊 Skumulowane
            </span>
          </div>
        </label>
        <label className="group flex items-start space-x-3 cursor-pointer p-1.5 rounded-md hover:bg-slate-600/60 transition-colors">
          <input
            type="radio"
            name="dataType"
            value="incremental"
            checked={dataType === 'incremental'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="mt-1 h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-slate-100 group-hover:text-white">
              📈 Inkrementalne
            </span>
          </div>
        </label>
      </div>
    </div>
  );
};
