import { Label } from "@/components/ui/label";

export type HeadersType = boolean;

interface HeadersSelectorProps {
  hasHeaders: boolean;
  onHeadersChange: (hasHeaders: boolean) => void;
}

export function HeadersSelector({ hasHeaders, onHeadersChange }: HeadersSelectorProps) {
  return (
    <div className="w-full rounded-lg border border-slate-500/40 bg-slate-800/20 p-2.5">
      <Label className="text-base leading-tight tracking-tight font-semibold text-slate-100">
        Czy dane zawierają podpisy kolumn i wierszy?
      </Label>
      <div className="mt-2 flex flex-col gap-1">
        <label className="group flex items-center space-x-2 cursor-pointer rounded-md px-1 py-1 hover:bg-slate-600/60 transition-colors">
          <input
            type="radio"
            name="headers"
            checked={hasHeaders === true}
            onChange={() => onHeadersChange(true)}
            className="h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <span className="text-sm text-slate-200 group-hover:text-white">
            ✓ Zawierają podpisy kolumn i wierszy
          </span>
        </label>
        <label className="group flex items-center space-x-2 cursor-pointer rounded-md px-1 py-1 hover:bg-slate-600/60 transition-colors">
          <input
            type="radio"
            name="headers"
            checked={hasHeaders === false}
            onChange={() => onHeadersChange(false)}
            className="h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <span className="text-sm text-slate-200 group-hover:text-white">
            ✗ Nie zawierają podpisów kolumn i wierszy
          </span>
        </label>
      </div>
    </div>
  );
}
