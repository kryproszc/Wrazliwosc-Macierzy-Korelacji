'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddPaidStore } from '@/stores/addPaidStore';
import { useExposureStore } from '@/stores/exposureStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useParamsymStore } from '@/stores/paramsymStore';
import { CalculationLayout, EmptyState } from '@/shared/components/calculation';
import { DataTableView } from '@/shared/ui/molecules/DataTableView';
import { processSelectedRow, processSelectedValues } from '@/shared/utils';
import { useDataValidation } from '@/shared/hooks';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';
const PAID_TAB_STORAGE_KEY = 'deterministic-paid-tab-state';

type PaidTabResults = {
	last_col: number[];
	cum_trian: number[];
	ult_net_disc: number[];
	userId?: string;
	shouldShowResults: boolean;
};

type PaidTabPersistedState = {
	methodType: 'multiplikatywna' | 'addytywna' | 'mix';
	kChange: string;
	calculationResults: PaidTabResults | null;
};

const getInitialPaidTabState = (): PaidTabPersistedState => {
	if (typeof window === 'undefined') {
		return {
			methodType: 'multiplikatywna',
			kChange: '0',
			calculationResults: null,
		};
	}

	try {
		const raw = window.sessionStorage.getItem(PAID_TAB_STORAGE_KEY);
		if (!raw) {
			return {
				methodType: 'multiplikatywna',
				kChange: '0',
				calculationResults: null,
			};
		}

		const parsed = JSON.parse(raw) as PaidTabPersistedState;
		return {
			methodType: parsed?.methodType === 'addytywna' || parsed?.methodType === 'mix' ? parsed.methodType : 'multiplikatywna',
			kChange: typeof parsed?.kChange === 'string' ? parsed.kChange : '0',
			calculationResults: parsed?.calculationResults ?? null,
		};
	} catch {
		return {
			methodType: 'multiplikatywna',
			kChange: '0',
			calculationResults: null,
		};
	}
};

export function DeterministicPaidTab() {
	const initialState = useMemo(() => getInitialPaidTabState(), []);
	const [methodType, setMethodType] = useState<'multiplikatywna' | 'addytywna' | 'mix'>(initialState.methodType);
	const [kChange, setKChange] = useState<string>(initialState.kChange);
	const [isSending, setIsSending] = useState(false);
	const [lastSendMessage, setLastSendMessage] = useState<string>('Jeszcze nic nie wysłano.');
	const [calculationResults, setCalculationResults] = useState<PaidTabResults | null>(initialState.calculationResults);
	const hasPaidTriangleWatcherInitialized = useRef(false);
	const previousPaidTriangleRef = useRef<(number | null)[][] | undefined>(undefined);

	const userId = useUserStore((s: any) => s.userId);

	const {
		paidTriangle,
		selectedValuesCL,
		combinedDevJSummary,
		devJ,
	} = useTrainDevideStoreDet();

	const {
		selectedValuesAddLR,
		combinedAddLRSummary,
		addJ,
	} = useAddPaidStore();

	const {
		exposureTriangle,
		selectedExposureLine,
		availableExposureLines,
	} = useExposureStore();

	const discountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
	const selectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

	const paramsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
	const selectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);

	const { isPaidTriangleLoaded, isDiscountRatesLoaded, isNettoBruttoLoaded, canSelectBrutto, canSelectBruttoDysk, canSelectNettoDysk } =
		useDataValidation(paidTriangle, discountRatesTriangle, paramsymTriangle);

	const exposureArray = useMemo(() => {
		if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) return [];
		if (selectedExposureLine === null) return [];

		const selectedLine = availableExposureLines.find((line) => line.index === selectedExposureLine);
		if (!selectedLine) return [];

		return selectedLine.values;
	}, [exposureTriangle, selectedExposureLine, availableExposureLines]);

	const canSend = useMemo(() => {
		return Boolean(userId) && Array.isArray(paidTriangle) && paidTriangle.length > 0;
	}, [userId, paidTriangle]);

	const vectorF = useMemo(() => {
		return processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
	}, [selectedValuesCL, combinedDevJSummary, devJ]);

	const vectorLr = useMemo(() => {
		return processSelectedValues(selectedValuesAddLR, combinedAddLRSummary, addJ as any[], 1.0);
	}, [selectedValuesAddLR, combinedAddLRSummary, addJ]);

	const hasValidExplicitValues = (values: number[] | undefined) =>
		Array.isArray(values) && values.some((value) => Number.isFinite(value));

	const vectorFLength = vectorF.length;
	const vectorLrLength = vectorLr.length;
	const isSelectedValueClEmpty = !hasValidExplicitValues(selectedValuesCL);
	const isSelectedValueLrEmpty = !hasValidExplicitValues(selectedValuesAddLR);
	const areBothSelectedVectorsEmpty = isSelectedValueClEmpty && isSelectedValueLrEmpty;
	const showMultiplikatywna = !isSelectedValueClEmpty;
	const showAddytywna = !isSelectedValueLrEmpty;
	const showMix = !isSelectedValueClEmpty && !isSelectedValueLrEmpty;
	const isMultiplikatywnaDisabled = !showMultiplikatywna;
	const isAddytywnaDisabled = !showAddytywna;
	const isMixDisabled = !showMix;
	const isCurrentMethodUnavailable =
		(methodType === 'multiplikatywna' && !showMultiplikatywna)
		|| (methodType === 'addytywna' && !showAddytywna)
		|| (methodType === 'mix' && !showMix);
	const parsedKChange = Number(kChange);
	const isMixMethod = methodType === 'mix';
	const isMixKInvalid = isMixMethod && (!Number.isFinite(parsedKChange) || parsedKChange > vectorFLength);

	useEffect(() => {
		if (!isCurrentMethodUnavailable) {
			return;
		}

		if (showMultiplikatywna) {
			setMethodType('multiplikatywna');
			return;
		}

		if (showAddytywna) {
			setMethodType('addytywna');
			return;
		}

		if (showMix) {
			setMethodType('mix');
		}
	}, [
		isCurrentMethodUnavailable,
		showMultiplikatywna,
		showAddytywna,
		showMix,
	]);

	const lightResultsTableData = useMemo(() => {
		if (!calculationResults) return null;

		const formatWholeNumber = (value: number) =>
			Math.round(value)
				.toLocaleString('pl-PL', {
					minimumFractionDigits: 0,
					maximumFractionDigits: 0,
					useGrouping: true,
				})
				.replace(/\u00A0/g, ' ');

		const headers = ['OKRES', 'Brutto', 'Brutto jednoroczne zdyskontowane', 'Netto jednoroczne zdyskontowane'];
		const maxLength = Math.max(
			calculationResults.last_col.length,
			calculationResults.cum_trian.length,
			calculationResults.ult_net_disc.length,
		);

		const lastColSum = calculationResults.last_col.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const cumTrianSum = calculationResults.cum_trian.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const ultNetDiscSum = calculationResults.ult_net_disc.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);

		const rows: string[][] = [headers];

		for (let index = 0; index < maxLength; index += 1) {
			const lastColValue = calculationResults.last_col[index];
			const cumTrianValue = calculationResults.cum_trian[index];
			const ultNetDiscValue = calculationResults.ult_net_disc[index];

			rows.push([
				String(index + 1),
				typeof lastColValue === 'number' ? formatWholeNumber(lastColValue) : '-',
				typeof cumTrianValue === 'number' ? formatWholeNumber(cumTrianValue) : '-',
				typeof ultNetDiscValue === 'number' ? formatWholeNumber(ultNetDiscValue) : '-',
			]);
		}

		rows.push([
			'SUMA',
			formatWholeNumber(lastColSum),
			formatWholeNumber(cumTrianSum),
			formatWholeNumber(ultNetDiscSum),
		]);

		return rows;
	}, [calculationResults]);

	const handleSend = async () => {
		let computedKChange: number;

		if (methodType === 'multiplikatywna') {
			computedKChange = -1;
		} else if (methodType === 'addytywna') {
			computedKChange = vectorLrLength;
		} else {
			let mixK = Number(kChange);

			if (!Number.isFinite(mixK)) {
				const promptValue = window.prompt('Podaj parametr k dla trybu Mix metod:', kChange || '0');
				if (promptValue === null) {
					setLastSendMessage('Anulowano wprowadzanie parametru k dla trybu Mix.');
					return;
				}
				setKChange(promptValue);
				mixK = Number(promptValue);
			}

			if (!Number.isFinite(mixK)) {
				setLastSendMessage('Parametr k dla trybu Mix musi być liczbą.');
				return;
			}

			if (mixK > vectorFLength) {
				setLastSendMessage(`Parametr k dla trybu Mix nie może być większy od: ${vectorFLength}`);
				return;
			}

			computedKChange = mixK;
		}

		if (!userId) {
			setLastSendMessage('Brak user_id - nie wysłano.');
			console.error('❌ [DeterministicPaidTab] Brak user_id');
			return;
		}

		if (!Array.isArray(paidTriangle) || paidTriangle.length === 0) {
			setLastSendMessage('Brak paid_triangle - nie wysłano.');
			console.error('❌ [DeterministicPaidTab] Brak paid_triangle');
			return;
		}

		if (isCurrentMethodUnavailable) {
			setLastSendMessage('Brak wymaganych danych selected_value_cl/selected_value_lr dla wybranej metody.');
			return;
		}

		const selectedValueCl = processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
		const selectedValueLr = processSelectedValues(selectedValuesAddLR, combinedAddLRSummary, addJ as any[], 1.0);
		const discountRates = processSelectedRow(discountRatesTriangle, selectedDiscountRateLine);
		const nettoDysk = processSelectedRow(paramsymTriangle, selectedParamsymLine, true);

		const payload = {
			user_id: userId,
			paid_triangle: paidTriangle,
			selected_value_cl: selectedValueCl,
			selected_value_lr: selectedValueLr,
			ekspozycja: exposureArray,
			k_change: computedKChange,
			discount_rates: discountRates,
			netto_dysk: nettoDysk,
			calculation_options: {
				brutto: canSelectBrutto,
				brutto_dysk: canSelectBruttoDysk,
				netto_dysk: canSelectNettoDysk,
			},
		};

		const requestBody = JSON.stringify(payload);

		console.log('📤 [DeterministicPaidTab] URL:', `${API_URL}/calc_change_method/execute_calculations`);
		console.log('📤 [DeterministicPaidTab] Method:', 'POST');
		console.log('📤 [DeterministicPaidTab] Headers:', { 'Content-Type': 'application/json' });
		console.log('📤 [DeterministicPaidTab] Wysyłany payload (object):', payload);
		console.log('📤 [DeterministicPaidTab] Wysyłany payload (JSON pretty):', JSON.stringify(payload, null, 2));
		console.log('📤 [DeterministicPaidTab] Wysyłane body dokładnie:', requestBody);
		console.log('📤 [DeterministicPaidTab] Klucze payloadu:', Object.keys(payload));
		console.log('✅ [DeterministicPaidTab] Czy payload zawiera wymagane pola?', {
			user_id: 'user_id' in payload,
			paid_triangle: 'paid_triangle' in payload,
			selected_value_cl: 'selected_value_cl' in payload,
			selected_value_lr: 'selected_value_lr' in payload,
			ekspozycja: 'ekspozycja' in payload,
			k_change: 'k_change' in payload,
			discount_rates: 'discount_rates' in payload,
			netto_dysk: 'netto_dysk' in payload,
			calculation_options: 'calculation_options' in payload,
		});

		try {
			setIsSending(true);
			setLastSendMessage('Wysyłanie...');

			const response = await fetch(`${API_URL}/calc_change_method/execute_calculations`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: requestBody,
			});

			const responseBody = await response.json().catch(() => null);

			console.log('📥 [DeterministicPaidTab] Status odpowiedzi:', response.status);
			console.log('📥 [DeterministicPaidTab] Odpowiedź backendu (na razie tylko log):', responseBody);

			if (!response.ok) {
				setLastSendMessage(`Błąd wysyłki: ${response.status}`);
				return;
			}

			const vectors = responseBody?.vectors ?? {};
			setCalculationResults({
				last_col: Array.isArray(vectors.last_col) ? vectors.last_col : [],
				cum_trian: Array.isArray(vectors.cum_trian) ? vectors.cum_trian : [],
				ult_net_disc: Array.isArray(vectors.ult_net_disc) ? vectors.ult_net_disc : [],
				userId: userId,
				shouldShowResults: true,
			});

			setLastSendMessage('Wysłano poprawnie (odbiór wyników dodamy później).');
		} catch (error) {
			console.error('❌ [DeterministicPaidTab] Błąd podczas wysyłki:', error);
			setLastSendMessage(`Błąd wysyłki: ${error}`);
		} finally {
			setIsSending(false);
		}
	};

	useEffect(() => {
		if (!hasPaidTriangleWatcherInitialized.current) {
			hasPaidTriangleWatcherInitialized.current = true;
			previousPaidTriangleRef.current = paidTriangle;
			return;
		}

		const hasTriangleChanged = previousPaidTriangleRef.current !== paidTriangle;
		previousPaidTriangleRef.current = paidTriangle;

		if (!hasTriangleChanged || !calculationResults) {
			return;
		}

		setCalculationResults(null);
		setLastSendMessage('Wyczyszczono wyniki po zmianie danych Trójkąta Paid.');
	}, [paidTriangle, calculationResults]);

	useEffect(() => {
		if (typeof window === 'undefined') return;

		const stateToPersist: PaidTabPersistedState = {
			methodType,
			kChange,
			calculationResults,
		};

		window.sessionStorage.setItem(PAID_TAB_STORAGE_KEY, JSON.stringify(stateToPersist));
	}, [methodType, kChange, calculationResults]);

	return (
		<CalculationLayout
			sidebarWidth="w-48"
			sidebarPadding="p-3"
			mainPadding="p-4 md:p-5"
			sidebar={
				<div className="space-y-4">
					<div className="space-y-3 rounded-lg bg-gray-800 p-3">
						<label className="mb-1 block text-sm font-medium text-white">Wybór metody:</label>
						<div className="space-y-2">
							<label className={`flex items-center gap-2 text-sm font-medium ${isMultiplikatywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_paid"
									checked={methodType === 'multiplikatywna'}
									onChange={() => setMethodType('multiplikatywna')}
									disabled={isMultiplikatywnaDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Multiplikatywna</span>
							</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isAddytywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_paid"
									checked={methodType === 'addytywna'}
									onChange={() => setMethodType('addytywna')}
									disabled={isAddytywnaDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Addytywna</span>
							</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isMixDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
								<input
									type="radio"
									name="deterministic_method_paid"
									checked={methodType === 'mix'}
									onChange={() => setMethodType('mix')}
									disabled={isMixDisabled}
									className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
								/>
								<span>Mix metod</span>
							</label>
						</div>
					</div>

					{isMixMethod && (
						<div>
							<label htmlFor="kChange" className="mb-2 block text-xs font-medium text-white">
								Parametr k (Mix):
							</label>
							<input
								id="kChange"
								type="number"
								step="0.01"
								value={kChange}
								onChange={(event) => setKChange(event.target.value)}
								className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
							/>
						</div>
					)}

					<hr className="border-gray-600" />
					<div className="mx-auto flex w-fit flex-col gap-3">
						<button
							onClick={handleSend}
							disabled={isSending || !canSend || isMixKInvalid || areBothSelectedVectorsEmpty || isCurrentMethodUnavailable}
							className={`h-8 w-40 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl ${
								isSending || !canSend || isMixKInvalid || areBothSelectedVectorsEmpty || isCurrentMethodUnavailable ? 'opacity-60 cursor-not-allowed hover:scale-100' : ''
							}`}
						>
							{isSending ? 'Wysyłanie...' : 'Oblicz'}
						</button>

						<button
							onClick={() => {}}
							disabled={areBothSelectedVectorsEmpty}
							className={`h-8 w-40 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl ${
								areBothSelectedVectorsEmpty ? 'opacity-60 cursor-not-allowed hover:scale-100' : ''
							}`}
						>
							Eksportuj do Excela
						</button>
					</div>
				</div>
			}
		>
			<div className="space-y-6">
				{calculationResults ? (
					<DataTableView
						title="Wyniki"
						className="[&_*_table]:text-[11px]"
						lightHeaderClassName="bg-gradient-to-r from-gray-100 to-gray-50 px-3 py-1 border-b border-gray-300 rounded-t-2xl"
						lightTitleClassName="font-bold text-gray-800 text-sm tracking-tight"
						tableWrapperClassName="w-full overflow-auto max-h-[calc(100vh-8.5rem)]"
						data={lightResultsTableData}
						noDataMessage="Brak danych wynikowych do wyświetlenia"
						variant="light"
					/>
				) : (
					<EmptyState
						title=""
						description={'Dla wybranej metody kliknij "Oblicz".'}
					/>
				)}
			</div>
		</CalculationLayout>
	);
}
