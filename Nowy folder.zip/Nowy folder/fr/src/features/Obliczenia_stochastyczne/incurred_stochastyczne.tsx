'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { ClSimulationIncurred } from '@/features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddPaidStore } from '@/stores/addPaidStore';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import { useSimulationResultsStore } from '@/stores/simulationResultsStore';
import { useCLSimulationStore } from '@/stores/clSimulationStore';

type StochasticIncurredMethodType = 'multiplikatywna' | 'addytywna' | 'mix';

export function StochasticIncurredTab() {
	const [methodType, setMethodType] = useState<StochasticIncurredMethodType>('multiplikatywna');
	const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);
	const incurredTriangle = useTrainDevideStoreIncurred((s) => s.incurredTriangle);
	const selectedValuesCL = useTrainDevideStoreIncurred((s) => s.selectedValuesCL);
	const selectedValuesSigma = useTrainDevideStoreIncurred((s) => s.selectedValuesSigma);
	const selectedValuesSD = useTrainDevideStoreIncurred((s) => s.selectedValuesSD);
	const selectedValuesRJPaidToIncurred = useTrainDevideStoreIncurred((s) => s.selectedValuesRJPaidToIncurred);
	const combinedRJPaidToIncurredSummary = useTrainDevideStoreIncurred((s) => s.combinedRJPaidToIncurredSummary);
	const rJPaidToIncurred = useTrainDevideStoreIncurred((s) => s.rJPaidToIncurred);
	const selectedValuesAddLR = useAddPaidStore((s) => s.selectedValuesAddLR);
	const selectedValuesAddSigma = useAddPaidStore((s) => s.selectedValuesAddSigma);
	const combinedAddSDSummary = useAddIncurredCoefficientsStore((s) => s.combinedAddSDSummary);
	const simulationResults = useSimulationResultsStore((s) => s.results);
	const clearSimulationResults = useSimulationResultsStore((s) => s.clearResults);
	const statisticsResults = useCLSimulationStore((s) => s.statisticsResults);
	const clearStatisticsResults = useCLSimulationStore((s) => s.clearStatisticsResults);
	const resetCLSimulationStore = useCLSimulationStore((s) => s.resetStore);
	const hasIncurredTriangleWatcherInitialized = useRef(false);
	const previousPaidTriangleRef = useRef<(number | null)[][] | undefined>(undefined);
	const previousIncurredTriangleRef = useRef<(number | null)[][] | undefined>(undefined);

	const hasAnyFiniteNumber = (input: unknown): boolean => {
		if (Array.isArray(input)) {
			return input.some((item) => hasAnyFiniteNumber(item));
		}

		if (typeof input === 'string') {
			const parsed = Number(input);
			return Number.isFinite(parsed);
		}

		return typeof input === 'number' && Number.isFinite(input);
	};

	const hasRj =
		hasAnyFiniteNumber(selectedValuesRJPaidToIncurred)
		|| hasAnyFiniteNumber(combinedRJPaidToIncurredSummary)
		|| hasAnyFiniteNumber(rJPaidToIncurred);

	const hasMultiplikatywnaCl = hasAnyFiniteNumber(selectedValuesCL);
	const hasMultiplikatywnaSigma = hasAnyFiniteNumber(selectedValuesSigma);
	const hasMultiplikatywnaSd = hasAnyFiniteNumber(selectedValuesSD);
	const hasAddytywnaLr = hasAnyFiniteNumber(selectedValuesAddLR);
	const hasAddytywnaSigma = hasAnyFiniteNumber(selectedValuesAddSigma);
	const hasAddytywnaSd = hasAnyFiniteNumber(combinedAddSDSummary);

	const showMultiplikatywna = hasRj && hasMultiplikatywnaCl && hasMultiplikatywnaSigma && hasMultiplikatywnaSd;
	const showAddytywna = hasRj && hasAddytywnaLr && hasAddytywnaSigma && hasAddytywnaSd;
	const showMix = showMultiplikatywna && showAddytywna;
	const isMultiplikatywnaDisabled = !showMultiplikatywna;
	const isAddytywnaDisabled = !showAddytywna;
	const isMixDisabled = !showMix;
	const isCurrentMethodUnavailable =
		(methodType === 'multiplikatywna' && isMultiplikatywnaDisabled)
		|| (methodType === 'addytywna' && isAddytywnaDisabled)
		|| (methodType === 'mix' && isMixDisabled);

	useEffect(() => {
		if (!hasIncurredTriangleWatcherInitialized.current) {
			hasIncurredTriangleWatcherInitialized.current = true;
			previousPaidTriangleRef.current = paidTriangle;
			previousIncurredTriangleRef.current = incurredTriangle;
			return;
		}

		const hasPaidTriangleChanged = previousPaidTriangleRef.current !== paidTriangle;
		const hasIncurredTriangleChanged = previousIncurredTriangleRef.current !== incurredTriangle;
		previousPaidTriangleRef.current = paidTriangle;
		previousIncurredTriangleRef.current = incurredTriangle;

		if (!hasPaidTriangleChanged && !hasIncurredTriangleChanged) {
			return;
		}

		clearSimulationResults();
		clearStatisticsResults();
		resetCLSimulationStore();
		setMethodType('multiplikatywna');
	}, [
		paidTriangle,
		incurredTriangle,
		clearSimulationResults,
		clearStatisticsResults,
		resetCLSimulationStore,
	]);

	useEffect(() => {
		if (!isCurrentMethodUnavailable) {
			return;
		}

		if (showMultiplikatywna) {
			setMethodType('multiplikatywna');
			return;
		}

		if (showAddytywna) {
			setMethodType('addytywna');
			return;
		}

		if (showMix) {
			setMethodType('mix');
		}
	}, [
		isCurrentMethodUnavailable,
		showMultiplikatywna,
		showAddytywna,
		showMix,
	]);

	const simulationEndpoint = useMemo(() => {
		if (methodType === 'multiplikatywna') return '/calc/incurred/simulation';
		if (methodType === 'addytywna') return '/calc/incurred/simulationaddytywna';
		return '/calc/incurred/simulation';
	}, [methodType]);

	const statisticsEndpoint = useMemo(() => {
		if (methodType === 'multiplikatywna') return '/calc/incurred/statistic';
		return '/calc/statisticClIncurred';
	}, [methodType]);

	return (
		<ClSimulationIncurred
			simulationEndpoint={simulationEndpoint}
			statisticsEndpoint={statisticsEndpoint}
			methodType={methodType}
			tableVariant="paid"
			topContent={
				<div className="space-y-4">
					<div className="space-y-3 rounded-lg bg-gray-800 p-3">
						<label className="mb-1 block text-sm font-medium text-white">Wybór metody:</label>
						<div className="space-y-2">
							<label className={`flex items-center gap-2 text-sm font-medium ${isMultiplikatywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'multiplikatywna'}
								onChange={() => setMethodType('multiplikatywna')}
								disabled={isMultiplikatywnaDisabled}
								className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
							/>
							<span>Multiplikatywna</span>
						</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isAddytywnaDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'addytywna'}
								onChange={() => setMethodType('addytywna')}
								disabled={isAddytywnaDisabled}
								className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
							/>
							<span>Addytywna</span>
						</label>
							<label className={`flex items-center gap-2 text-sm font-medium ${isMixDisabled ? 'cursor-not-allowed text-gray-500' : 'cursor-pointer text-gray-200'}`}>
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'mix'}
								onChange={() => setMethodType('mix')}
								disabled={isMixDisabled}
								className="accent-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
							/>
							<span>Mix metod</span>
						</label>
						</div>
					</div>

					<hr className="border-gray-600" />
				</div>
			}
		/>
	);
}
