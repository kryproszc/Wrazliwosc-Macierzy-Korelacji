"use client"

import React, { useEffect, useMemo } from "react"
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddIncurredSDSummaryTab() {
  const leftCount = useAddIncurredCoefficientsStore(s => s.leftCountAddSD)
  const setLeftCount = useAddIncurredCoefficientsStore(s => s.setLeftCountAddSD)
  const selectedCurve = useAddIncurredCoefficientsStore(s => s.selectedCurveAddSD)
  const setSelectedCurve = useAddIncurredCoefficientsStore(s => s.setSelectedCurveAddSD)
  const manualOverrides = useAddIncurredCoefficientsStore(s => s.manualOverridesAddSD)
  const setManualOverrides = useAddIncurredCoefficientsStore(s => s.setManualOverridesAddSD)
  const sourceSwitches = useAddIncurredCoefficientsStore(s => s.sourceSwitchesAddSD)
  const setSourceSwitches = useAddIncurredCoefficientsStore(s => s.setSourceSwitchesAddSD)
  const baseData = useAddIncurredCoefficientsStore(s => s.sdLR)
  const rawSimResults = useAddIncurredCoefficientsStore(s => s.sdLR)
  const setCombinedData = useAddIncurredCoefficientsStore(s => s.setCombinedAddSDSummary)

  const transformedBaseData = useMemo(() => baseData, [baseData])

  useEffect(() => {
    const initialSelectionLength = transformedBaseData?.length ?? 0
    if (leftCount <= 0 && initialSelectionLength > 0) {
      setLeftCount(initialSelectionLength)
    }
  }, [transformedBaseData, leftCount, setLeftCount])

  const simResults = useMemo(() => {
    if (!rawSimResults || !Array.isArray(rawSimResults)) return undefined
    const sdLRData = Object.fromEntries(
      rawSimResults.map((value: number, index: number) => [`k: ${index + 1}`, value])
    )
    return { "se_pred": sdLRData }
  }, [rawSimResults])

  const rawIncurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels)
  const incurredColumnLabels = useMemo(() => ["", ...rawIncurredColumnLabels], [rawIncurredColumnLabels])

  if (!transformedBaseData?.length || !simResults) {
    return (
      <div className="p-6 text-gray-300">
        <p className="mb-2">Brak danych do podsumowania SD.</p>
        <p className="text-sm text-gray-400">
          Przejdź do kroku 2 „Współczynniki Add” i kliknij „Oblicz”, aby wygenerować dane SD.
        </p>
      </div>
    )
  }

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={transformedBaseData || undefined}
      simResults={simResults}
      setCombinedDevJ={setCombinedData}
      columnLabels={incurredColumnLabels}
      onRemainingDevJHeaders={() => {}}
      disabledCurves={[]}
      tableContext='AddSD'
      useClassicStyle={true}
      lockExponentialWeighted={true}
    />
  )
}
