'use client';

import { FitCurvePageLayout } from '@/shared/components/fit-curve/FitCurvePageLayout';
import { ADD_J_CONFIG } from '@/shared/components/fit-curve/configs';
import { useFitCurveData } from '@/shared/hooks/useFitCurveData';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';

const ADD_J_INCURRED_BASE_DATA: string[] = ['addJ', 'sigmaLR', 'sdLR'];
const ADD_J_INCURRED_FINAL_DATA: string[] = ['finalAddJ'];
const ADD_J_INCURRED_CLEAR_METHODS: string[] = ['clearSimResultsAddJ', 'clearR2ScoresAddJ'];

const ADD_J_INCURRED_STORE_MAPPING = {
  preview: 'addJPreview',
  previewCandidate: 'addJPreviewCandidate',
  selectedIndexes: 'selectedAddJIndexes',
  simResults: 'simResultsAddJ',
  r2Scores: 'r2ScoresAddJ',
  tailCount: 'tailCountAddJ',
  finalCustom: 'addJFinalCustom',
  baseData: ADD_J_INCURRED_BASE_DATA,
  finalData: ADD_J_INCURRED_FINAL_DATA,
  clearMethods: ADD_J_INCURRED_CLEAR_METHODS,
  setMethods: {
    setPreview: 'setAddJPreview',
    setPreviewCandidate: 'setAddJPreviewCandidate',
    setSelectedIndexes: 'setSelectedAddJIndexes',
    setSimResults: 'setSimResultsAddJ',
    setR2Scores: 'setR2ScoresAddJ',
    setTailCount: 'setTailCountAddJ',
  },
} as const;

const ADD_J_INCURRED_CONFIG = {
  ...ADD_J_CONFIG,
  apiEndpoint: '/calc/add/selected_add_j_incurred',
  displayName: 'Add J Incurred',
  noDataMessage:
    'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Add" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Add J Incurred',
  modalMessage:
    'Czy na pewno chcesz zaktualizować wektor Add J Incurred?\nObliczenia w kolejnych zakładkach zostaną utracone.',
};

export default function FitCurveAddJIncurred() {
  const fitCurveProps = useFitCurveData({
    config: ADD_J_INCURRED_CONFIG,
    storeMapping: ADD_J_INCURRED_STORE_MAPPING,
    useStore: useAddIncurredCoefficientsStore,
  });

  return (
    <FitCurvePageLayout
      config={ADD_J_INCURRED_CONFIG}
      {...fitCurveProps}
    />
  );
}
