'use client';

import { FitCurvePageLayout } from '@/shared/components/fit-curve/FitCurvePageLayout';
import { SIGMA_LR_CONFIG } from '@/shared/components/fit-curve/configs';
import { useFitCurveData } from '@/shared/hooks/useFitCurveData';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';

const SIGMA_LR_INCURRED_BASE_DATA: string[] = ['sigmaLR', 'addJ', 'sdLR'];
const SIGMA_LR_INCURRED_FINAL_DATA: string[] = ['finalSigmaLR'];
const SIGMA_LR_INCURRED_CLEAR_METHODS: string[] = ['clearSimResultsSigmaLR', 'clearR2ScoresSigmaLR'];

const SIGMA_LR_INCURRED_STORE_MAPPING = {
  preview: 'sigmaLRPreview',
  previewCandidate: 'sigmaLRPreviewCandidate',
  selectedIndexes: 'selectedSigmaLRIndexes',
  simResults: 'simResultsSigmaLR',
  r2Scores: 'r2ScoresSigmaLR',
  tailCount: 'tailCountSigmaLR',
  finalCustom: 'sigmaLRFinalCustom',
  baseData: SIGMA_LR_INCURRED_BASE_DATA,
  finalData: SIGMA_LR_INCURRED_FINAL_DATA,
  clearMethods: SIGMA_LR_INCURRED_CLEAR_METHODS,
  setMethods: {
    setPreview: 'setSigmaLRPreview',
    setPreviewCandidate: 'setSigmaLRPreviewCandidate',
    setSelectedIndexes: 'setSelectedSigmaLRIndexes',
    setSimResults: 'setSimResultsSigmaLR',
    setR2Scores: 'setR2ScoresSigmaLR',
    setTailCount: 'setTailCountSigmaLR',
  },
} as const;

const SIGMA_LR_INCURRED_CONFIG = {
  ...SIGMA_LR_CONFIG,
  apiEndpoint: '/calc/add/selected_sigma_LR_incurred',
  displayName: 'Sigma LR Incurred',
  noDataMessage:
    'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Add" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma LR Incurred',
  modalMessage:
    'Czy na pewno chcesz zaktualizować wektor Sigma LR Incurred?\nObliczenia w kolejnych zakładkach zostaną utracone.',
};

export default function FitCurveSigmaLRIncurred() {
  const fitCurveProps = useFitCurveData({
    config: SIGMA_LR_INCURRED_CONFIG,
    storeMapping: SIGMA_LR_INCURRED_STORE_MAPPING,
    useStore: useAddIncurredCoefficientsStore,
  });

  return (
    <FitCurvePageLayout
      config={SIGMA_LR_INCURRED_CONFIG}
      {...fitCurveProps}
    />
  );
}
