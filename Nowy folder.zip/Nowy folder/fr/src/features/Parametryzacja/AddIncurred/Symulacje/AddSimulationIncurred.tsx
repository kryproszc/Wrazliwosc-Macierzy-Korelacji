'use client';

export function AddSimulationIncurred() {
  return (
    <div className="p-6 rounded-lg border border-slate-700 bg-slate-900 text-slate-200">
      Addytywna Incurred — Symulacje (szkielet).
    </div>
  );
}
