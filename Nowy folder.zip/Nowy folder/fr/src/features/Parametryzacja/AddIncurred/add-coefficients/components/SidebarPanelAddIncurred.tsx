'use client';

import { useEffect, useState } from 'react';
import { Maximize2, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Modal from '@/components/Modal';
import { exportAddIncurredToExcel } from '@/untils/exportToExcel';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import { useAddIncurredStore } from '@/stores/addIncurredStore';
import { useDeterministicIncurredResultsStore } from '@/stores/deterministicIncurredResultsStore';

type Props = {
  decimalPlaces: number;
  setDecimalPlaces: (places: number) => void;
  volume: number;
  setVolume: (volume: number) => void;
  maxVolume: number;
  minMaxHighlighting: boolean;
  toggleMinMax: () => void;
  tableScale: number;
  increaseScale: () => void;
  decreaseScale: () => void;
  onOpenFullscreen: () => void;
  onCalculate: () => void;
};

export default function SidebarPanelAddIncurred({
  decimalPlaces,
  setDecimalPlaces,
  volume,
  setVolume,
  maxVolume,
  minMaxHighlighting,
  toggleMinMax,
  tableScale,
  increaseScale,
  decreaseScale,
  onOpenFullscreen,
  onCalculate,
}: Props) {
  const [resetOpen, setResetOpen] = useState(false);
  const { devJ, sigma, sd, clearCalculationResults } = useAddIncurredCoefficientsStore();
  const resetAddIncurredData = useAddIncurredStore((s) => s.resetData);
  const clearDeterministicIncurredResults = useDeterministicIncurredResultsStore((s) => s.clearResults);

  useEffect(() => {
    if (volume < 1 || volume > 20) {
      setVolume(20);
    }
  }, [setVolume, volume]);

  const handleExport = () => {
    exportAddIncurredToExcel([
      { label: 'LR', values: devJ ?? [] },
      { label: 'sigma', values: sigma ?? [] },
      { label: 'sd', values: sd ?? [] },
    ]);
  };

  return (
    <div className="w-48 shrink-0 space-y-4">
      <div className="space-y-4 rounded-lg bg-gray-800 p-3">
        <div className="mb-2 text-sm font-medium text-white">Ustawienia wyświetlania</div>

        <div>
          <label className="mb-1 block text-xs font-medium text-white">Rozmiar tabeli</label>
          <div className="flex items-center gap-2">
            <Button
              onClick={decreaseScale}
              variant="outline"
              size="sm"
              className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
              disabled={tableScale <= 0.5}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="min-w-[3rem] text-center text-sm text-white">
              {Math.round(tableScale * 100)}%
            </span>
            <Button
              onClick={increaseScale}
              variant="outline"
              size="sm"
              className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
              disabled={tableScale >= 2.0}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Button
          onClick={onOpenFullscreen}
          size="sm"
          className="mx-auto h-8 w-40 bg-blue-600 text-xs text-white hover:bg-blue-700"
        >
          <Maximize2 className="mr-2 h-3.5 w-3.5" />
          Pełny ekran
        </Button>

        <div>
          <label htmlFor="add-incurred-decimal-places" className="mb-2 block text-xs font-medium text-white">Miejsca po przecinku</label>
          <input
            id="add-incurred-decimal-places"
            type="number"
            min={0}
            max={10}
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces(Number(e.target.value))}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="add-incurred-volume" className="mb-2 block text-xs font-medium text-white">Wybierz volume</label>
          <input
            id="add-incurred-volume"
            type="number"
            min={1}
            max={20}
            value={volume}
            onChange={(e) => {
              const nextValue = e.currentTarget.valueAsNumber;
              if (Number.isFinite(nextValue)) {
                setVolume(Math.min(20, Math.max(1, nextValue)));
              }
            }}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="flex w-full flex-col gap-3">
        <button
          onClick={onCalculate}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl"
        >
          Oblicz
        </button>
        <button
          onClick={handleExport}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl"
        >
          Eksportuj do Excela
        </button>
        <button
          onClick={() => setResetOpen(true)}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-orange-700 hover:to-orange-600 hover:shadow-2xl"
        >
          Reset współczynników
        </button>
      </div>

      <Modal
        isOpen={resetOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki Add Incurred? Ta operacja jest nieodwracalna."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          clearCalculationResults();
          resetAddIncurredData();
          clearDeterministicIncurredResults();
          setVolume(20);
          setResetOpen(false);
        }}
      />

      <button
        onClick={toggleMinMax}
        className={`block h-8 w-full rounded-lg px-3 text-xs font-medium text-white transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700'
            : 'bg-gray-600 hover:bg-gray-700'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>
    </div>
  );
}
