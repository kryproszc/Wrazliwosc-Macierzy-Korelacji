'use client';

import { useMemo } from 'react';

interface Props {
  data: (string | number)[][];
  weights?: number[][];
  selectedCells?: [number, number][];
  minCells?: [number, number][];
  maxCells?: [number, number][];
  decimalPlaces: number;
  onToggleWeightCell?: (r: number, c: number) => void;
  onToggleRow?: (rowIndex: number) => void;
  showRowToggle?: boolean;
}

export default function TableDataAddIncurred({
  data,
  weights,
  minCells = [],
  maxCells = [],
  decimalPlaces,
  onToggleWeightCell,
  onToggleRow,
  showRowToggle = false,
}: Props) {
  const formatNumber = (cell: string | number): string => {
    if (typeof cell === 'number') {
      return cell.toFixed(decimalPlaces);
    }
    if (typeof cell === 'string' && !Number.isNaN(Number(cell)) && cell !== '') {
      return Number(cell).toFixed(decimalPlaces);
    }
    return String(cell);
  };

  const rowSelectionStates = useMemo(() => {
    if (!weights || !data) return new Map<number, boolean>();
    const states = new Map<number, boolean>();

    for (let i = 1; i < data.length; i += 1) {
      const weightRow = weights[i - 1];
      const dataRow = data[i];
      if (!weightRow || !dataRow) {
        states.set(i, false);
        continue;
      }

      let hasAnyData = false;
      let allSelected = true;
      for (let j = 1; j < dataRow.length; j += 1) {
        const cell = dataRow[j];
        const hasData = cell !== null && cell !== undefined && cell !== '';
        if (hasData) {
          hasAnyData = true;
          if (weightRow[j - 1] !== 1) {
            allSelected = false;
            break;
          }
        }
      }

      states.set(i, hasAnyData && allSelected);
    }

    return states;
  }, [weights, data]);

  return (
    <div className="overflow-x-auto bg-white rounded-xl border border-gray-300">
      <table className="min-w-full text-sm border-collapse">
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              {showRowToggle && (
                <td className="p-2 text-center bg-gray-100 border border-gray-300">
                  {i === 0 ? (
                    <span className="text-gray-800 font-semibold text-xs">Cały wiersz</span>
                  ) : (
                    <input
                      type="checkbox"
                      checked={rowSelectionStates.get(i) || false}
                      onChange={() => onToggleRow?.(i - 1)}
                      className="w-4 h-4 text-blue-600 bg-white border-gray-400 rounded focus:ring-blue-500 focus:ring-2 cursor-pointer"
                    />
                  )}
                </td>
              )}

              {row.map((cell, j) => {
                const isHeader = i === 0 || j === 0;
                const hasData = !isHeader && cell !== null && cell !== undefined && cell !== '';
                const isMin = minCells.some(([r, c]) => r === i && c === j);
                const isMax = maxCells.some(([r, c]) => r === i && c === j);
                const enabled = hasData && weights?.[i - 1]?.[j - 1] === 1;

                const cellStyle = isHeader
                  ? 'bg-gray-200 text-gray-900 font-semibold'
                  : enabled
                    ? 'bg-white text-gray-900'
                    : hasData
                      ? 'bg-gray-200 text-gray-500'
                      : 'bg-gray-100 text-gray-500';

                const borderStyle = isMin
                  ? 'border-4 border-green-500'
                  : isMax
                    ? 'border-4 border-red-500'
                    : 'border border-gray-300';

                return (
                  <td
                    key={j}
                    className={`p-2 text-center transition-all duration-200 ${cellStyle} ${borderStyle} ${hasData ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                    onClick={hasData ? () => onToggleWeightCell?.(i - 1, j - 1) : undefined}
                  >
                    {isHeader ? cell : formatNumber(cell)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
