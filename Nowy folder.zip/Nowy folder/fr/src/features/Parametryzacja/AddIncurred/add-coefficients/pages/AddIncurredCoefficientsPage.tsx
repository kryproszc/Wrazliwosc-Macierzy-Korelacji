'use client';

import React, { useState } from 'react';
import { useAddIncurredCL } from '../hooks/useAddIncurred';
import SidebarPanelAddIncurred from '../components/SidebarPanelAddIncurred';
import TableDataAddIncurred from '../components/TableDataAddIncurred';
import { useAddIncurredStore } from '@/stores/addIncurredStore';
import { useDisplaySettingsAddIncurredStore } from '@/stores/useDisplaySettingsAddIncurredStore';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import CalculationPageLayout from '@/shared/components/calculation-tables/CalculationPageLayout';
import type { ResultRow } from '@/shared/components/calculation-tables/ResultsTable';

export default function AddIncurredCoefficientsPage() {
  const rowLabelsStore = useAddIncurredStore((s) => s.rowLabels);
  const columnLabelsStore = useAddIncurredStore((s) => s.columnLabels);

  const fullscreenMode = useDisplaySettingsAddIncurredStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsAddIncurredStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsAddIncurredStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsAddIncurredStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsAddIncurredStore((s) => s.decreaseScale);

  const decimalPlaces = useAddIncurredCoefficientsStore((s) => s.decimalPlacesAddIncurred);
  const setDecimalPlaces = useAddIncurredCoefficientsStore((s) => s.setDecimalPlacesAddIncurred);

  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    volumeAddIncurred,
    toggleRowAdd,
    toggleWeightCellAddIncurred,
    setMinMaxHighlighting,
    setVolumeAddIncurred,
    runSigma,
    isLoading,
  } = useAddIncurredCL();

  const handleCloseFullscreen = () => {
    setIsClosing(true);
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300);
  };

  const expectedColumnCount = trainDevide?.[0]?.length || 0;
  const labelsFromStore =
    columnLabelsStore.length > 1
      ? columnLabelsStore.slice(1, 1 + expectedColumnCount)
      : [];

  const coeffHeaderLabels =
    labelsFromStore.length === expectedColumnCount
      ? labelsFromStore
      : Array.from({ length: expectedColumnCount }, (_, i) => String(i + 1));

  const rowLabelAt = (i: number) => rowLabelsStore[i] ?? String(i + 1);

  const tableData = trainDevide?.length
    ? [
        [''].concat(coeffHeaderLabels),
        ...trainDevide.map((row, i) => [
          rowLabelAt(i),
          ...row.map((c) => (c == null ? '' : c.toString())),
        ]),
      ]
    : [];

  const resultRows: ResultRow[] = [
    { label: 'LR', values: devJ || [], visible: !!devJ },
    { label: 'sigma', values: sigma || [], visible: !!sigma },
    { label: 'sd', values: sd || [], visible: !!sd },
  ];

  return (
    <CalculationPageLayout
      title="Tabela współczynników rok do roku"
      isLoading={isLoading}
      loadingMessage="⏳ Oczekiwanie na dane wejściowe incurredTriangle…"
      noDataMessage="Brak wyników 😢"
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={rowLabelsStore}
      hasData={!!triangle?.length && !!trainDevide?.length}
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxCells}
      minCells={minCells}
      maxCells={maxCells}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowAdd}
      onToggleWeightCell={toggleWeightCellAddIncurred}
      tableComponent={(props: any) => <TableDataAddIncurred {...props} decimalPlaces={decimalPlaces} />}
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń"
      decimalPlaces={decimalPlaces}
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      showTopScaleControls={false}
      volume={volumeAddIncurred}
      onVolumeChange={setVolumeAddIncurred}
      onCalculate={runSigma}
      calculateLabel="Oblicz"
      sidebar={
        <SidebarPanelAddIncurred
          decimalPlaces={decimalPlaces}
          setDecimalPlaces={setDecimalPlaces}
          volume={volumeAddIncurred}
          setVolume={setVolumeAddIncurred}
          maxVolume={Math.max(1, trainDevide?.length ?? 0, trainDevide?.[0]?.length ?? 0)}
          minMaxHighlighting={minMaxHighlighting}
          toggleMinMax={() => setMinMaxHighlighting(!minMaxHighlighting)}
          tableScale={tableScale}
          increaseScale={increaseScale}
          decreaseScale={decreaseScale}
          onOpenFullscreen={() => setFullscreenMode(true)}
          onCalculate={runSigma}
        />
      }
    />
  );
}
