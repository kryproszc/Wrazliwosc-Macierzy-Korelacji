'use client';

import React, { useEffect } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useAddIncurredStore } from '@/stores/addIncurredStore';
import { TriangleTableView } from '@/shared/components/TriangleTableView';

const DEFAULT_TRIANGLE_SCALE = 0.8;

export function IncurredTriangleView() {
  const sourceTriangle = useTrainDevideStoreIncurred((s) => s.incurredTriangle);
  const sourceRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const sourceColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  const triangle = useAddIncurredStore((s) => s.incurredTriangle);
  const rowLabels = useAddIncurredStore((s) => s.rowLabels);
  const columnLabels = useAddIncurredStore((s) => s.columnLabels);
  const setTriangleSnapshot = useAddIncurredStore((s) => s.setTriangleSnapshot);

  useEffect(() => {
    const clonedTriangle = sourceTriangle
      ? sourceTriangle.map((row) => row.map((cell) => cell))
      : null;

    setTriangleSnapshot(clonedTriangle, [...sourceRowLabels], [...sourceColumnLabels]);
  }, [sourceTriangle, sourceRowLabels, sourceColumnLabels, setTriangleSnapshot]);

  return (
    <div className="min-h-0 overflow-x-auto pb-2">
      <div
        style={{
          zoom: DEFAULT_TRIANGLE_SCALE,
          width: `${100 / DEFAULT_TRIANGLE_SCALE}%`,
        }}
      >
        <TriangleTableView
          title="Trójkąt Incurred"
          triangle={triangle ?? undefined}
          noDataMessage="Brak danych trójkąta Incurred. Przejdź do zakładki 'Wprowadź dane' aby załadować dane incurred."
          withNumericHeaders={true}
          rowLabels={rowLabels}
          columnLabels={columnLabels}
          className="space-y-4"
          variant="light"
        />
      </div>
    </div>
  );
}

export default IncurredTriangleView;
