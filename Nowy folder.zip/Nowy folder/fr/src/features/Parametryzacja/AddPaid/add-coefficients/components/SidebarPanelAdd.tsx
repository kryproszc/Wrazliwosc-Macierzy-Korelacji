'use client';

import { useEffect, useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useAddPaidStore } from '@/stores/addPaidStore';
import { useAddPaidResultsStore } from '@/stores/addPaidResultsStore';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import SidebarPanelBase from '@/shared/ui/molecules/SidebarPanelBase'
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
  maxVolume?: number;
  onVolumeChange?: (volume: number) => void;
};

export default function SidebarPanelAdd({ onCalculate, className, maxVolume, onVolumeChange }: Props) {
  // GŁÓWNY STORE - volume, decimalPlaces (tak jak MultPaid)
  const mainStore = useTrainDevideStoreDet();
  // ADDPAID STORE - wyniki i ustawienia specyficzne dla AddPaid
  const addStore = useAddCoefficientsStore();
  const addPaidStore = useAddPaidStore();
  const addPaidResultsStore = useAddPaidResultsStore();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  // Z głównego store tylko decimalPlaces (wspólne formatowanie)
  const { decimalPlaces, setDecimalPlaces } = mainStore;
  // Z AddPaid store niezależny volume
  const { volumeAdd, setVolumeAdd } = addStore;
  
  // Użyj zewnętrznego handlera volume jeśli został przekazany
  const effectiveVolumeHandler = onVolumeChange || setVolumeAdd;

  useEffect(() => {
    if (volumeAdd < 1 || volumeAdd > 20) {
      effectiveVolumeHandler(20);
    }
  }, [effectiveVolumeHandler, volumeAdd]);
  
  // Z AddPaid store - wszystko inne
  const {
    clearCalculationResults,
    clearDevJResults,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearSigmaResults,
    setFinalSigma,
    clearAllSigmaFinalValues,
    clearFitCurveData,
    clearDevSummaryData,
    clearAllWeights,
    openMissingFinalModal,
    isMissingFinalModalOpen,
    closeMissingFinalModal,
    finalDevJ,
    finalDevVector,
    devFinalCustom,
    devJResults,
    trainDevideAdd,
    minMaxHighlighting,
    setMinMaxHighlighting,
  } = addStore;

  const overrides = Object.entries(devFinalCustom).map(([idx, c]) => ({
    index: +idx,
    curve: c.curve,
    value: c.value,
  }));

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector || undefined, overrides);
  };

  const handleReset = () => {
    effectiveVolumeHandler(20);
    clearCalculationResults();
    clearDevJResults();
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearSigmaResults();
    setFinalSigma(undefined);
    clearAllSigmaFinalValues();
    clearFitCurveData();
    clearDevSummaryData();
    clearAllWeights(); // Resetuj zaznaczenia w tabeli współczynników

    // Wyczyść też kolejne kroki AddPaid (FitCurve/Summary/Wyniki)
    addPaidStore.resetData();
    addPaidResultsStore.clearResults();
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-48 shrink-0 space-y-4 ${className ?? ''}`}>
      <div className="space-y-4 rounded-lg bg-gray-800 p-3">
        <div className="mb-2 text-sm font-medium text-white">
          Ustawienia wyświetlania
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-white">
            Rozmiar tabeli
          </label>
          <ScaleControls />
        </div>

        <Button
          onClick={() => setFullscreenMode(true)}
          size="sm"
          className="mx-auto h-8 w-40 bg-blue-600 text-xs text-white hover:bg-blue-700"
        >
          <Maximize2 className="mr-2 h-3.5 w-3.5" />
          Pełny ekran
        </Button>

        <div>
          <label htmlFor="add-paid-decimal-places" className="mb-2 block text-xs font-medium text-white">
            Miejsca po przecinku
          </label>
          <input
            id="add-paid-decimal-places"
            type="number"
            min="0"
            max="10"
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces(Number(e.target.value))}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="add-paid-volume" className="mb-2 block text-xs font-medium text-white">
            Wybierz volume
          </label>
          <input
            id="add-paid-volume"
            type="number"
            min={1}
            max={20}
            value={volumeAdd}
            onChange={(e) => {
              const nextValue = e.currentTarget.valueAsNumber;
              if (Number.isFinite(nextValue)) {
                effectiveVolumeHandler(Math.min(20, Math.max(1, nextValue)));
              }
            }}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <SidebarPanelBase
        volume={volumeAdd}
        onVolumeChange={effectiveVolumeHandler}
        maxVolume={maxVolume}
        showVolume={false}
        fullWidthActions
        onCalculate={onCalculate}
        onExport={handleExport}
        onReset={handleReset}
        isResetModalOpen={resetOpen}
        setResetModalOpen={setResetOpen}
        isMissingFinalModalOpen={isMissingFinalModalOpen}
        closeMissingFinalModal={closeMissingFinalModal}
      />

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`block h-8 w-full rounded-lg px-3 text-xs font-medium text-white transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700'
            : 'bg-gray-600 hover:bg-gray-700'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>
    </div>
  );
}