/* ------------------------------------------------------------------ */
/*                   CL Summary Configuration (Incurred)              */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred'

export const clSummaryIncurredConfig: SummaryConfig = {
  tableContext: 'CL (Incurred)',
  useClassicStyle: true,
  lockExponentialWeighted: true,
  
  // Store hook - używamy Incurred store
  useStore: useTrainDevideStoreIncurred,
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountCL,
  setLeftCountSelector: (s) => s.setLeftCountCL,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveSummary,
  setSelectedCurveSelector: (s) => s.setSelectedCurveSummary,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesSummary,
  setManualOverridesSelector: (s) => s.setManualOverridesSummary,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesSummary,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesSummary,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.devJPreview,
  simResultsSelector: (s) => s.simResults,
  assignRangeStateSelector: (s) => s.assignRangeStateCL,
  setAssignRangeStateSelector: (s) => s.setAssignRangeStateCL,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedDevJSummary,
  
  // Store selectors - pozostałe
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders,
  
  // Brak transformacji dla CL - dane używane bezpośrednio
  disabledCurves: [],
  debugLabel: undefined
}