// features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred.tsx
'use client';

import { useMemo, useState, type ReactNode } from 'react';
import { Loader2 } from 'lucide-react';
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { exportStatisticsToExcel } from '../../../../untils/exportToExcel';
import { useTrainDevideStoreDet } from '../../../../stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreIncurred } from '../../../../stores/useTrainDevideStoreIncurred';
import { useAddIncurredCoefficientsStore } from '../../../../stores/addIncurredCoefficientsStore';
import { useAddPaidStore } from '../../../../stores/addPaidStore';
import { useSimulationResultsStore } from '../../../../stores/simulationResultsStore';
import { useCombinedSDSummary } from '../hooks/useCombinedSDSummary';
import { useSelectedValuesSD } from '../hooks/useSelectedValuesSD';
import { useParamsymStore } from '../../../../stores/paramsymStore';
import { useDiscountRatesStore } from '../../../../stores/discountRatesStore';
import { useChainLadderResultsStore } from '../../../../stores/chainLadderResultsStore';
import { useExposureStore } from '../../../../stores/exposureStore';
import { useUserStore } from '../../../../app/_components/useUserStore';
import { useDeterministicIncurredResultsStore } from '../../../../stores/deterministicIncurredResultsStore';

// Import store dla symulacji incurred (podobny do useCLSimulationStore ale dla incurred)
import { useCLSimulationStore } from '../../../../stores/clSimulationStore';

// 🎯 IMPORTY REUŻYWALNYCH KOMPONENTÓW (dokładnie jak w ClSimulationPaid)
import {
  SimulationLayout,
  SimulationControlPanel,
  SimulationStatisticsTable,
  type DataAvailabilityStatus,
  type SimulationParams
} from '../../../../shared/components/Symulacje';
import { EmptyState } from '../../../../shared/components/calculation';
import { DataTableView } from '../../../../shared/ui/molecules/DataTableView';

import {
  useSimulationApi,
  type AlertState,
  type SimulationRequestData
} from '../../../../shared/hooks';

import {
  validateVectorLengths,
  checkDataAvailability,
  getCalculationOptions,
  prepareSelectedValueCL,
  prepareSelectedValueSigma,
  prepareCombinedSDSummary,
  processNetBruttoParams,
  processDiscountRates,
  parseQuantiles
} from '../../../../shared/utils';

interface ClSimulationIncurredProps {
  simulationEndpoint?: string;
  statisticsEndpoint?: string;
  methodType?: 'multiplikatywna' | 'addytywna' | 'mix';
  topContent?: ReactNode;
  tableVariant?: 'default' | 'paid';
}

export function ClSimulationIncurred({
  simulationEndpoint = '/calc/incurred/simulation',
  statisticsEndpoint = '/calc/incurred/statistic',
  methodType = 'multiplikatywna',
  topContent,
  tableVariant = 'default'
}: ClSimulationIncurredProps = {}) {
  const effectiveSimulationEndpoint = methodType === 'addytywna'
    ? '/calc/incurred/simulationaddytywna'
    : simulationEndpoint;
  // State dla modali (jak w ClSimulationPaid)
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'success',
    title: '',
    message: ''
  });

  // API Hook
  const { executeSimulation, executeStatistics, isCalculating, isCalculatingStatistics } = useSimulationApi();

  // Stores dla symulacji incurred
  const {
    simulationParams,
    kwantyle,
    statisticsResults,
    updateSimulationParam,
    setKwantyle,
    setStatisticsResults,
  } = useCLSimulationStore();

  const { 
    results: simulationResults, 
    setResults, 
    clearResults, 
  } = useSimulationResultsStore();

  const hasResults = simulationResults !== null;

  const lightStatisticsTableData = useMemo(() => {
    if (!Array.isArray(statisticsResults) || statisticsResults.length === 0) {
      return null;
    }

    const formatValue = (value: unknown) => {
      if (typeof value !== 'number' || !Number.isFinite(value)) return '-';
      return value.toLocaleString('pl-PL', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).replace(/\u00A0/g, ' ');
    };

    const parsedQuantiles = parseQuantiles(kwantyle);
    const headers = ['METRYKA', ...statisticsResults.map((stat: any, idx: number) => String(stat?.column ?? `Kolumna ${idx + 1}`))];
    const rows: string[][] = [headers];

    rows.push([
      'Średnia',
      ...statisticsResults.map((stat: any) => formatValue(stat?.mean)),
    ]);
    rows.push([
      'Odch. std.',
      ...statisticsResults.map((stat: any) => formatValue(stat?.std)),
    ]);
    rows.push([
      'SCR',
      ...statisticsResults.map((stat: any) => formatValue(stat?.SCR)),
    ]);

    parsedQuantiles.forEach((q, qIdx) => {
      rows.push([
        `Q${(q * 100).toFixed(1)}%`,
        ...statisticsResults.map((stat: any) => formatValue(stat?.quantiles?.[qIdx])),
      ]);
    });

    return rows;
  }, [statisticsResults, kwantyle]);

  // Prawdziwe dane ze store'ów - użyj właściwych store'ów jak w determinMethodCLrj.tsx
  const { paidTriangle } = useTrainDevideStoreDet(); // Paid z MultPaid store
  const {
    selectedAddJIndexes,
    selectedSigmaLRIndexes,
    leftCountAddLR,
    tailCountAddJ,
    addJ,
    sigmaLR,
    sdLR,
    combinedAddLRSummary,
    combinedAddSigmaSummary,
    combinedAddSDSummary,
    selectedWeightsAddIncurred,
    trainDevideAddIncurred,
  } = useAddIncurredCoefficientsStore();

  const selectedValuesAddLR = useAddPaidStore((s) => s.selectedValuesAddLR);
  const selectedValuesAddSigma = useAddPaidStore((s) => s.selectedValuesAddSigma);

  const { 
    incurredTriangle,
    selectedDevJIndexes,
    selectedSigmaIndexes,
    leftCountCL,
    tailCountCL,
    combinedDevJSummary,
    combinedSigmaSummary,
    devJ,
    selectedValuesCL,
    selectedValuesSigma,
    combinedRJPaidToIncurredSummary,
    rJPaidToIncurredPreview,
    selectedValuesRJPaidToIncurred,
    selectedValuesVarJPaidToIncurred,
    tailCountRJPaidToIncurred,
    tailCountVarJPaidToIncurred,
    leftCountRJPaidToIncurred,
    selectedRJPaidToIncurredIndexes,
    selectedVarJPaidToIncurredIndexes,
    sd,
    combinedSDSummary,
    selectedValuesSD,
    safeWeights,  // 🎯 DODANE - wagi z MultIncurred
    selectedWeightsIncurred,  // 🎯 DODANE - wybrane wagi
    setSafeWeights,  // 🎯 DODANE - setter dla safeWeights
    
    // 🎯 DODANE - wagi PaidToIncurred dla weights_rj_incurred
    selectedWeightsPaidToIncurred,  // Wagi z PaidToIncurred (większa macierz)
    safeWeightsPaidToIncurred,  // Przetworzone wagi PaidToIncurred
    
    // 🎯 DODANE - dane PaidToIncurred dla wysylania
    trainPaidToIncurred,     // Główna tabela z endpointu /calc/paid_incurred/triangles
    resIJPaidToIncurred,     // Tabela res_i_j z PaidToIncurred
    lambdaJPaidToIncurred,   // Wartość lambda_j z PaidToIncurred
    
    // 🎯 DODANE - fallback data dla walidacji
    rJPaidToIncurred,        // r_j aktualne wartości (fallback dla selected_values_rj)
    varJPaidToIncurred,      // var_j aktualne wartości (fallback dla selected_values_varj)
  } = useTrainDevideStoreIncurred(); // Incurred z MultIncurred store
  
  const userId = useUserStore((s: any) => s.userId);
  const deterministicIncurredResults = useDeterministicIncurredResultsStore((s) => s.results);
  
  // Oddzielnie pobierz wyniki deterministyczne (tylko do odczytu)
  const { results: chainLadderResults } = useChainLadderResultsStore();
  
  const { combinedSDSummary: combinedSDSummaryFromHook, getAsNumbers: getSDAsNumbers, hasData: hasSDData } = useCombinedSDSummary();
  const { getAsNumbers: getSelectedValuesSDAsNumbers, hasData: hasSelectedValuesSD } = useSelectedValuesSD();
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);
  const selectedExposureLine = useExposureStore((s) => s.selectedExposureLine);
  const availableExposureLines = useExposureStore((s) => s.availableExposureLines);

  // Sprawdzenie dostępności danych dla Incurred
  const dataAvailability = checkDataAvailability(
    incurredTriangle || [], // Używamy incurred triangle
    getDiscountRatesTriangle,
    getParamsymTriangle
  );

  const calculationOptions = getCalculationOptions(dataAvailability);

  // Przygotuj dane dla DataAvailabilityStatus
  const dataAvailabilityStatus: DataAvailabilityStatus[] = [
    {
      label: 'Trójkąt Paid',
      isAvailable: Boolean(paidTriangle && paidTriangle.length > 0),
      status: (paidTriangle && paidTriangle.length > 0) ? 'Wczytany' : 'Brak danych',
      isRequired: true,
    },
    {
      label: 'Trójkąt Incurred', 
      isAvailable: dataAvailability.paidTriangle, // Tu sprawdzamy incurred (funkcja checkDataAvailability sprawdza pierwszy parametr)
      status: dataAvailability.paidTriangle ? 'Wczytany' : 'Brak danych',
      isRequired: true,
    },
    {
      label: 'Stopy Dyskontowe',
      isAvailable: dataAvailability.discountRates,
      status: dataAvailability.discountRates ? 'Wczytany' : 'Brak danych',
      isRequired: false,
    },
    {
      label: 'Netto/Brutto',
      isAvailable: dataAvailability.nettoBrutto,
      status: dataAvailability.nettoBrutto ? 'Wczytany' : 'Brak danych',
      isRequired: false,
    }
  ];

  // Funkcje pomocnicze
  const showAlert = (state: Partial<AlertState>) => {
    setAlertState(prev => ({ ...prev, ...state, show: true }));
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };


  // Główna funkcja wykonania obliczeń
  const handleExecuteCalculations = async () => {
    // Wyczyść stare wyniki
    clearResults();
    setStatisticsResults([]);
    
    if (!userId) {
      return;
    }

    // Sprawdź podstawowe wymagania
    if (!dataAvailability.paidTriangle) { // Sprawdzamy incurred triangle
      showAlert({
        variant: 'error',
        title: 'Błąd danych',
        message: 'Wymagany trójkąt incurred do wykonania obliczeń'
      });
      return;
    }

    // Pobierz dane z incurred store
    const freshIncurredState = useTrainDevideStoreIncurred.getState();
    const freshDetState = useTrainDevideStoreDet.getState();
    
    // Przygotuj wagi dla Incurred (identycznie jak w ClSimulationPaid)
    let calculatedSafeWeights: number[][];
    if (safeWeights && safeWeights.length > 0) {
      calculatedSafeWeights = safeWeights;
    } else {
      calculatedSafeWeights = selectedWeightsIncurred?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      setSafeWeights(calculatedSafeWeights);
    }

    const isAddytywnaMethod = methodType === 'addytywna';

    const normalizeNumberArray = (arr: any[] | null | undefined, fallback: number[] = []): number[] => {
      if (!Array.isArray(arr) || arr.length === 0) return fallback;
      const parsed = arr
        .map((value) => Number(value))
        .filter((value) => Number.isFinite(value));
      return parsed.length > 0 ? parsed : fallback;
    };

    const alignToTargetLength = (
      preferredValues: number[],
      targetLength: number,
      fallbackValues: any[] | null | undefined = []
    ): number[] => {
      if (targetLength <= 0) return preferredValues;

      const normalizedPreferred = normalizeNumberArray(preferredValues);
      if (normalizedPreferred.length >= targetLength) {
        return normalizedPreferred.slice(0, targetLength);
      }

      const normalizedFallback = normalizeNumberArray(fallbackValues);
      if (normalizedFallback.length === 0) {
        return normalizedPreferred;
      }

      const merged = [...normalizedPreferred];
      for (let index = normalizedPreferred.length; index < targetLength; index += 1) {
        const fallbackValue = normalizedFallback[index];
        if (fallbackValue !== undefined && Number.isFinite(fallbackValue)) {
          merged.push(fallbackValue);
        }
      }

      return merged;
    };

    // Przygotuj wektory z fallbackami dla Incurred - UŻYJ DANYCH Z FINALTABLE
    const multVectorSelectedValueCL = prepareSelectedValueCL(
      freshIncurredState.selectedValuesCL,  // Z FinalTable Selected Values 
      combinedDevJSummary,
      devJ || []
    );

    const multVectorSelectedValueSigma = prepareSelectedValueSigma(
      freshIncurredState.selectedValuesSigma,  // Z FinalTable Selected Values
      combinedSigmaSummary,
      freshIncurredState.sigma || []
    );

    // 🎯 UŻYWAJ selectedValuesSD zamiast hook'ów - to są dane z FinalTable!
    const multVectorCombinedSDSummary = prepareCombinedSDSummary(
      selectedValuesSD || [],  // 🎯 BEZPOŚREDNIO z store (FinalTable Selected Values)
      freshIncurredState.combinedSDSummary || [],
      sd || []
    );

    const addVectorSelectedValueCL = normalizeNumberArray(
      selectedValuesAddLR,
      normalizeNumberArray(combinedAddLRSummary as any[])
    );
    const addTargetLength = addVectorSelectedValueCL.length;
    const addVectorSelectedValueSigma = alignToTargetLength(
      normalizeNumberArray(
        selectedValuesAddSigma,
        normalizeNumberArray(combinedAddSigmaSummary as any[])
      ),
      addTargetLength,
      sigmaLR
    );
    const addVectorCombinedSDSummary = alignToTargetLength(
      normalizeNumberArray(combinedAddSDSummary as any[]),
      addTargetLength,
      sdLR
    );

    const vectorSelectedValueCL = isAddytywnaMethod ? addVectorSelectedValueCL : multVectorSelectedValueCL;
    const vectorSelectedValueSigma = isAddytywnaMethod ? addVectorSelectedValueSigma : multVectorSelectedValueSigma;
    const vectorCombinedSDSummary = isAddytywnaMethod ? addVectorCombinedSDSummary : multVectorCombinedSDSummary;

    const addCalculatedSafeWeights = selectedWeightsAddIncurred?.map((weightRow, rowIndex) =>
      weightRow.map((weight, colIndex) => {
        const trainValue = trainDevideAddIncurred?.[rowIndex]?.[colIndex];
        if (trainValue === null || trainValue === undefined) return 0;
        return weight === 1 ? 1 : 0;
      }),
    ) ?? [];

    const effectiveWeightsIncurred = isAddytywnaMethod ? addCalculatedSafeWeights : calculatedSafeWeights;
    const effectiveSelectedDevIndexes = isAddytywnaMethod ? (selectedAddJIndexes || []) : (selectedDevJIndexes || []);
    const effectiveSelectedSigmaIndexes = isAddytywnaMethod
      ? ((selectedSigmaLRIndexes && selectedSigmaLRIndexes.length > 0 ? selectedSigmaLRIndexes : selectedAddJIndexes) || [])
      : (selectedSigmaIndexes || []);
    const effectiveLeftCountCL = isAddytywnaMethod ? (leftCountAddLR || 0) : (leftCountCL || 0);
    const effectiveTailCountCLRaw = isAddytywnaMethod ? tailCountAddJ : tailCountCL;
    const effectiveTailCountCL = effectiveTailCountCLRaw === "" || effectiveTailCountCLRaw === null || effectiveTailCountCLRaw === undefined
      ? 0
      : Number(effectiveTailCountCLRaw);
    const effectiveSigmaIncurredData = isAddytywnaMethod
      ? normalizeNumberArray(sigmaLR, normalizeNumberArray(freshIncurredState.sigma))
      : (freshIncurredState.sigma || []);
    const effectiveSdIncurredData = isAddytywnaMethod
      ? normalizeNumberArray(sdLR, normalizeNumberArray(sd))
      : (sd || []);

    // Waliduj długości wektorów
    const validation = validateVectorLengths(
      vectorSelectedValueCL,
      vectorSelectedValueSigma,
      vectorCombinedSDSummary
    );

    if (!validation.isValid) {
      showAlert({
        variant: 'error',
        title: 'Błąd długości wektorów',
        message: validation.errorMessage || 'Błąd walidacji wektorów'
      });
      return;
    }

    // Przygotuj pozostałe dane
    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    const exposureLineValues = selectedExposureLine === null
      ? []
      : (availableExposureLines.find((line) => line.index === selectedExposureLine)?.values ?? []);
    const eValues = exposureLineValues
      .map((value) => Number(value))
      .filter((value) => Number.isFinite(value));

    // 🔍 DEBUGGING: Sprawdź dane z FinalTable Selected Values
    console.log('🔍 [INCURRED STORE DATA] selectedValuesSD:', selectedValuesSD);
    console.log('🔍 [INCURRED STORE DATA] selectedValuesCL:', selectedValuesCL);
    console.log('🔍 [INCURRED STORE DATA] selectedValuesSigma:', selectedValuesSigma);
    console.log('🔍 [INCURRED STORE DATA] combinedSDSummary:', combinedSDSummary);
    console.log('🔍 [INCURRED STORE DATA] combinedDevJSummary:', combinedDevJSummary);
    console.log('🔍 [INCURRED STORE DATA] combinedSigmaSummary:', combinedSigmaSummary);
    
    // 🔍 DEBUGGING: Sprawdź co jest w chainLadderResults
    console.log('🔍 [chainLadderResults] PEŁNA STRUKTURA:', chainLadderResults);
    console.log('🔍 [chainLadderResults] KLUCZE:', chainLadderResults ? Object.keys(chainLadderResults) : 'NULL');
    console.log('🔍 [chainLadderResults._incurred] last_col_incurred:', chainLadderResults?.last_col_incurred);
    console.log('🔍 [chainLadderResults._incurred] cum_trian_incurred:', chainLadderResults?.cum_trian_incurred);
    console.log('🔍 [chainLadderResults._incurred] ult_net_disc_incurred:', chainLadderResults?.ult_net_disc_incurred);
    console.log('🔍 [chainLadderResults.metadata] calculationType:', chainLadderResults?.calculationType);
    console.log('🔍 [chainLadderResults.metadata] userId:', chainLadderResults?.userId);

    // 🎯 DEBUG - sprawdź rozmiary macierzy WAG przed utworzeniem requestData
    console.log('🔍 === SPRAWDZENIE ROZMIARÓW MACIERZY WAG ===');
    console.log('calculatedSafeWeights (MultIncurred):', calculatedSafeWeights?.length || 0, 'x', calculatedSafeWeights?.[0]?.length || 0);
    console.log('safeWeightsPaidToIncurred (PaidToIncurred):', safeWeightsPaidToIncurred?.length || 0, 'x', safeWeightsPaidToIncurred?.[0]?.length || 0);
    console.log('selectedWeightsPaidToIncurred (PaidToIncurred):', selectedWeightsPaidToIncurred?.length || 0, 'x', selectedWeightsPaidToIncurred?.[0]?.length || 0);
    
    // Wybierz właściwe wagi dla weights_rj_incurred
    const weightsRjIncurred = safeWeightsPaidToIncurred || selectedWeightsPaidToIncurred || calculatedSafeWeights;
    console.log('weightsRjIncurred (używane dla weights_rj_incurred):', weightsRjIncurred?.length || 0, 'x', weightsRjIncurred?.[0]?.length || 0);
    console.log('🔍 === KONIEC SPRAWDZENIA ===');

    // 🔍 WALIDACJA I FALLBACK SELECTED VALUES PRZED WYSŁANIEM
    console.log('🔍 === WALIDACJA SELECTED VALUES ===');
    
    // Funkcja sprawdzająca czy array jest pusty lub ma NaN/null/undefined
    const isEmptyOrInvalid = (arr: any[]): boolean => {
      if (!Array.isArray(arr) || arr.length === 0) return true;
      return arr.every(val => val == null || isNaN(val) || val === undefined || val === '');
    };

    // 1. Walidacja selected_values_rj_paid_to_incurred
    let finalSelectedValuesRJ = selectedValuesRJPaidToIncurred || [];
    if (isEmptyOrInvalid(finalSelectedValuesRJ)) {
      console.log('⚠️ selected_values_rj_paid_to_incurred jest puste/invalid, używam rJPaidToIncurred jako fallback');
      finalSelectedValuesRJ = freshIncurredState.rJPaidToIncurred || [];
    }
    console.log('🔵 Finalne selected_values_rj_paid_to_incurred:', finalSelectedValuesRJ?.length || 0, 'elementów');

    // 2. Walidacja selected_values_sd_incurred  
    let finalSelectedValuesSD = selectedValuesSD || [];
    if (isEmptyOrInvalid(finalSelectedValuesSD)) {
      console.log('⚠️ selected_values_sd_incurred jest puste/invalid, używam sd jako fallback');
      finalSelectedValuesSD = sd || [];
    }
    console.log('🔵 Finalne selected_values_sd_incurred:', finalSelectedValuesSD?.length || 0, 'elementów');

    // 3. Walidacja selected_values_varj_paid_to_incurred
    let finalSelectedValuesVarJ = selectedValuesVarJPaidToIncurred || [];
    if (isEmptyOrInvalid(finalSelectedValuesVarJ)) {
      console.log('⚠️ selected_values_varj_paid_to_incurred jest puste/invalid, używam varJPaidToIncurred jako fallback');
      finalSelectedValuesVarJ = freshIncurredState.varJPaidToIncurred || [];
    }
    console.log('🔵 Finalne selected_values_varj_paid_to_incurred:', finalSelectedValuesVarJ?.length || 0, 'elementów');

    // 4. Walidacja selected_value_sd_incurred (vectorCombinedSDSummary)
    let finalSelectedValueSD = vectorCombinedSDSummary;
    if (isEmptyOrInvalid(finalSelectedValueSD)) {
      console.log('⚠️ selected_value_sd_incurred jest puste/invalid, używam sd jako fallback');
      finalSelectedValueSD = effectiveSdIncurredData;
    }
    console.log('🔵 Finalne selected_value_sd_incurred:', finalSelectedValueSD?.length || 0, 'elementów');
    console.log('🔍 === KONIEC WALIDACJI ===');

    // Przygotuj request data dla Incurred zgodnie z klasą SimulationClIncurredRequest
    const requestData: any = {
      // Wektory obliczeń z Chain Ladder Results (MultIncurred z suffixami)
      last_col_incurred: Array.isArray(chainLadderResults?.last_col_incurred) ? chainLadderResults.last_col_incurred : [],
      cum_trian_incurred: Array.isArray(chainLadderResults?.cum_trian_incurred) ? chainLadderResults.cum_trian_incurred : [],
      ult_net_disc_incurred: Array.isArray(chainLadderResults?.ult_net_disc_incurred) ? chainLadderResults.ult_net_disc_incurred : [],
      
      user_id: userId,
      user_id_incurred: userId,
      
      // Parametry symulacji zgodnie z klasą backendu
      ilosc_symulacji_incurred: simulationParams.iloscSymulacji,
      ziarno_incurred: simulationParams.ziarno,
      skalowanie_incurred: simulationParams.skalowanie,
      skalowanie2_incurred: simulationParams.skalowanie2,
      kwantyle_incurred: parseQuantiles(kwantyle),
      
      // Trójkąty danych
      paid_triangle_incurred: paidTriangle || [], // Z MultPaid store
      incurred_triangle_incurred: incurredTriangle || [], // Z MultIncurred store
      
      // Wagi - DODANE
      weights_incurred: effectiveWeightsIncurred,
      weights_rj_incurred: weightsRjIncurred,  // 🎯 POPRAWIONE - wagi z PaidToIncurred (większa macierz)
      
      // Opcje kalkulacji
      calculation_options_incurred: calculationOptions,
      
      // Podsumowania i współczynniki
      combined_sd_summary_incurred: vectorCombinedSDSummary,
      
      // Indeksy i selekcje - POPRAWIONE NAZWY zgodnie z backendem
      selected_dev_j_indexes_incurred: effectiveSelectedDevIndexes,
      selected_sigma_indexes_incurred: effectiveSelectedSigmaIndexes,
      sigma_indexes_incurred: effectiveSelectedSigmaIndexes, // Duplikacja dla kompatybilności
      left_count_cl_incurred: effectiveLeftCountCL,
      
      // Selected values - DODANE BRAKUJĄCE POLA
      selected_value_cl_incurred: vectorSelectedValueCL,  // 🎯 DODANE - dane z CL (Incurred) FinalTable 
      selected_value_sigma_incurred: vectorSelectedValueSigma,
      selected_value_sd_incurred: finalSelectedValueSD,  // 🎯 ZWALIDOWANE - z fallbackiem do sd_incurred
      selected_values_rj_paid_to_incurred: finalSelectedValuesRJ,  // 🎯 ZWALIDOWANE - z fallbackiem
      selected_values_varj_paid_to_incurred: finalSelectedValuesVarJ,  // 🎯 ZWALIDOWANE - z fallbackiem
      selected_rj_paid_to_incurred_indexes_incurred: selectedRJPaidToIncurredIndexes || [],  // 🎯 DODANE - indeksy zaznaczonych r_j
      selected_varj_paid_to_incurred_indexes_incurred: selectedVarJPaidToIncurredIndexes || [],
      
      // 🎯 DODANE - oryginalne dane z API (analogiczne do dev_j i rj_paid_to_incurred)
      sigma_incurred: effectiveSigmaIncurredData,
      sd_incurred: effectiveSdIncurredData,
      
      // Tail counts - POPRAWIONE NAZWY
      tail_count_cl_incurred: effectiveTailCountCL,
      tail_count_rj_paid_to_incurred: leftCountRJPaidToIncurred || 0,
      tail_count_varj_paid_to_incurred_incurred: tailCountVarJPaidToIncurred || 0,
      
      // Stawki dyskontowe i netto/brutto
      discount_rates_incurred: processedDiscountRates,
      netto_brutto_incurred: processedNetBrutto,
      
      // 🎯 DODANE - dane PaidToIncurred
      train_paidtoincurred: trainPaidToIncurred || [],  // 🎯 NOWE POLE - główna tabela z endpointu /calc/paid_incurred/triangles
      res_i_j_paid_to_incurred: resIJPaidToIncurred || [],  // Tabela res_i_j z PaidToIncurred
      lambda_j_paid_to_incurred: lambdaJPaidToIncurred || null,  // Wartość lambda_j z PaidToIncurred
      
      // 🎯 DODANE - współczynniki var_j z tabeli PaidToIncurred  
      varj_paid_to_incurred_coefficients: freshIncurredState.varJPaidToIncurred || [],  // Współczynniki var_j z tabeli PaidToIncurred
      
      // Lambda jako ostatnie pole
      lambda: lambdaJPaidToIncurred || null,

      // 🎯 ALIASY BACKEND (NUMBA) - mapowanie 1:1 wg FE->backend
      data_paid_np: paidTriangle || [],
      data_inc_np: incurredTriangle || [],
      lr_inc: vectorSelectedValueCL,
      Lr_inc: vectorSelectedValueCL,
      sigma_inc: vectorSelectedValueSigma,
      sd_inc: finalSelectedValueSD,
      rj: finalSelectedValuesRJ,
      varj: finalSelectedValuesVarJ,
      r_i_j: resIJPaidToIncurred || [],
      lambda_cor: lambdaJPaidToIncurred || null,
      sim_total: simulationParams.iloscSymulacji,
      batch_sim: simulationParams.podzialZiarna,
      main_seed: simulationParams.ziarno,
      discount_factors: processedDiscountRates,
      net_to_gross: processedNetBrutto,
      weights_np: effectiveWeightsIncurred,
      data_wagi_pi: weightsRjIncurred,
      Poz_LR: effectiveSelectedDevIndexes,
      Poz_LR_p_i: selectedRJPaidToIncurredIndexes || [],
      wykluczenia_p_i: selectedRJPaidToIncurredIndexes || [],
      il_ogon: effectiveTailCountCL,
      dop_ogo_p_i: false,

      // 🎯 DODANE DLA TRYBU ADDYTYWNA (mapowanie pod backend p_i)
      ...(methodType === 'addytywna' ? {
        wykluczenia_p_i: selectedRJPaidToIncurredIndexes || [],
        il_ogon: leftCountRJPaidToIncurred || 0,
        dop_ogo_p_i: false,
      } : {}),
    };

    if (isAddytywnaMethod) {
      console.log('🧪 [ADDYTYWNA INCURRED] endpoint:', effectiveSimulationEndpoint);
      console.log('🧪 [ADDYTYWNA INCURRED] vector lengths:', {
        Lr_inc: vectorSelectedValueCL?.length || 0,
        sigma_inc: vectorSelectedValueSigma?.length || 0,
        sd_inc: finalSelectedValueSD?.length || 0,
        rj: finalSelectedValuesRJ?.length || 0,
        varj: finalSelectedValuesVarJ?.length || 0,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] vector heads (first 5):', {
        Lr_inc: (vectorSelectedValueCL || []).slice(0, 5),
        sigma_inc: (vectorSelectedValueSigma || []).slice(0, 5),
        sd_inc: (finalSelectedValueSD || []).slice(0, 5),
        rj: (finalSelectedValuesRJ || []).slice(0, 5),
        varj: (finalSelectedValuesVarJ || []).slice(0, 5),
      });
      console.log('🧪 [ADDYTYWNA INCURRED] source lengths:', {
        combinedAddLRSummary: combinedAddLRSummary?.length || 0,
        addJ: addJ?.length || 0,
        combinedAddSigmaSummary: combinedAddSigmaSummary?.length || 0,
        sigmaLR: sigmaLR?.length || 0,
        combinedAddSDSummary: combinedAddSDSummary?.length || 0,
        sdLR: sdLR?.length || 0,
      });
    }

    const addytywnaMinimalPayload = {
      Lr_inc: vectorSelectedValueCL,
      sigma_inc: vectorSelectedValueSigma,
      sd_inc: finalSelectedValueSD,
      e_values: eValues,
      rj: finalSelectedValuesRJ,
      varj: finalSelectedValuesVarJ,
      lambda: lambdaJPaidToIncurred || null,
      weights_np: effectiveWeightsIncurred,
      data_wagi_pi: weightsRjIncurred,
      data_paid_np: paidTriangle || [],
      data_inc_np: incurredTriangle || [],
      discount_factors: processedDiscountRates,
      net_to_gross: processedNetBrutto,
      sim_total: simulationParams.iloscSymulacji,
      main_seed: simulationParams.ziarno,
      batch_sim: simulationParams.podzialZiarna,
      Poz_LR: leftCountAddLR || 0,
      Poz_pi: leftCountRJPaidToIncurred || 0,
      wykluczenia: selectedAddJIndexes || [],
      wykluczenia_pi: selectedRJPaidToIncurredIndexes || [],
      wykluczenia_p_i: selectedRJPaidToIncurredIndexes || [],
      il_ogon: tailCountAddJ === '' || tailCountAddJ === null || tailCountAddJ === undefined ? 0 : Number(tailCountAddJ),
      il_ogon_pi: tailCountRJPaidToIncurred === '' || tailCountRJPaidToIncurred === null || tailCountRJPaidToIncurred === undefined ? 0 : Number(tailCountRJPaidToIncurred),
    };

    const payloadToSend = isAddytywnaMethod ? addytywnaMinimalPayload : requestData;

    if (isAddytywnaMethod) {
      console.log('🧪 [ADDYTYWNA INCURRED] Lr_inc source preferred = selectedValuesAddLR (FinalTable Selected Value AddLR):', selectedValuesAddLR);
      console.log('🧪 [ADDYTYWNA INCURRED] Lr_inc fallback = combinedAddLRSummary:', combinedAddLRSummary);
      console.log('🧪 [ADDYTYWNA INCURRED] sigma_inc source preferred = selectedValuesAddSigma (FinalTable Selected Value AddSigma):', selectedValuesAddSigma);
      console.log('🧪 [ADDYTYWNA INCURRED] sigma_inc fallback = combinedAddSigmaSummary:', combinedAddSigmaSummary);
      console.log('🧪 [ADDYTYWNA INCURRED] weights_np source = selectedWeightsAddIncurred -> effectiveWeightsIncurred:', {
        selectedWeightsAddIncurred,
        weights_np: effectiveWeightsIncurred,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] data_wagi_pi source = PaidToIncurred weights:', {
        selectedWeightsPaidToIncurred,
        safeWeightsPaidToIncurred,
        data_wagi_pi: weightsRjIncurred,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] triangles source = paidTriangle / incurredTriangle:', {
        paidRows: paidTriangle?.length || 0,
        paidCols: paidTriangle?.[0]?.length || 0,
        incurredRows: incurredTriangle?.length || 0,
        incurredCols: incurredTriangle?.[0]?.length || 0,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] discount/net sources:', {
        discount_factors: processedDiscountRates,
        net_to_gross: processedNetBrutto,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] discount_factors (final payload):', addytywnaMinimalPayload.discount_factors);
      console.log('🧪 [ADDYTYWNA INCURRED] net_to_gross (final payload):', addytywnaMinimalPayload.net_to_gross);
      console.log('🧪 [ADDYTYWNA INCURRED] simulation params source:', {
        sim_total: addytywnaMinimalPayload.sim_total,
        main_seed: addytywnaMinimalPayload.main_seed,
        batch_sim: addytywnaMinimalPayload.batch_sim,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] e_values source = exposureStore selected line:', {
        selectedExposureLine,
        e_values: eValues,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] rj/varj/lambda sources:', {
        rj: finalSelectedValuesRJ,
        varj: finalSelectedValuesVarJ,
        lambda: lambdaJPaidToIncurred || null,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] il_ogon source = AddJ "Ile obserwacji w ogonie":', {
        tailCountAddJ,
        il_ogon: addytywnaMinimalPayload.il_ogon,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] wykluczenia_pi source = FitCurveRJPaidToIncurred user selection:', {
        selectedRJPaidToIncurredIndexes,
        wykluczenia_pi: addytywnaMinimalPayload.wykluczenia_pi,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] Poz_pi/il_ogon_pi source = Paid/Incurred:', {
        leftCountRJPaidToIncurred,
        tailCountRJPaidToIncurred,
        Poz_pi: addytywnaMinimalPayload.Poz_pi,
        il_ogon_pi: addytywnaMinimalPayload.il_ogon_pi,
      });
      console.log('🧪 [ADDYTYWNA INCURRED] payload (5 pól):');
      console.table(addytywnaMinimalPayload);
      console.log(JSON.stringify(addytywnaMinimalPayload, null, 2));
    } else {
      console.log(`🚀 [BACKEND REQUEST] PEŁNE requestData wysyłane na ${effectiveSimulationEndpoint}:`);
      console.log(JSON.stringify(requestData, null, 2));
    }

    // Wykonaj symulację
    const results = await executeSimulation(
      payloadToSend,
      effectiveSimulationEndpoint,
      showAlert
    );

    if (results) {
      console.log('🔍 [SYMULACJA DEBUG] Wyniki z backendu przed zapisem:', results);
      console.log('🔍 [SYMULACJA DEBUG] results.userId:', results.userId);
      console.log('🔍 [SYMULACJA DEBUG] typeof results.userId:', typeof results.userId);
      console.log('🔍 [SYMULACJA DEBUG] aktualny userId:', userId);
      
      // 🎯 UPEWNIJ SIĘ ŻE userId JEST ZAPISANY W WYNIKACH
      const resultsWithUserId = {
        ...results,
        userId: userId,  // Wymuś ustawienie userId
        calculatedAt: new Date().toISOString() // Dodaj timestamp
      };
      
      console.log('🔍 [SYMULACJA DEBUG] Wyniki po dodaniu userId:', resultsWithUserId);
      
      setResults(resultsWithUserId);
      
      // Jeśli symulacja się udała, usuń stare statystyki
      setStatisticsResults([]);
    }
  };

  // Funkcja wykonania statystyk
  const handleExecuteStatistics = async () => {
    // Guard clause dla userId
    if (!userId) {
      showAlert({
        variant: 'error',
        title: 'Błąd użytkownika',
        message: 'Brak identyfikatora użytkownika'
      });
      return;
    }

    // 🔍 DEBUG - sprawdź stan danych
    console.log('🔍 [DEBUG STATYSTYKI] simulationResults:', simulationResults);
    console.log('🔍 [DEBUG STATYSTYKI] simulationResults?.userId:', simulationResults?.userId);
    console.log('🔍 [DEBUG STATYSTYKI] aktualny userId:', userId);
    console.log('🔍 [DEBUG STATYSTYKI] chainLadderResults?.userId:', chainLadderResults?.userId);

    if (!simulationResults) {
      console.log('❌ [WALIDACJA] Brak simulationResults - pokazuję alert');
      showAlert({
        variant: 'warning',
        title: 'Brak danych symulacji',
        message: 'Najpierw wykonaj "Wykonaj obliczenia", a następnie statystyki.'
      });
      return;
    }

    // Sprawdź czy wyniki są świeże (mają userId)
    console.log('🔍 [WALIDACJA] Sprawdzam świeżość danych...');
    console.log('🔍 [WALIDACJA] simulationResults.userId:', simulationResults.userId);
    console.log('🔍 [WALIDACJA] typeof simulationResults.userId:', typeof simulationResults.userId);
    console.log('🔍 [WALIDACJA] userId:', userId);
    console.log('🔍 [WALIDACJA] typeof userId:', typeof userId);
    console.log('🔍 [WALIDACJA] !simulationResults.userId:', !simulationResults.userId);
    console.log('🔍 [WALIDACJA] simulationResults.userId !== userId:', simulationResults.userId !== userId);
    
    if (!simulationResults.userId || simulationResults.userId !== userId) {
      console.log('❌ [WALIDACJA] Nieświeże dane - userId nie pasuje lub brak userId');
      showAlert({
        variant: 'warning',
        title: 'Nieświeże dane symulacji',
        message: 'Wyniki symulacji są przestarzałe. Wykonaj ponownie "Wykonaj obliczenia".'
      });
      return;
    }

    console.log('✅ [WALIDACJA] Dane są świeże - kontynuuję...');

    const deterministicResultsFromStore =
      deterministicIncurredResults &&
      deterministicIncurredResults.userId === userId &&
      deterministicIncurredResults.shouldShowResults &&
      Array.isArray(deterministicIncurredResults.last_col_incurred) &&
      Array.isArray(deterministicIncurredResults.cum_trian_incurred) &&
      Array.isArray(deterministicIncurredResults.ult_net_disc_incurred)
        ? {
            cum_trian: deterministicIncurredResults.cum_trian_incurred,
            last_col: deterministicIncurredResults.last_col_incurred,
            ult_net_disc: deterministicIncurredResults.ult_net_disc_incurred,
          }
        : null;

    const deterministicResultsFromChainLadder =
      chainLadderResults &&
      chainLadderResults.userId === userId &&
      chainLadderResults.shouldShowResults === true &&
      Array.isArray(chainLadderResults.last_col_incurred) &&
      Array.isArray(chainLadderResults.cum_trian_incurred) &&
      Array.isArray(chainLadderResults.ult_net_disc_incurred)
        ? {
            cum_trian: chainLadderResults.cum_trian_incurred as number[],
            last_col: chainLadderResults.last_col_incurred as number[],
            ult_net_disc: chainLadderResults.ult_net_disc_incurred as number[],
          }
        : null;

    const deterministicResultsPayload = deterministicResultsFromStore ?? deterministicResultsFromChainLadder;

    // Używamy identycznej logiki jak w ClSimulationPaid - optimized approach + dodatkowe pola Incurred
    const statisticsData: any = {
      // Podstawowe pola jak w ClSimulationPaid
      user_id: userId, // userId jest już sprawdzony wyżej
      kwantyle: parseQuantiles(kwantyle),
      skalowanie: simulationParams.skalowanie,
      skalowanie2: simulationParams.skalowanie2,
      // Zamiast wysyłać dummy results, wyślij null - backend użyje zapisanych danych
      simulation_results: null,
      // 🎯 WYSYŁAJ tylko rzeczywiste wyniki deterministyczne dla Incurred
      deterministic_results: deterministicResultsPayload,
      
      // 🎯 DODATKOWE POLA INCURRED - identyczne jak w symulacji
      last_col_incurred: Array.isArray(chainLadderResults?.last_col_incurred) ? chainLadderResults.last_col_incurred : [],
      cum_trian_incurred: Array.isArray(chainLadderResults?.cum_trian_incurred) ? chainLadderResults.cum_trian_incurred : [],
      ult_net_disc_incurred: Array.isArray(chainLadderResults?.ult_net_disc_incurred) ? chainLadderResults.ult_net_disc_incurred : [],
      user_id_incurred: userId,
      skalowanie_incurred: simulationParams.skalowanie,
      skalowanie2_incurred: simulationParams.skalowanie2,
      kwantyle_incurred: parseQuantiles(kwantyle),
    };

    console.log('🚀 [WYKONAJ STATYSTYKI INCURRED] Wysyłane dane:', statisticsData);
    
    // 🔍 DEBUG - sprawdź czy pola Incurred są załadowane
    console.log('🔍 [STATISTYKI DEBUG] last_col_incurred:', statisticsData.last_col_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] cum_trian_incurred:', statisticsData.cum_trian_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] ult_net_disc_incurred:', statisticsData.ult_net_disc_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] user_id_incurred:', statisticsData.user_id_incurred);
    console.log('🔍 [STATISTYKI DEBUG] skalowanie_incurred:', statisticsData.skalowanie_incurred);
    console.log('🔍 [STATISTYKI DEBUG] skalowanie2_incurred:', statisticsData.skalowanie2_incurred);
    console.log('🔍 [STATISTYKI DEBUG] kwantyle_incurred:', statisticsData.kwantyle_incurred);

    const results = await executeStatistics(
      statisticsData,
      statisticsEndpoint,
      showAlert
    );

    if (results) {
      setStatisticsResults(results);
    }
  };


  // Funkcja eksportu do Excel
  const handleExportStatistics = () => {
    if (statisticsResults.length === 0) {
      showAlert({
        variant: 'warning',
        title: 'Brak danych',
        message: 'Najpierw wykonaj statystyki, aby móc je wyeksportować do Excel.'
      });
      return;
    }

    try {
      exportStatisticsToExcel(
        statisticsResults,
        kwantyle,
        simulationParams.skalowanie,
        simulationParams
      );
      showAlert({
        variant: 'success',
        title: 'Eksport wykonany!',
        message: 'Statystyki zostały zapisane do pliku Excel.'
      });
    } catch (error) {
      console.error('Błąd podczas eksportu:', error);
      showAlert({
        variant: 'error',
        title: 'Błąd eksportu',
        message: 'Wystąpił błąd podczas zapisywania do Excel. Sprawdź konsolę przeglądarki.'
      });
    }
  };

  return (
    <>
      <SimulationLayout
        mainPadding="p-4 md:p-5"
        sidebar={
          <SimulationControlPanel
            sidebarWidth="w-48"
            sidebarPadding="p-3"
            compactActionButtons
            actionSectionTopSpacingClassName="pt-0"
            placeExecuteButtonAboveDivider
            sectionSpacingClassName="space-y-4"
            simulationParams={simulationParams}
            kwantyle={kwantyle}
            isCalculating={isCalculating}
            isCalculatingStatistics={isCalculatingStatistics}
            hasResults={hasResults}
            statisticsResultsCount={statisticsResults.length}
            dataAvailability={dataAvailabilityStatus}
            onUpdateSimulationParam={updateSimulationParam}
            onSetKwantyle={setKwantyle}
            onExecuteCalculations={() => {
              handleExecuteCalculations();
            }}
            onExecuteStatistics={handleExecuteStatistics}
            onClearResults={clearResults}
            onClearStatistics={() => setStatisticsResults([])}
            onExportStatistics={handleExportStatistics}
            topContent={topContent}
          />
        }
      >
        {tableVariant === 'paid' ? (
          <div className="space-y-6">
            {lightStatisticsTableData ? (
              <DataTableView
                title="Wyniki Statystyk"
                className="[&_*_table]:text-[11px]"
                lightHeaderClassName="bg-gradient-to-r from-gray-100 to-gray-50 px-3 py-1 border-b border-gray-300 rounded-t-2xl"
                lightTitleClassName="font-bold text-gray-800 text-sm tracking-tight"
                tableWrapperClassName="w-full overflow-auto max-h-[calc(100vh-8.5rem)]"
                data={lightStatisticsTableData}
                noDataMessage="Brak danych wynikowych do wyświetlenia"
                variant="light"
              />
            ) : (
              <EmptyState
                title=""
                description={'Dla wybranej metody kliknij "Wykonaj symulacje".'}
              />
            )}
          </div>
        ) : (
          <SimulationStatisticsTable
            statisticsResults={statisticsResults}
            kwantyle={kwantyle}
            skalowanie={simulationParams.skalowanie}
            skalowanie2={simulationParams.skalowanie2}
            title="📊 Wyniki Statystyk Chain Ladder Incurred"
            subtitle="Analiza statystyczna wyników symulacji metodą Chain Ladder z danymi Incurred"
          />
        )}
      </SimulationLayout>

      {/* Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />

      {isCalculating && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/70 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-4 rounded-2xl bg-slate-900/95 px-10 py-8 shadow-2xl">
            <Loader2 className="h-16 w-16 animate-spin text-white" />
            <p className="text-lg font-semibold text-white">Trwają obliczenia symulacji...</p>
            <p className="text-sm text-slate-300">Poczekaj do zakończenia operacji.</p>
          </div>
        </div>
      )}
    </>
  );
}