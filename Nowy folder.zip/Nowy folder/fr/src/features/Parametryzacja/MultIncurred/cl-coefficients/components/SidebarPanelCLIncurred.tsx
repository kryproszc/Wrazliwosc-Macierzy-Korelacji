'use client';

import { useEffect, useState } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import Modal from '@/components/Modal';
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelCLIncurred({ onCalculate, className }: Props) {
  const store = useTrainDevideStoreIncurred();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  const {
    clearDevJResults,
    setDevJ,
    setSigma,
    setSd,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearSigmaResults,
    setFinalSigma,
    clearFitCurveData,
    clearDevSummaryData,
    clearCurrentCoefficientResults,
    finalDevJ,
    finalDevVector,
    devJResults,
    minMaxHighlighting,
    setMinMaxHighlighting,
    safeWeights,
    volume,
    setVolume,
    decimalPlaces = 6,
    setDecimalPlaces,
  } = store;

  useEffect(() => {
    if (volume < 1 || volume > 20) {
      setVolume(20);
    }
  }, [setVolume, volume]);

  const overrides: any[] = []; // można dodać obsługę overrides jeśli potrzeba

  const [isMissingFinalModalOpen, setIsMissingFinalModalOpen] = useState(false);
  
  const openMissingFinalModal = () => setIsMissingFinalModalOpen(true);
  const closeMissingFinalModal = () => setIsMissingFinalModalOpen(false);

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    // Adaptacja funkcji eksportu dla incurred - może wymagać modyfikacji
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides);
  };

  const handleReset = () => {
    setVolume(20);
    clearCurrentCoefficientResults();
    clearDevJResults();
    setDevJ([]);
    setSigma([]);
    setSd([]);
    clearAllDevFinalValues();
    clearSigmaResults();
    setFinalDevJ(undefined);
    setFinalSigma(undefined);
    clearFitCurveData();
    clearDevSummaryData();
    // resetuj zaznaczenia w tabeli współczynników rok do roku
    store.resetSelectionIncurred();
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="h-4 w-4" />
      </Button>
      
      <span className="min-w-[3rem] text-center text-sm text-white">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );

  return (
    <div className={`!w-48 shrink-0 flex flex-col gap-4 ${className ?? ''}`}>
      <div className="rounded-lg bg-gray-800 p-3">
        <div className="mb-2 text-sm font-medium text-white">
          Ustawienia wyświetlania
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-white">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>

          <Button
            onClick={() => setFullscreenMode(true)}
            size="sm"
            className="mx-auto h-8 w-40 bg-blue-600 text-xs text-white hover:bg-blue-700"
          >
            <Maximize2 className="mr-2 h-3.5 w-3.5" />
            Pełny ekran
          </Button>

          <div>
            <label htmlFor="incurred-cl-decimal-places" className="mb-2 block text-xs font-medium text-white">
              Miejsca po przecinku
            </label>
            <input
              id="incurred-cl-decimal-places"
              type="number"
              min="0"
              max="10"
              value={decimalPlaces}
              onChange={(e) => setDecimalPlaces?.(Number(e.target.value))}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="incurred-cl-volume" className="mb-2 block text-xs font-medium text-white">
              Wybierz volume
            </label>
            <input
              id="incurred-cl-volume"
              type="number"
              min={1}
              max={20}
              value={volume}
              onChange={(e) => {
                const nextValue = e.currentTarget.valueAsNumber;
                if (Number.isFinite(nextValue)) {
                  setVolume(Math.min(20, Math.max(1, nextValue)));
                }
              }}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Przyciski akcji */}
      <div className="flex flex-col gap-3">
        <button
          onClick={onCalculate}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl"
        >
          Oblicz
        </button>

        <button
          onClick={handleExport}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl"
        >
          Eksportuj do Excela
        </button>

        <button
          onClick={() => setResetOpen(true)}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-orange-700 hover:to-orange-600 hover:shadow-2xl"
        >
          Reset współczynników
        </button>
      </div>

      {/* Modals */}
      <Modal
        isOpen={resetOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          handleReset();
          setResetOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`block h-8 w-full rounded-lg px-3 text-xs font-medium text-white transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700'
            : 'bg-gray-600 hover:bg-gray-700'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

    </div>
  );
}