'use client';

import { useEffect, useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import SidebarPanelBase from '@/shared/ui/molecules/SidebarPanelBase'
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelCL({ onCalculate, className  }: Props) {
  const store = useTrainDevideStoreDet();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  const {
    volume, setVolume,
    clearDevJResults,
    setDevJ,
    setSigma,
    setSd,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearSigmaResults,
    setFinalSigma,
    clearAllSigmaFinalValues,
    clearFitCurveData,
    clearDevSummaryData,
    clearAllWeightsDet,
    openMissingFinalModal,
    isMissingFinalModalOpen,
    closeMissingFinalModal,
    finalDevJ,
    finalDevVector,
    devFinalCustom,
    devJResults,
    minMaxHighlighting,
    setMinMaxHighlighting,
    decimalPlaces,
    setDecimalPlaces,
    selectedWeightsDet,
    safeWeights,
  } = store;

  useEffect(() => {
    if (volume < 1 || volume > 20) {
      setVolume(20);
    }
  }, [setVolume, volume]);

  const overrides = Object.entries(devFinalCustom).map(([idx, c]) => ({
    index: +idx,
    curve: c.curve,
    value: c.value,
  }));

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides);
  };

  const handleReset = () => {
    setVolume(20);
    clearDevJResults();
    setDevJ([]);
    setSigma([]);
    setSd([]);
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearSigmaResults();
    setFinalSigma(undefined);
    clearAllSigmaFinalValues();
    clearFitCurveData();
    clearDevSummaryData();
    clearAllWeightsDet(); // Resetuj zaznaczenia w tabeli współczynników rok do roku
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  const logSafeWeights = () => {
    if (!safeWeights) {
      console.log('❌ Brak safeWeights w store - wywołaj store.calculateSafeWeights()');
      return;
    }

    console.log('🟦 === SAFEWEIGHTS ZE STORE ===');
    safeWeights.forEach((row, i) => {
      console.log(`Wiersz ${i}:`, row);
    });
    
    console.log('📊 Statystyki safeWeights ze store:', {
      rows: safeWeights.length,
      cols: safeWeights[0]?.length || 0,
      totalSelected: safeWeights.flat().filter(w => w === 1).length,
      totalZeros: safeWeights.flat().filter(w => w === 0).length,
      source: 'STORE'
    });
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="h-4 w-4" />
      </Button>
      
      <span className="min-w-[3rem] text-center text-sm text-white">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="h-8 w-8 border-gray-600 p-0 text-white hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-48 shrink-0 space-y-4 ${className ?? ''}`}>
      <div className="space-y-4 rounded-lg bg-gray-800 p-3">
        <div className="mb-2 text-sm font-medium text-white">
          Ustawienia wyświetlania
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-white">
            Rozmiar tabeli
          </label>
          <ScaleControls />
        </div>

        <Button
          onClick={() => setFullscreenMode(true)}
          size="sm"
          className="mx-auto h-8 w-40 bg-blue-600 text-xs text-white hover:bg-blue-700"
        >
          <Maximize2 className="mr-2 h-3.5 w-3.5" />
          Pełny ekran
        </Button>

        <div>
          <label htmlFor="paid-cl-decimal-places" className="mb-2 block text-xs font-medium text-white">
            Miejsca po przecinku
          </label>
          <input
            id="paid-cl-decimal-places"
            type="number"
            min="0"
            max="10"
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces(Number(e.target.value))}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="paid-cl-volume" className="mb-2 block text-xs font-medium text-white">
            Wybierz volume
          </label>
          <input
            id="paid-cl-volume"
            type="number"
            min={1}
            max={20}
            value={volume}
            onChange={(e) => {
              const nextValue = e.currentTarget.valueAsNumber;
              if (Number.isFinite(nextValue)) {
                setVolume(Math.min(20, Math.max(1, nextValue)));
              }
            }}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <SidebarPanelBase
        volume={volume}
        onVolumeChange={setVolume}
        showVolume={false}
        fullWidthActions
        onCalculate={onCalculate}
        onExport={handleExport}
        onReset={handleReset}
        isResetModalOpen={resetOpen}
        setResetModalOpen={setResetOpen}
        isMissingFinalModalOpen={isMissingFinalModalOpen}
        closeMissingFinalModal={closeMissingFinalModal}
      />

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`block h-8 w-full rounded-lg px-3 text-xs font-medium transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* Debug: Show SafeWeights Button */}
      <button
        onClick={logSafeWeights}
        className="block h-8 w-full rounded-lg bg-blue-600 px-3 text-xs font-medium text-white transition-colors hover:bg-blue-700"
      >
        🟦 SafeWeights ze Store
      </button>

    </div>
  );
}