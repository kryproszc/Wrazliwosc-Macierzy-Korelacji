'use client';

import { useEffect, useState } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import Modal from '@/components/Modal';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelPaidToIncurred({ onCalculate, className }: Props) {
  const store = useTrainDevideStoreIncurred();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  const {
    trainPaidToIncurred,
    selectedWeightsPaidToIncurred,
    devJPaidToIncurred,
    sigmaPaidToIncurred,
    sdPaidToIncurred,
    minMaxHighlightingPaidToIncurred,
    setMinMaxHighlightingPaidToIncurred,
    resetSelectionPaidToIncurred,
    clearPaidToIncurredCalculationResults,
    volumePaidToIncurred,
    setVolumePaidToIncurred,
    decimalPlaces = 6,
    setDecimalPlaces,
  } = store;

  useEffect(() => {
    if (volumePaidToIncurred < 1 || volumePaidToIncurred > 20) {
      setVolumePaidToIncurred(20);
    }
  }, [setVolumePaidToIncurred, volumePaidToIncurred]);

  const [isMissingDataModalOpen, setIsMissingDataModalOpen] = useState(false);
  
  const openMissingDataModal = () => setIsMissingDataModalOpen(true);
  const closeMissingDataModal = () => setIsMissingDataModalOpen(false);

  const handleExport = () => {
    if (!devJPaidToIncurred?.length) {
      openMissingDataModal();
      return;
    }
    
    // TODO: Implementuj eksport dla PaidToIncurred
    console.log('Export PaidToIncurred data:', {
      devJ: devJPaidToIncurred,
      sigma: sigmaPaidToIncurred,
      sd: sdPaidToIncurred
    });
  };

  const handleReset = () => {
    // Reset selection in table
    resetSelectionPaidToIncurred();
    clearPaidToIncurredCalculationResults();
    setVolumePaidToIncurred(20);
  };

  const toggleMinMax = () => {
    setMinMaxHighlightingPaidToIncurred(!minMaxHighlightingPaidToIncurred);
  };

  // Komponent kontrolek rozmiaru
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-48 shrink-0 space-y-4 ${className ?? ''}`}>
      <div className="space-y-4 rounded-lg bg-gray-800 p-3">
        <div className="mb-2 text-sm font-medium text-white">Ustawienia wyświetlania</div>

        <div>
          <label className="mb-1 block text-xs font-medium text-white">
            Rozmiar tabeli
          </label>
          <ScaleControls />
        </div>

        <Button
          onClick={() => setFullscreenMode(true)}
          size="sm"
          className="mx-auto h-8 w-40 bg-blue-600 text-xs text-white hover:bg-blue-700"
        >
          <Maximize2 className="mr-2 h-3.5 w-3.5" />
          Pełny ekran
        </Button>

        <div>
          <label htmlFor="paid-to-incurred-decimal-places" className="mb-2 block text-xs font-medium text-white">
            Miejsca po przecinku
          </label>
          <input
            id="paid-to-incurred-decimal-places"
            type="number"
            min="0"
            max="10"
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces?.(Number(e.target.value))}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="paid-to-incurred-volume" className="mb-2 block text-xs font-medium text-white">
            Wybierz volume
          </label>
          <input
            id="paid-to-incurred-volume"
            type="number"
            min={1}
            max={20}
            value={volumePaidToIncurred}
            onChange={(e) => {
              const nextValue = e.currentTarget.valueAsNumber;
              if (Number.isFinite(nextValue)) {
                setVolumePaidToIncurred(Math.min(20, Math.max(1, nextValue)));
              }
            }}
            className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <button
          onClick={onCalculate}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl"
          disabled={!trainPaidToIncurred}
        >
          Oblicz
        </button>

        <button
          onClick={handleExport}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl"
          disabled={!devJPaidToIncurred}
        >
          Eksportuj do Excela
        </button>

        <button
          onClick={() => setResetOpen(true)}
          className="h-8 w-full rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-orange-700 hover:to-orange-600 hover:shadow-2xl"
        >
          Reset współczynników
        </button>
      </div>

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className="block h-8 w-full rounded-lg bg-gray-600 px-3 text-xs font-medium text-white transition-colors hover:bg-gray-700"
      >
        {minMaxHighlightingPaidToIncurred ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* Modals */}
      <Modal
        isOpen={resetOpen}
        title="Reset zaznaczenia"
        message="Czy na pewno chcesz zresetować zaznaczenie komórek w tabeli? Wszystkie komórki zostaną zaznaczone."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          handleReset();
          setResetOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingDataModalOpen}
        title="Brak danych do eksportu"
        message="Najpierw oblicz współczynniki PaidToIncurred."
        onConfirm={closeMissingDataModal}
        onlyOk
      />
    </div>
  );
}