// src/lib/resetAllStores.ts

import { useTableStore } from "@/stores/tableStore";
import { useTrainDevideStore } from '@/stores/trainDevideStore';
import { useInputSettingsStore } from "@/stores/inputSettingsStore";
import { useCLSimulationStore } from "@/stores/clSimulationStore";
import { useInflacjaStore } from "@/stores/inflacjaStore";
import { useExposureStore } from "@/stores/exposureStore";
import { useParamsymStore } from "@/stores/paramsymStore";
import { useDiscountRatesStore } from "@/stores/discountRatesStore";
import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";
import { useIncurredTableStore } from "@/stores/useIncurredTableStore";
import { useAddIncurredStore } from "@/stores/addIncurredStore";
import { useAddIncurredCoefficientsStore } from "@/stores/addIncurredCoefficientsStore";
import { useDisplaySettingsAddIncurredStore } from "@/stores/useDisplaySettingsAddIncurredStore";
import { useAddPaidStore } from '@/stores/addPaidStore';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useAddSimulationStore } from '@/stores/addSimulationStore';
import { useAddPaidResultsStore } from '@/stores/addPaidResultsStore';
import { useChainLadderResultsStore } from '@/stores/chainLadderResultsStore';
import { useSimulationResultsStore } from '@/stores/simulationResultsStore';
import { useStochasticPaidSimulationStore } from '@/stores/stochasticPaidSimulationStore';
import { useDeterministicIncurredResultsStore } from '@/stores/deterministicIncurredResultsStore';
import { useCalculationOptionsStore } from '@/stores/calculationOptionsStore';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';

export function resetAllStores() {
  // Stare store'y
  useTableStore.getState().resetData();
  useTrainDevideStore.getState().reset();
  useInputSettingsStore.getState().reset();
  useCLSimulationStore.getState().resetStore();
  useCalculationOptionsStore.getState().resetOptions();
  
  // Store'y wprowadzania danych
  useInflacjaStore.getState().resetData();
  useExposureStore.getState().resetData();
  useParamsymStore.getState().resetData();
  useDiscountRatesStore.getState().resetData();

  // Metoda Paid / Incurred
  useTrainDevideStoreDet.getState().resetDet();
  useTrainDevideStoreIncurred.getState().resetData();
  useChainLadderResultsStore.getState().clearResults();
  useSimulationResultsStore.getState().clearResults();
  useDeterministicIncurredResultsStore.getState().resetAll();
  
  // AddPaid
  useAddPaidStore.getState().resetData();
  useAddCoefficientsStore.getState().resetAll();
  useAddSimulationStore.getState().resetAll();
  useAddPaidResultsStore.getState().clearResults();

  // AddIncurred
  useIncurredTableStore.getState().resetData();
  useAddIncurredStore.getState().resetData();
  useAddIncurredCoefficientsStore.getState().resetData();
  useDisplaySettingsAddIncurredStore.getState().resetData();

  // Stochastic paid user states
  useStochasticPaidSimulationStore.setState({ userStates: {} });

  // Reset display settings persisted w sessionStorage
  useDisplaySettingsPaidStore.setState({
    fullscreenMode: false,
    tableScale: 0.7,
  });
  
  // Twarde czyszczenie pamięci przeglądarki: start "od zera"
  if (typeof window !== 'undefined') {
    localStorage.clear();
    sessionStorage.clear();
  }
}
