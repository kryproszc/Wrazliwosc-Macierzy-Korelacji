/* ------------------------------------------------------------------ */
/*                         DevBasicTable                             */
/* ------------------------------------------------------------------ */

import React from 'react'
import type { DevBasicTableProps } from '@/shared/types/developmentEnd'

export function DevBasicTable({ 
  devJPreview, 
  columnLabels, 
  leftCount, 
  sourceSwitches, 
  setSourceSwitches, 
  selectedCurve,
  simResults,
  manualOverrides,
  setManualOverrides,
  disableClicks = false,
  useClassicStyle = false
}: DevBasicTableProps) {
  if (!devJPreview) return null

  const handleCellClick = (idx: number) => {
    // Jeśli kliknięcia są zablokowane, nie rób nic
    if (disableClicks) return
    
    // Tylko dla komórek w lewej części (< leftCount)
    if (idx >= leftCount) return
    
    // Jeśli nie ma wybranej krzywej, nie można przełączać
    if (!selectedCurve || !simResults) return

    // Przełącz stan sourceSwitches dla tej komórki
    const newSwitches = { ...sourceSwitches }
    const currentSwitch = sourceSwitches[idx]
    
    if (currentSwitch && currentSwitch.curve !== 'Initial Selection') {
      // Jeśli była ustawiona inna krzywa (nie Initial Selection), ustaw na 'Initial Selection'
      const initialValue = devJPreview?.[idx]
      if (initialValue !== undefined) {
        newSwitches[idx] = { curve: 'Initial Selection', value: initialValue }
        console.log(`🔄 DevBasicTable - Ustawiam Initial Selection dla idx ${idx}:`, {
          initialValue,
          previousCurve: currentSwitch.curve
        })
        
        // Usuń ręczne nadpisania gdy przełączamy na Initial Selection
        const newOverrides = { ...manualOverrides }
        if (newOverrides[idx]) {
          delete newOverrides[idx]
          setManualOverrides(newOverrides)
        }
      }
    } else if (currentSwitch && currentSwitch.curve === 'Initial Selection') {
      // Jeśli już jest Initial Selection, przełącz na wybraną krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx}:`, {
          value,
          previousCurve: 'Initial Selection'
        })
      }
    } else {
      // Brak wpisu - ustaw krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx} (pierwszy raz):`, {
          value
        })
      }
    }
    setSourceSwitches(newSwitches)
  }
  
  return (
    <section className={useClassicStyle ? 'w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white' : undefined}>
      {useClassicStyle ? (
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-2 border-b-2 border-gray-400 rounded-t-2xl">
          <h2 className="font-bold text-gray-800 text-base tracking-tight text-left">Tabela współczynników Initial Selection</h2>
        </div>
      ) : (
        <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników Initial Selection</h2>
      )}
      <div className={useClassicStyle ? 'overflow-auto p-4' : 'relative w-full max-w-full overflow-x-auto rounded-xl'}>
        <div className={useClassicStyle ? 'relative w-full overflow-x-auto rounded-xl' : undefined}>
        <table className={useClassicStyle ? 'min-w-max border-collapse bg-white text-sm text-gray-800' : 'min-w-max border-collapse bg-gray-900 rounded-xl shadow-md text-sm'}>
          <thead>
            <tr>
              <th className={useClassicStyle ? 'border border-gray-300 px-3 py-2 bg-gray-50' : 'border border-gray-700 px-3 py-2 bg-gray-800'}>-</th>
              {devJPreview.map((_, idx) => {
                const label = columnLabels.length > idx + 2 
                  ? columnLabels[idx + 2] 
                  : String(idx)
                return (
                  <th key={idx} className={useClassicStyle ? 'border border-gray-300 px-3 py-2 bg-gray-50' : 'border border-gray-700 px-3 py-2 bg-gray-800'}>
                    {String(label).replace(/^j=/, '')}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className={useClassicStyle ? 'border border-gray-300 px-3 py-2 bg-gray-50 font-semibold' : 'border border-gray-700 px-3 py-2 bg-gray-800'}>Initial Selection</td>
              {devJPreview.map((val, idx) => {
                const isInLeftPart = idx < leftCount
                const switchedSource = sourceSwitches[idx]
                const canSwitch = isInLeftPart && selectedCurve && !disableClicks
                
                // Kolory tła - zielony dla wybranych (leftCount), przełączone na fioletowo
                let bgClass = ""
                if (isInLeftPart) {
                  if (switchedSource && switchedSource.curve !== 'Initial Selection') {
                    bgClass = useClassicStyle ? 'bg-blue-200/70' : 'bg-purple-600/70'
                  } else {
                    bgClass = useClassicStyle ? 'bg-blue-200/70' : 'bg-green-600/70'
                  }
                } else {
                  bgClass = "" // Brak podświetlenia poza lewą częścią
                }

                return (
                  <td
                    key={idx}
                    onClick={disableClicks ? undefined : () => handleCellClick(idx)}
                    className={`${useClassicStyle ? 'border border-gray-300' : 'border border-gray-700'} px-3 py-2 text-center transition-colors ${bgClass} ${
                      canSwitch ? (useClassicStyle ? 'cursor-pointer hover:bg-gray-100' : 'cursor-pointer hover:opacity-80') : disableClicks ? 'cursor-not-allowed' : ''
                    }`}
                    title={
                      disableClicks
                        ? "Kliknięcia zostały zablokowane w tej zakładce"
                        : canSwitch
                        ? switchedSource
                          ? switchedSource.curve === 'Initial Selection'
                            ? `Źródło: Initial Selection - kliknij aby użyć krzywej "${selectedCurve}"`
                            : `Źródło: krzywa "${switchedSource.curve}" - kliknij aby przywrócić Initial Selection`
                          : `Źródło: krzywa "${selectedCurve}" - kliknij aby przywrócić Initial Selection`
                        : isInLeftPart && !selectedCurve
                        ? "Wybierz krzywę, aby móc przełączać źródło"
                        : ""
                    }
                  >
                    {val !== undefined ? val.toFixed(6) : "-"}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
        </div>
      </div>
    </section>
  )
}
