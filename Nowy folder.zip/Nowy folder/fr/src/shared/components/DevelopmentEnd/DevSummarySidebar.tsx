/* ------------------------------------------------------------------ */
/*                         DevSummarySidebar                         */
/* ------------------------------------------------------------------ */

import React from 'react'
import { useEffect, useRef, useState } from 'react'
import type { AssignRangeState, OverrideMap, SourceSwitchMap } from '@/shared/types/developmentEnd'

interface DevSummarySidebarProps {
  leftCount: number
  setLeftCount: (count: number) => void
  manualOverrides: OverrideMap
  setManualOverrides: (overrides: OverrideMap) => void
  sourceSwitches: SourceSwitchMap
  setSourceSwitches: (switches: SourceSwitchMap) => void
  maxLen: number
  useClassicStyle?: boolean
  assignRangeState?: AssignRangeState
  setAssignRangeState?: (state: AssignRangeState) => void
}

export function DevSummarySidebar({
  leftCount,
  setLeftCount,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches,
  maxLen,
  useClassicStyle = false,
  assignRangeState,
  setAssignRangeState
}: DevSummarySidebarProps) {
  const safeMaxLen = Math.max(1, maxLen)
  const previousLeftCount = useRef(leftCount)
  const initializedLeftCountWatch = useRef(false)
  const [localRangeFrom, setLocalRangeFrom] = useState(1)
  const [localRangeTo, setLocalRangeTo] = useState(safeMaxLen)
  const [assignValue, setAssignValue] = useState<string>('')
  const [assignError, setAssignError] = useState<string | null>(null)
  const [beforeAssignSnapshot, setBeforeAssignSnapshot] = useState<{
    manualOverrides: OverrideMap
    sourceSwitches: SourceSwitchMap
  } | null>(null)

  const normalizeRangeValue = (value: number, fallback: number) => {
    if (!Number.isFinite(value)) return fallback
    return Math.min(Math.max(1, Math.floor(value)), safeMaxLen)
  }

  const hasPersistedAssignState = Boolean(assignRangeState && setAssignRangeState)

  const rangeFrom = hasPersistedAssignState
    ? normalizeRangeValue(assignRangeState!.from, 1)
    : normalizeRangeValue(localRangeFrom, 1)

  const rangeTo = hasPersistedAssignState
    ? normalizeRangeValue(assignRangeState!.to, safeMaxLen)
    : normalizeRangeValue(localRangeTo, safeMaxLen)

  const currentAssignValue = hasPersistedAssignState
    ? (assignRangeState!.value ?? '')
    : assignValue

  const persistAssignState = (next: { from: number; to: number; value: string }) => {
    const normalizedFrom = normalizeRangeValue(next.from, 1)
    const normalizedTo = normalizeRangeValue(next.to, safeMaxLen)
    const normalizedValue = next.value

    if (hasPersistedAssignState) {
      const prevFrom = assignRangeState!.from
      const prevTo = assignRangeState!.to
      const prevValue = assignRangeState!.value ?? ''

      if (prevFrom === normalizedFrom && prevTo === normalizedTo && prevValue === normalizedValue) {
        return
      }

      setAssignRangeState!({
        from: normalizedFrom,
        to: normalizedTo,
        value: normalizedValue
      })
      return
    }

    setLocalRangeFrom(normalizedFrom)
    setLocalRangeTo(normalizedTo)
    setAssignValue(normalizedValue)
  }

  useEffect(() => {
    if (!initializedLeftCountWatch.current) {
      previousLeftCount.current = leftCount
      initializedLeftCountWatch.current = true
      return
    }

    const leftCountChanged = previousLeftCount.current !== leftCount
    previousLeftCount.current = leftCount

    if (!leftCountChanged || !beforeAssignSnapshot) {
      return
    }

    setManualOverrides(beforeAssignSnapshot.manualOverrides)
    setSourceSwitches(beforeAssignSnapshot.sourceSwitches)
    setBeforeAssignSnapshot(null)
    setAssignError(null)
  }, [leftCount, beforeAssignSnapshot, setManualOverrides, setSourceSwitches])

  const handleLeftCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value)
    if (!Number.isNaN(val) && val >= 0) setLeftCount(val)
  }

  const handleAssignRange = () => {
    const normalizedAssignValue = currentAssignValue.trim()
    if (normalizedAssignValue === '') {
      setAssignError('Wpisz wartość przed kliknięciem Przypisz.')
      return
    }

    const parsedValue = Number(normalizedAssignValue)
    if (!Number.isFinite(parsedValue)) {
      setAssignError('Podaj poprawną wartość liczbową.')
      return
    }

    const safeFrom = Math.max(1, Math.floor(rangeFrom || 1))
    const safeTo = Math.max(1, Math.floor(rangeTo || 1))
    const start = Math.min(safeFrom, safeTo)
    const end = Math.max(safeFrom, safeTo)

    if (start > safeMaxLen || end < 1) {
      setAssignError('Zakres jest poza długością wektora Selected Value.')
      return
    }

    const clampedStart = Math.max(1, start)
    const clampedEnd = Math.min(safeMaxLen, end)

    const nextOverrides = { ...manualOverrides }
    const nextSwitches = { ...sourceSwitches }

    setBeforeAssignSnapshot({
      manualOverrides: { ...manualOverrides },
      sourceSwitches: { ...sourceSwitches }
    })

    for (let idx = clampedStart - 1; idx <= clampedEnd - 1; idx++) {
      nextOverrides[idx] = { curve: 'manual', value: parsedValue }
      if (nextSwitches[idx]) {
        delete nextSwitches[idx]
      }
    }

    setManualOverrides(nextOverrides)
    setSourceSwitches(nextSwitches)
    setAssignError(null)
  }

  const handleRestoreBeforeAssign = () => {
    if (!beforeAssignSnapshot) {
      return
    }

    setManualOverrides(beforeAssignSnapshot.manualOverrides)
    setSourceSwitches(beforeAssignSnapshot.sourceSwitches)
    setBeforeAssignSnapshot(null)
    setAssignError(null)
  }

  if (useClassicStyle) {
    return (
      <aside className="w-full h-fit shrink-0">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-3 rounded-lg bg-gray-800 p-3">
          <label className="flex items-center gap-2 text-sm font-medium whitespace-nowrap">
            <span className="text-white text-sm font-medium">Ilość pozostawionych</span>
            <input
              type="number"
              min={0}
              value={leftCount}
              onChange={handleLeftCountChange}
              className="w-24 bg-gray-600 border border-gray-500 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </label>
          </div>

          <div className="flex flex-wrap items-center gap-3 rounded-lg bg-gray-800 p-3">
            <div className="text-white text-sm font-medium whitespace-nowrap">Przypisz wartość:</div>
            <label className="flex items-center gap-1 text-xs text-gray-300">
              <span>Wartość</span>
              <input
                type="number"
                step="any"
                value={currentAssignValue}
                onChange={(e) => {
                  const nextValue = e.target.value
                  if (hasPersistedAssignState) {
                    persistAssignState({ from: rangeFrom, to: rangeTo, value: nextValue })
                  } else {
                    setAssignValue(nextValue)
                  }
                }}
                className="w-24 bg-gray-600 border border-gray-500 rounded-md px-2 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </label>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1 text-xs text-gray-300">
                <span>Od</span>
                <input
                  type="number"
                  min={1}
                  max={safeMaxLen}
                  value={rangeFrom}
                  onChange={(e) => {
                    const next = Number(e.target.value)
                    if (!Number.isFinite(next)) return
                    persistAssignState({ from: next, to: rangeTo, value: currentAssignValue })
                  }}
                  className="w-16 bg-gray-600 border border-gray-500 rounded-md px-2 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </label>

              <label className="flex items-center gap-1 text-xs text-gray-300">
                <span>Do</span>
                <input
                  type="number"
                  min={1}
                  max={safeMaxLen}
                  value={rangeTo}
                  onChange={(e) => {
                    const next = Number(e.target.value)
                    if (!Number.isFinite(next)) return
                    persistAssignState({ from: rangeFrom, to: next, value: currentAssignValue })
                  }}
                  className="w-16 bg-gray-600 border border-gray-500 rounded-md px-2 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </label>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAssignRange}
                className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-md px-3 py-2 text-xs font-bold transition-colors"
              >
                Przypisz
              </button>

              <button
                type="button"
                onClick={handleRestoreBeforeAssign}
                disabled={!beforeAssignSnapshot}
                className="bg-gray-600 hover:bg-gray-500 text-white rounded-md px-3 py-2 text-xs font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Przywróć
              </button>
            </div>

            {assignError && (
              <p className="text-xs text-red-300">{assignError}</p>
            )}

          </div>
        </div>
      </aside>
    )
  }

  return (
    <aside className="w-64 shrink-0 bg-gray-900 border-r border-gray-800 p-6 flex flex-col gap-6">
      <h3 className="text-lg font-semibold">Ustawienia</h3>
      <label className="flex flex-col gap-2 text-sm font-medium">
        <span>Ilość pozostawionych</span>
        <input
          type="number"
          min={0}
          value={leftCount}
          onChange={handleLeftCountChange}
          className="bg-gray-600 border border-gray-500 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-600/60"
        />
      </label>
    </aside>
  )
}
