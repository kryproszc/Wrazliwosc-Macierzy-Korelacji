// shared/components/Symulacje/SimulationControlPanel.tsx
'use client';

import { type ReactNode } from 'react';

export interface SimulationParams {
  iloscSymulacji: number;
  ziarno: number;
  podzialZiarna: number;
  skalowanie: number;
  skalowanie2: number;
}

export interface DataAvailabilityStatus {
  label: string;
  isAvailable: boolean;
  status: string;
  isRequired?: boolean;
}

export interface SimulationControlPanelProps {
  simulationParams: SimulationParams;
  kwantyle: string;
  isCalculating: boolean;
  isCalculatingStatistics: boolean;
  hasResults: boolean;
  statisticsResultsCount: number;
  dataAvailability: DataAvailabilityStatus[];
  
  onUpdateSimulationParam: (key: keyof SimulationParams, value: number) => void;
  onSetKwantyle: (value: string) => void;
  onExecuteCalculations: () => void;
  onExecuteStatistics: () => void;
  onClearResults: () => void;
  onClearStatistics: () => void;
  onExportStatistics: () => void;
  
  topContent?: ReactNode;
  children?: ReactNode;
  sidebarWidth?: string;
  sidebarPadding?: string;
  compactActionButtons?: boolean;
  actionSectionTopSpacingClassName?: string;
  placeExecuteButtonAboveDivider?: boolean;
  sectionSpacingClassName?: string;
}

export function SimulationControlPanel({
  simulationParams,
  kwantyle,
  isCalculating,
  isCalculatingStatistics,
  hasResults,
  statisticsResultsCount,
  dataAvailability,
  onUpdateSimulationParam,
  onSetKwantyle,
  onExecuteCalculations,
  onExecuteStatistics,
  onClearResults,
  onClearStatistics,
  onExportStatistics,
  topContent,
  children,
  sidebarWidth = 'w-80',
  sidebarPadding = 'p-6',
  compactActionButtons = false,
  actionSectionTopSpacingClassName = 'pt-3',
  placeExecuteButtonAboveDivider = false,
  sectionSpacingClassName = 'space-y-6',
}: SimulationControlPanelProps) {
  const hasMissingRequiredData = dataAvailability.some((item) => {
    const isRequired = item.isRequired !== false;
    return isRequired && !item.isAvailable;
  });
  const isExecuteDisabled = isCalculating || hasMissingRequiredData;
  const isStatisticsDisabled = isCalculatingStatistics || hasMissingRequiredData;

  const primaryActionButtonClass = compactActionButtons
    ? 'h-8 w-full rounded-xl px-3 text-xs font-bold transition-all duration-200 shadow-lg hover:shadow-2xl'
    : 'w-full py-4 px-5 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl transform';

  const secondaryActionButtonClass = compactActionButtons
    ? 'h-8 w-full rounded-lg px-3 text-xs font-medium transition-colors'
    : 'w-full py-2 px-3 rounded-lg font-medium text-sm transition-colors';

  return (
    <aside className={`${sidebarWidth} bg-[#1e293b] border-r border-gray-700 ${sidebarPadding} sticky top-0 h-full overflow-y-auto subtle-scrollbar`}>
      <div className={sectionSpacingClassName}>
        {topContent}

        {/* Parametry Symulacji */}
        <div className="space-y-3">
          {/* Ilość symulacji */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Ilość symulacji:
            </label>
            <input
              type="number"
              value={simulationParams.iloscSymulacji}
              onChange={(e) => onUpdateSimulationParam('iloscSymulacji', parseInt(e.target.value) || 1000)}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
              max="10000"
            />
          </div>

          {/* Podział ziarna */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Podział ziarna:
            </label>
            <input
              type="number"
              value={simulationParams.podzialZiarna}
              onChange={(e) => onUpdateSimulationParam('podzialZiarna', parseInt(e.target.value) || 1000)}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
            />
          </div>

          {/* Ziarno */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Ziarno:
            </label>
            <input
              type="number"
              value={simulationParams.ziarno}
              onChange={(e) => onUpdateSimulationParam('ziarno', parseInt(e.target.value) || 1111)}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
            />
          </div>
        </div>

        {/* Dodatkowa zawartość (np. specyficzne dla typu symulacji) */}
        {children}

        {placeExecuteButtonAboveDivider && (
          <div className="space-y-2">
            <button 
              onClick={onExecuteCalculations}
              disabled={isExecuteDisabled}
              className={`${primaryActionButtonClass} ${
                isExecuteDisabled
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 opacity-60 cursor-not-allowed'
                  : `bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 ${compactActionButtons ? 'hover:scale-[1.02]' : 'hover:scale-[1.02]'}`
              } text-white`}
            >
              {isCalculating ? 'Wykonywanie...' : 'Wykonaj symulacje'}
            </button>
          </div>
        )}

        {/* Divider */}
        <hr className="border-gray-600" />

        {/* Action Buttons */}
        <div className={`space-y-2 ${actionSectionTopSpacingClassName}`}>
          {!placeExecuteButtonAboveDivider && (
            <button 
              onClick={onExecuteCalculations}
              disabled={isExecuteDisabled}
              className={`${primaryActionButtonClass} ${
                isExecuteDisabled
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 opacity-60 cursor-not-allowed'
                  : `bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 ${compactActionButtons ? 'hover:scale-[1.02]' : 'hover:scale-[1.02]'}`
              } text-white`}
            >
              {isCalculating ? 'Wykonywanie...' : 'Wykonaj symulacje'}
            </button>
          )}
          
          {/* Skalowanie 1 */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Skalowanie 1:
            </label>
            <input
              type="number"
              step="0.1"
              value={simulationParams.skalowanie}
              onChange={(e) => {
                const nextValue = Number(e.target.value);
                if (Number.isFinite(nextValue)) {
                  onUpdateSimulationParam('skalowanie', nextValue);
                }
              }}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Skalowanie 2 */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Skalowanie 2:
            </label>
            <input
              type="number"
              step="0.1"
              value={simulationParams.skalowanie2}
              onChange={(e) => {
                const nextValue = Number(e.target.value);
                if (Number.isFinite(nextValue)) {
                  onUpdateSimulationParam('skalowanie2', nextValue);
                }
              }}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Kwantyle */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Kwantyle:
            </label>
            <input
              type="text"
              value={kwantyle}
              onChange={(e) => onSetKwantyle(e.target.value)}
              className="w-full rounded-md border border-gray-600 bg-white px-3 py-2 text-sm font-medium text-black focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,0.995"
            />
          </div>

          {/* Przycisk Wykonaj statystyki */}
          <button 
            onClick={onExecuteStatistics}
            disabled={isStatisticsDisabled}
            className={`${primaryActionButtonClass} ${
              isStatisticsDisabled
                ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 opacity-60 cursor-not-allowed'
                : `bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 ${compactActionButtons ? 'hover:scale-[1.02]' : 'hover:scale-[1.02]'}`
            } text-white`}
          >
            {isCalculatingStatistics ? 'Wykonywanie statystyk...' : 'Oblicz statystyki'}
          </button>
          
          {false && hasResults && (
            <button 
              onClick={onClearResults}
              className={`${secondaryActionButtonClass} bg-red-600 text-white hover:bg-red-700`}
            >
              🗑️ Wyczyść wyniki
            </button>
          )}
          
          {statisticsResultsCount > 0 && (
            <>
              {false && (
                <button 
                  onClick={onClearStatistics}
                  className={`${secondaryActionButtonClass} bg-purple-600 text-white hover:bg-purple-700`}
                >
                  📊 Wyczyść statystyki
                </button>
              )}
              
              <button 
                onClick={onExportStatistics}
                className={`${secondaryActionButtonClass} bg-gray-600 text-white hover:bg-gray-700`}
              >
                📊 Generuj raport
              </button>
            </>
          )}
        </div>
      </div>
    </aside>
  );
}