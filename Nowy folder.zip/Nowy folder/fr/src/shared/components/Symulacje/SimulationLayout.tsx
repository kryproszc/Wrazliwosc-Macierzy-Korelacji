// shared/components/Symulacje/SimulationLayout.tsx
'use client';

import { type ReactNode } from 'react';

export interface SimulationLayoutProps {
  sidebar: ReactNode;
  children: ReactNode;
  mainPadding?: string;
}

export function SimulationLayout({ sidebar, children, mainPadding = 'p-8' }: SimulationLayoutProps) {
  return (
    <div className="flex h-full min-h-0 bg-[#0f172a]">
      {/* Sidebar Panel */}
      {sidebar}

      {/* Main Content Area */}
      <main className={`flex-1 ${mainPadding} bg-[#0f172a] min-h-0`}>
        <div className="w-full max-w-none">
          <div className="space-y-6">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}