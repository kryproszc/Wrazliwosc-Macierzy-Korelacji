'use client';

import React from 'react';

export interface ResultRow {
  label: string;
  values: (number | null | undefined)[];
  visible?: boolean;
}

interface Props {
  title?: string;
  headerLabels: string[];
  rows: ResultRow[];
  decimalPlaces: number;
  className?: string;
  fullscreenMode?: boolean;
}

export default function ResultsTable({
  title = "Wyniki obliczeń",
  headerLabels,
  rows,
  decimalPlaces,
  className = "",
  fullscreenMode = false,
}: Props) {
  console.log('📋 [ResultsTable] Otrzymane dane:', {
    title,
    rows: rows.map(r => ({
      label: r.label,
      values: r.values,
      valuesLength: r.values?.length,
      visible: r.visible,
      hasValues: r.values && r.values.some(v => v != null)
    })),
    headerLabels
  });

  // Pokaż tylko wiersze które są widoczne lub mają dane
  const visibleRows = rows.filter(row => 
    row.visible !== false && (row.values && row.values.some(v => v != null))
  );

  console.log('👁️ [ResultsTable] Widoczne wiersze:', visibleRows.map(r => r.label));

  if (visibleRows.length === 0) {
    return null;
  }

  const titleColor = "text-gray-800";

  return (
    <div className={`mt-2 rounded-2xl border-2 border-gray-400 bg-white px-3 py-3 shadow-sm ${className}`}>
      <h3 className={`font-semibold mb-3 text-lg ${titleColor}`}>{title}</h3>
      <div className="overflow-x-auto rounded-xl border border-gray-300 pb-2">
        <table className="min-w-max table-auto border-separate border-spacing-0 text-gray-800">
          <thead>
            <tr>
              <th className="border-t border-b border-l-2 border-r-2 border-gray-400 px-3 py-2 bg-gray-100 text-gray-800 rounded-tl-xl">
                Typ
              </th>
              {headerLabels.map((label, i) => (
                <th
                  key={i}
                  className={`border-t border-b border-r border-gray-300 px-3 py-2 bg-gray-100 text-center text-gray-800 font-semibold ${
                    i === headerLabels.length - 1 ? 'rounded-tr-xl' : ''
                  }`}
                >
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visibleRows.map((row, rowIndex) => {
              const isLastRow = rowIndex === visibleRows.length - 1;
              const paddedValues = [
                ...(row.values ?? []),
                ...Array.from({ length: Math.max(0, headerLabels.length - (row.values?.length ?? 0)) }).map(() => null),
              ].slice(0, headerLabels.length);

              return (
                <tr key={row.label}>
                  <td
                    className={`border-b border-l-2 border-r-2 border-gray-400 px-3 py-2 bg-gray-50 font-medium text-gray-800 ${
                      isLastRow ? 'rounded-bl-xl' : ''
                    }`}
                  >
                    {row.label}
                  </td>
                  {paddedValues.map((value, i) => (
                    <td
                      key={`${row.label}-${i}`}
                      className={`border-b border-r border-gray-300 px-3 py-2 text-center font-mono bg-white ${
                        value != null ? 'text-gray-800' : 'text-gray-500'
                      } ${isLastRow && i === headerLabels.length - 1 ? 'rounded-br-xl' : ''}`}
                    >
                      {value != null ? value.toFixed(decimalPlaces) : '-'}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}