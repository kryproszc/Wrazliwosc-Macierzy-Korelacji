'use client';

import React from 'react';

interface CalculationLayoutProps {
  sidebar: React.ReactNode;
  children: React.ReactNode;
  sidebarWidth?: string;
  sidebarPadding?: string;
  mainPadding?: string;
  className?: string;
}

export function CalculationLayout({ 
  sidebar, 
  children, 
  sidebarWidth = "w-80",
  sidebarPadding = "p-6",
  mainPadding = "p-8",
  className = ""
}: CalculationLayoutProps) {
  return (
    <div className={`flex h-full min-h-0 bg-[#0f172a] ${className}`}>
      {/* Sidebar Panel */}
      <aside className={`${sidebarWidth} bg-[#1e293b] border-r border-gray-700 ${sidebarPadding} sticky top-0 h-full overflow-y-auto subtle-scrollbar`}>
        {sidebar}
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 ${mainPadding} bg-[#0f172a] min-h-0`}>
        <div className="w-full max-w-none">
          {children}
        </div>
      </main>
    </div>
  );
}