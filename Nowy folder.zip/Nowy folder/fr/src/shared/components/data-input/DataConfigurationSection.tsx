import { HeadersSelector } from '@/components/HeadersSelector';
import { DataTypeSelector, type DataType } from '@/components/DataTypeSelector';
import { InflationSelector } from './InflationSelector';

interface DataConfigurationSectionProps {
  hasHeaders: boolean;
  onHeadersChange: (hasHeaders: boolean) => void;
  dataType: DataType;
  onDataTypeChange: (dataType: DataType) => void;
  hasInflationData: boolean;
  useInflation: boolean;
  onInflationChange: (useInflation: boolean) => void;
  showHeaders?: boolean;
}

export function DataConfigurationSection({
  hasHeaders,
  onHeadersChange,
  dataType,
  onDataTypeChange,
  hasInflationData,
  useInflation,
  onInflationChange,
  showHeaders = true,
}: DataConfigurationSectionProps) {
  return (
    <div className="space-y-3">
      {/* --- Czy dane zawierają podpisy --- */}
      {showHeaders && (
        <HeadersSelector 
          hasHeaders={hasHeaders} 
          onHeadersChange={onHeadersChange} 
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:items-stretch">
        {/* --- Typ danych --- */}
        <DataTypeSelector
          dataType={dataType}
          onDataTypeChange={onDataTypeChange}
        />

        {/* --- Uwzględnianie inflacji --- */}
        <InflationSelector
          hasInflationData={hasInflationData}
          useInflation={useInflation}
          onInflationChange={onInflationChange}
        />
      </div>
    </div>
  );
}