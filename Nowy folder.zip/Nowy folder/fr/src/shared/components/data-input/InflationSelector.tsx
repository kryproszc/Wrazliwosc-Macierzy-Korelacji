import { Label } from '@/components/ui/label';

interface InflationSelectorProps {
  hasInflationData: boolean;
  useInflation: boolean;
  onInflationChange: (use: boolean) => void;
}

export function InflationSelector({ 
  hasInflationData, 
  useInflation, 
  onInflationChange 
}: InflationSelectorProps) {
  return (
    <div className="w-full rounded-lg border border-slate-500/40 bg-slate-800/20 p-2.5">
      <Label className="text-base leading-tight tracking-tight font-semibold text-slate-100">
        Uwzględnianie inflacji
      </Label>
      <div className="mt-2 flex flex-col gap-1">
        <label className={`group flex items-center space-x-2 rounded-md px-1 py-1 ${!hasInflationData ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-600/60 transition-colors'}`}>
          <input
            type="radio"
            name="inflation"
            checked={useInflation === true}
            onChange={() => hasInflationData && onInflationChange(true)}
            disabled={!hasInflationData}
            className="h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <span className="text-sm text-slate-200 group-hover:text-white">
            ✓ Uwzględnij współczynniki inflacji w obliczeniach
          </span>
        </label>
        <label className={`group flex items-center space-x-2 rounded-md px-1 py-1 ${!hasInflationData ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-600/60 transition-colors'}`}>
          <input
            type="radio"
            name="inflation"
            checked={useInflation === false}
            onChange={() => hasInflationData && onInflationChange(false)}
            disabled={!hasInflationData}
            className="h-4 w-4 text-blue-500 bg-slate-700 border-slate-400 focus:ring-2 focus:ring-blue-400"
          />
          <span className="text-sm text-slate-200 group-hover:text-white">
            ✗ Nie uwzględniaj współczynników inflacji w obliczeniach
          </span>
        </label>
      </div>
      
      {!hasInflationData && (
        <div className="mt-2 rounded-md border border-rose-300/30 bg-rose-400/10 px-2 py-1.5 text-xs text-rose-200">
          ❌ Dane inflacji są niedostępne - możesz włączyć uwzględnianie inflacji
        </div>
      )}
    </div>
  );
}