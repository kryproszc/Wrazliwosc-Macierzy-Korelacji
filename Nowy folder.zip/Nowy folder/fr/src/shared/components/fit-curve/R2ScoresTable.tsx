'use client';

import React from 'react';
import { GenericTable } from '@/shared/ui';

interface R2ScoresTableProps {
  r2Scores: Record<string, number>;
  title: string;
  useClassicPaidStyle?: boolean;
}

export function R2ScoresTable({
  r2Scores,
  title,
  useClassicPaidStyle = false
}: R2ScoresTableProps) {
  const sorted = Object.entries(r2Scores).sort((a, b) => b[1] - a[1]);

  const renderCell = (row: number, col: number) => {
    const pair = sorted[row];
    if (!pair) return null;
    const [curve, r2] = pair;

    return col === 0 ? <strong>{curve}</strong> : r2.toFixed(6);
  };

  return (
    <section className={useClassicPaidStyle ? 'w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white' : undefined}>
      {useClassicPaidStyle ? (
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-2 border-b-2 border-gray-400 rounded-t-2xl">
          <h2 className="font-bold text-gray-800 text-base tracking-tight">{title}</h2>
        </div>
      ) : (
        <h2 className="text-xl font-bold mb-4 text-center">{title}</h2>
      )}

      {useClassicPaidStyle ? (
        <div className="overflow-auto p-4">
          <div className="relative w-full overflow-x-auto rounded-xl">
            <table className="min-w-max border-collapse bg-white text-sm text-gray-800">
              <thead>
                <tr>
                  {['Krzywa', 'R²'].map((column, index) => (
                    <th
                      key={index}
                      className="border border-gray-300 px-3 py-2 bg-gray-50 text-center"
                    >
                      {column}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: Object.keys(r2Scores).length }).map((_, row) => (
                  <tr key={row}>
                    {[0, 1].map((col) => (
                      <td
                        key={col}
                        className="border border-gray-300 px-3 py-2 text-center"
                      >
                        {renderCell(row, col)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <GenericTable
          cols={['Krzywa', 'R²']}
          rows={Object.keys(r2Scores).length}
          stickyFirstCol
          renderCell={renderCell}
        />
      )}
    </section>
  );
}