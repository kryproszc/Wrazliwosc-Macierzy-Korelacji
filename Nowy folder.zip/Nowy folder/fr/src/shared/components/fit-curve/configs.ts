// Konfiguracje dla różnych typów FitCurve
import type { FitCurveConfig } from './types';

const FIT_CURVE_TITLES = {
  tableTitle: 'Wyliczone współczynniki',
  resultsTableTitle: 'Współczynniki z dopasowanej krzywej',
  r2TableTitle: 'Wyliczone R^2',
  chartTitle: 'Wykres współczynnikow',
} as const;

export const DEV_J_CONFIG: FitCurveConfig = {
  dataType: 'devJ',
  apiEndpoint: '/calc/paid/selected_dev_j',
  thresholdValue: 1,
  dataKey: 'selected_dev_j',
  
  displayName: 'Dev J',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-blue-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki CL" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 1, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_CONFIG: FitCurveConfig = {
  dataType: 'sigma',
  apiEndpoint: '/calc/sigma/selected_sigma',
  thresholdValue: 0,
  dataKey: 'selected_sigma',
  
  displayName: 'Sigma',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-red-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych sigma z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Łatwo dodać nowe konfiguracje:
export const SD_CONFIG: FitCurveConfig = {
  dataType: 'sd',
  apiEndpoint: '/calc/sd/selected_sd',
  thresholdValue: 0,
  dataKey: 'selected_sd',
  
  displayName: 'SD',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'SD_weighted'],
  initialSelectionColor: 'text-green-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych SD z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki SD" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora SD',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

export const ADD_J_CONFIG: FitCurveConfig = {
  dataType: 'addJ',
  apiEndpoint: '/calc/add/selected_add_j',
  thresholdValue: 0,
  dataKey: 'selected_add_j',
  
  displayName: 'Add J',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'AddJ_weighted'],
  initialSelectionColor: 'text-green-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych Add J z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Add J" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Add J',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Add J?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_LR_CONFIG: FitCurveConfig = {
  dataType: 'sigmaLR',
  apiEndpoint: '/calc/add/selected_sigma_LR',
  thresholdValue: 0,
  dataKey: 'selected_sigma_l_r',
  
  displayName: 'Sigma LR',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-orange-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych Sigma LR z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma LR" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma LR',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma LR?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Incurred configurations
export const DEV_J_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'devJ',
  apiEndpoint: '/calc/incurred/selected_dev_j',
  thresholdValue: 1,
  dataKey: 'selected_dev_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - tylko na żądanie przez "Zaktualizuj wektor"
  
  displayName: 'Dev J (Incurred)',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-cyan-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki CL" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora (Incurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 1, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'sigma',
  apiEndpoint: '/calc/incurred/selected_sigma',
  thresholdValue: 0,
  dataKey: 'selected_sigma',
  
  displayName: 'Sigma (Incurred)',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-emerald-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych sigma z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma (Incurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// PaidIncurred configurations
export const R_J_PAID_TO_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'rJ',
  apiEndpoint: '/calc/paid_incurred/fit_curve_rj',
  thresholdValue: -0.001,
  dataKey: 'r_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - użytkownik musi ręcznie kliknąć "Zaktualizuj wektor"
  
  displayName: 'r_j (PaidToIncurred)',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection'], // Będzie rozszerzane dynamicznie o wszystkie krzywe z API
  initialSelectionColor: 'text-violet-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych r_j z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Paid to Incurred" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora r_j (PaidToIncurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor r_j?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości ≠ 1, aby wybrać je do dopasowania krzywych (wartości równe 1 są automatycznie wyłączone)'
};

export const VAR_J_PAID_TO_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'varJ',
  apiEndpoint: '/calc/paid_incurred/fit_curve_varj',
  thresholdValue: 0,
  dataKey: 'var_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - użytkownik musi ręcznie kliknąć "Zaktualizuj wektor"
  
  displayName: 'var_j (PaidToIncurred)',
  tableTitle: FIT_CURVE_TITLES.tableTitle,
  resultsTableTitle: FIT_CURVE_TITLES.resultsTableTitle,
  r2TableTitle: FIT_CURVE_TITLES.r2TableTitle,
  chartTitle: FIT_CURVE_TITLES.chartTitle,
  
  selectedCurves: ['Initial Selection', 'VarJ_weighted'],
  initialSelectionColor: 'text-rose-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych var_j z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Paid to Incurred" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora var_j (PaidToIncurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor var_j?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Export all configs for easy access
export const FIT_CURVE_CONFIGS = {
  devJ: DEV_J_CONFIG,
  sigma: SIGMA_CONFIG,
  sd: SD_CONFIG,
  addJ: ADD_J_CONFIG,
  sigmaLR: SIGMA_LR_CONFIG,
  devJIncurred: DEV_J_INCURRED_CONFIG,
  sigmaIncurred: SIGMA_INCURRED_CONFIG,
  rJPaidToIncurred: R_J_PAID_TO_INCURRED_CONFIG,
  varJPaidToIncurred: VAR_J_PAID_TO_INCURRED_CONFIG,
} as const;