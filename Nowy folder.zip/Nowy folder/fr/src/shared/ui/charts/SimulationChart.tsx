import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

type SimResults = Record<string, Record<string, number>>;

type Props = {
  simResults: SimResults | null;
  devJ?: number[];
  dpRange: [number, number];
  selectedCurves: string[];
  useClassicPaidStyle?: boolean;
};

export const SimulationChart = ({
  simResults,
  devJ,
  dpRange,
  selectedCurves,
  useClassicPaidStyle = false,
}: Props) => {
  // Oblicz dynamiczny domain Y na podstawie wszystkich wartości
  const yAxisDomain = useMemo(() => {
    if (!simResults) return [0, 1];
    
    const allValues: number[] = [];
    

    
    // Zbierz wszystkie wartości z simResults
    Object.values(simResults).forEach(curveData => {
      Object.values(curveData).forEach(value => {
        if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
          allValues.push(value);
        }
      });
    });
    
    // Dodaj wartości z devJ (Initial Selection)
    if (devJ) {
      devJ.forEach(value => {
        if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
          allValues.push(value);
        }
      });
    }
    
    if (allValues.length === 0) return [0, 1];
    
    const minValue = Math.min(...allValues);
    const maxValue = Math.max(...allValues);
    const range = maxValue - minValue;
    
    // Dodaj 10% marginesu w górę i w dół
    const margin = range * 0.1;
    const yMin = minValue - margin;
    const yMax = maxValue + margin;
    
    return [yMin, yMax];
  }, [simResults, devJ]);

  const data = useMemo(() => {
    if (!simResults) return [];
    
    // Weź klucze z pierwszej dostępnej krzywej zamiast zakładać że jest "Exponential"
    const firstCurve = Object.keys(simResults)[0];
    if (!firstCurve) return [];
    

    
    const allDpKeys = Object.keys(simResults[firstCurve] ?? {});
    const chartData = allDpKeys
      .filter((dpKey) => {
        const n = parseInt(dpKey.replace("dp: ", ""), 10);
        return n >= dpRange[0] && n <= dpRange[1];
      })
      .map((dpKey) => {
        const point: Record<string, number | string> = { dp: dpKey };
        for (const curve in simResults) {
          point[curve] = simResults[curve]?.[dpKey] ?? 0;
        }
        const idx = parseInt(dpKey.replace("dp: ", ""), 10) - 1;
        const devVal = devJ?.[idx];
        if (typeof devVal === "number") point["Initial Selection"] = devVal;
        return point;
      });
      
    return chartData;
  }, [simResults, devJ, dpRange, selectedCurves]);

  if (!simResults) return null;

  // Funkcja do formatowania liczb
  const formatNumber = (value: number): string => {
    if (value >= 1000000) {
      return (value / 1000000).toFixed(2) + 'M';
    }
    if (value >= 1000) {
      return (value / 1000).toFixed(2) + 'k';
    }
    return value.toFixed(3);
  };

  const formatClassicNumber = (value: number): string => value.toFixed(2);

  // Funkcja do formatowania tooltipa
  const formatTooltip = (value: any, name: string) => {
    if (typeof value === 'number') {
      return [formatNumber(value), name];
    }
    return [value, name];
  };

  const getCurveColor = (curveName: string): string => {
    if (useClassicPaidStyle) {
      if (curveName === 'Exponential') return '#2563eb';
      if (curveName === 'Weibull') return '#059669';
      if (curveName === 'Power') return '#d97706';
      if (curveName === 'Inverse Power') return '#7c3aed';
      return '#4f8bff';
    }

    const colors = [
      '#8b5cf6',
      '#10b981',
      '#f59e0b',
      '#2dd4bf',
      '#4f8bff',
      '#f87171',
      '#facc15',
      '#ec4899',
    ];
    const index = Object.keys(simResults ?? {}).findIndex((name) => name === curveName);
    return colors[(index >= 0 ? index : 0) % colors.length] ?? '#4f8bff';
  };

  return (
    <div
      className={useClassicPaidStyle ? 'bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-4 text-gray-900 w-full h-[650px]' : 'w-full h-[600px]'}
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={useClassicPaidStyle ? { top: 40, right: 60, left: 80, bottom: 100 } : { top: 30, right: 40, left: 80, bottom: 100 }}
          style={useClassicPaidStyle ? undefined : { background: '#1a1a2e', borderRadius: 12, padding: 15 }}
        >
          <CartesianGrid
            stroke={useClassicPaidStyle ? '#9ca3af' : '#444'}
            strokeDasharray={useClassicPaidStyle ? '2 2' : '3 3'}
            strokeWidth={1}
          />
          <XAxis 
            dataKey="dp" 
            stroke={useClassicPaidStyle ? '#374151' : '#ccc'}
            interval={0} 
            tick={useClassicPaidStyle ? { fill: '#374151', fontSize: 14, fontFamily: 'serif' } : { fill: '#ccc', fontSize: 14 }}
            tickLine={useClassicPaidStyle ? { stroke: '#374151', strokeWidth: 1 } : undefined}
            axisLine={useClassicPaidStyle ? { stroke: '#374151', strokeWidth: 2 } : undefined}
            label={useClassicPaidStyle ? {
              value: 'Okres rozwoju (dp)',
              position: 'insideBottom',
              offset: -15,
              style: { textAnchor: 'middle', fontSize: '14px', fontFamily: 'serif', fill: '#374151', fontWeight: '600' }
            } : undefined}
          />
          <YAxis 
            stroke={useClassicPaidStyle ? '#374151' : '#ccc'}
            domain={useClassicPaidStyle ? ['auto', 'auto'] : yAxisDomain}
            tick={useClassicPaidStyle ? { fill: '#374151', fontSize: 14, fontFamily: 'serif' } : { fill: '#ccc', fontSize: 12 }}
            tickLine={useClassicPaidStyle ? { stroke: '#374151', strokeWidth: 1 } : undefined}
            axisLine={useClassicPaidStyle ? { stroke: '#374151', strokeWidth: 2 } : undefined}
            tickFormatter={useClassicPaidStyle ? formatClassicNumber : formatNumber}
            width={80}
            label={useClassicPaidStyle ? {
              value: 'Współczynnik rozwoju',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '14px', fontFamily: 'serif', fill: '#374151', fontWeight: '600' }
            } : undefined}
          />
          <Tooltip
            contentStyle={useClassicPaidStyle ? {
              background: '#f9fafb',
              borderColor: '#6b7280',
              color: '#111827',
              border: '2px solid #6b7280',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              fontSize: '14px',
              padding: '12px'
            } : {
              background: '#2c2c3e',
              borderColor: '#666',
              color: '#fff',
              fontSize: '14px',
              borderRadius: '8px'
            }}
            labelStyle={useClassicPaidStyle ? { color: '#374151', fontWeight: '600', fontSize: '14px' } : { color: '#aaa', fontSize: '12px' }}
            formatter={useClassicPaidStyle
              ? (value: any, name: string) => [typeof value === 'number' ? value.toFixed(4) : value, name]
              : formatTooltip}
          />
          <Legend 
            verticalAlign="bottom" 
            height={60} 
            wrapperStyle={useClassicPaidStyle
              ? {
                  paddingTop: 25,
                  color: '#374151',
                  fontSize: '14px',
                  fontFamily: 'serif',
                  fontWeight: '500'
                }
              : {
                  paddingTop: 30,
                  fontSize: '14px'
                }}
          />

          {selectedCurves.includes("Initial Selection") && (
            <Line
              type="monotone"
              dataKey="Initial Selection"
              stroke={useClassicPaidStyle ? '#dc2626' : '#ef4444'}
              strokeWidth={useClassicPaidStyle ? 4 : 3}
              name="Initial Selection"
              dot={useClassicPaidStyle ? { fill: '#dc2626', strokeWidth: 2, r: 5 } : { r: 4 }}
              activeDot={useClassicPaidStyle ? { r: 8, stroke: '#dc2626', strokeWidth: 3, fill: '#ffffff' } : undefined}
            />
          )}
          
          {/* Dynamiczne renderowanie wszystkich krzywych z simResults */}
          {simResults && Object.keys(simResults).map((curveName) => {
            if (!selectedCurves.includes(curveName) || curveName === "Initial Selection") return null;
            const color = getCurveColor(curveName);
            
            return (
              <Line 
                key={curveName}
                type="monotone" 
                dataKey={curveName} 
                stroke={color} 
                strokeWidth={useClassicPaidStyle ? 3.5 : 3}
                name={curveName}
                dot={useClassicPaidStyle ? { fill: color, strokeWidth: 1.5, r: 4 } : { r: 4 }}
                activeDot={useClassicPaidStyle ? { r: 7, stroke: color, strokeWidth: 3, fill: '#ffffff' } : undefined}
              />
            );
          })}
          
          {/* Backward compatibility - static curves */}
          {selectedCurves.includes("Exponential") && !simResults?.["Exponential"] && (
            <Line type="monotone" dataKey="Exponential" stroke="#4f8bff" strokeWidth={3} dot={{ r: 4 }} />
          )}
          {selectedCurves.includes("Exponential_weighted") && !simResults?.["Exponential_weighted"] && (
            <Line type="monotone" dataKey="Exponential_weighted" stroke="#8b5cf6" strokeWidth={3} name="Exponential Weighted" dot={{ r: 4 }} />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
