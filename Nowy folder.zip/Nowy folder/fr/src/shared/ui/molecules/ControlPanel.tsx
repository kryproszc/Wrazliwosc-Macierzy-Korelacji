import { Button } from "../atoms/Button";
import { InputNumber } from "../atoms/InputNumber";
import { Card } from "../atoms/Card";

type Props = {
  currentVectorLength: number;
  tailCount: number | "";
  onTailChange: (v: number | "") => void;
  onUpdateVector: () => void;
  onSend: () => void;
  disableSend: boolean;
};

export const ControlPanel = ({
  currentVectorLength,
  tailCount,
  onTailChange,
  onUpdateVector,
  onSend,
  disableSend,
}: Props) => (
  <Card className="w-full h-fit shrink-0">
    <div className="flex flex-wrap items-center gap-4">
      <Button
        onClick={onUpdateVector}
        disabled={!currentVectorLength}
        className={`h-8 w-48 px-3 text-xs rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
          currentVectorLength
            ? 'bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white'
            : 'bg-gray-600 text-gray-400 cursor-not-allowed'
        }`}
      >
        Zaktualizuj wektor
      </Button>

      <div className="h-8 border-l border-gray-600" aria-hidden="true" />

      <div className="flex items-center gap-2">
        <label className="text-sm whitespace-nowrap">Obserwacje w&nbsp;ogonie:</label>
        <InputNumber
          min={0}
          value={tailCount}
          placeholder="np. 2"
          className="h-8 w-20"
          onChange={(e) =>
            onTailChange(e.target.value === "" ? "" : parseInt(e.target.value, 10))
          }
        />
      </div>

      <Button
        variant="success"
        onClick={onSend}
        disabled={disableSend}
        className={`h-8 w-48 px-3 text-xs rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
          disableSend
            ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
            : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white'
        }`}
      >
        Dopasuj krzywe
      </Button>
    </div>

  </Card>
);
