import { TableData } from '@/components/TableData';

interface DataTableViewProps {
  title: string;
  data: string[][] | null | undefined;
  noDataMessage: string;
  fallbackComponent?: React.ComponentType;
  className?: string;
  titleClassName?: string;
  tableWrapperClassName?: string;
  lightHeaderClassName?: string;
  lightTitleClassName?: string;
  variant?: 'dark' | 'light';
}

/**
 * Generic reusable table view component for displaying formatted data
 * Part of Atomic Design - Molecule level
 */
export function DataTableView({
  title,
  data,
  noDataMessage,
  fallbackComponent: FallbackComponent,
  className = "space-y-4",
  titleClassName = "text-xl font-semibold",
  tableWrapperClassName = "w-full overflow-auto",
  lightHeaderClassName = "bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-2 border-b-2 border-gray-400 rounded-t-2xl",
  lightTitleClassName = "font-bold text-gray-800 text-lg tracking-tight",
  variant = 'dark'
}: DataTableViewProps) {
  
  if (!data || data.length === 0) {
    return (
      <div className={className}>
        <p className={`text-sm ${
          variant === 'dark' ? 'text-gray-400' : 'text-gray-600'
        }`}>
          {noDataMessage}
        </p>
        {FallbackComponent && <FallbackComponent />}
      </div>
    );
  }

  if (variant === 'light') {
    return (
      <div className={`rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white ${className}`}>
        {title && (
          <div className={lightHeaderClassName}>
            <h3 className={lightTitleClassName}>{title}</h3>
          </div>
        )}
        <div className="px-4 pb-6 pt-4">
          <div className={tableWrapperClassName}>
            <TableData data={data} variant={variant} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      {title && (
        <h2 className={`${titleClassName} ${
          variant === 'dark' ? 'text-white' : 'text-gray-800'
        }`}>
          {title}
        </h2>
      )}
      <div className={tableWrapperClassName}>
        <TableData data={data} variant={variant} />
      </div>
    </div>
  );
}
