'use client';

import Modal from '@/components/Modal';

export type SidebarPanelBaseProps = {
  volume: number;
  onVolumeChange: (v: number) => void;
  maxVolume?: number;
  showVolume?: boolean;

  onCalculate: () => void;
  onExport   : () => void;
  onReset    : () => void;
  fullWidthActions?: boolean;

  isResetModalOpen       : boolean;
  setResetModalOpen      : (b: boolean) => void;
  isMissingFinalModalOpen: boolean;
  closeMissingFinalModal : () => void;
};

export default function SidebarPanelBase({
  volume,
  onVolumeChange,
  maxVolume,
  showVolume = true,
  onCalculate,
  onExport,
  onReset,
  fullWidthActions = false,
  isResetModalOpen,
  setResetModalOpen,
  isMissingFinalModalOpen,
  closeMissingFinalModal,
}: SidebarPanelBaseProps) {
  return (
    <div className="w-full flex flex-col gap-3">
      {showVolume && (
        <>
          <label className="text-sm text-white">Wybierz volume</label>
          <input
            type="number"
            className="w-full p-3 rounded bg-white text-black font-medium"
            value={volume}
            min={0}
            max={maxVolume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
          />
        </>
      )}

      <button
        onClick={onCalculate}
        className={`${fullWidthActions ? 'w-full' : 'mx-auto w-40'} h-8 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-emerald-700 hover:to-emerald-600 hover:shadow-2xl`}
      >
        Oblicz
      </button>

      <button
        onClick={onExport}
        className={`${fullWidthActions ? 'w-full' : 'mx-auto w-40'} h-8 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-amber-700 hover:to-amber-600 hover:shadow-2xl`}
      >
        Eksportuj do Excela
      </button>

      <button
        onClick={() => setResetModalOpen(true)}
        className={`${fullWidthActions ? 'w-full' : 'mx-auto w-40'} h-8 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 px-3 text-xs font-bold text-white shadow-lg transition-all duration-200 hover:scale-[1.02] hover:from-orange-700 hover:to-orange-600 hover:shadow-2xl`}
      >
        Reset współczynników
      </button>

      <Modal
        isOpen={isResetModalOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetModalOpen(false)}
        onConfirm={() => {
          onReset();
          setResetModalOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />
    </div>
  );
}
