import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type TriangleData = (number | null)[][] | null;

export interface AddIncurredStore {
  incurredTriangle: TriangleData;
  rowLabels: string[];
  columnLabels: string[];

  setTriangleSnapshot: (
    triangle: TriangleData,
    rowLabels: string[],
    columnLabels: string[]
  ) => void;
  resetData: () => void;
}

const initialState = {
  incurredTriangle: null,
  rowLabels: [],
  columnLabels: [],
};

export const useAddIncurredStore = create<AddIncurredStore>()(
  persist(
    (set) => ({
      ...initialState,

      setTriangleSnapshot: (triangle, rowLabels, columnLabels) =>
        set({
          incurredTriangle: triangle,
          rowLabels,
          columnLabels,
        }),

      resetData: () => set(initialState),
    }),
    {
      name: 'addincurred-store',
      partialize: (state) => ({
        incurredTriangle: state.incurredTriangle,
        rowLabels: state.rowLabels,
        columnLabels: state.columnLabels,
      }),
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);
