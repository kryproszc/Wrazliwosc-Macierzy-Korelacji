import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type DeterministicMethodType = 'multiplikatywna' | 'addytywna' | 'mix';

export interface IncurredTabResults {
	last_col_incurred: number[];
	cum_trian_incurred: number[];
	ult_net_disc_incurred: number[];
	userId?: string;
	shouldShowResults: boolean;
}

interface DeterministicIncurredResultsState {
	methodType: DeterministicMethodType;
	kChange: string;
	results: IncurredTabResults | null;
	setMethodType: (methodType: DeterministicMethodType) => void;
	setKChange: (kChange: string) => void;
	setResults: (results: IncurredTabResults) => void;
	clearResults: () => void;
	resetAll: () => void;
}

const initialState = {
	methodType: 'multiplikatywna' as DeterministicMethodType,
	kChange: '0',
	results: null as IncurredTabResults | null,
};

export const useDeterministicIncurredResultsStore = create<DeterministicIncurredResultsState>()(
	persist(
		(set) => ({
			...initialState,
			setMethodType: (methodType) => set({ methodType }),
			setKChange: (kChange) => set({ kChange }),
			setResults: (results) => set({ results }),
			clearResults: () => set({ results: null }),
			resetAll: () => set(initialState),
		}),
		{
			name: 'deterministic-incurred-results-storage',
			storage: createJSONStorage(() => sessionStorage),
			partialize: (state) => ({
				methodType: state.methodType,
				kChange: state.kChange,
				results: state.results,
			}),
		}
	)
);
