import type { WorkBook } from "xlsx";
import { create } from "zustand";
import { persist } from "zustand/middleware";

// Typy dla Stopy dyskontowe store
export interface DiscountRatesTriangleData {
	[rowIndex: number]: {
		[colIndex: number]: number | string | null; // Dodaj string dla labeli
	};
}

export interface DiscountRatesStore {
	// Dane trójkąta stóp dyskontowych
	discountRatesTriangle: DiscountRatesTriangleData;
	workbook: WorkBook | null;
	availableSheetNames: string[];
	previewDiscountRatesTriangle: DiscountRatesTriangleData;
	selectedSheetName: string;
	uploadedFileName: string;
	decimalPlaces: number;
	selectedDiscountRateLine: number | null;
	availableDiscountRateLines: {
		index: number;
		label: string;
		values: (number | null)[];
	}[];

	// Actions
	setDiscountRatesTriangle: (triangle: DiscountRatesTriangleData) => void;
	setWorkbook: (workbook: WorkBook | null) => void;
	setAvailableSheetNames: (names: string[]) => void;
	setPreviewDiscountRatesTriangle: (
		triangle: DiscountRatesTriangleData,
	) => void;
	setSelectedSheetName: (name: string) => void;
	setUploadedFileName: (name: string) => void;
	setDecimalPlaces: (places: number) => void;
	setSelectedDiscountRateLine: (line: number | null) => void;
	updateAvailableDiscountRateLines: () => void;
	resetData: () => void;
}

// Stan początkowy
const initialState = {
	discountRatesTriangle: {},
	workbook: null,
	availableSheetNames: [],
	previewDiscountRatesTriangle: {},
	selectedSheetName: "",
	uploadedFileName: "",
	decimalPlaces: 2,
	selectedDiscountRateLine: null,
	availableDiscountRateLines: [],
};

export const useDiscountRatesStore = create<DiscountRatesStore>()(
	persist(
		(set, get) => ({
			...initialState,

			setDiscountRatesTriangle: (triangle) => {
				set({ discountRatesTriangle: triangle });
				// Automatycznie przygotuj dostępne linie
				get().updateAvailableDiscountRateLines();
			},

			setWorkbook: (workbook) => set({ workbook }),

			setAvailableSheetNames: (names) => set({ availableSheetNames: names }),

			setPreviewDiscountRatesTriangle: (triangle) =>
				set({ previewDiscountRatesTriangle: triangle }),

			setSelectedDiscountRateLine: (line) =>
				set({ selectedDiscountRateLine: line }),

			updateAvailableDiscountRateLines: () => {
				const triangle = get().discountRatesTriangle;
				const lines: {
					index: number;
					label: string;
					values: (number | null)[];
				}[] = [];

				// Iteruj przez wiersze trójkąta
				Object.keys(triangle).forEach((rowIndexStr) => {
					const rowIndex = Number.parseInt(rowIndexStr);
					const row = triangle[rowIndex];
					if (!row) return;

					// Pobierz label z pierwszej kolumny (kolumna 0)
					const labelValue = row[0];
					const label =
						labelValue !== null && labelValue !== undefined
							? String(labelValue)
							: `Wiersz ${rowIndex + 1}`;

					// Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
					const values: (number | null)[] = [];
					const colKeys = Object.keys(row)
						.map(Number)
						.sort((a, b) => a - b);
					for (const colIndex of colKeys) {
						if (colIndex !== 0) {
							// Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
							const cellValue = row[colIndex] ?? null;
							// Konwertuj stringi na liczby, zostaw null jak jest
							if (typeof cellValue === "string") {
								const numValue = Number(cellValue);
								values.push(Number.isFinite(numValue) ? numValue : null);
							} else {
								values.push(cellValue);
							}
						}
					}

					// Dodaj linię tylko jeśli ma jakieś wartości
					if (values.some((v) => v !== null)) {
						lines.push({
							index: rowIndex,
							label,
							values,
						});
					}
				});

				console.log("🔍 updateAvailableDiscountRateLines result:", lines);
				set({ availableDiscountRateLines: lines });
			},

			setSelectedSheetName: (name) => set({ selectedSheetName: name }),
			setUploadedFileName: (name) => set({ uploadedFileName: name }),
			setDecimalPlaces: (places) => set({ decimalPlaces: places }),

			resetData: () => set(initialState),
		}),
		{
			name: "discount-rates-store",
			partialize: (state) => ({
				discountRatesTriangle: state.discountRatesTriangle,
				selectedDiscountRateLine: state.selectedDiscountRateLine,
				availableDiscountRateLines: state.availableDiscountRateLines,
				availableSheetNames: state.availableSheetNames,
				previewDiscountRatesTriangle: state.previewDiscountRatesTriangle,
				selectedSheetName: state.selectedSheetName,
				uploadedFileName: state.uploadedFileName,
				decimalPlaces: state.decimalPlaces,
			}),
			storage: {
				getItem: (name) => {
					const str = sessionStorage.getItem(name);
					if (!str) return null;
					return JSON.parse(str);
				},
				setItem: (name, value) => {
					sessionStorage.setItem(name, JSON.stringify(value));
				},
				removeItem: (name) => sessionStorage.removeItem(name),
			},
		},
	),
);
