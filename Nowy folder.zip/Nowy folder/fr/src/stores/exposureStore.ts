import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { WorkBook } from 'xlsx';

// Typy dla Exposure store
export interface ExposureTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | string | null;
  };
}

export interface ExposureStore {
  // Dane trójkąta ekspozycji
  exposureTriangle: ExposureTriangleData;
  
  // Oryginalne dane exposure (bez inflacji) - używane do obliczeń inflacji
  originalExposureTriangle: ExposureTriangleData;
  
  // Wybór linii ekspozycji
  selectedExposureLine: number | null;
  availableExposureLines: { index: number; label: string; values: (number | null)[] }[];
  
  // Metadane
  workbook: WorkBook | null;
  availableSheetNames: string[];
  previewExposureTriangle: ExposureTriangleData;
  selectedSheetName: string;
  uploadedFileName: string;
  
  // Ustawienia wyświetlania
  decimalPlaces: number;
  
  // Wynik inflacji
  inflationResult: (number | null)[] | null;
  appliedInflationPreview: {
    rowName: string;
    columnLabels: string[];
  } | null;

  // Ustawienie UI: czy nakładać inflację przy akceptacji
  applyInflationOnAccept: boolean;
  
  // Akcje
  setExposureTriangle: (triangle: ExposureTriangleData) => void;
  setOriginalExposureTriangle: (triangle: ExposureTriangleData) => void;
  setWorkbook: (workbook: WorkBook | null) => void;
  setAvailableSheetNames: (names: string[]) => void;
  setPreviewExposureTriangle: (triangle: ExposureTriangleData) => void;
  setInflationResult: (result: (number | null)[] | null) => void;
  setAppliedInflationPreview: (preview: { rowName: string; columnLabels: string[] } | null) => void;
  setApplyInflationOnAccept: (value: boolean) => void;
  setSelectedExposureLine: (lineIndex: number | null) => void;
  updateAvailableExposureLines: () => void;
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  resetData: () => void;
}

const initialState = {
  exposureTriangle: {},
  originalExposureTriangle: {},
  selectedExposureLine: null,
  availableExposureLines: [],
  workbook: null,
  availableSheetNames: [],
  previewExposureTriangle: {},
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
  inflationResult: null,
  appliedInflationPreview: null,
  applyInflationOnAccept: false,
};

export const useExposureStore = create<ExposureStore>()(
  persist(
    (set, get) => ({
  ...initialState,
  
  setExposureTriangle: (triangle) => {
    set({ exposureTriangle: triangle });
    // Automatycznie przygotuj dostępne linie
    get().updateAvailableExposureLines();
  },
  
  setOriginalExposureTriangle: (triangle) => set({ originalExposureTriangle: triangle }),

  setWorkbook: (workbook) => set({ workbook }),

  setAvailableSheetNames: (names) => set({ availableSheetNames: names }),

  setPreviewExposureTriangle: (triangle) => set({ previewExposureTriangle: triangle }),
  
  setSelectedExposureLine: (lineIndex) => set({ selectedExposureLine: lineIndex }),
  
  updateAvailableExposureLines: () => {
    const triangle = get().exposureTriangle;
    const lines: { index: number; label: string; values: (number | null)[] }[] = [];
    
    // Iteruj przez wiersze trójkąta
    Object.keys(triangle).forEach(rowIndexStr => {
      const rowIndex = parseInt(rowIndexStr);
      const row = triangle[rowIndex];
      if (!row) return;
      
      // Pobierz label z pierwszej kolumny (kolumna 0)
      const labelValue = row[0];
      const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
      
      // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
      const values: (number | null)[] = [];
      const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
      for (const colIndex of colKeys) {
        if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
          const cellValue = row[colIndex] ?? null;
          if (typeof cellValue === 'string') {
            const numValue = Number(cellValue);
            values.push(Number.isFinite(numValue) ? numValue : null);
          } else {
            values.push(cellValue);
          }
        }
      }
      
      // Dodaj linię tylko jeśli ma jakieś wartości
      if (values.some(v => v !== null)) {
        lines.push({
          index: rowIndex,
          label,
          values
        });
      }
    });
    
    console.log('🔍 updateAvailableExposureLines result:', lines);
    set({ availableExposureLines: lines });
  },
  
  setSelectedSheetName: (name) => set({ selectedSheetName: name }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
  setDecimalPlaces: (places) => set({ decimalPlaces: places }),
  setInflationResult: (result) => set({ inflationResult: result }),
  setAppliedInflationPreview: (preview) => set({ appliedInflationPreview: preview }),
  setApplyInflationOnAccept: (value) => set({ applyInflationOnAccept: value }),
  
  resetData: () => set(initialState),
    }),
    {
      name: 'exposure-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        exposureTriangle: state.exposureTriangle,
        originalExposureTriangle: state.originalExposureTriangle,
        selectedExposureLine: state.selectedExposureLine,
        availableExposureLines: state.availableExposureLines,
        availableSheetNames: state.availableSheetNames,
        previewExposureTriangle: state.previewExposureTriangle,
        selectedSheetName: state.selectedSheetName,
        uploadedFileName: state.uploadedFileName,
        decimalPlaces: state.decimalPlaces,
        inflationResult: state.inflationResult,
        appliedInflationPreview: state.appliedInflationPreview,
        applyInflationOnAccept: state.applyInflationOnAccept,
      }),
    }
  )
);