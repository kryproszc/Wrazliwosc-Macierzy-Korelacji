import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { SimulationResults } from '@/shared/hooks';

export interface StochasticSimulationParams {
  iloscSymulacji: number;
  ziarno: number;
  podzialZiarna: number;
  skalowanie: number;
  skalowanie2: number;
}

export type StochasticMethodType = 'multiplikatywna' | 'addytywna' | 'mix';

export interface StochasticPaidUserState {
  methodType: StochasticMethodType;
  kChange: string;
  simulationParams: StochasticSimulationParams;
  kwantyle: string;
  statisticsResults: any[];
  simulationResults: SimulationResults | null;
}

export const DEFAULT_STOCHASTIC_PAID_USER_STATE: StochasticPaidUserState = {
  methodType: 'multiplikatywna',
  kChange: '0',
  simulationParams: {
    iloscSymulacji: 1000,
    ziarno: 1111,
    podzialZiarna: 1000,
    skalowanie: 1,
    skalowanie2: 1,
  },
  kwantyle: '0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,0.995',
  statisticsResults: [],
  simulationResults: null,
};

interface StochasticPaidSimulationStore {
  userStates: Record<string, StochasticPaidUserState>;
  ensureUserState: (userId: string) => void;
  resetUserState: (userId: string) => void;
  setMethodType: (userId: string, methodType: StochasticMethodType) => void;
  setKChange: (userId: string, value: string) => void;
  updateSimulationParam: (userId: string, key: keyof StochasticSimulationParams, value: number) => void;
  setKwantyle: (userId: string, value: string) => void;
  setStatisticsResults: (userId: string, results: any[]) => void;
  setSimulationResults: (userId: string, results: SimulationResults | null) => void;
  clearResults: (userId: string) => void;
}

const getUserState = (
  state: Record<string, StochasticPaidUserState>,
  userId: string,
): StochasticPaidUserState => state[userId] ?? DEFAULT_STOCHASTIC_PAID_USER_STATE;

export const useStochasticPaidSimulationStore = create<StochasticPaidSimulationStore>()(
  persist(
    (set, get) => ({
      userStates: {},

      ensureUserState: (userId) => {
        if (!userId) return;
        const current = get().userStates[userId];
        if (current) return;

        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: { ...DEFAULT_STOCHASTIC_PAID_USER_STATE },
          },
        }));
      },

      resetUserState: (userId) => {
        if (!userId) return;
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: { ...DEFAULT_STOCHASTIC_PAID_USER_STATE },
          },
        }));
      },

      setKChange: (userId, value) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              kChange: value,
            },
          },
        }));
      },

      setMethodType: (userId, methodType) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              methodType,
            },
          },
        }));
      },

      updateSimulationParam: (userId, key, value) => {
        set((state) => {
          const current = getUserState(state.userStates, userId);
          return {
            userStates: {
              ...state.userStates,
              [userId]: {
                ...current,
                simulationParams: {
                  ...current.simulationParams,
                  [key]: value,
                },
              },
            },
          };
        });
      },

      setKwantyle: (userId, value) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              kwantyle: value,
            },
          },
        }));
      },

      setStatisticsResults: (userId, results) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              statisticsResults: results,
            },
          },
        }));
      },

      setSimulationResults: (userId, results) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              simulationResults: results,
            },
          },
        }));
      },

      clearResults: (userId) => {
        set((state) => ({
          userStates: {
            ...state.userStates,
            [userId]: {
              ...getUserState(state.userStates, userId),
              simulationResults: null,
              statisticsResults: [],
            },
          },
        }));
      },
    }),
    {
      name: 'stochastic-paid-simulation-store',
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    },
  ),
);
