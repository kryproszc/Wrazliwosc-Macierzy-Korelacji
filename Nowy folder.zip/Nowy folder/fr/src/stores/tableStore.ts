
import { create } from "zustand";
import * as XLSX from "xlsx";
import type { RowData } from "@/types/table";
import { parseRange, toExcelRange } from "../utils/parseTableRange";
import type { DataType } from '@/components/DataTypeSelector';
import type { TriangleType } from '@/components/TriangleTypeSelector';

type TableStore = {
  table?: File;
  isHydrated: boolean;
  workbook?: XLSX.WorkBook;
  selectedSheet?: XLSX.WorkSheet;
  selectedSheetJSON?: RowData[];
  selectedCells?: number[][];
  selectedSheetName?: string | undefined;
  isValid?: boolean;
  validationErrorReason?: string;

  previousSheetJSON?: RowData[]; // 🆕 nowość: trzymanie starego JSONa
  setPreviousSheetJSON: (data: RowData[]) => void; // 🆕 setter do starego JSONa

  sheetRange?: string;
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;
  activeStochTriangle: 'paid' | 'incurred';
  setActiveStochTriangle: (v: 'paid' | 'incurred') => void;
  // 🆕 Ustawienia typu danych - osobne dla każdej zakładki
  triangleType: TriangleType;
  setTriangleType: (type: TriangleType) => void;
  dataType: DataType;
  setDataType: (type: DataType) => void;

  // 🆕 Ustawienie czy dane zawierają podpisy kolumn i wierszy
  hasHeaders: boolean;
  setHasHeaders: (hasHeaders: boolean) => void;

  
  uploadedFileName?: string;

  processedData?: RowData[];
  setProcessedData: (data: RowData[]) => void;

  
  processedTriangle?: RowData[];
  setProcessedTriangle: (data: RowData[]) => void;

  clData?: RowData[];
  setClData: (data: RowData[]) => void;

  clWeights?: RowData[];
  setClWeights: (weights: RowData[]) => void;

  setStartRow: (startRow: number) => void;
  setEndRow: (endRow: number) => void;
  setStartCol: (startCol: number) => void;
  setEndCol: (endCol: number) => void;
  setRangeAndUpdate: (range: { startRow: number; endRow: number; startCol: number; endCol: number }) => void;
  getDefaultRange: () => { startRow: number; startCol: number; endRow: number; endCol: number } | undefined;

  setIsHydrated: (isHydrated: boolean) => void;
  setWorkbook: (workbook?: XLSX.WorkBook) => void;
  setSelectedSheetName: (selectedSheetName: string | undefined) => void;
  updateSheetJSON: () => void;
  resetData: () => void;

  getSheetNames: () => string[] | undefined;
  setSelectedCells: (selectedCells: number[][]) => void;

  setUploadedFileName: (fileName: string) => void;
  
};

function customValidate(jsonData: any[][]) {
  if (!Array.isArray(jsonData) || jsonData.length < 2) {
    return {
      isValid: false,
      reason: "Brak danych lub dane mają niepoprawny format."
    };
  }

  const firstRow = jsonData[0];
  if (!Array.isArray(firstRow) || firstRow.length < 2) {
    return {
      isValid: false,
      reason: "Pierwszy wiersz nie ma wystarczającej liczby kolumn."
    };
  }

  for (let i = 1; i < firstRow.length; i++) {
    const val = firstRow[i];
    if (val === undefined || val === null) {
      return {
        isValid: false,
        reason: `Pierwszy wiersz: Kolumna ${i + 1} nie ma wartości.`
      };
    }
  }

  // Sprawdzamy kolejne wiersze
  for (let rowIdx = 1; rowIdx < jsonData.length; rowIdx++) {
    const row = jsonData[rowIdx];

    if (!row) {
      return {
        isValid: false,
        reason: `Rząd ${rowIdx + 1}: Brak danych w tym wierszu.`
      };
    }

    if (typeof row[0] !== 'number') {
      return {
        isValid: false,
        reason: `Rząd ${rowIdx + 1}: Pierwsza kolumna nie jest rokiem (liczbą).`
      };
    }

    let emptyCount = 0;
    for (let colIdx = row.length - 1; colIdx >= 1; colIdx--) {
      if (row[colIdx] === "") {
        emptyCount++;
      } else {
        break;
      }
    }

    const expectedEmpty = rowIdx - 1;

    if (emptyCount !== expectedEmpty) {
      return {
        isValid: false,
        reason: `Rząd ${rowIdx + 1}: Oczekiwano ${expectedEmpty} pustych wartości na końcu, znaleziono ${emptyCount}.`
      };
    }
  }

  return {
    isValid: true
  };
}

export const useTableStore = create<TableStore>((set, get) => ({
  
  table: undefined,
  isHydrated: false,

  startRow: 1,
  endRow: 1,
  startCol: 1,
  endCol: 1,

  uploadedFileName: undefined,

  // 🆕 Ustawienia typu danych - domyślne dla zakładki stochastic
  triangleType: 'paid',
  setTriangleType: (type) => set({ triangleType: type }),
  dataType: 'cumulative',
  setDataType: (type) => set({ dataType: type }),

  // 🆕 Ustawienie czy dane zawierają podpisy - domyślnie TRUE (jak teraz)
  hasHeaders: true,
  setHasHeaders: (hasHeaders) => set({ hasHeaders }),

  processedData: undefined,
  setProcessedData: (data) => set({ processedData: data }),

  previousSheetJSON: undefined, // 🆕 dodane
  setPreviousSheetJSON: (data) => set({ previousSheetJSON: data }), // 🆕 dodane

  processedTriangle: undefined,
  setProcessedTriangle: (data) => set({ processedTriangle: data }),

  clData: undefined,
  setClData: (data) => set({ clData: data }),

  clWeights: undefined,
  setClWeights: (weights) => set({ clWeights: weights }),

    activeStochTriangle: 'paid',
    setActiveStochTriangle: (v) => set({ activeStochTriangle: v }),
  setStartRow: (startRow) => set({ startRow }),
  setEndRow: (endRow) => set({ endRow }),
  setStartCol: (startCol) => set({ startCol }),
  setEndCol: (endCol) => set({ endCol }),

  setRangeAndUpdate: (range) => {
    set({
      startRow: range.startRow,
      endRow: range.endRow,
      startCol: range.startCol,
      endCol: range.endCol,
    });
    get().updateSheetJSON();
  },

  getDefaultRange: () => {
    const defaultRef = get().sheetRange;
    if (!defaultRef) return;
    return parseRange(defaultRef);
  },

  setIsHydrated: (isHydrated) => set({ isHydrated }),

  setWorkbook: (workbook) => {
    const selected = workbook?.SheetNames[0];
    const sheet = selected ? workbook?.Sheets[selected] : undefined;

    set({
      workbook,
      selectedSheetName: selected,
      sheetRange: sheet ? sheet["!ref"] : undefined,
    });
  },

  setSelectedSheetName: (sheetName) => {
    // Reset tylko danych z tego store'a (nie wszystkich store'ów)
    get().resetData();

    if (!sheetName) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    const sheet = get().workbook?.Sheets[sheetName];
    if (!sheet || !sheet["!ref"]) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    set({
      selectedSheetName: sheetName,
      selectedSheet: sheet,
      sheetRange: sheet["!ref"],
    });
  },

  updateSheetJSON: () => {
    const sheetName = get().selectedSheetName;
    if (!sheetName) return;

    const sheet = get().workbook?.Sheets[sheetName];
    if (!sheet) return;

    const range = toExcelRange({
      startRow: get().startRow,
      endRow: get().endRow,
      startCol: get().startCol,
      endCol: get().endCol,
    });

    const tempSheet = { ...sheet, ["!ref"]: range };

    const jsonData = XLSX.utils.sheet_to_json<RowData>(tempSheet, {
      header: 1,
      blankrows: true,
      defval: "",
    });
    console.log("JSON Data:", JSON.stringify(jsonData, null, 2));

    const validation = customValidate(jsonData);

    if (!validation.isValid) {
      set({
        isValid: false,
        validationErrorReason: "Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const selectedCells = jsonData.map((row) =>
      row.map((cell) => {
        const numeric = typeof cell === "number" ? cell : Number(cell);
        return !isNaN(numeric) ? 1 : 0;
      })
    );

    set({
      previousSheetJSON: get().selectedSheetJSON, // 🆕 zapamiętujemy stare przed nadpisaniem
      selectedSheetJSON: jsonData,
      selectedCells,
      isValid: true,
      validationErrorReason: undefined,
    });
  },

  resetData: () =>
    set({
      selectedSheetJSON: undefined,
      selectedCells: undefined,
      isValid: undefined,
      validationErrorReason: undefined,
      processedData: undefined,
      processedTriangle: undefined,
      clData: undefined,
      clWeights: undefined,
      // Zachowujemy ustawienia typu danych przy resetowaniu
      // triangleType i dataType nie są resetowane
    }),

  getSheetNames: () => get().workbook?.SheetNames,
  setSelectedCells: (selectedCells) => set({ selectedCells }),

  setUploadedFileName: (fileName) => set({ uploadedFileName: fileName }),
}));
